﻿
// Uses canonical toSafeLabString and getFirstDefinedLabValue from js/data.js

/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - UNIFIED STAFF ONBOARDING & DATA ENTRY PORTAL
   Full Edit & Print Functionality + 100% Dynamic Bilingual Support
   ========================================================================== */

let currentEditingEmpNo = null;

// Uses master getUniqueEmployees() and window.invalidateEmployeesCache() from js/data.js

function handleResultDropdownOther(selectEl, customInputId) {
  const customInput = document.getElementById(customInputId);
  if (customInput) {
    if (selectEl.value === 'Other') {
      customInput.style.display = 'block';
      customInput.focus();
    } else {
      customInput.style.display = 'none';
      customInput.value = '';
    }
  }
  const val = getSelectOrCustomVal(selectEl.id, customInputId);
  if (!val || val.trim() === '') {
    const dateInputId = selectEl.id + 'Date';
    let dateEl = document.getElementById(dateInputId);
    if (!dateEl) {
      const tr = selectEl.closest('tr');
      if (tr) {
        dateEl = tr.querySelector('input[type="date"], input[class*="date"], input[id*="Date"], input[id*="date"]');
      }
    }
    if (dateEl) {
      dateEl.value = '';
    }
  }
}
window.handleResultDropdownOther = handleResultDropdownOther;

document.addEventListener('change', function(e) {
  const target = e.target;
  if (!target) return;
  if (target.tagName === 'SELECT' || (target.tagName === 'INPUT' && target.type === 'text')) {
    const val = target.value ? target.value.trim() : '';
    const isBlank = !val || val.startsWith('-- Select');
    if (isBlank) {
      let dateEl = null;
      if (target.id) {
        dateEl = document.getElementById(target.id + 'Date');
        if (!dateEl && target.id.endsWith('_custom')) {
          const baseId = target.id.replace('_custom', '');
          dateEl = document.getElementById(baseId + 'Date');
        }
      }
      if (!dateEl) {
        const tr = target.closest('tr');
        if (tr) {
          dateEl = tr.querySelector('input[type="date"], input[class*="date"], input[id*="Date"], input[id*="date"]');
        }
      }
      if (dateEl && dateEl !== target) {
        dateEl.value = '';
      }
    }
  }
});

document.addEventListener('input', function(e) {
  const target = e.target;
  if (!target) return;
  if (target.tagName === 'INPUT' && target.type === 'text') {
    const val = target.value ? target.value.trim() : '';
    if (!val) {
      let dateEl = null;
      if (target.id) {
        dateEl = document.getElementById(target.id + 'Date');
        if (!dateEl && target.id.endsWith('_custom')) {
          const baseId = target.id.replace('_custom', '');
          dateEl = document.getElementById(baseId + 'Date');
        }
      }
      if (!dateEl) {
        const tr = target.closest('tr');
        if (tr) {
          dateEl = tr.querySelector('input[type="date"], input[class*="date"], input[id*="Date"], input[id*="date"]');
        }
      }
      if (dateEl && dateEl !== target) {
        dateEl.value = '';
      }
    }
  }
});

function getSelectOrCustomVal(selectId, customInputId) {
  const sel = document.getElementById(selectId);
  const custom = document.getElementById(customInputId);
  if (!sel) return '';
  if (sel.value === 'Other') {
    return custom ? custom.value.trim() : 'Other';
  }
  return sel.value ? sel.value.trim() : '';
}
window.getSelectOrCustomVal = getSelectOrCustomVal;

function normalizeEmploymentStatus(val) {
  const s = String(val || '').trim().toLowerCase();
  if (s.includes('leave') || s.includes('إجازة')) return 'On Leave';
  if (s.includes('transf') || s.includes('منقول')) return 'Transferred';
  if (s.includes('resign') || s.includes('استقال') || s.includes('مستقيل')) return 'Resigned';
  if (s.includes('retir') || s.includes('تقاعد') || s.includes('متقاعد')) return 'Retired';
  if (s.includes('decea') || s.includes('متوف')) return 'Deceased';
  if (s.includes('terminat') || s.includes('إنهاء')) return 'Terminated';
  if (s.includes('contract') || s.includes('عقد')) return 'Contract Finished';
  if (s.includes('discharg') || s.includes('تسريح') || s.includes('إخلاء') || s.includes('مغادر')) return 'Discharged';
  return 'Active Staff';
}
window.normalizeEmploymentStatus = normalizeEmploymentStatus;

function handleEmploymentStatusChange(statusVal, empObj = null) {
  const norm = normalizeEmploymentStatus(statusVal);
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const isAct = (norm === 'Active Staff');
  
  const banner = document.getElementById('active_employee_summary_banner');
  const summaryStatus = document.getElementById('summary_emp_status');
  const hintEl = document.getElementById('sec1_employmentStatus_hint');

  if (hintEl) {
    if (isAct) {
      hintEl.style.color = '#047857';
      hintEl.innerHTML = `🟢 ${isAr ? 'سيبقى الموظف في القائمة الرئيسية النشطة وكافة الإحصائيات' : 'Kept in Active Master List & Live Statistics'}`;
    } else {
      hintEl.style.color = '#B45309';
      hintEl.innerHTML = `📁 ${isAr ? `سينتقل الموظف إلى قائمة الكادر المؤرشف / السابق (${norm}) ويُستثنى من الإحصائيات النشطة` : `Will move to Archived / Former Staff (${norm}) & excluded from active statistics`}`;
    }
  }

  if (summaryStatus) {
    if (isAct) {
      summaryStatus.className = 'role-pill role-specialist';
      summaryStatus.style.background = '#ECFDF5';
      summaryStatus.style.color = '#065F46';
      summaryStatus.style.border = '1px solid #10B981';
      summaryStatus.innerHTML = `🟢 ${isAr ? 'كادر نشط على رأس عمله - مشمول في القائمة الرئيسية والإحصائيات' : 'Active Staff - In Master List & Statistics'}`;
    } else {
      summaryStatus.className = 'role-pill';
      summaryStatus.style.background = '#FEF3C7';
      summaryStatus.style.color = '#92400E';
      summaryStatus.style.border = '1px solid #F59E0B';
      summaryStatus.innerHTML = `📁 ${isAr ? `كادر مؤرشف / سابق (${norm}) - في الأرشيف فقط` : `Archived / Former Staff (${norm}) - In Archive Only`}`;
    }
  }

  if (banner) {
    if (isAct) {
      banner.style.background = 'linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%)';
      banner.style.borderColor = '#10B981';
    } else {
      banner.style.background = 'linear-gradient(135deg, #FFFBEB 0%, #FEF3C7 100%)';
      banner.style.borderColor = '#F59E0B';
    }
  }
}
window.handleEmploymentStatusChange = handleEmploymentStatusChange;

function buildStaffQuickSelectOptionsHtml(employees, isAr, selectedEmpNo = null) {
  const activeStaff = [];
  const archivedStaff = [];
  (employees || []).forEach(e => {
    if (!e) return;
    if (typeof isActiveStaff === 'function' ? isActiveStaff(e) : true) {
      activeStaff.push(e);
    } else {
      archivedStaff.push(e);
    }
  });

  let html = `<option value="">-- 👤 ${isAr ? 'اختر موظفاً لفتح كافة بياناته' : 'Select Employee from List'} --</option>`;
  
  if (activeStaff.length > 0) {
    html += `<optgroup label="🟢 ${isAr ? 'الكادر النشط على رأس عمله' : 'Active Staff'} (${activeStaff.length})">`;
    activeStaff.forEach(e => {
      const eNo = e.empNo || e.id || '';
      const isSel = selectedEmpNo && String(selectedEmpNo) === String(eNo);
      html += `<option value="${eNo}" ${isSel ? 'selected' : ''}>${e.name} (${eNo}) - ${e.department || 'Staff'}</option>`;
    });
    html += `</optgroup>`;
  }

  if (archivedStaff.length > 0) {
    html += `<optgroup label="📁 ${isAr ? 'الكادر المؤرشف / السابق' : 'Archived / Former Staff'} (${archivedStaff.length})">`;
    archivedStaff.forEach(e => {
      const eNo = e.empNo || e.id || '';
      const st = e.employmentStatus || (e.demographic ? e.demographic.employmentStatus : '') || (isAr ? 'مؤرشف' : 'Archived');
      const isSel = selectedEmpNo && String(selectedEmpNo) === String(eNo);
      html += `<option value="${eNo}" ${isSel ? 'selected' : ''}>${e.name} (${eNo}) [📁 ${st}] - ${e.department || 'Staff'}</option>`;
    });
    html += `</optgroup>`;
  }

  return html;
}
window.buildStaffQuickSelectOptionsHtml = buildStaffQuickSelectOptionsHtml;

function renderStaffEntryForm(container) {
  const employees = getUniqueEmployees();
  const t = key => (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t(key) : key);
  const isAr = (window.i18n && typeof window.i18n.isRTL === 'function') ? window.i18n.isRTL() : false;
  let selEmp = typeof window.getGlobalSelectedStaff === 'function' ? window.getGlobalSelectedStaff() : null;
  const selEmpKey = selEmp ? (selEmp.empNo || selEmp.id || (selEmp.demographic && selEmp.demographic.personNumber)) : null;
  const selEmpName = selEmp ? (selEmp.name || (selEmp.demographic && selEmp.demographic.fullName) || '') : '';
  const selEmpIdNo = selEmp ? (selEmp.idNo || (selEmp.demographic && selEmp.demographic.nationalId) || '') : '';
  const selEmpSearchVal = selEmpName ? (selEmpName + (selEmpIdNo ? ' (ID: ' + selEmpIdNo + ')' : '')) : '';

  container.innerHTML = `
    <!-- MAIN SCREEN HEADER BANNER -->
    <div style="background: linear-gradient(135deg, #113F52 0%, #1A5F7A 100%); color: white; padding: 22px 28px; border-radius: 12px; margin-bottom: 24px; box-shadow: 0 4px 15px rgba(0,0,0,0.12); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
      <div>
        <h2 style="font-size: 1.5rem; font-weight: 800; margin: 0;">🏥 ${t('portal_header_title')}</h2>
      </div>
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <button class="btn btn-success" onclick="resetFormForNewStaff(true)">${t('btn_introduce_new')}</button>
      </div>
    </div>

    <!-- LIVE SEARCH BAR & RECORD CONTROLS -->
    <div class="card" style="border-left: 4px solid var(--accent-teal); margin-bottom: 24px; padding: 18px 22px; background: #FAFDFD;">
      <div style="display: flex; gap: 14px; align-items: flex-end; flex-wrap: wrap;">
        <div style="flex: 2; min-width: 280px; position: relative;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            🔍 ${isAr ? 'البحث السريع عن موظف (الاسم / الهوية / الرقم الوظيفي):' : 'Quick Search Staff (Name, ID, or Emp No):'}
          </label>
          <div class="search-flex-group" style="display: flex; gap: 8px;">
            <input type="text" id="staff_search_input" value="${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(selEmpSearchVal) : selEmpSearchVal}" placeholder="${isAr ? 'اكتب اسم الموظف أو الهوية أو الرقم الوظيفي...' : 'Type Name, ID, or Emp No...'}" onfocus="handleStaffSearchInput(this.value)" oninput="handleStaffSearchInput(this.value)" onkeydown="handleStaffSearchKeyDown(event)" style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.95rem; font-weight: 600; background: white;">
            <button type="button" class="btn btn-outline" style="padding: 8px 14px; font-weight: bold; background: white; white-space: nowrap; border-color: #94A3B8; color: #475569;" onclick="resetFormForNewStaff(false)">
              🧹 ${isAr ? 'تفرغ الشاشة' : 'Clear Form'}
            </button>
          </div>
          <div id="staff_search_results" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1.5px solid var(--accent-teal); border-radius: 6px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); z-index: 100; max-height: 280px; overflow-y: auto;"></div>
        </div>

        <div style="flex: 1.5; min-width: 240px;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            👤 ${isAr ? 'أو اختر موظفاً من القائمة مباشرة:' : 'Or Select Employee from List:'}
          </label>
          <select id="staff_quick_select" style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.92rem; font-weight: 600; background: white;" onchange="selectStaffFromDropdown(this.value)">
            ${typeof buildStaffQuickSelectOptionsHtml === 'function' ? buildStaffQuickSelectOptionsHtml(employees, isAr, selEmpKey) : buildStaffQuickSelectOptionsHtml(employees, isAr)}
          </select>
        </div>
      </div>
    </div>

    <!-- UNIFIED 7-SECTION ENTRY FORM -->
    <form id="unifiedStaffForm" onsubmit="handleSaveUnifiedStaffForm(event)">
      <!-- ACTIVE SELECTED EMPLOYEE SUMMARY CARD -->
      <div id="active_employee_summary_banner" style="display: flex; justify-content: space-between; align-items: center; background: linear-gradient(135deg, #ECFDF5 0%, #D1FAE5 100%); border: 2px solid #10B981; padding: 14px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.15); flex-wrap: wrap; gap: 12px;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="font-size: 2.2rem;">👤</div>
          <div>
            <div style="font-size: 1.15rem; font-weight: 800; color: #065F46;" id="summary_emp_name">--</div>
            <div style="font-size: 0.88rem; color: #047857;" id="summary_emp_details">
              ${isAr ? 'اختر أو ابحث عن موظف لعرض كامل بياناته في كافة الأقسام الـ 7' : 'Select or search an employee to explore all saved data across all 7 sections'}
            </div>
          </div>
        </div>
        <div style="display: flex; gap: 8px;">
          <span class="role-pill role-specialist" style="padding: 6px 14px; font-size: 0.85rem;" id="summary_emp_status">
            🟢 ${isAr ? 'معلومات الموظف المختار معروضة ومحملة بالكامل' : 'Selected Employee Data Loaded'}
          </span>
        </div>
      </div>

      <!-- QUICK SECTION EDIT JUMP TOOLBAR -->
      <div style="background: #F1F5F9; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; border: 1px solid var(--border-color); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
        <div style="font-weight: 700; font-size: 0.88rem; color: var(--primary-blue); display: flex; align-items: center; gap: 6px;">
          <span>✏️ ${isAr ? 'تعديل مباشر لجميع الأقسام الـ 7:' : 'Direct Edit Navigation for All 7 Sections:'}</span>
        </div>
        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem; background: white;" onclick="focusAndEditSection('sec1_nationalId', 'section_card_1')">✏️ ${isAr ? 'قسم 1' : 'Sec 1'}</button>
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem; background: white;" onclick="focusAndEditSection('sec2_pregnancyStatus', 'section_card_2')">✏️ ${isAr ? 'قسم 2' : 'Sec 2'}</button>
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem; background: white;" onclick="focusAndEditSection('sec3_hbsabResult', 'section_card_3')">✏️ ${isAr ? 'قسم 3' : 'Sec 3'}</button>
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem; background: white;" onclick="focusAndEditSection('sec4_ipvDate', 'section_card_4')">✏️ ${isAr ? 'قسم 4' : 'Sec 4'}</button>
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem; background: white;" onclick="focusAndEditSection('sec5_meningococcal', 'section_card_5')">✏️ ${isAr ? 'قسم 5' : 'Sec 5'}</button>
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem; background: white;" onclick="focusAndEditSection('sec6_fluDate', 'section_card_6')">✏️ ${isAr ? 'قسم 6' : 'Sec 6'}</button>
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem; background: white;" onclick="focusAndEditSection('sec7_pepStatus', 'section_card_7')">✏️ ${isAr ? 'قسم 7' : 'Sec 7'}</button>
        </div>
      </div>

      <!-- SECTION 1: EMPLOYEE DEMOGRAPHIC -->
      <div class="card" id="section_card_1" style="margin-bottom: 24px; border-top: 4px solid var(--primary-blue); transition: all 0.3s ease;">
        <div class="card-title" style="color: var(--primary-blue); font-size: 1.15rem;">
          <span>${t('sec1_title')}</span>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin-top: 14px;">
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'رقم الهوية:' : 'National Identifier:'}</label>
            <input type="text" id="sec1_nationalId" required placeholder="${isAr ? 'مثال: 902148591' : 'e.g. 902148591'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الرقم الوظيفي:' : 'Person Number / Emp No:'}</label>
            <input type="text" id="sec1_personNumber" required placeholder="${isAr ? 'مثال: EMP-2041' : 'e.g. EMP-2041'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; font-weight: bold;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الاسم الكامل بالإنجليزية:' : 'Full Name (English):'}</label>
            <input type="text" id="sec1_fullName" required placeholder="${isAr ? 'مثال: Yousef Khoury' : 'e.g. Yousef Khoury'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الاسم الكامل بالعربية:' : 'Arabic Full Name:'}</label>
            <input type="text" id="sec1_arabicFullName" placeholder="${isAr ? 'مثال: يوسف خوري' : 'e.g. يوسف خوري'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; direction: rtl;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'تاريخ الميلاد:' : 'Date Of Birth:'}</label>
            <input type="date" id="sec1_dob" onchange="calculateAgeFromDOB(this.value)" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'العمر:' : 'Age:'}</label>
            <input type="text" id="sec1_age" placeholder="${isAr ? 'محسوب تلقائياً' : 'Auto-calculated'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; background: #F8FAFC;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الجنس:' : 'Gender:'}</label>
            <select id="sec1_gender" onchange="togglePregnancyVisibility(this.value)" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; font-weight: bold;">
              <option value="Male">${isAr ? 'ذكر (Male)' : 'Male'}</option>
              <option value="Female">${isAr ? 'أنثى (Female)' : 'Female'}</option>
            </select>
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'نوع الهوية:' : 'National Identifier Type:'}</label>
            <select id="sec1_idType" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
              <option value="Palestinian ID">${isAr ? 'هوية فلسطينية' : 'Palestinian ID'}</option>
              <option value="Jerusalem ID">${isAr ? 'هوية مقدسية' : 'Jerusalem ID'}</option>
              <option value="Passport">${isAr ? 'جواز سفر' : 'Passport'}</option>
            </select>
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'اسم المؤسسة:' : 'Organization Name:'}</label>
            <input type="text" id="sec1_orgName" value="${isAr ? 'مستشفى الأوغستا فكتوريا' : 'Augusta Victoria Hospital'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'المسمى الوظيفي بالإنجليزية:' : 'Position Name:'}</label>
            <input type="text" id="sec1_positionName" placeholder="${isAr ? 'مثال: Staff Registered Nurse' : 'e.g. Staff Registered Nurse'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'المسمى الوظيفي بالعربية:' : 'Position Arabic:'}</label>
            <input type="text" id="sec1_positionArabic" placeholder="${isAr ? 'مثال: ممرض قانوني' : 'e.g. ممرض قانوني'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; direction: rtl;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'تاريخ سريان التكليف:' : 'Assignment Effective Date:'}</label>
            <input type="date" id="sec1_assignmentEffectiveDate" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الفئة الوظيفية:' : 'Staff Group:'}</label>
            <select id="sec1_staffGroup" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; font-weight: bold;">
              <option value="Basic Plan">${isAr ? 'Basic Plan (الخطة الأساسية)' : 'Basic Plan'}</option>
              <option value="Extended Program">${isAr ? 'Extended Program (البرنامج الممتد)' : 'Extended Program'}</option>
              <option value="Minimum Plan">${isAr ? 'Minimum Plan (الخطة الأدنى)' : 'Minimum Plan'}</option>
            </select>
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الفئات والوحدات الطبية المعالجة:' : 'Departments/Units/Clinics Treating:'}</label>
            <select id="sec1_deptTreating" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; font-weight: bold;">
              <option value="">-- ${isAr ? 'بدون تصنيف خاص (الكادر العام)' : 'None / General Staff'} --</option>
              <option value="babies under 1 years">${isAr ? 'الأطفال والرضع (<1 سنة) (babies under 1 years)' : 'babies under 1 years'}</option>
              <option value="Employees in oncology, hematooncology">${isAr ? 'كادر الأورام وأورام الدم (Employees in oncology, hematooncology)' : 'Employees in oncology, hematooncology'}</option>
            </select>
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الإجراءات التداخلية (Invasive procedure):' : 'Invasive procedure:'}</label>
            <select id="sec1_invasiveProcedure" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; font-weight: bold;">
              <option value="No">${isAr ? 'لا (No)' : 'No'}</option>
              <option value="Yes">${isAr ? 'نعم (Yes)' : 'Yes'}</option>
            </select>
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.82rem; color: var(--primary-blue);">${isAr ? 'حالة العمل والتوظيف (Employment Status):' : 'Employment Status:'}</label>
            <select id="sec1_employmentStatus" onchange="handleEmploymentStatusChange(this.value)" style="width: 100%; padding: 8px 10px; border: 2px solid #0284C7; border-radius: 4px; font-weight: bold; background: #F0F9FF;">
              <option value="Active Staff">🟢 ${isAr ? 'على رأس عمله (Active Staff)' : 'Active Staff'}</option>
              <option value="On Leave">🟡 ${isAr ? 'إجازة (On Leave – maternity, unpaid, long-term)' : 'On Leave – maternity, unpaid leave, long-term leave'}</option>
              <option value="Transferred">🔵 ${isAr ? 'منقول لقسم/مرفق آخر (Transferred)' : 'Transferred – moved to another department/facility'}</option>
              <option value="Resigned">🟠 ${isAr ? 'مستقيل (Resigned)' : 'Resigned'}</option>
              <option value="Retired">🟣 ${isAr ? 'متقاعد (Retired)' : 'Retired'}</option>
              <option value="Deceased">⚫ ${isAr ? 'متوفى (Deceased)' : 'Deceased'}</option>
              <option value="Terminated">🔴 ${isAr ? 'إنهاء خدمات من المؤسسة (Terminated)' : 'Terminated – employment ended by institution'}</option>
              <option value="Contract Finished">🟤 ${isAr ? 'انتهاء عقد (Contract Finished)' : 'Contract Finished'}</option>
              <option value="Discharged">⚪ ${isAr ? 'منتهي الخدمة / مغادر (Discharged)' : 'Discharged'}</option>
            </select>
            <div id="sec1_employmentStatus_hint" style="margin-top: 5px; font-size: 0.76rem; font-weight: 700; color: #047857;">
              🟢 ${isAr ? 'سيبقى الموظف في القائمة الرئيسية النشطة وكافة الإحصائيات' : 'Kept in Active Master List & Statistics'}
            </div>
          </div>
        </div>

        <div style="margin-top: 18px; padding-top: 12px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap;">
          <button type="button" class="btn btn-success" style="padding: 6px 18px; font-weight: bold; font-size: 0.85rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);" onclick="saveAndAutoFillStaffForm(event, 'update')">💾 ${isAr ? 'حفظ وتحديث حالة التوظيف الآن' : 'Save & Sync Employment Status Now'}</button>
          <button type="button" class="btn btn-outline" style="padding: 5px 14px; font-weight: bold; font-size: 0.82rem; border-radius: 6px; color: var(--primary-blue); border-color: var(--primary-blue);" onclick="focusAndEditSection('sec1_nationalId', 'section_card_1')">✏️ ${isAr ? 'تعديل هذا القسم' : 'Edit Section'}</button>
        </div>
      </div>

      <!-- SECTION 2: HEALTH STATUS & PRE-VACCINATION CHECKLIST -->
      <div class="card" id="section_card_2" style="margin-bottom: 24px; border-top: 4px solid #D69E2E; transition: all 0.3s ease;">
        <div class="card-title" style="color: #D69E2E; font-size: 1.15rem;">
          <span>${t('sec2_title')}</span>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-top: 14px; margin-bottom: 16px;">
          <div id="sec2_pregnancy_container">
            <label style="font-weight: bold; font-size: 0.85rem;">
              ${isAr ? 'حالة الحمل (للإناث):' : 'Pregnancy Status (For Females):'}
              <span id="sec2_pregnancy_badge" style="font-weight: normal; font-size: 0.78rem;"></span>
            </label>
            <select id="sec2_pregnancyStatus" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
              <option value="Not Pregnant / N/A">${isAr ? 'غير حامل / لا ينطبق' : 'Not Pregnant / N/A'}</option>
              <option value="Pregnant (1st Trimester)">${isAr ? 'حامل (الثلث الأول)' : 'Pregnant (1st Trimester)'}</option>
              <option value="Pregnant (2nd/3rd Trimester)">${isAr ? 'حامل (الثلث الثاني أو الثالث)' : 'Pregnant (2nd/3rd Trimester)'}</option>
              <option value="Planning Pregnancy">${isAr ? 'تخطيط للحمل' : 'Planning Pregnancy'}</option>
            </select>
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.85rem;">${isAr ? 'تفاصيل الحساسية (أدوية/أطعمة):' : 'Allergies Details:'}</label>
            <input type="text" id="sec2_allergies" placeholder="${isAr ? 'اكتب تفاصيل الحساسية هنا (أو اترك فارغاً)...' : 'Type allergy details here (or leave blank)...'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
          </div>
        </div>

        <!-- FULL-WIDTH LANDSCAPE PRE-VACCINATION CHECKLIST 11-QUESTION TABLE -->
        <h4 style="color: var(--primary-blue); margin-top: 18px; margin-bottom: 10px; font-size: 0.95rem; font-weight: bold; border-top: 1px solid var(--border-color); padding-top: 14px;">
          📋 ${isAr ? 'قائمة الفحص والتقييم قبل التطعيم (Pre-Vaccination Check List - 11 أسئلة طبية):' : 'Pre-Vaccination Check List (11 Clinical Screening Questions):'}
        </h4>
        <div class="table-responsive" style="width: 100%; margin-top: 8px;">
          <table class="clinical-table" style="width: 100%; background: white; border: 1px solid var(--border-color);">
            <thead>
              <tr style="background: var(--primary-light); color: var(--primary-dark);">
                <th style="font-weight: bold; padding: 10px 14px; text-align: left;">${isAr ? 'السؤال / التقييم الطبي' : 'Clinical Screening Question'}</th>
                <th style="width: 85px; text-align: center; font-weight: bold; padding: 10px;">Yes / نعم</th>
                <th style="width: 85px; text-align: center; font-weight: bold; padding: 10px;">No / لا</th>
                <th style="width: 110px; text-align: center; font-weight: bold; padding: 10px;">N/A / غير ينطبق</th>
              </tr>
            </thead>
            <tbody>
              ${[
                { id: "q1", en: "Did you receive Vaccination during adult Hood? (Tdap, MMR, IPV, other )", ar: "هل تلقيت أي تطعيمات أثناء مرحلة البلوغ؟ (Tdap, MMR, IPV, غيرها)" },
                { id: "q2", en: "Do you have a document for vaccination during adult hood?", ar: "هل لديك وثيقة تثبت التطعيمات خلال مرحلة البلوغ؟" },
                { id: "q3", en: "Positive pregnancy test for married females (qualitative test)", ar: "فحص حمل إيجابي للإناث المتزوجات (فحص نوعي)" },
                { id: "q4", en: "Plan for pregnancy next 3 months", ar: "تخطيط للحمل خلال الأشهر الثلاثة القادمة" },
                { id: "q5", en: "Absence of any previous hypersensitivity to any vaccine, yeast, streptomycin, neomycin, eggs or polymixin B.", ar: "عدم وجود أثر لحساسية مفرطة سابقة لأي مطعوم، خميرة، ستربتومايسين، نيوميسين، بيض أو بوليميكسين ب" },
                { id: "q6", en: "Asplenia, complement deficiencies", ar: "استئصال الطحال أو نقص البروتينات المكملة" },
                { id: "q7", en: "Immune-compromised", ar: "ضعف أو نقص في جهاز المناعة" },
                { id: "q8", en: "End stage renal disease, on hemodialysis", ar: "فشل كلوي بمراحل متقدمة أو غسيل كلى منتظم" },
                { id: "q9", en: "Heart or lung disease, alcoholism", ar: "أمراض القلب، أمراض الرئة، أو إدمان الكحول" },
                { id: "q10", en: "Chronic liver disease", ar: "أمراض الكبد المزمنة" },
                { id: "q11", en: "diabetic", ar: "مرض السكري" }
              ].map(q => `
                <tr>
                  <td style="padding: 10px 14px; font-size: 0.9rem; font-weight: 600;">
                    ${q.en}
                    ${isAr ? `<br><small style="color: var(--text-muted);">${q.ar}</small>` : ''}
                  </td>
                  <td style="text-align: center; vertical-align: middle; padding: 8px;">
                    <input type="radio" name="sec2_${q.id}" id="sec2_${q.id}_yes" value="Yes" ${q.id === 'q5' ? 'checked' : ''} style="width: 17px; height: 17px; cursor: pointer;">
                  </td>
                  <td style="text-align: center; vertical-align: middle; padding: 8px;">
                    <input type="radio" name="sec2_${q.id}" id="sec2_${q.id}_no" value="No" ${(q.id !== 'q5' && q.id !== 'q3' && q.id !== 'q4') ? 'checked' : ''} style="width: 17px; height: 17px; cursor: pointer;">
                  </td>
                  <td style="text-align: center; vertical-align: middle; padding: 8px;">
                    <input type="radio" name="sec2_${q.id}" id="sec2_${q.id}_na" value="N/A" ${(q.id === 'q3' || q.id === 'q4') ? 'checked' : ''} style="width: 17px; height: 17px; cursor: pointer;">
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        <div style="margin-top: 18px; padding-top: 12px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap;">
          <button type="button" class="btn btn-success sec-save-btn" style="padding: 6px 18px; font-weight: bold; font-size: 0.85rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);" onclick="handleSaveUnifiedStaffForm(event, 'update')">💾 ${isAr ? 'حفظ وتحديث بيانات الموظف الآن' : 'Save & Update Staff Record Now'}</button>
          <button type="button" class="btn btn-outline" style="padding: 5px 14px; font-weight: bold; font-size: 0.82rem; border-radius: 6px; color: #D69E2E; border-color: #D69E2E;" onclick="focusAndEditSection('sec2_pregnancyStatus', 'section_card_2')">✏️ ${isAr ? 'تعديل هذا القسم' : 'Edit Section'}</button>
        </div>
      </div>

      <!-- SECTION 3: LABORATORY TEST RESULTS -->
      <div class="card" id="section_card_3" style="margin-bottom: 24px; border-top: 4px solid var(--accent-teal); transition: all 0.3s ease;">
        <div class="card-title" style="color: var(--accent-teal); font-size: 1.15rem;">
          <span>${t('sec3_title')}</span>
        </div>

        <div style="background: #F0F9FF; border: 1.5px solid #0284C7; border-radius: 8px; padding: 12px 16px; margin-top: 14px; margin-bottom: 14px;">
          <label style="font-weight: 800; color: #0369A1; font-size: 0.92rem; display: block; margin-bottom: 6px;">
            🛡️ ${isAr ? 'التحكم والتعديل اليدوي لحالة التطعيم والمناعة العامة:' : 'Manual Immunity & Vaccination Status Override:'}
          </label>
          <select id="sec3_manualImmunityStatus" style="width: 100%; padding: 8px 12px; border: 1.5px solid #0284C7; border-radius: 6px; font-weight: bold; font-size: 0.9rem; color: #0C4A6E; background: white;">
            <option value="Fully Vaccinated">${isAr ? '🟢 مُلقح بالكامل / محصن (Fully Vaccinated / Fully Immune)' : '🟢 Fully Vaccinated / Fully Immune'}</option>
            <option value="Fully Immune">${isAr ? '🟢 منيع بالكامل (Fully Immune)' : '🟢 Fully Immune'}</option>
            <option value="Partially Vaccinated">${isAr ? '🟡 مُلقح جزئياً (Partially Vaccinated)' : '🟡 Partially Vaccinated'}</option>
            <option value="Ongoing">${isAr ? '🔵 قيد التطعيم المستمر (Ongoing / In Progress)' : '🔵 Ongoing / In Progress'}</option>
            <option value="Not Vaccinated">${isAr ? '🔴 غير مُلقح (Not Vaccinated)' : '🔴 Not Vaccinated'}</option>
            <option value="Contraindication">${isAr ? '⚠️ موانع تطبيق التطعيم / إعفاء طبي (Contraindication / Medical Exemption)' : '⚠️ Contraindication / Medical Exemption'}</option>
            <option value="Non-Responder">${isAr ? '⚠️ غير مستجيب للتطعيم (Non-Responder - HBsAb < 10 mIU/mL)' : '⚠️ Non-Responder (HBsAb < 10 mIU/mL)'}</option>
          </select>
        </div>

        <div class="table-responsive" style="margin-top: 14px;">
          <table class="clinical-table" style="background: #FFFDF5; border: 1px solid #E2E8F0;">
            <thead>
              <tr style="background: #E0F2FE; color: #075985;">
                <th style="width: 22%;">${isAr ? 'نوع الفحص (Test)' : 'Test'}</th>
                <th style="width: 53%;">${isAr ? 'النتيجة (Result)' : 'Result'}</th>
                <th style="width: 25%;">${isAr ? 'تاريخ الفحص (Date)' : 'Date'}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="font-weight: bold; color: #075985;">HBsAb</td>
                <td><input type="text" id="sec3_hbsabResult" placeholder="${isAr ? 'مثال: >10 mIU/mL (مناعة)' : 'e.g. >10 mIU/mL (Immune)'}" style="font-weight: bold;"></td>
                <td><input type="date" id="sec3_hbsabDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">HBsAg</td>
                <td>
                  <select id="sec3_hbsagResult" onchange="handleResultDropdownOther(this, 'sec3_hbsagResult_custom')" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                    <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                    <option value="Non-Reactive">${isAr ? 'غير تفاعلي (Non-Reactive)' : 'Non-Reactive'}</option>
                    <option value="Other">${isAr ? 'أخرى (اكتب النتيجة) / Other' : 'Other'}</option>
                  </select>
                  <input type="text" id="sec3_hbsagResult_custom" placeholder="${isAr ? 'اكتب النتيجة هنا...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_hbsagDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">HCV</td>
                <td>
                  <select id="sec3_hcvResult" onchange="handleResultDropdownOther(this, 'sec3_hcvResult_custom')" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="">${isAr ? '-- اختر النتيجة --' : '-- Select Result --'}</option>
                    <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                    <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                    <option value="Non-Reactive">${isAr ? 'غير تفاعلي (Non-Reactive)' : 'Non-Reactive'}</option>
                    <option value="Other">${isAr ? 'أخرى (اكتب النتيجة) / Other' : 'Other'}</option>
                  </select>
                  <input type="text" id="sec3_hcvResult_custom" placeholder="${isAr ? 'اكتب النتيجة هنا...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_hcvDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">HIV</td>
                <td>
                  <select id="sec3_hivResult" onchange="handleResultDropdownOther(this, 'sec3_hivResult_custom')" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="">${isAr ? '-- اختر النتيجة --' : '-- Select Result --'}</option>
                    <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                    <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                    <option value="Non-Reactive">${isAr ? 'غير تفاعلي (Non-Reactive)' : 'Non-Reactive'}</option>
                    <option value="Other">${isAr ? 'أخرى (اكتب النتيجة) / Other' : 'Other'}</option>
                  </select>
                  <input type="text" id="sec3_hivResult_custom" placeholder="${isAr ? 'اكتب النتيجة هنا...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_hivDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">PPD (1st Test)</td>
                <td>
                  <div style="display: flex; gap: 8px; align-items: center;">
                    <span style="font-size: 0.85rem; font-weight: 700; white-space: nowrap;">1<sup>st</sup> test:</span>
                    <input type="text" id="sec3_ppdStep1Induration" placeholder="0 mm" style="width: 90px;">
                    <select id="sec3_ppdStep1Result" onchange="handleResultDropdownOther(this, 'sec3_ppdStep1Result_custom')" style="flex: 1; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                      <option value="">${isAr ? '-- النتيجة --' : '-- Result --'}</option>
                      <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                      <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                      <option value="Other">${isAr ? 'أخرى / Other' : 'Other'}</option>
                    </select>
                  </div>
                  <input type="text" id="sec3_ppdStep1Result_custom" placeholder="${isAr ? 'نتيجة مخصصة...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_ppdStep1Date"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">PPD (2nd Test)</td>
                <td>
                  <div style="display: flex; gap: 8px; align-items: center;">
                    <span style="font-size: 0.85rem; font-weight: 700; white-space: nowrap;">2<sup>nd</sup> test:</span>
                    <input type="text" id="sec3_ppdStep2Induration" placeholder="0 mm" style="width: 90px;">
                    <select id="sec3_ppdStep2Result" onchange="handleResultDropdownOther(this, 'sec3_ppdStep2Result_custom')" style="flex: 1; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                      <option value="">${isAr ? '-- النتيجة --' : '-- Result --'}</option>
                      <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                      <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                      <option value="Other">${isAr ? 'أخرى / Other' : 'Other'}</option>
                    </select>
                  </div>
                  <input type="text" id="sec3_ppdStep2Result_custom" placeholder="${isAr ? 'نتيجة مخصصة...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_ppdStep2Date"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">Varicella Zoster, IgG</td>
                <td>
                  <select id="sec3_varicellaIgG" onchange="handleResultDropdownOther(this, 'sec3_varicellaIgG_custom')" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="">${isAr ? '-- اختر النتيجة --' : '-- Select Result --'}</option>
                    <option value="Natural Immunity">${isAr ? 'مناعة طبيعية (Natural Immunity)' : 'Natural Immunity'}</option>
                    <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                    <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                    <option value="Other">${isAr ? 'أخرى (اكتب النتيجة) / Other' : 'Other'}</option>
                  </select>
                  <input type="text" id="sec3_varicellaIgG_custom" placeholder="${isAr ? 'اكتب النتيجة هنا...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_varicellaIgGDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">Mumps IgG Titer</td>
                <td>
                  <select id="sec3_mumpsIgGTiter" onchange="handleResultDropdownOther(this, 'sec3_mumpsIgGTiter_custom')" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="">${isAr ? '-- اختر النتيجة --' : '-- Select Result --'}</option>
                    <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                    <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                    <option value="Natural Immunity">${isAr ? 'مناعة طبيعية (Natural Immunity)' : 'Natural Immunity'}</option>
                    <option value="Equivocal">${isAr ? 'مشكوك فيه (Equivocal)' : 'Equivocal'}</option>
                    <option value="Other">${isAr ? 'أخرى (اكتب النتيجة) / Other' : 'Other'}</option>
                  </select>
                  <input type="text" id="sec3_mumpsIgGTiter_custom" placeholder="${isAr ? 'اكتب النتيجة هنا...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_mumpsIgGTiterDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">Measles IgG Titer</td>
                <td>
                  <select id="sec3_measlesIgGTiter" onchange="handleResultDropdownOther(this, 'sec3_measlesIgGTiter_custom')" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="">${isAr ? '-- اختر النتيجة --' : '-- Select Result --'}</option>
                    <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                    <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                    <option value="Natural Immunity">${isAr ? 'مناعة طبيعية (Natural Immunity)' : 'Natural Immunity'}</option>
                    <option value="Equivocal">${isAr ? 'مشكوك فيه (Equivocal)' : 'Equivocal'}</option>
                    <option value="Other">${isAr ? 'أخرى (اكتب النتيجة) / Other' : 'Other'}</option>
                  </select>
                  <input type="text" id="sec3_measlesIgGTiter_custom" placeholder="${isAr ? 'اكتب النتيجة هنا...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_measlesIgGTiterDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">Rubella IgG Titer</td>
                <td>
                  <select id="sec3_rubellaIgGTiter" onchange="handleResultDropdownOther(this, 'sec3_rubellaIgGTiter_custom')" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="">${isAr ? '-- اختر النتيجة --' : '-- Select Result --'}</option>
                    <option value="Positive">${isAr ? 'موجب (Positive)' : 'Positive'}</option>
                    <option value="Negative">${isAr ? 'سالب (Negative)' : 'Negative'}</option>
                    <option value="Natural Immunity">${isAr ? 'مناعة طبيعية (Natural Immunity)' : 'Natural Immunity'}</option>
                    <option value="Equivocal">${isAr ? 'مشكوك فيه (Equivocal)' : 'Equivocal'}</option>
                    <option value="Other">${isAr ? 'أخرى (اكتب النتيجة) / Other' : 'Other'}</option>
                  </select>
                  <input type="text" id="sec3_rubellaIgGTiter_custom" placeholder="${isAr ? 'اكتب النتيجة هنا...' : 'Write result here...'}" style="display: none; margin-top: 4px; width: 100%; padding: 5px; border: 1px solid #0284C7; border-radius: 4px; background: #F0F9FF; font-weight: 600;">
                </td>
                <td><input type="date" id="sec3_rubellaIgGTiterDate"></td>
              </tr>
              <tr>
                <td style="font-weight: bold; color: #075985;">Other Laboratory Test</td>
                <td><input type="text" id="sec3_otherLabResult" placeholder="${isAr ? 'فحوصات مخبرية أخرى' : 'Other Lab Test Result'}"></td>
                <td><input type="date" id="sec3_otherLabDate"></td>
              </tr>
            </tbody>
          </table>
        </div>

        <div style="margin-top: 18px; padding-top: 12px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap;">
          <button type="button" class="btn btn-success sec-save-btn" style="padding: 6px 18px; font-weight: bold; font-size: 0.85rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);" onclick="handleSaveUnifiedStaffForm(event, 'update')">💾 ${isAr ? 'حفظ وتحديث بيانات الموظف الآن' : 'Save & Update Staff Record Now'}</button>
          <button type="button" class="btn btn-outline" style="padding: 5px 14px; font-weight: bold; font-size: 0.82rem; border-radius: 6px; color: var(--accent-teal); border-color: var(--accent-teal);" onclick="focusAndEditSection('sec3_hbsabResult', 'section_card_3')">✏️ ${isAr ? 'تعديل هذا القسم' : 'Edit Section'}</button>
        </div>
      </div>

      <!-- SECTION 4: EMPLOYEE VACCINATION (INSIDE OR OUTSIDE) -->
      <div class="card" id="section_card_4" style="margin-bottom: 24px; border-top: 4px solid var(--primary-blue); transition: all 0.3s ease;">
        <div class="card-title" style="color: var(--primary-blue); font-size: 1.15rem;">
          <span>${t('sec4_title')}</span>
        </div>

        <h5 style="color: #78350F; margin-top: 10px; margin-bottom: 8px;">${isAr ? 'تطعيم التهاب الكبد ب (Engrix / Hepatitis B Series):' : 'Hepatitis B Vaccine Series (Engrix Doses):'}</h5>
        <div class="table-responsive" style="margin-bottom: 16px;">
          <table class="clinical-table" style="background: #FFFDF5; border: 1px solid #FEF3C7;">
            <thead>
              <tr style="background: #FEF3C7; color: #78350F;">
                <th>${isAr ? 'تاريخ الجرعة 1 إنجريكس' : 'Date of 1st Engrix dose'}</th>
                <th>${isAr ? 'تاريخ الجرعة 2 إنجريكس' : 'Date of 2nd Engrix dose'}</th>
                <th>${isAr ? 'تاريخ الجرعة 3 إنجريكس' : 'Date of 3rd Engrix dose'}</th>
                <th>${isAr ? 'جرعة منشطة إنجريكس' : 'Engrix Booster dose'}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><input type="date" id="sec3_engrixDose1"></td>
                <td><input type="date" id="sec3_engrixDose2"></td>
                <td><input type="date" id="sec3_engrixDose3"></td>
                <td><input type="date" id="sec3_engrixBooster"></td>
              </tr>
            </tbody>
          </table>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 14px; margin-bottom: 8px;">
          <h5 style="color: #075985; margin: 0;">${isAr ? 'باقي التطعيمات الأساسية (IPV, Tdap, MMR, Chickenpox):' : 'Other Mandatory & Core Vaccines (IPV, Tdap, MMR, Varicella):'}</h5>
          <button type="button" class="btn btn-outline" style="padding: 4px 12px; font-size: 0.82rem; border-color: #075985; color: #075985; background: white; font-weight: bold;" onclick="addCoreVaccineDoseRow()">
            ➕ ${isAr ? 'إضافة صف للجرعات الأخرى' : '➕ Add Line for Other Doses'}
          </button>
        </div>
        <div class="table-responsive">
          <table class="clinical-table" style="background: #F0F9FF;">
            <thead>
              <tr style="background: #E0F2FE; color: #075985;">
                <th style="width: 75px; text-align: center; font-weight: bold;">${isAr ? 'الجرعة' : 'Dose'}</th>
                <th>${isAr ? 'تطعيم شلل الأطفال IPV (>18 سنة)' : 'IPV Vaccine (>18 Yrs)'}</th>
                <th>${isAr ? 'تطعيم الكزاز Tdap (>7 سنوات)' : 'Tdap Vaccine (>7 Yrs)'}</th>
                <th>${isAr ? 'جرعة MMR الأولى (>سنة)' : 'MMR 1st Dose (>1 Yr)'}</th>
                <th>${isAr ? 'جرعة MMR الثانية (>سنة)' : 'MMR 2nd Dose (>1 Yr)'}</th>
                <th>${isAr ? 'حالة جدري الماء (إصابة/مطعم)' : 'Chickenpox Infected/Vaccinated'}</th>
                <th>${isAr ? 'تاريخ جرعة 1 جدري الماء' : 'Chickenpox Dose 1 Date'}</th>
                <th>${isAr ? 'تاريخ جرعة 2 جدري الماء' : 'Chickenpox Dose 2 Date'}</th>
                <th>${isAr ? 'عيار مناعة Varicella IgG' : 'Varicella Zoster, IgG'}</th>
                <th>${isAr ? 'تاريخ فحص Varicella IgG' : 'Varicella Zoster, IgG date'}</th>
              </tr>
            </thead>
            <tbody id="sec4_core_vaccines_tbody">
              <tr>
                <td style="font-weight: bold; text-align: center; background: #E0F2FE; color: #075985; font-family: 'Times New Roman', serif; font-size: 0.95rem;">Dose 1</td>
                <td>
                  <input type="text" id="sec4_ipvDate" list="childhood_presets" placeholder="DD/MM/YYYY or child hood" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                </td>
                <td>
                  <input type="text" id="sec4_tdapDate" list="childhood_presets" placeholder="DD/MM/YYYY or child hood" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                </td>
                <td>
                  <input type="text" id="sec4_mmrDose1" list="childhood_presets" placeholder="DD/MM/YYYY or child hood" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                </td>
                <td>
                  <input type="text" id="sec4_mmrDose2" list="childhood_presets" placeholder="DD/MM/YYYY or child hood" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                </td>
                <datalist id="childhood_presets">
                  <option value="child hood">child hood (تطعيم الطفولة)</option>
                  <option value="Declaration of having vaccination">Declaration of having vaccination (إقرار بأخذ التطعيم)</option>
                  <option value="Natural Immunity">Natural Immunity (مناعة طبيعية)</option>
                  <option value="Not Vaccinated">Not Vaccinated (غير مطعم)</option>
                  <option value="NO need according MOH">NO need according MOH (لا حاجة حسب وزارة الصحة)</option>
                </datalist>
                <td>
                  <select id="sec4_chickenpoxStatus" onchange="handleChickenpoxStatusChange(this)" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                    <option value="">-- Select Status --</option>
                    <option value="Natural Immunity">Natural Immunity</option>
                    <option value="Positive IGG">Positive IGG</option>
                    <option value="2 doses vaccine">2 doses vaccine</option>
                    <option value="Vaccinated">Vaccinated</option>
                    <option value="Infected / History">Infected / History</option>
                    <option value="Declaration of having vaccination">Declaration of having vaccination</option>
                    <option value="Not Vaccinated">Not Vaccinated</option>
                  </select>
                </td>
                <td><input type="text" id="sec4_chickenpoxDose1" list="childhood_presets" placeholder="${isAr ? 'تاريخ الجرعة 1' : 'Dose 1 Date (DD/MM/YYYY)'}" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
                <td><input type="text" id="sec4_chickenpoxDose2" list="childhood_presets" placeholder="${isAr ? 'تاريخ الجرعة 2' : 'Dose 2 Date (DD/MM/YYYY)'}" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
                <td>
                  <input type="text" id="sec4_varicellaIgG" list="varicella_igg_presets" placeholder="${isAr ? 'النتيجة أو عيار المناعة...' : 'Result or titer (Positive, 973.9...)'}" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
                  <datalist id="varicella_igg_presets">
                    <option value="Positive">Positive (موجب)</option>
                    <option value="Negative">Negative (سالب)</option>
                    <option value="Natural Immunity">Natural Immunity (مناعة طبيعية)</option>
                    <option value=">1.1">>1.1</option>
                  </datalist>
                </td>
                <td><input type="text" id="sec4_varicellaIgGDate" list="childhood_presets" placeholder="DD/MM/YYYY or choice..." style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- OTHER VACCINES (DYNAMIC DOSE 2, 3, 4, 5 LINES) -->
        <div style="margin-top: 20px; padding: 14px 18px; background: #FAF5FF; border: 1.5px solid #E9D5FF; border-radius: 8px;">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; margin-bottom: 10px;">
            <div>
              <h5 style="color: #6B21A8; margin: 0; font-weight: 800; font-size: 0.95rem;">
                💉 ${isAr ? 'مطاعيم أخرى (Other Vaccines):' : 'Other Vaccines:'}
              </h5>
              <div style="font-size: 0.78rem; color: #7E22CE; margin-top: 2px;">
                ${isAr ? 'إضافة صفوف لمطاعيم أخرى وتسجيل الجرعة (Dose 2, Dose 3, Dose 4, Dose 5...)' : 'Add custom vaccine lines to record Dose 2, Dose 3, Dose 4, Dose 5 with date and batch/lot number.'}
              </div>
            </div>
            <button type="button" class="btn btn-primary" style="padding: 6px 14px; font-weight: bold; background: #8B5CF6; color: white; border: none; font-size: 0.82rem; border-radius: 6px; cursor: pointer;" onclick="addDynamicVaccineRow('sec4_custom_tbody')">
              ➕ ${isAr ? 'إضافة صف للمطاعيم الأخرى' : '➕ Add Line for Other Vaccines'}
            </button>
          </div>
          <div class="table-responsive">
            <table class="clinical-table" style="background: white; border: 1px solid #E9D5FF;">
              <thead>
                <tr style="background: #F3E8FF; color: #6B21A8;">
                  <th>${isAr ? 'اسم المطعوم / Vaccine Name' : 'Vaccine Name / Disease'}</th>
                  <th>${isAr ? 'نوع الجرعة / Dose Type' : 'Dose Type (Dose 2, 3, 4, 5)'}</th>
                  <th>${isAr ? 'تاريخ الجرعة / Date Administered' : 'Date Administered'}</th>
                  <th>${isAr ? 'رقم التشغيلة / Batch - Lot No.' : 'Batch / Lot No.'}</th>
                  <th style="width: 70px; text-align: center;">${isAr ? 'إجراء' : 'Action'}</th>
                </tr>
              </thead>
              <tbody id="sec4_custom_tbody"></tbody>
            </table>
          </div>
        </div>

        <div style="margin-top: 18px; padding-top: 12px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap;">
          <button type="button" class="btn btn-success sec-save-btn" style="padding: 6px 18px; font-weight: bold; font-size: 0.85rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);" onclick="handleSaveUnifiedStaffForm(event, 'update')">💾 ${isAr ? 'حفظ وتحديث بيانات الموظف الآن' : 'Save & Update Staff Record Now'}</button>
          <button type="button" class="btn btn-outline" style="padding: 5px 14px; font-weight: bold; font-size: 0.82rem; border-radius: 6px; color: var(--primary-blue); border-color: var(--primary-blue);" onclick="focusAndEditSection('sec3_engrixDose1', 'section_card_4')">✏️ ${isAr ? 'تعديل هذا القسم' : 'Edit Section'}</button>
        </div>
      </div>

      <!-- SECTION 5: SPECIAL VACCINATION -->
      <div class="card" id="section_card_5" style="margin-bottom: 24px; border-top: 4px solid #166534; transition: all 0.3s ease;">
        <div class="card-title" style="color: #166534; font-size: 1.15rem; display: flex; justify-content: space-between; align-items: center; cursor: pointer;" onclick="toggleSectionCollapse(5)">
          <span>${t('sec5_title')}</span>
          <button type="button" id="section_toggle_btn_5" class="btn btn-outline" style="padding: 4px 12px; font-size: 0.8rem; border-color: #166534; color: #166534; font-weight: bold; background: white;" onclick="event.stopPropagation(); toggleSectionCollapse(5)">
            🔽 ${isAr ? 'فتح القسم' : 'Expand'}
          </button>
        </div>

        <div id="section_body_5" style="display: none;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 14px; margin-bottom: 8px;">
            <h5 style="color: #166534; margin: 0;">${isAr ? 'التطعيمات الخاصة (Special Vaccination Series):' : 'Special Vaccination Series:'}</h5>
            <button type="button" class="btn btn-primary" style="padding: 5px 14px; font-weight: bold; background: #166534; color: white; border: none; font-size: 0.82rem; border-radius: 6px; cursor: pointer;" onclick="addSpecialVaccineDoseRow()">
              ➕ ${isAr ? 'إضافة جرعة مطعوم خاص' : '➕ Add Line for Special Vaccine'}
            </button>
          </div>
          <div class="table-responsive">
            <table class="clinical-table" style="background: white; border: 1px solid var(--border-color);">
              <thead>
                <tr style="background: #DCFCE7; color: #166534;">
                  <th>${isAr ? 'المطعوم / الجرعة (Vaccine / Booster)' : 'Vaccine / Booster'}</th>
                  <th>${isAr ? 'الشركة / النوع (Manufacturer / Type)' : 'Manufacturer / Type'}</th>
                  <th>${isAr ? 'تاريخ الجرعة (Date Administered)' : 'Date Administered'}</th>
                  <th>${isAr ? 'رقم التشغيلة (Batch / Lot #)' : 'Batch / Lot #'}</th>
                  <th style="width: 70px; text-align: center;">${isAr ? 'إجراء' : 'Action'}</th>
                </tr>
              </thead>
              <tbody id="sec5_special_vaccines_tbody"></tbody>
            </table>
          </div>

          <div style="margin-top: 18px; padding-top: 12px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap;">
            <button type="button" class="btn btn-success sec-save-btn" style="padding: 6px 18px; font-weight: bold; font-size: 0.85rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);" onclick="handleSaveUnifiedStaffForm(event, 'update')">💾 ${isAr ? 'حفظ وتحديث بيانات الموظف الآن' : 'Save & Update Staff Record Now'}</button>
            <button type="button" class="btn btn-outline" style="padding: 5px 14px; font-weight: bold; font-size: 0.82rem; border-radius: 6px; color: #166534; border-color: #166534;" onclick="focusAndEditSection('sec5_special_vaccines_tbody', 'section_card_5')">✏️ ${isAr ? 'تعديل هذا القسم' : 'Edit Section'}</button>
          </div>
        </div>
      </div>

      <!-- SECTION 6: COVID-19 & FLU VACCINATION -->
      <div class="card" id="section_card_6" style="margin-bottom: 24px; border-top: 4px solid var(--accent-teal); transition: all 0.3s ease;">
        <div class="card-title" style="color: var(--accent-teal); font-size: 1.15rem; display: flex; justify-content: space-between; align-items: center; cursor: pointer;" onclick="toggleSectionCollapse(6)">
          <span>${t('sec6_title')}</span>
          <button type="button" id="section_toggle_btn_6" class="btn btn-outline" style="padding: 4px 12px; font-size: 0.8rem; border-color: var(--accent-teal); color: var(--accent-teal); font-weight: bold; background: white;" onclick="event.stopPropagation(); toggleSectionCollapse(6)">
            🔽 ${isAr ? 'فتح القسم' : 'Expand'}
          </button>
        </div>

        <div id="section_body_6" style="display: none;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 14px; margin-bottom: 8px;">
            <h5 style="color: var(--accent-teal); margin: 0;">${isAr ? 'تطعيم الإنفلونزا الموسمية وكوفيد-19 (Covid-19 & Flu Vaccination):' : 'Covid-19 & Influenza Seasonal Vaccination:'}</h5>
            <button type="button" class="btn btn-primary" style="padding: 5px 14px; font-weight: bold; background: var(--accent-teal); color: white; border: none; font-size: 0.82rem; border-radius: 6px; cursor: pointer;" onclick="addCovidFluDoseRow()">
              ➕ ${isAr ? 'إضافة جرعة كوفيد / انفلونزا' : '➕ Add Line for Covid / Flu Dose'}
            </button>
          </div>
          <div class="table-responsive">
            <table class="clinical-table" style="background: white; border: 1px solid var(--border-color);">
              <thead>
                <tr style="background: #CCFBF1; color: var(--accent-teal);">
                  <th>${isAr ? 'المطعوم / الجرعة (Vaccine / Booster)' : 'Vaccine / Booster'}</th>
                  <th>${isAr ? 'الشركة / النوع (Manufacturer / Type)' : 'Manufacturer / Type'}</th>
                  <th>${isAr ? 'تاريخ الجرعة (Date Administered)' : 'Date Administered'}</th>
                  <th>${isAr ? 'رقم التشغيلة (Batch / Lot #)' : 'Batch / Lot #'}</th>
                  <th style="width: 70px; text-align: center;">${isAr ? 'إجراء' : 'Action'}</th>
                </tr>
              </thead>
              <tbody id="sec6_covid_flu_tbody"></tbody>
            </table>
          </div>

          <div style="margin-top: 18px; padding-top: 12px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap;">
            <button type="button" class="btn btn-success sec-save-btn" style="padding: 6px 18px; font-weight: bold; font-size: 0.85rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);" onclick="handleSaveUnifiedStaffForm(event, 'update')">💾 ${isAr ? 'حفظ وتحديث بيانات الموظف الآن' : 'Save & Update Staff Record Now'}</button>
            <button type="button" class="btn btn-outline" style="padding: 5px 14px; font-weight: bold; font-size: 0.82rem; border-radius: 6px; color: var(--accent-teal); border-color: var(--accent-teal);" onclick="focusAndEditSection('sec6_covid_flu_tbody', 'section_card_6')">✏️ ${isAr ? 'تعديل هذا القسم' : 'Edit Section'}</button>
          </div>
        </div>
      </div>

      <!-- SECTION 7: POST EXPOSURE PROPHYLAXIS (PEP) -->
      <div class="card" id="section_card_7" style="margin-bottom: 24px; border-top: 4px solid #EF4444; transition: all 0.3s ease;">
        <div class="card-title" style="color: #EF4444; font-size: 1.15rem; display: flex; justify-content: space-between; align-items: center; cursor: pointer;" onclick="toggleSectionCollapse(7)">
          <span>${t('sec7_title')}</span>
          <button type="button" id="section_toggle_btn_7" class="btn btn-outline" style="padding: 4px 12px; font-size: 0.8rem; border-color: #EF4444; color: #EF4444; font-weight: bold; background: white;" onclick="event.stopPropagation(); toggleSectionCollapse(7)">
            🔽 ${isAr ? 'فتح القسم' : 'Expand'}
          </button>
        </div>

        <div id="section_body_7" style="display: none;">
          <div style="background: #FEF3C7; border: 1px solid #FCD34D; border-radius: 6px; padding: 10px 14px; margin-top: 12px; margin-bottom: 12px; font-size: 0.85rem; color: #92400E; font-weight: 500;">
            <strong>PEP Protocol Status:</strong> ${isAr ? 'سجل إجراءات وتدابير الوخز بالبر أو التعرض لسوائل الجسم الوظيفية.' : 'Record of occupational blood / body fluid exposure interventions and prophylaxis regimens.'}
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;">
            <h5 style="color: #EF4444; margin: 0; font-weight: 800;">${isAr ? 'إجراءات الوقاية بعد التعرض (PEP Protocols):' : 'PEP Protocol Interventions:'}</h5>
            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
              <button type="button" class="btn btn-outline" style="padding: 5px 12px; font-weight: bold; color: #DC2626; border-color: #FCA5A5; background: #FEF2F2; font-size: 0.82rem; border-radius: 6px; cursor: pointer;" onclick="autoLinkInjuryReportsToSec7()">
                📥 ${isAr ? 'مزامنة بلاغات الإصابة SQE 02.01' : '📥 Auto-Link SQE 02.01 Reports'}
              </button>
              <button type="button" class="btn btn-primary" style="padding: 5px 14px; font-weight: bold; background: #EF4444; color: white; border: none; font-size: 0.82rem; border-radius: 6px; cursor: pointer;" onclick="addPepRow()">
                ➕ ${isAr ? 'إضافة إجراء PEP' : '➕ Add Line for PEP Protocol'}
              </button>
            </div>
          </div>

          <div id="sec7_incident_summary_banner" style="background: #FEF2F2; border: 1.5px solid #FCA5A5; border-radius: 8px; padding: 12px 16px; margin-bottom: 14px; font-size: 0.88rem; color: #991B1B; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
            <div style="flex: 1; min-width: 260px;">
              <strong>📌 ${isAr ? 'أرقام متابعة البلاغات المسجلة للموظف (Incident Follow-Up Serials):' : 'Incident Follow-Up Tracking Serials:'}</strong>
              <div id="sec7_serial_list_badges" style="margin-top: 6px; display: flex; flex-wrap: wrap; gap: 6px;"></div>
            </div>
            <div style="display: flex; align-items: center; gap: 8px; background: white; padding: 6px 12px; border-radius: 6px; border: 1.5px solid #FCA5A5; box-shadow: 0 2px 5px rgba(0,0,0,0.05);">
              <label style="font-size: 0.82rem; font-weight: 800; color: #991B1B; white-space: nowrap;">
                📋 ${isAr ? 'فتح بلاغ حسب الرقم:' : 'Open Report by Serial:'}
              </label>
              <select id="sec7_quick_serial_select" style="padding: 5px 8px; border-radius: 4px; font-weight: 700; border: 1px solid #DC2626; color: #991B1B; background: #FEF2F2; font-size: 0.82rem; max-width: 220px;" onchange="if(this.value) openInjuryReportBySerial(this.value)">
                <option value="">${isAr ? '-- اختر رقم البلاغ --' : '-- Select Incident Serial --'}</option>
              </select>
              <button type="button" class="btn btn-outline" style="padding: 5px 12px; font-size: 0.8rem; font-weight: bold; background: #DC2626; color: white; border: none; border-radius: 4px; cursor: pointer; white-space: nowrap;" onclick="const s = document.getElementById('sec7_quick_serial_select').value || document.querySelector('.pep-serial-no')?.value; if(s) openInjuryReportBySerial(s);">
                🚀 ${isAr ? 'فتح التقرير' : 'Open Report'}
              </button>
            </div>
          </div>

          <div class="table-responsive">
            <table class="clinical-table" style="background: white; border: 1px solid var(--border-color);">
              <thead>
                <tr style="background: #FEF2F2; color: #EF4444;">
                  <th style="width: 155px;">${isAr ? 'رقم متابعة البلاغ (Incident Serial No.)' : 'Incident Serial / Ref No.'}</th>
                  <th style="width: 145px;">${isAr ? 'تاريخ تقرير الإصابة (Injury Incident Report Date)' : 'Injury Incident Report Date'}</th>
                  <th>${isAr ? 'المطعوم / العلاج / الإجراء (Vaccine / Medication / Protocol)' : 'Vaccine / Medication / Protocol'}</th>
                  <th>${isAr ? 'دواعي الإجراء (Indication)' : 'Indication'}</th>
                  <th style="width: 140px;">${isAr ? 'الحالة (Status)' : 'Status'}</th>
                  <th style="width: 140px;">${isAr ? 'تاريخ الإجراء (Date)' : 'Date'}</th>
                  <th style="width: 70px; text-align: center;">${isAr ? 'إجراء' : 'Action'}</th>
                </tr>
              </thead>
              <tbody id="sec7_pep_tbody"></tbody>
            </table>
          </div>

          <div style="margin-top: 18px; padding-top: 12px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; align-items: center; gap: 10px; flex-wrap: wrap;">
            <button type="button" class="btn btn-success sec-save-btn" style="padding: 6px 18px; font-weight: bold; font-size: 0.85rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);" onclick="handleSaveUnifiedStaffForm(event, 'update')">💾 ${isAr ? 'حفظ وتحديث بيانات الموظف الآن' : 'Save & Update Staff Record Now'}</button>
            <button type="button" class="btn btn-outline" style="padding: 5px 14px; font-weight: bold; font-size: 0.82rem; border-radius: 6px; color: #EF4444; border-color: #EF4444;" onclick="focusAndEditSection('sec7_pep_tbody', 'section_card_7')">✏️ ${isAr ? 'تعديل هذا القسم' : 'Edit Section'}</button>
          </div>
        </div>
      </div>

      <!-- SAVE, UPDATE, PRINT & BACKUP SYNC ACTION BUTTONS -->
      <div class="card" style="background: #F8FAFC; border: 2px solid var(--primary-blue); display: flex; flex-direction: column; gap: 14px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
          <div>
            <strong style="color: var(--primary-blue); font-size: 1.05rem;">${isAr ? 'حفظ / تحديث البيانات ومزامنة الإكسل' : 'Save, Update & Print Staff Health Record'}</strong>
            <div style="font-size: 0.85rem; color: var(--text-muted);">${isAr ? 'يحفظ أو يحدث البيانات محلياً ويرسل الأقسام السبعة إلى جوجل شيت مع إمكانية طباعة النموذج.' : 'Saves or updates application state, pushes all 7 sections to Google Sheets, or prints the unified form.'}</div>
          </div>
          <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
            <span id="unsaved_changes_badge" style="display: none; background: #FEF3C7; color: #92400E; border: 1.5px solid #F59E0B; padding: 6px 14px; border-radius: 6px; font-size: 0.88rem; font-weight: bold; align-items: center; gap: 6px;">
              ⚠️ ${isAr ? 'تغييرات غير محفوظة' : 'Unsaved changes'}
            </span>
            <button type="submit" id="portal_save_btn" class="btn btn-success" style="padding: 10px 22px; font-size: 0.95rem; font-weight: bold; background: #10B981; color: white; border: none; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 6px;" onclick="handleSaveUnifiedStaffForm(event, 'save')">
              💾 ${isAr ? 'حفظ' : 'Save'}
            </button>
            <button type="button" id="portal_update_btn" class="btn btn-primary" style="padding: 10px 22px; font-size: 0.95rem; font-weight: bold; background: #2563EB; color: white; border: none; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 6px;" onclick="handleSaveUnifiedStaffForm(event, 'update')">
              🔄 ${isAr ? 'تحديث' : 'Update'}
            </button>
            <button type="button" class="btn btn-outline" style="padding: 10px 22px; font-size: 0.95rem; font-weight: bold; color: var(--primary-blue); border: 2px solid var(--primary-blue); background: white; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 6px;" onclick="printStaffForm()">
              🖨️ ${isAr ? 'طباعة' : 'Print'}
            </button>
          </div>
        </div>
        <div id="portal_save_status_container" style="width: 100%;"></div>
      </div>
    </form>
    <!-- STICKY FLOATING BOTTOM ACTION BAR FOR INSTANT 1-CLICK SAVE ANYWHERE -->
    <div id="sticky_staff_save_bar" style="position: sticky; bottom: 0; left: 0; right: 0; z-index: 990; background: rgba(255, 255, 255, 0.98); backdrop-filter: blur(8px); border-top: 2.5px solid #0284C7; box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.12); padding: 10px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin: 24px -20px -20px -20px; border-radius: 0 0 8px 8px;">
      <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
        <span style="font-weight: 800; color: #0369A1; font-size: 0.95rem; display: flex; align-items: center; gap: 6px;">
          <span>👤</span>
          <span id="sticky_emp_name_display">${isAr ? 'لم يتم تحديد موظف' : 'No staff selected'}</span>
        </span>
        <span id="sticky_unsaved_badge" style="display: none; background: #FEF3C7; color: #92400E; border: 1.5px solid #F59E0B; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: bold; align-items: center; gap: 4px;">
          ⚠️ ${isAr ? 'تعديلات غير محفوظة' : 'Unsaved changes'}
        </span>
      </div>
      <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
        <button type="button" class="btn btn-outline" style="padding: 7px 16px; font-weight: bold; font-size: 0.88rem; border-radius: 6px; color: #475569; border-color: #94A3B8; background: white; cursor: pointer;" onclick="printStaffForm()">
          🖨️ ${isAr ? 'طباعة النموذج' : 'Print'}
        </button>
        <button type="button" class="btn btn-primary sec-save-btn" style="padding: 8px 22px; font-weight: 800; font-size: 0.92rem; border-radius: 6px; background: #2563EB; color: white; border: none; cursor: pointer; box-shadow: 0 2px 6px rgba(37, 99, 235, 0.35); display: flex; align-items: center; gap: 6px;" onclick="handleSaveUnifiedStaffForm(event, 'update')">
          💾 ${isAr ? 'حفظ وتحديث بيانات الموظف الآن' : 'Save & Update Staff Record Now'}
        </button>
        <button type="button" class="btn btn-success sec-save-btn" style="padding: 8px 18px; font-weight: 700; font-size: 0.88rem; border-radius: 6px; background: #10B981; color: white; border: none; cursor: pointer; box-shadow: 0 2px 6px rgba(16, 185, 129, 0.3); display: flex; align-items: center; gap: 6px;" onclick="handleSaveUnifiedStaffForm(event, 'save')">
          ➕ ${isAr ? 'حفظ كموظف جديد' : 'Save as New Staff'}
        </button>
      </div>
    </div>
  `;

  // Attach dirty change tracking
  const formEl = document.getElementById('unifiedStaffForm');
  if (formEl) {
    formEl.addEventListener('input', () => { if (typeof markStaffFormDirty === 'function') markStaffFormDirty(); });
    formEl.addEventListener('change', () => { if (typeof markStaffFormDirty === 'function') markStaffFormDirty(); });
  }

  // Load globally selected staff if set, otherwise reset form
  selEmp = typeof window.getGlobalSelectedStaff === 'function' ? window.getGlobalSelectedStaff() : null;
  if (selEmp) {
    loadStaffRecordIntoForm(selEmp);
    const selectEl = document.getElementById('staff_quick_select');
    if (selectEl) {
      selectEl.value = selEmp.empNo || selEmp.id || '';
    }
  } else {
    resetFormForNewStaff();
  }
}

function handleStaffSearchInput(query) {
  const resultsBox = document.getElementById('staff_search_results');
  const employees = getUniqueEmployees();
  const isAr = window.i18n.isRTL();
  const q = query.trim().toLowerCase();

  if (!q) {
    if (resultsBox) {
      resultsBox.innerHTML = `
        <div style="padding: 6px 12px; background: #F1F5F9; border-bottom: 1px solid #CBD5E1; font-size: 0.78rem; font-weight: bold; color: var(--primary-blue);">
          ⚡ ${isAr ? 'انقر على أي موظف لفتح بياناته مباشرة:' : 'Click any staff member to load full record:'}
        </div>
      ` + employees.slice(0, 8).map(e => {
        const isAct = typeof isActiveStaff === 'function' ? isActiveStaff(e) : true;
        const stLabel = e.employmentStatus || (e.demographic ? e.demographic.employmentStatus : '') || (isAct ? 'Active Staff' : 'Archived');
        const stPill = isAct
          ? `<span style="background: #ECFDF5; color: #065F46; border: 1px solid #10B981; padding: 2px 8px; border-radius: 12px; font-size: 0.72rem; font-weight: 700;">🟢 ${isAr ? 'نشط' : 'Active'}</span>`
          : `<span style="background: #FEF3C7; color: #92400E; border: 1px solid #F59E0B; padding: 2px 8px; border-radius: 12px; font-size: 0.72rem; font-weight: 700;">📁 ${isAr ? 'مؤرشف' : 'Archived'}: ${stLabel}</span>`;
        return `
        <div style="padding: 8px 12px; border-bottom: 1px solid var(--border-color); cursor: pointer; display: flex; justify-content: space-between; align-items: center;" onclick="selectStaffFromSearch('${e.empNo || e.id}')">
          <div>
            <strong>${e.name}</strong> <span style="font-size: 0.78rem; color: var(--text-muted);">(${e.department || 'Staff'})</span> ${stPill}<br>
            <small style="color: var(--primary-blue);">${isAr ? 'الرقم الوظيفي:' : 'Emp No:'} ${e.empNo || e.id} | ${isAr ? 'الهوية:' : 'ID:'} ${e.idNo || 'N/A'}</small>
          </div>
          <span class="role-pill role-specialist" style="padding: 2px 8px; font-size: 0.75rem;">${isAr ? 'اختيار' : 'Select'}</span>
        </div>
        `;
      }).join('');
      resultsBox.style.display = 'block';
    }
    return;
  }

  const matches = employees.filter(e => {
    const demo = e.demographic || {};
    const name = (e.name || demo.fullName || '').toString().toLowerCase();
    const arName = (demo.arabicFullName || '').toString().toLowerCase();
    const empNo = (e.empNo || e.id || demo.personNumber || '').toString().toLowerCase();
    const idNo = (e.idNo || demo.nationalId || '').toString().toLowerCase();
    const dept = (e.department || demo.deptTreating || '').toString().toLowerCase();
    const job = (e.jobTitle || demo.positionName || '').toString().toLowerCase();
    return name.includes(q) || arName.includes(q) || empNo.includes(q) || idNo.includes(q) || dept.includes(q) || job.includes(q);
  });

  const quickSelect = document.getElementById('staff_quick_select');
  if (quickSelect && matches.length > 0) {
    quickSelect.value = matches[0].empNo || matches[0].id;
  }

  if (resultsBox) {
    if (matches.length === 0) {
      const cleanQ = query.replace(/'/g, "\\'");
      resultsBox.innerHTML = `
        <div style="padding: 12px 14px; background: #FFFBEB; border: 1px solid #FCD34D; border-radius: 6px;">
          <div style="font-weight: 700; color: #92400E; margin-bottom: 6px; font-size: 0.88rem;">
            ⚠️ ${isAr ? `لم يتم العثور على موظف محفظ برقم أو اسم: "${query}"` : `No saved staff record found for query: "${query}"`}
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button type="button" class="btn btn-success" style="padding: 6px 12px; font-size: 0.8rem;" onclick="createNewStaffFromSearch('${cleanQ}')">
              ➕ ${isAr ? `بدء تسجيل موظف جديد بالرقم: ${query}` : `Start Entry for ID / Emp No: ${query}`}
            </button>
            <label class="btn btn-outline" style="padding: 6px 12px; font-size: 0.8rem; cursor: pointer; background: white; border: 1px solid var(--accent-teal); color: var(--accent-teal); border-radius: 4px; font-weight: bold;">
              📥 ${isAr ? 'استيراد من إكسل' : 'Import Excel'}
              <input type="file" accept=".xlsx,.xls,.csv" style="display:none;" onchange="importStaffFromExcelFile(event)">
            </label>
          </div>
        </div>
      `;
    } else {
      resultsBox.innerHTML = `
        <div style="padding: 6px 12px; background: #ECFDF5; border-bottom: 1px solid #A7F3D0; font-size: 0.78rem; font-weight: bold; color: #065F46;">
          🔍 ${isAr ? `نتائج البحث (${matches.length}) - انقر لاختيار الموظف:` : `Matching Results (${matches.length}) - Click to load staff record:`}
        </div>
      ` + matches.map(e => {
        const isAct = typeof isActiveStaff === 'function' ? isActiveStaff(e) : true;
        const stLabel = e.employmentStatus || (e.demographic ? e.demographic.employmentStatus : '') || (isAct ? 'Active Staff' : 'Archived');
        const stPill = isAct
          ? `<span style="background: #ECFDF5; color: #065F46; border: 1px solid #10B981; padding: 2px 8px; border-radius: 12px; font-size: 0.72rem; font-weight: 700;">🟢 ${isAr ? 'نشط' : 'Active'}</span>`
          : `<span style="background: #FEF3C7; color: #92400E; border: 1px solid #F59E0B; padding: 2px 8px; border-radius: 12px; font-size: 0.72rem; font-weight: 700;">📁 ${isAr ? 'مؤرشف' : 'Archived'}: ${stLabel}</span>`;
        return `
        <div style="padding: 10px 14px; border-bottom: 1px solid var(--border-color); cursor: pointer; display: flex; justify-content: space-between; align-items: center;" onclick="selectStaffFromSearch('${e.empNo || e.id}')">
          <div>
            <strong>${e.name}</strong> <span style="font-size: 0.78rem; color: var(--text-muted);">(${e.department || 'Staff'})</span> ${stPill}<br>
            <small style="color: var(--primary-blue);">${isAr ? 'الرقم الوظيفي:' : 'Emp No:'} ${e.empNo || e.id} | ${isAr ? 'الهوية:' : 'ID:'} ${e.idNo || 'N/A'}</small>
          </div>
          <div style="display: flex; gap: 6px; align-items: center;">
            <span class="role-pill role-specialist">${isAr ? 'تعديل / اختيار' : 'Edit / Select'}</span>
            <button type="button" class="btn btn-outline" style="padding: 2px 8px; font-size: 0.72rem; color: #EF4444; border-color: #EF4444;" onclick="event.stopPropagation(); deleteEmployeeRecord('${e.empNo || e.id}', '${e.name}')">🗑️ ${isAr ? 'حذف' : 'Delete'}</button>
          </div>
        </div>
        `;
      }).join('');
    }
    resultsBox.style.display = 'block';
  }
}

function selectStaffFromSearch(empNoOrId) {
  if (!empNoOrId) return;
  const resultsBox = document.getElementById('staff_search_results');
  if (resultsBox) resultsBox.style.display = 'none';

  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const targetStr = String(empNoOrId).trim().toLowerCase();
  const targetClean = targetStr.replace(/^emp-/i, '').replace(/^0+/, '');

  const emp = employees.find(e => {
    if (!e) return false;
    const demo = e.demographic || {};
    const eNo = String(e.empNo || e.id || demo.personNumber || '').trim().toLowerCase();
    const eCleanNo = eNo.replace(/^emp-/i, '').replace(/^0+/, '');
    const eId = String(e.idNo || demo.nationalId || '').trim().toLowerCase();
    const eCleanId = eId.replace(/^0+/, '');

    return (eNo === targetStr || eCleanNo === targetClean || eId === targetStr || eCleanId === targetClean || String(e.empNo) === String(empNoOrId) || String(e.id) === String(empNoOrId));
  });

  if (emp) {
    loadStaffRecordIntoForm(emp);
    const searchInput = document.getElementById('staff_search_input');
    if (searchInput) searchInput.value = emp.name || (emp.demographic ? emp.demographic.fullName : '');
    const quickSelect = document.getElementById('staff_quick_select');
    if (quickSelect) quickSelect.value = emp.empNo || emp.id;

    // Scroll smoothly to section 1
    const card1 = document.getElementById('section_card_1');
    if (card1) {
      card1.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }
}

function selectStaffFromDropdown(empNoOrId) {
  if (!empNoOrId) return;
  selectStaffFromSearch(empNoOrId);
}

function handleStaffSearchKeyDown(e) {
  if (e.key === 'Enter') {
    e.preventDefault();
    const query = e.target.value.trim().toLowerCase();
    if (!query) return;
    const employees = getUniqueEmployees();
    const match = employees.find(emp => {
      const demo = emp.demographic || {};
      const name = (emp.name || demo.fullName || '').toString().toLowerCase();
      const arName = (demo.arabicFullName || '').toString().toLowerCase();
      const empNo = (emp.empNo || emp.id || demo.personNumber || '').toString().toLowerCase();
      const idNo = (emp.idNo || demo.nationalId || '').toString().toLowerCase();
      return name.includes(query) || arName.includes(query) || empNo.includes(query) || idNo.includes(query);
    });
    if (match) {
      selectStaffFromSearch(match.empNo || match.id);
    }
  }
}

// Global listener to dismiss search dropdown when clicking outside
if (typeof window !== 'undefined') {
  document.addEventListener('click', (e) => {
    const searchInput = document.getElementById('staff_search_input');
    const resultsBox = document.getElementById('staff_search_results');
    if (resultsBox && searchInput) {
      if (!searchInput.contains(e.target) && !resultsBox.contains(e.target)) {
        resultsBox.style.display = 'none';
      }
    }
  });
}

function addCoreVaccineDoseRow(doseData) {
  const tbody = document.getElementById('sec4_core_vaccines_tbody');
  if (!tbody) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const rowsCount = tbody.querySelectorAll('tr').length + 1;
  const data = doseData || {};
  const doseLabel = data.doseLabel || `dose ${rowsCount}`;

  const tr = document.createElement('tr');
  tr.className = 'dynamic-core-dose-row';

  tr.innerHTML = `
    <td style="font-weight: bold; text-align: center; background: #E0F2FE; color: #075985; font-family: 'Times New Roman', serif; font-size: 0.95rem;">${doseLabel}</td>
    <td><input type="text" class="core-ipv-date" list="childhood_presets" value="${formatDateDDMMYYYY(data.ipvDate || '')}" placeholder="DD/MM/YYYY or choice..." style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td><input type="text" class="core-tdap-date" list="childhood_presets" value="${formatDateDDMMYYYY(data.tdapDate || '')}" placeholder="DD/MM/YYYY or choice..." style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td><input type="text" class="core-mmr1-date" list="childhood_presets" value="${formatDateDDMMYYYY(data.mmrDose1 || '')}" placeholder="DD/MM/YYYY or choice..." style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td><input type="text" class="core-mmr2-date" list="childhood_presets" value="${formatDateDDMMYYYY(data.mmrDose2 || '')}" placeholder="DD/MM/YYYY or choice..." style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td>
      <select class="core-cp-status" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
        <option value="">-- Select Status --</option>
        <option value="Natural Immunity" ${data.chickenpoxStatus === 'Natural Immunity' ? 'selected' : ''}>Natural Immunity</option>
        <option value="Positive IGG" ${data.chickenpoxStatus === 'Positive IGG' || data.chickenpoxStatus === 'Positive IgG' ? 'selected' : ''}>Positive IGG</option>
        <option value="2 doses vaccine" ${data.chickenpoxStatus === '2 doses vaccine' ? 'selected' : ''}>2 doses vaccine</option>
        <option value="Vaccinated" ${data.chickenpoxStatus === 'Vaccinated' ? 'selected' : ''}>Vaccinated</option>
        <option value="Infected / History" ${data.chickenpoxStatus === 'Infected / History' ? 'selected' : ''}>Infected / History</option>
        <option value="Declaration of having vaccination" ${data.chickenpoxStatus === 'Declaration of having vaccination' || data.chickenpoxStatus === 'declaration of having vaccination' ? 'selected' : ''}>Declaration of having vaccination</option>
        <option value="Not Vaccinated" ${data.chickenpoxStatus === 'Not Vaccinated' ? 'selected' : ''}>Not Vaccinated</option>
      </select>
    </td>
    <td><input type="text" class="core-cp-dose1" list="childhood_presets" value="${formatDateDDMMYYYY(data.chickenpoxDose1 || '')}" placeholder="${isAr ? 'تاريخ جرعة 1' : 'Dose 1 Date'}" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td><input type="text" class="core-cp-dose2" list="childhood_presets" value="${formatDateDDMMYYYY(data.chickenpoxDose2 || '')}" placeholder="${isAr ? 'تاريخ جرعة 2' : 'Dose 2 Date'}" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td>
      <select class="core-var-igg" style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
        <option value="">${isAr ? '-- اختر النتيجة --' : '-- Select Result --'}</option>
        <option value="Positive" ${data.varicellaIgG === 'Positive' ? 'selected' : ''}>${isAr ? 'موجب (Positive)' : 'Positive'}</option>
        <option value="Negative" ${data.varicellaIgG === 'Negative' ? 'selected' : ''}>${isAr ? 'سالب (Negative)' : 'Negative'}</option>
        <option value="Natural Immunity" ${data.varicellaIgG === 'Natural Immunity' ? 'selected' : ''}>${isAr ? 'مناعة طبيعية (Natural Immunity)' : 'Natural Immunity'}</option>
      </select>
    </td>
    <td style="position: relative;">
      <input type="text" class="core-var-date" list="childhood_presets" value="${formatDateDDMMYYYY(data.varicellaIgGDate || '')}" placeholder="DD/MM/YYYY or choice..." style="width: 100%; padding: 6px; border: 1px solid var(--border-color); border-radius: 4px;">
      <button type="button" class="btn btn-danger" style="position: absolute; right: -28px; top: 50%; transform: translateY(-50%); padding: 2px 6px; font-size: 0.72rem; background: #EF4444; color: white; border: none; border-radius: 4px; cursor: pointer;" onclick="this.closest('tr').remove()">🗑️</button>
    </td>
  `;
  tbody.appendChild(tr);
}

function addSpecialVaccineDoseRow(vacData) {
  const tbody = document.getElementById('sec5_special_vaccines_tbody');
  if (!tbody) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const data = vacData || {};
  const currentVal = data.vacName || data.vaccine || '';

  const options = [
    { value: '', label: isAr ? '-- اختر المطعوم الخاص --' : '-- Select Special Vaccine --' },
    { value: 'Meningiococcal A, C', label: 'Meningiococcal A, C' },
    { value: 'Hepatitis A Dose 1', label: 'Hepatitis A Dose 1' },
    { value: 'Hepatitis A Dose 2', label: 'Hepatitis A Dose 2' },
    { value: 'Typhoid Vaccine', label: 'Typhoid Vaccine' },
    { value: 'Pneumovax (Pneumococcal)', label: 'Pneumovax (Pneumococcal)' },
    { value: 'Rabies Vaccine', label: 'Rabies Vaccine' },
    { value: 'Yellow Fever Vaccine', label: 'Yellow Fever Vaccine' },
    { value: 'Japanese Encephalitis', label: 'Japanese Encephalitis' },
    { value: 'Other Special Vaccine', label: isAr ? 'مطعوم خاص آخر' : 'Other Special Vaccine' }
  ];

  const selectHtml = `
    <select class="sp-vac-name" style="font-weight: bold; width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
      ${options.map(opt => `<option value="${opt.value}" ${currentVal === opt.value ? 'selected' : ''}>${opt.label}</option>`).join('')}
      ${currentVal && !options.some(o => o.value === currentVal) ? `<option value="${currentVal}" selected>${currentVal}</option>` : ''}
    </select>
  `;

  const tr = document.createElement('tr');
  tr.className = 'dynamic-special-dose-row';

  tr.innerHTML = `
    <td>${selectHtml}</td>
    <td>
      <input type="text" class="sp-manufacturer" value="${data.manufacturer || data.type || ''}" placeholder="${isAr ? 'مثال: Menactra / Havrix' : 'e.g. Menactra, Havrix, Typhim Vi'}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td>
      <input type="text" class="sp-date" value="${formatDateDDMMYYYY(data.date || data.meningococcal || data.hepA1 || data.hepA2 || data.typhoid || data.pneumovax || '')}" placeholder="DD/MM/YYYY" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td>
      <input type="text" class="sp-batch" value="${data.batch || data.lot || ''}" placeholder="${isAr ? 'مثال: MEN-01 / HAV-22' : 'e.g. MEN-01, HAV-22'}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td style="text-align: center;">
      <button type="button" class="btn btn-danger" style="padding: 3px 10px; font-size: 0.8rem; background: #EF4444; color: white; border: none; border-radius: 4px; cursor: pointer;" onclick="this.closest('tr').remove()">🗑️</button>
    </td>
  `;
  tbody.appendChild(tr);
}

function handleCfDoseTypeChange(selectEl) {
  const tr = selectEl.closest('tr');
  if (!tr) return;
  const fluYearContainer = tr.querySelector('.cf-flu-year-container');
  if (fluYearContainer) {
    if (selectEl.value === 'flu') {
      fluYearContainer.style.display = 'inline-block';
    } else {
      fluYearContainer.style.display = 'none';
    }
  }
}
window.handleCfDoseTypeChange = handleCfDoseTypeChange;

function addCovidFluDoseRow(vacData) {
  const tbody = document.getElementById('sec6_covid_flu_tbody');
  if (!tbody) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const data = vacData || {};

  let parsed = typeof parseVaccineLabel === 'function' ? parseVaccineLabel(data.label || data.vacName || data.vaccine || '') : { type: 'covid', doseType: 'first' };
  if (data.type) parsed.type = data.type;
  if (data.doseType) parsed.doseType = data.doseType;
  if (data.fluYear) parsed.fluYear = data.fluYear;

  let selectedKey = 'covid_first';
  if (parsed.type === 'flu') {
    selectedKey = 'flu';
  } else if (parsed.doseType === 'second') {
    selectedKey = 'covid_second';
  } else if (parsed.doseType === 'third') {
    selectedKey = 'covid_third';
  } else if (parsed.doseType === 'booster') {
    selectedKey = 'covid_booster';
  }

  const fluYearVal = data.fluYear || parsed.fluYear || '2025/2026';
  const mfrVal = data.mfr !== undefined ? data.mfr : (data.manufacturer !== undefined ? data.manufacturer : '');
  const dateVal = formatDateDDMMYYYY(data.date || data.fluDate || data.covidBrandDate || '');
  const lotVal = data.lot !== undefined ? data.lot : (data.batch !== undefined ? data.batch : '');

  const tr = document.createElement('tr');
  tr.className = 'dynamic-cf-dose-row';

  tr.innerHTML = `
    <td>
      <div style="display: flex; flex-direction: column; gap: 4px;">
        <select class="cf-dose-select" onchange="handleCfDoseTypeChange(this)" style="font-weight: bold; width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
          <option value="covid_first" ${selectedKey === 'covid_first' ? 'selected' : ''}>COVID -19 first dose</option>
          <option value="covid_second" ${selectedKey === 'covid_second' ? 'selected' : ''}>COVID -19 second dose</option>
          <option value="covid_third" ${selectedKey === 'covid_third' ? 'selected' : ''}>COVID -19 third dose</option>
          <option value="covid_booster" ${selectedKey === 'covid_booster' ? 'selected' : ''}>COVID -19 booster dose</option>
          <option value="flu" ${selectedKey === 'flu' ? 'selected' : ''}>${isAr ? 'تطعيم الإنفلونزا الموسمية - flu vaccine year' : 'flu vaccine year (-----)'}</option>
        </select>
        <div class="cf-flu-year-container" style="display: ${selectedKey === 'flu' ? 'inline-block' : 'none'}; margin-top: 2px;">
          <input type="text" class="cf-flu-year" value="${fluYearVal}" placeholder="e.g. 2026 or 2025/2026" style="width: 100%; padding: 4px 6px; font-size: 0.82rem; font-weight: bold; border: 1px solid #0D9488; border-radius: 4px; background: #F0FDF4;" title="Flu Year / Season">
        </div>
      </div>
    </td>
    <td>
      <input type="text" class="cf-manufacturer" value="${mfrVal}" placeholder="${isAr ? 'الشركة / الماركة (مثال: Pfizer-BioNTech / Influvac)' : 'e.g. Pfizer-BioNTech, Moderna, Influvac'}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td>
      <input type="text" class="cf-date" value="${dateVal}" placeholder="DD/MM/YYYY" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td>
      <input type="text" class="cf-batch" value="${lotVal}" placeholder="${isAr ? 'رقم التشغيلة / Batch - Lot No.' : 'e.g. PFI-001, MOD-44, FLU-25'}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td style="text-align: center; vertical-align: middle;">
      <button type="button" class="btn btn-danger" style="padding: 3px 10px; font-size: 0.8rem; background: #EF4444; color: white; border: none; border-radius: 4px; cursor: pointer;" onclick="this.closest('tr').remove()">🗑️</button>
    </td>
  `;
  tbody.appendChild(tr);
}

function updateSec7IncidentBadges() {
  const badgeContainer = document.getElementById('sec7_serial_list_badges');
  const selectBox = document.getElementById('sec7_quick_serial_select');
  const isAr = window.i18n ? window.i18n.isRTL() : false;

  const rows = document.querySelectorAll('#sec7_pep_tbody .dynamic-pep-row');
  if (rows.length === 0) {
    if (badgeContainer) badgeContainer.innerHTML = '<span style="font-weight: 500; font-size: 0.82rem; color: #9CA3AF;">No incident records filed</span>';
    if (selectBox) selectBox.innerHTML = `<option value="">${isAr ? '-- لا توجد بلاغات مسجلة --' : '-- No Serials Filed --'}</option>`;
    return;
  }

  const rawSerials = Array.from(rows).map((r, i) => r.querySelector('.pep-serial-no')?.value || ('INC-2026-' + (i + 1)));

  if (badgeContainer) {
    badgeContainer.innerHTML = rawSerials.map(val => {
      const cleanVal = val.replace(/'/g, "\\'");
      return `<span style="display: inline-flex; align-items: center; gap: 5px; background: #DC2626; color: white; padding: 3px 10px; border-radius: 12px; font-size: 0.78rem; font-family: monospace; font-weight: 800; margin-right: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.15); cursor: pointer;" onclick="openInjuryReportBySerial('${cleanVal}')" title="${isAr ? 'انقر لفتح تقرير إصابة العمل SQE 02.01' : 'Click to open SQE 02.01 Injury Incident Report'}">
        📌 ${val}
        <span style="background: rgba(255,255,255,0.25); padding: 1px 5px; border-radius: 4px; font-size: 0.72rem;">📋 ${isAr ? 'فتح التقرير' : 'Open Report'}</span>
      </span>`;
    }).join(' ');
  }

  if (selectBox) {
    selectBox.innerHTML = `<option value="">${isAr ? '-- اختر رقم البلاغ لفتحه --' : '-- Select Serial to Open --'}</option>` +
      rawSerials.map(val => `<option value="${val}">📌 ${val}</option>`).join('');
  }
}
window.updateSec7IncidentBadges = updateSec7IncidentBadges;

function autoLinkInjuryReportsToSec7() {
  const pepTbody = document.getElementById('sec7_pep_tbody');
  if (!pepTbody) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;

  const empNo = document.getElementById('sec1_personNumber')?.value || '';
  const empName = (document.getElementById('sec1_fullName')?.value || '').toLowerCase();
  const empId = document.getElementById('sec1_nationalId')?.value || '';

  if (!empNo && !empName && !empId) {
    alert(isAr ? 'يرجى اختيار أو تعبئة اسم أو رقم الموظف أولاً.' : 'Please select or enter staff details first.');
    return;
  }

  const injuries = JSON.parse(localStorage.getItem('avh_injuries')) || [];
  let addedCount = 0;

  injuries.forEach((inj, i) => {
    const p1 = inj.part1 || {};
    const injName = (inj.employeeName || p1.name || '').toLowerCase();
    const injFile = (p1.fileNo || '').toString();

    const isMatch = (empNo && injFile && injFile === String(empNo)) || (empName && injName && (empName.includes(injName) || injName.includes(empName)));

    if (isMatch) {
      const cleanFileDigits = String(empNo || '001').replace(/[^0-9]/g, '') || '001';
      const serialNo = inj.id || p1.serialNo || (`INC-2026-${cleanFileDigits}-${String(i + 1).padStart(2, '0')}`);
      const incidentDate = inj.incidentDate || p1.dateTime || new Date().toLocaleDateString();

      const existingSerials = Array.from(pepTbody.querySelectorAll('.pep-serial-no')).map(el => el.value);
      if (!existingSerials.includes(serialNo)) {
        addPepRow({
          serialNo: serialNo,
          incidentDate: incidentDate,
          protocol: 'HBIG / Tetanus / PEP Baseline Protocol (SQE 02.01)',
          indication: p1.exposureType ? (`${p1.exposureType} Exposure`) : (p1.description ? p1.description.substring(0, 60) : 'Needlestick / Body Fluid Exposure'),
          status: inj.status || 'In Progress',
          date: incidentDate
        });
        addedCount++;
      }
    }
  });

  updateSec7IncidentBadges();

  if (typeof showSuccessToast === 'function') {
    if (addedCount > 0) {
      showSuccessToast(isAr ? `تم ربط واستيراد ${addedCount} بلاغات إصابة عمل بنجاح!` : `Auto-linked ${addedCount} SQE 02.01 Injury Reports to Section 7!`, 'Done Successfully!');
    } else {
      showSuccessToast(isAr ? 'كافة بلاغات الإصابة المسجلة مضافة ومربوطة بالفعل.' : 'All filed injury reports for this staff member are already linked in Section 7.', 'Up to Date');
    }
  }
}
window.autoLinkInjuryReportsToSec7 = autoLinkInjuryReportsToSec7;

function addPepRow(pepData) {
  const tbody = document.getElementById('sec7_pep_tbody');
  if (!tbody) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const data = pepData || {};

  const empNo = document.getElementById('sec1_personNumber')?.value || 'EMP';
  const cleanEmpDigits = String(empNo).replace(/[^0-9]/g, '') || '001';
  const currentCount = tbody.querySelectorAll('.dynamic-pep-row').length + 1;
  const autoSerial = data.serialNo || data.incidentId || (`INC-2026-${cleanEmpDigits}-${String(currentCount).padStart(2, '0')}`);

  const tr = document.createElement('tr');
  tr.className = 'dynamic-pep-row';

  tr.innerHTML = `
    <td style="vertical-align: middle;">
      <div style="display: flex; gap: 4px; align-items: center;">
        <input type="text" class="pep-serial-no" value="${autoSerial}" oninput="updateSec7IncidentBadges()" style="font-weight: 800; color: #DC2626; background: #FEF2F2; width: 100%; padding: 6px 8px; border: 1.5px solid #FCA5A5; border-radius: 4px; font-family: monospace; font-size: 0.85rem;" title="Incident Follow-up Serial Number">
        <button type="button" class="btn btn-outline" style="padding: 5px 8px; font-size: 0.78rem; background: white; border: 1.5px solid #EF4444; color: #DC2626; font-weight: bold; border-radius: 4px; cursor: pointer; white-space: nowrap;" onclick="openInjuryReportBySerial(this.previousElementSibling.value)" title="${isAr ? 'فتح تقرير الإصابة SQE 02.01' : 'Open Injury Incident Report SQE 02.01'}">
          📋
        </button>
      </div>
    </td>
    <td>
      <input type="date" class="pep-incident-date" value="${formatDateForInput(data.incidentDate || '')}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td>
      <input type="text" class="pep-protocol" value="${data.protocol || data.medication || ''}" placeholder="${isAr ? 'مثال: Hepatitis B Immune Globulin (HBIG)' : 'e.g. Hepatitis B Immune Globulin (HBIG)'}" style="font-weight: bold; width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td>
      <input type="text" class="pep-indication" value="${data.indication || ''}" placeholder="${isAr ? 'مثال: Needlestick Injury - Source HBsAg Positive' : 'e.g. Needlestick Injury - Source HBsAg Positive'}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td>
      <select class="pep-status" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px; font-weight: 600;">
        <option value="Completed" ${data.status === 'Completed' ? 'selected' : ''}>Completed</option>
        <option value="Not Required" ${data.status === 'Not Required' ? 'selected' : ''}>Not Required</option>
        <option value="In Progress" ${data.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
        <option value="Refused" ${data.status === 'Refused' ? 'selected' : ''}>Refused</option>
      </select>
    </td>
    <td>
      <input type="date" class="pep-date" value="${formatDateForInput(data.date || '')}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
    </td>
    <td style="text-align: center; vertical-align: middle; white-space: nowrap;">
      <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; border-color: #DC2626; color: #DC2626; background: #FEF2F2; font-weight: bold; cursor: pointer; border-radius: 4px; margin-right: 4px;" onclick="openInjuryReportBySerial(this.closest('tr').querySelector('.pep-serial-no').value)" title="${isAr ? 'فتح تقرير الإصابة SQE 02.01' : 'Open SQE 02.01 Report'}">
        📋 ${isAr ? 'فتح SQE 02.01' : 'Open SQE 02.01'}
      </button>
      <button type="button" class="btn btn-danger" style="padding: 4px 8px; font-size: 0.8rem; background: #EF4444; color: white; border: none; border-radius: 4px; cursor: pointer;" onclick="this.closest('tr').remove(); updateSec7IncidentBadges();" title="${isAr ? 'حذف' : 'Delete'}">🗑️</button>
    </td>
  `;
  tbody.appendChild(tr);
  updateSec7IncidentBadges();
}

function addDynamicVaccineRow(tbodyId, vacData) {
  const tbody = document.getElementById(tbodyId);
  if (!tbody) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const data = vacData || {};

  const tr = document.createElement('tr');
  tr.className = 'dynamic-vac-row';
  tr.innerHTML = `
    <td><input type="text" class="dyn-vac-name" value="${data.name || ''}" placeholder="${isAr ? 'اسم المطعوم (مثال: Rabies, HPV)' : 'e.g. Rabies, HPV, Chickenpox'}" style="font-weight: bold; width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td>
      <select class="dyn-vac-dose" style="font-weight: bold; width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;">
        <option value="Dose 1" ${data.dose === 'Dose 1' ? 'selected' : ''}>${isAr ? 'الجرعة 1 (Dose 1)' : 'Dose 1'}</option>
        <option value="Dose 2" ${data.dose === 'Dose 2' ? 'selected' : ''}>${isAr ? 'الجرعة 2 (Dose 2)' : 'Dose 2'}</option>
        <option value="Dose 3" ${data.dose === 'Dose 3' ? 'selected' : ''}>${isAr ? 'الجرعة 3 (Dose 3)' : 'Dose 3'}</option>
        <option value="Dose 4" ${data.dose === 'Dose 4' ? 'selected' : ''}>${isAr ? 'الجرعة 4 (Dose 4)' : 'Dose 4'}</option>
        <option value="Dose 5" ${data.dose === 'Dose 5' ? 'selected' : ''}>${isAr ? 'الجرعة 5 (Dose 5)' : 'Dose 5'}</option>
        <option value="Dose 6" ${data.dose === 'Dose 6' ? 'selected' : ''}>${isAr ? 'الجرعة 6 (Dose 6)' : 'Dose 6'}</option>
        <option value="Dose 7" ${data.dose === 'Dose 7' ? 'selected' : ''}>${isAr ? 'الجرعة 7 (Dose 7)' : 'Dose 7'}</option>
        <option value="Booster" ${data.dose === 'Booster' ? 'selected' : ''}>${isAr ? 'جرعة منشطة (Booster)' : 'Booster'}</option>
      </select>
    </td>
    <td><input type="date" class="dyn-vac-date" value="${formatDateForInput(data.date || '')}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td><input type="text" class="dyn-vac-batch" value="${data.batch || ''}" placeholder="${isAr ? 'رقم التشغيلة (مثال: LOT-991)' : 'e.g. LOT-991'}" style="width: 100%; padding: 6px 8px; border: 1px solid var(--border-color); border-radius: 4px;"></td>
    <td style="text-align: center;">
      <button type="button" class="btn btn-danger" style="padding: 3px 10px; font-size: 0.8rem; background: #EF4444; color: white; border: none; border-radius: 4px; cursor: pointer;" onclick="this.closest('tr').remove()">🗑️</button>
    </td>
  `;
  tbody.appendChild(tr);
}

function togglePregnancyVisibility(genderVal) {
  const gender = genderVal || (document.getElementById('sec1_gender') ? document.getElementById('sec1_gender').value : 'Male');
  const isMale = /^(male|m|ذكر)$/i.test(String(gender).trim());
  const container = document.getElementById('sec2_pregnancy_container');
  const pregInput = document.getElementById('sec2_pregnancyStatus');
  const badge = document.getElementById('sec2_pregnancy_badge');

  if (container) {
    container.style.display = 'block';
  }

  if (pregInput) {
    if (isMale) {
      pregInput.disabled = true;
      pregInput.value = 'Not Pregnant / N/A';
      pregInput.style.background = '#F1F5F9';
      pregInput.style.color = '#94A3B8';
      pregInput.style.borderColor = '#CBD5E1';
      pregInput.style.cursor = 'not-allowed';
      pregInput.style.opacity = '0.65';
      if (badge) {
        badge.textContent = ' (غير ينطبق - ذكر / N/A - Male)';
        badge.style.color = '#94A3B8';
      }
    } else {
      pregInput.disabled = false;
      pregInput.style.background = '#FFFFFF';
      pregInput.style.color = 'var(--text-color, #1E293B)';
      pregInput.style.borderColor = 'var(--border-color, #CBD5E1)';
      pregInput.style.cursor = 'default';
      pregInput.style.opacity = '1.0';
      if (badge) {
        badge.textContent = '';
      }
    }
  }

  // Strictly enforce N/A for Male staff on Q3 (pregnancy test) & Q4 (plan for pregnancy)
  ['q3', 'q4'].forEach(qId => {
    const radYes = document.getElementById(`sec2_${qId}_yes`);
    const radNo = document.getElementById(`sec2_${qId}_no`);
    const radNA = document.getElementById(`sec2_${qId}_na`);
    if (isMale) {
      if (radNA) radNA.checked = true;
      if (radYes) { radYes.disabled = true; radYes.style.cursor = 'not-allowed'; radYes.style.opacity = '0.35'; }
      if (radNo) { radNo.disabled = true; radNo.style.cursor = 'not-allowed'; radNo.style.opacity = '0.35'; }
      if (radNA) { radNA.disabled = false; radNA.style.cursor = 'default'; radNA.style.opacity = '1.0'; }
    } else {
      if (radYes) { radYes.disabled = false; radYes.style.cursor = 'pointer'; radYes.style.opacity = '1.0'; }
      if (radNo) { radNo.disabled = false; radNo.style.cursor = 'pointer'; radNo.style.opacity = '1.0'; }
      if (radNA) { radNA.disabled = false; radNA.style.cursor = 'pointer'; radNA.style.opacity = '1.0'; }
    }
  });
}
window.togglePregnancyVisibility = togglePregnancyVisibility;

function standardizeDateStr(raw, strictDateOnly = false) {
  if (typeof window !== 'undefined' && typeof window.standardizeDateStr === 'function' && window.standardizeDateStr !== standardizeDateStr) {
    return window.standardizeDateStr(raw, strictDateOnly);
  }
  if (!raw) return '';
  let str = String(raw).trim();
  if (!str) return '';

  if (/child|natural|history|vaccin|declarat|n\/a|not vaccin|no need|positive|negative|igg|immune|mui\/ml|titer/i.test(str)) {
    return str;
  }

  let isoMatch = str.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
  if (isoMatch) {
    let [_, year, month, day] = isoMatch;
    day = day.padStart(2, '0');
    month = month.padStart(2, '0');
    return `${day}/${month}/${year}`;
  }

  if (/^\d{4,5}(\.\d+)?$/.test(str) || (typeof raw === 'number' && raw > 10000 && raw < 60000)) {
    const num = parseFloat(str);
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const utcDays = Math.floor(num);
    const msPerDay = 24 * 60 * 60 * 1000;
    const dateObj = new Date(excelEpoch.getTime() + utcDays * msPerDay);
    if (!isNaN(dateObj.getTime())) {
      const d = String(dateObj.getUTCDate()).padStart(2, '0');
      const m = String(dateObj.getUTCMonth() + 1).padStart(2, '0');
      const y = dateObj.getUTCFullYear();
      return `${d}/${m}/${y}`;
    }
  }

  const parts = str.split(/[/.\-]/);
  if (parts.length >= 3) {
    let [p1, p2, p3] = parts;
    p3 = p3.substring(0, 4);
    if (p1.length === 4) {
      return `${p3.padStart(2, '0')}/${p2.padStart(2, '0')}/${p1}`;
    } else if (p3.length === 4) {
      return `${p1.padStart(2, '0')}/${p2.padStart(2, '0')}/${p3}`;
    }
  }
  return str;
}

function formatDateForInput(dateStr) {
  if (!dateStr) return '';
  const str = String(dateStr).trim();
  if (!str) return '';

  if (/child|natural|history|vaccin|declarat|n\/a|not vaccin|no need|positive|negative|igg|immune|mui\/ml|titer/i.test(str)) {
    return str;
  }

  let isoMatch = str.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
  if (isoMatch) {
    let [_, year, month, day] = isoMatch;
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  }

  if (/^\d{4,5}(\.\d+)?$/.test(str) || (typeof dateStr === 'number' && dateStr > 10000 && dateStr < 60000)) {
    const num = parseFloat(str);
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const utcDays = Math.floor(num);
    const msPerDay = 24 * 60 * 60 * 1000;
    const dateObj = new Date(excelEpoch.getTime() + utcDays * msPerDay);
    if (!isNaN(dateObj.getTime())) {
      const d = String(dateObj.getUTCDate()).padStart(2, '0');
      const m = String(dateObj.getUTCMonth() + 1).padStart(2, '0');
      const y = dateObj.getUTCFullYear();
      return `${y}-${m}-${d}`;
    }
  }

  const parts = str.split(/[/.\-]/);
  if (parts.length >= 3) {
    let [p1, p2, p3] = parts;
    p3 = p3.substring(0, 4);
    if (p3.length === 4) {
      return `${p3}-${p2.padStart(2, '0')}-${p1.padStart(2, '0')}`;
    } else if (p1.length === 4) {
      return `${p1}-${p2.padStart(2, '0')}-${p3.padStart(2, '0')}`;
    }
  }

  if (/\d/.test(str)) {
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime()) && parsed.getUTCFullYear() > 1900 && parsed.getUTCFullYear() < 2100) {
      const d = String(parsed.getUTCDate()).padStart(2, '0');
      const m = String(parsed.getUTCMonth() + 1).padStart(2, '0');
      const y = parsed.getUTCFullYear();
      return `${y}-${m}-${d}`;
    }
  }

  return str;
}

function loadStaffRecordIntoForm(emp) {
  const t = key => (window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t(key) : key);
  const isAr = (window.i18n && typeof window.i18n.isRTL === 'function') ? window.i18n.isRTL() : false;
  let selEmp = typeof window.getGlobalSelectedStaff === 'function' ? window.getGlobalSelectedStaff() : null;
  const selEmpKey = selEmp ? (selEmp.empNo || selEmp.id || (selEmp.demographic && selEmp.demographic.personNumber)) : null;
  const selEmpName = selEmp ? (selEmp.name || (selEmp.demographic && selEmp.demographic.fullName) || '') : '';
  const selEmpIdNo = selEmp ? (selEmp.idNo || (selEmp.demographic && selEmp.demographic.nationalId) || '') : '';
  const selEmpSearchVal = selEmpName ? (selEmpName + (selEmpIdNo ? ' (ID: ' + selEmpIdNo + ')' : '')) : '';

  currentEditingEmpNo = emp.empNo || emp.id;
  const staffSearchInput = document.getElementById('staff_search_input');
  if (staffSearchInput) {
    const dispName = emp.name || (emp.demographic ? emp.demographic.fullName : '');
    const dispId = emp.idNo || (emp.demographic ? emp.demographic.nationalId : '');
    staffSearchInput.value = dispName ? (dispName + (dispId ? ' (ID: ' + dispId + ')' : '')) : '';
  }
  const staffQuickSelect = document.getElementById('staff_quick_select');
  if (staffQuickSelect) {
    staffQuickSelect.value = emp.empNo || emp.id || (emp.demographic ? emp.demographic.personNumber : '');
  }
  if (typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(emp);
  }

  // Format last updated date
  let lastUpdatedStr = '';
  if (emp.updated_at) {
    try {
      const d = new Date(emp.updated_at);
      if (!isNaN(d.getTime())) {
        const day = String(d.getDate()).padStart(2, '0');
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const year = d.getFullYear();
        const hrs = String(d.getHours()).padStart(2, '0');
        const mins = String(d.getMinutes()).padStart(2, '0');
        lastUpdatedStr = `${day}/${month}/${year} ${hrs}:${mins}`;
      }
    } catch(e) {}
  }
  if (!lastUpdatedStr) {
    lastUpdatedStr = typeof getCurrentDateDDMMYYYY === 'function' ? getCurrentDateDDMMYYYY() : new Date().toLocaleDateString();
  }

  const syncState = emp.sync_status || 'Synced';
  const syncBadgeHtml = syncState === 'Synced'
    ? `<span style="background: #D1FAE5; color: #065F46; border: 1px solid #10B981; padding: 3px 10px; border-radius: 12px; font-size: 0.78rem; font-weight: 800;">🟢 ${isAr ? 'مزامَن' : 'Synced'}</span>`
    : syncState === 'Pending Sync'
    ? `<span style="background: #FEF3C7; color: #92400E; border: 1px solid #F59E0B; padding: 3px 10px; border-radius: 12px; font-size: 0.78rem; font-weight: 800;">🟠 ${isAr ? 'قيد المزامنة' : 'Pending Sync'}</span>`
    : syncState === 'Syncing'
    ? `<span style="background: #E0F2FE; color: #0369A1; border: 1px solid #0284C7; padding: 3px 10px; border-radius: 12px; font-size: 0.78rem; font-weight: 800;">🔄 ${isAr ? 'جاري المزامنة...' : 'Syncing...'}</span>`
    : `<span style="background: #FEE2E2; color: #991B1B; border: 1px solid #EF4444; padding: 3px 10px; border-radius: 12px; font-size: 0.78rem; font-weight: 800;">🔴 ${isAr ? 'خطأ مزامنة' : 'Sync Error'}</span>`;

  // Update Active Employee Summary Banner
  const nameEl = document.getElementById('summary_emp_name');
  const detailsEl = document.getElementById('summary_emp_details');
  const statusEl = document.getElementById('summary_emp_status');
  if (nameEl) nameEl.textContent = emp.name || emp.fullName || (emp.demographic ? emp.demographic.fullName : 'Staff Member');
  if (detailsEl) {
    const empNo = emp.empNo || emp.id || 'N/A';
    const idNo = emp.idNo || (emp.demographic ? emp.demographic.nationalId : 'N/A');
    const dept = emp.department || (emp.demographic ? emp.demographic.deptTreating : 'N/A');
    const title = emp.jobTitle || (emp.demographic ? emp.demographic.positionName : 'N/A');
    detailsEl.innerHTML = `
      ${isAr ? 'الرقم الوظيفي:' : 'Emp No:'} <strong>${empNo}</strong> | 
      ${isAr ? 'رقم الهوية:' : 'ID:'} <strong>${idNo}</strong> | 
      ${isAr ? 'القسم:' : 'Dept:'} <strong>${dept}</strong> | 
      ${isAr ? 'المسمى:' : 'Title:'} <strong>${title}</strong>
      <br><span style="font-size: 0.8rem; color: #065F46; font-weight: 600;">🕒 ${isAr ? 'آخر تحديث:' : 'Last updated:'} ${lastUpdatedStr}</span>
    `;
  }
  if (statusEl) {
    statusEl.innerHTML = `${syncBadgeHtml} <span style="font-size: 0.82rem; font-weight: 700; color: #065F46; margin-left: 6px;">🟢 ${isAr ? 'بيانات الموظف محملة' : 'Staff Record Loaded'}</span>`;
  }
  const stickyNameEl = document.getElementById('sticky_emp_name_display');
  if (stickyNameEl) {
    const dispName = emp.name || emp.fullName || (emp.demographic ? emp.demographic.fullName : 'Staff Member');
    const dispNo = emp.empNo || emp.id || '';
    stickyNameEl.textContent = dispNo ? `${dispName} (${dispNo})` : dispName;
  }

  // Update Edit Mode Indicator Badge if present
  const indicator = document.getElementById('editModeIndicator');
  const indicatorText = document.getElementById('editModeText');
  if (indicator && indicatorText) {
    indicatorText.innerHTML = `✏️ <strong>${t('editing_mode')}</strong> ${emp.name || (emp.demographic ? emp.demographic.fullName : '')} (${isAr ? 'الرقم الوظيفي:' : 'Emp No:'} ${currentEditingEmpNo})`;
    indicator.style.background = '#FEF3C7';
    indicator.style.borderColor = '#F59E0B';
  }

  const d = emp.demographic || {};
  const h = emp.healthStatus || {};
  const lab = emp.labResults || {};
  const vac = emp.vaccines || {};
  const sp = emp.specialVaccines || {};
  const cf = emp.covidFlu || {};
  const pep = emp.pep || {};

  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (!el) return;
    let cleanVal = (val !== undefined && val !== null) ? String(val).trim() : '';
    if (el.type === 'date' && cleanVal) {
      cleanVal = formatDateForInput(cleanVal);
    }
    if (el.tagName === 'SELECT' && cleanVal) {
      const trimmedClean = cleanVal.toLowerCase();
      let matchedOpt = Array.from(el.options).find(opt => opt.value.trim().toLowerCase() === trimmedClean || opt.textContent.trim().toLowerCase() === trimmedClean);
      if (matchedOpt) {
        cleanVal = matchedOpt.value;
      } else {
        const newOpt = document.createElement('option');
        newOpt.value = cleanVal;
        newOpt.textContent = cleanVal;
        el.appendChild(newOpt);
      }
    }
    el.value = cleanVal;
  };
  const setCheck = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.checked = !!val;
  };

  const rawDob = d.dob || emp.dob || '';
  const isoDob = formatDateForInput(rawDob);

  // Sec 1: Demographic
  const currentGender = d.gender || emp.gender || 'Male';
  setVal('sec1_gender', currentGender);
  setVal('sec1_nationalId', d.nationalId || emp.idNo || emp.nationalId || '');
  setVal('sec1_personNumber', d.personNumber || emp.empNo || emp.id || '');
  setVal('sec1_fullName', d.fullName || emp.name || '');
  setVal('sec1_arabicFullName', d.arabicFullName || emp.arabicName || '');
  setVal('sec1_dob', isoDob);
  const rawAgeVal = d.age || calculateAgeVal(rawDob) || (emp.age ? emp.age + (isAr ? ' سنة' : ' Years') : '');
  setVal('sec1_age', typeof formatAgeToOneDecimal === 'function' ? formatAgeToOneDecimal(rawAgeVal) : rawAgeVal);
  setVal('sec1_idType', d.idType || emp.idType || 'Palestinian ID');
  setVal('sec1_orgName', d.orgName || emp.orgName || (isAr ? 'مستشفى الأوغستا فكتوريا' : 'Augusta Victoria Hospital'));
  setVal('sec1_positionName', d.positionName || emp.jobTitle || emp.positionName || '');
  setVal('sec1_positionArabic', d.positionArabic || emp.positionArabic || '');
  setVal('sec1_startDate', formatDateForInput(d.startDate || emp.startDate || ''));
  setVal('sec1_assignmentEffectiveDate', formatDateForInput(d.assignmentEffectiveDate || emp.assignmentEffectiveDate || ''));
  setVal('sec1_department', d.department || emp.department || '');
  setVal('sec1_deptTreating', d.deptTreating || emp.deptTreating || emp.unit || '');
  setVal('sec1_invasiveProcedure', d.invasiveProcedure || emp.invasiveProcedure || (typeof isInvasiveProcedureStaff === 'function' && isInvasiveProcedureStaff(emp) ? 'Yes' : 'No'));
  const normStatus = typeof normalizeEmploymentStatus === 'function' ? normalizeEmploymentStatus(d.employmentStatus || emp.employmentStatus || emp.workStatus) : (d.employmentStatus || emp.employmentStatus || 'Active Staff');
  setVal('sec1_employmentStatus', normStatus);
  if (typeof handleEmploymentStatusChange === 'function') {
    handleEmploymentStatusChange(normStatus, emp);
  }

  // Sec 2: Health Status & Pre-Vaccination Check List
  togglePregnancyVisibility(currentGender);
  setVal('sec2_pregnancyStatus', h.pregnancyStatus || (emp.contraindications && emp.contraindications.pregnancy ? 'Pregnant' : 'Not Pregnant / N/A'));
  const rawAllergies = h.allergies || (emp.contraindications && emp.contraindications.allergies ? 'Allergic' : '');
  setVal('sec2_allergies', (rawAllergies === 'None' || rawAllergies === 'none') ? '' : rawAllergies);
  setCheck('sec2_feverToday', h.feverToday !== undefined ? !!h.feverToday : !!(emp.checklist && emp.checklist.fever));
  setCheck('sec2_immunodeficient', h.immunodeficient !== undefined ? !!h.immunodeficient : !!(emp.checklist && emp.checklist.immunodeficient));
  setCheck('sec2_steroids', h.steroids !== undefined ? !!h.steroids : !!(emp.checklist && emp.checklist.steroids));

  const clData = emp.preVaccinationChecklist || emp.checklist || {};
  const isMale = /^(male|m|ذكر)$/i.test(String(currentGender).trim());
  for (let i = 1; i <= 11; i++) {
    const qKey = `q${i}`;
    let val = clData[qKey];
    if (isMale && (i === 3 || i === 4)) {
      val = 'N/A';
    } else if (!val) {
      if (i === 5) {
        val = 'Yes';
      } else if (i === 3 && h.pregnancyStatus && h.pregnancyStatus !== 'Not Pregnant / N/A') {
        val = 'Yes';
      } else if (i === 7 && h.immunodeficient) {
        val = 'Yes';
      } else {
        val = 'No';
      }
    }
    const radYes = document.getElementById(`sec2_${qKey}_yes`);
    const radNo = document.getElementById(`sec2_${qKey}_no`);
    const radNA = document.getElementById(`sec2_${qKey}_na`);
    if (val === 'Yes') {
      if (radYes) radYes.checked = true;
    } else if (val === 'N/A' || val === 'NA' || val === 'n/a') {
      if (radNA) radNA.checked = true;
    } else {
      if (radNo) radNo.checked = true;
    }
  }
  togglePregnancyVisibility(currentGender);

  // Sec 3: Lab Results
  const getLabVal = (directVal, objKey, subKey, fallback = '') => {
    if (directVal !== undefined && directVal !== null && String(directVal).trim() !== '') return String(directVal).trim();
    if (lab[objKey]) {
      if (typeof lab[objKey] === 'object' && lab[objKey] !== null) {
        const subVal = lab[objKey][subKey] || lab[objKey].result || lab[objKey].qual1 || lab[objKey].qual2;
        if (subVal !== undefined && subVal !== null && String(subVal).trim() !== '') return String(subVal).trim();
      } else if (String(lab[objKey]).trim() !== '') {
        return String(lab[objKey]).trim();
      }
    }
    return fallback;
  };

  const effectiveDate = d.assignmentEffectiveDate || emp.assignmentEffectiveDate || d.startDate || emp.startDate || '';
  const rawHbsabDate = lab.hbsabDate || (lab.HBsAb && lab.HBsAb.date ? lab.HBsAb.date : '') || emp.hbsabDate || emp.hbvBoosterDate || '';
  const rawHcvDate = lab.hcvDate || (lab.HCV && lab.HCV.date ? lab.HCV.date : '') || emp.hcvDate || '';
  const rawHivDate = lab.hivDate || (lab.HIV && lab.HIV.date ? lab.HIV.date : '') || emp.hivDate || '';
  const rawPpd1Date = lab.ppdStep1Date || (lab.PPD && (lab.PPD.date1 || lab.PPD.date) ? (lab.PPD.date1 || lab.PPD.date) : '') || emp.ppdStep1Date || '';
  const rawPpd2Date = lab.ppdStep2Date || (lab.PPD && lab.PPD.date2 ? lab.PPD.date2 : '') || emp.ppdStep2Date || '';
  const rawVaricellaDate = lab.varicellaIgGDate || (lab.Varicella_IgG && lab.Varicella_IgG.date ? lab.Varicella_IgG.date : '') || emp.varicellaIgGDate || '';
  const rawMumpsDate = lab.mumpsIgGTiterDate || (lab.Mumps_IgG && lab.Mumps_IgG.date ? lab.Mumps_IgG.date : '') || emp.mumpsIgGTiterDate || '';
  const rawMeaslesDate = lab.measlesIgGTiterDate || (lab.Measles_IgG && lab.Measles_IgG.date ? lab.Measles_IgG.date : '') || emp.measlesIgGTiterDate || '';
  const rawRubellaDate = lab.rubellaIgGTiterDate || (lab.Rubella_IgG && lab.Rubella_IgG.date ? lab.Rubella_IgG.date : '') || emp.rubellaIgGTiterDate || '';

  setVal('sec3_manualImmunityStatus', emp.immunityStatus || 'Fully Vaccinated');
  setVal('sec3_hbsabResult', getLabVal(lab.hbsabResult, 'HBsAb', 'result', (emp.hepbTiter !== undefined && emp.hepbTiter !== null ? emp.hepbTiter : '')));
  setVal('sec3_hbsabDate', rawHbsabDate ? formatDateForInput(rawHbsabDate) : '');

  const setSelectWithCustom = (selectId, customInputId, val) => {
    const sel = document.getElementById(selectId);
    const custom = document.getElementById(customInputId);
    if (!sel) return;
    const cleanVal = (val !== undefined && val !== null) ? String(val).trim() : '';
    if (!cleanVal) {
      sel.value = '';
      if (custom) {
        custom.value = '';
        custom.style.display = 'none';
      }
      return;
    }
    const options = Array.from(sel.options).filter(opt => opt.value !== 'Other' && opt.value !== '');
    const matchedOpt = options.find(opt => opt.value.trim().toLowerCase() === cleanVal.toLowerCase() || opt.textContent.trim().toLowerCase() === cleanVal.toLowerCase());
    if (matchedOpt) {
      sel.value = matchedOpt.value;
      if (custom) {
        custom.value = '';
        custom.style.display = 'none';
      }
    } else {
      sel.value = 'Other';
      if (custom) {
        custom.value = cleanVal === 'Other' ? '' : cleanVal;
        custom.style.display = 'block';
      }
    }
  };

  const hbsagRes = getLabVal(lab.hbsagResult || (lab.HBsAg ? lab.HBsAg.result : ''), 'HBsAg', 'result', '');
  const rawHbsagDate = lab.hbsagDate || (lab.HBsAg && lab.HBsAg.date ? lab.HBsAg.date : '') || '';
  setSelectWithCustom('sec3_hbsagResult', 'sec3_hbsagResult_custom', hbsagRes);
  setVal('sec3_hbsagDate', hbsagRes && rawHbsagDate ? formatDateForInput(rawHbsagDate) : '');

  setVal('sec3_engrixDose1', formatDateForInput(lab.engrixDose1 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d1 : '') || ''));
  setVal('sec3_engrixDose2', formatDateForInput(lab.engrixDose2 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d2 : '') || ''));
  setVal('sec3_engrixDose3', formatDateForInput(lab.engrixDose3 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d3 : '') || ''));
  setVal('sec3_engrixBooster', formatDateForInput(lab.engrixBooster || (vac['Hepatitis B'] ? vac['Hepatitis B'].d5 : '') || emp.hbvBoosterDate || ''));

  const hcvRes = getLabVal(lab.hcvResult, 'HCV', 'result', '');
  setSelectWithCustom('sec3_hcvResult', 'sec3_hcvResult_custom', hcvRes);
  setVal('sec3_hcvDate', hcvRes && rawHcvDate ? formatDateForInput(rawHcvDate) : '');

  const hivRes = getLabVal(lab.hivResult, 'HIV', 'result', '');
  setSelectWithCustom('sec3_hivResult', 'sec3_hivResult_custom', hivRes);
  setVal('sec3_hivDate', hivRes && rawHivDate ? formatDateForInput(rawHivDate) : '');

  const ppd1Res = getLabVal(lab.ppdStep1Result, 'PPD', 'qual1', '');
  setSelectWithCustom('sec3_ppdStep1Result', 'sec3_ppdStep1Result_custom', ppd1Res);
  setVal('sec3_ppdStep1Induration', ppd1Res ? (lab.ppdStep1Induration || (lab.PPD ? lab.PPD.test1 : '') || '0mm') : '');
  setVal('sec3_ppdStep1Date', ppd1Res && rawPpd1Date ? formatDateForInput(rawPpd1Date) : '');

  const ppd2Res = getLabVal(lab.ppdStep2Result, 'PPD', 'qual2', '');
  setSelectWithCustom('sec3_ppdStep2Result', 'sec3_ppdStep2Result_custom', ppd2Res);
  setVal('sec3_ppdStep2Induration', ppd2Res ? (lab.ppdStep2Induration || (lab.PPD ? lab.PPD.test2 : '') || '0mm') : '');
  setVal('sec3_ppdStep2Date', ppd2Res && rawPpd2Date ? formatDateForInput(rawPpd2Date) : '');

  const varRes = getLabVal(lab.varicellaIgG || vac.varicellaIgG, 'Varicella_IgG', 'result', '');
  setSelectWithCustom('sec3_varicellaIgG', 'sec3_varicellaIgG_custom', varRes);
  setVal('sec3_varicellaIgGDate', varRes && rawVaricellaDate ? formatDateForInput(rawVaricellaDate) : '');

  const mumpsRes = getLabVal(lab.mumpsIgGTiter, 'Mumps_IgG', 'result', '');
  setSelectWithCustom('sec3_mumpsIgGTiter', 'sec3_mumpsIgGTiter_custom', mumpsRes);
  setVal('sec3_mumpsIgGTiterDate', mumpsRes && rawMumpsDate ? formatDateForInput(rawMumpsDate) : '');

  const measlesRes = getLabVal(lab.measlesIgGTiter, 'Measles_IgG', 'result', '');
  setSelectWithCustom('sec3_measlesIgGTiter', 'sec3_measlesIgGTiter_custom', measlesRes);
  setVal('sec3_measlesIgGTiterDate', measlesRes && rawMeaslesDate ? formatDateForInput(rawMeaslesDate) : '');

  const rubellaRes = getLabVal(lab.rubellaIgGTiter, 'Rubella_IgG', 'result', '');
  setSelectWithCustom('sec3_rubellaIgGTiter', 'sec3_rubellaIgGTiter_custom', rubellaRes);
  setVal('sec3_rubellaIgGTiterDate', rubellaRes && rawRubellaDate ? formatDateForInput(rawRubellaDate) : '');

  const otherRes = lab.otherLabResult || '';
  setVal('sec3_otherLabResult', otherRes);
  setVal('sec3_otherLabDate', otherRes && lab.otherLabDate ? formatDateForInput(lab.otherLabDate) : '');

  // Sec 4: Vaccines
  setVal('sec4_ipvDate', formatDateDDMMYYYY(vac.ipvDate || (vac.IPV ? (vac.IPV.d5 || vac.IPV.d1) : '') || ''));
  setVal('sec4_tdapDate', formatDateDDMMYYYY(vac.tdapDate || (vac.Tdap ? (vac.Tdap.d5 || vac.Tdap.d1) : '') || ''));
  setVal('sec4_mmrDose1', formatDateDDMMYYYY(vac.mmrDose1 || (vac.MMR ? vac.MMR.d1 : '') || ''));
  setVal('sec4_mmrDose2', formatDateDDMMYYYY(vac.mmrDose2 || (vac.MMR ? vac.MMR.d2 || vac.MMR.d5 : '') || ''));
  let cpDose2Val = vac.chickenpoxDose2 || vac.chickenpoxDose2Date || '';
  if (/positive|negative|igg|natural|infected/i.test(cpDose2Val)) {
    if (!varRes || varRes === 'Natural Immunity') {
      varRes = cpDose2Val;
    }
    cpDose2Val = '';
  }

  setVal('sec4_chickenpoxStatus', vac.chickenpoxStatus || (vac['Varicella Zoster (Chicken pox)'] ? '2 doses vaccine' : ''));
  setVal('sec4_chickenpoxDose1', formatDateDDMMYYYY(vac.chickenpoxDose1 || vac.chickenpoxDose1Date || vac.chickenpoxDateDose1 || ''));
  setVal('sec4_chickenpoxDose2', formatDateDDMMYYYY(cpDose2Val));
  setVal('sec4_varicellaIgG', varRes || lab.varicellaIgG || (emp.labResults ? emp.labResults.varicellaIgG : '') || '');
  setVal('sec4_varicellaIgGDate', rawVaricellaDate ? formatDateDDMMYYYY(rawVaricellaDate) : '');

  const coreTbody = document.getElementById('sec4_core_vaccines_tbody');
  if (coreTbody) {
    coreTbody.querySelectorAll('.dynamic-core-dose-row').forEach(row => row.remove());
    if (vac.additionalCoreDoses && Array.isArray(vac.additionalCoreDoses)) {
      vac.additionalCoreDoses.forEach(cd => addCoreVaccineDoseRow(cd));
    }
  }

  const hasSec5 = !!(sp.meningococcal || sp.hepA1 || sp.hepA2 || sp.typhoid || sp.pneumovax || (Array.isArray(sp.additionalSpecialDoses) && sp.additionalSpecialDoses.some(d => d.date || d.vacName)));
  const hasSec6 = !!(cf.fluDate || cf.covidBrandDate || cf.flu2324 || (Array.isArray(cf.additionalCovidFluDoses) && cf.additionalCovidFluDoses.some(d => d.date || d.vacName)));
  const hasSec7 = !!((Array.isArray(pep.additionalPepRecords) && pep.additionalPepRecords.some(p => p.incidentDate || p.protocol || p.date)) || (pep.status && pep.status !== 'No Incident Reported' && pep.status !== 'Clear'));

  // Sec 5: Special Vaccines
  const spTbody = document.getElementById('sec5_special_vaccines_tbody');
  if (spTbody) {
    spTbody.innerHTML = '';
    const pneDate = sp.pneumovax || sp.pnemovax || '';
    if (sp.additionalSpecialDoses && Array.isArray(sp.additionalSpecialDoses) && sp.additionalSpecialDoses.length > 0) {
      let foundPne = false;
      sp.additionalSpecialDoses.forEach(sd => {
        const vName = (sd.vacName || sd.name || '').toLowerCase();
        if (vName.includes('pneumo') || vName.includes('pnemovax')) {
          foundPne = true;
          if (!sd.date && pneDate) {
            sd.date = formatDateForInput(pneDate);
          }
        }
        addSpecialVaccineDoseRow(sd);
      });
      if (!foundPne && pneDate) {
        addSpecialVaccineDoseRow({ vacName: 'Pneumovax (Pneumococcal)', manufacturer: 'Pneumovax 23', date: formatDateForInput(pneDate), batch: '' });
      }
    } else {
      const defaultSpecialRows = [
        { vacName: 'Meningiococcal A, C', manufacturer: 'Menactra', date: formatDateForInput(sp.meningococcal || ''), batch: '' },
        { vacName: 'Hepatitis A Dose 1', manufacturer: 'Havrix', date: formatDateForInput(sp.hepA1 || ''), batch: '' },
        { vacName: 'Hepatitis A Dose 2', manufacturer: 'Havrix', date: formatDateForInput(sp.hepA2 || ''), batch: '' },
        { vacName: 'Typhoid Vaccine', manufacturer: 'Typhim Vi', date: formatDateForInput(sp.typhoid || ''), batch: '' },
        { vacName: 'Pneumovax (Pneumococcal)', manufacturer: 'Pneumovax 23', date: formatDateForInput(pneDate), batch: '' }
      ];
      defaultSpecialRows.forEach(row => addSpecialVaccineDoseRow(row));
    }
    // Collapse Section 5 by default for all staff
    toggleSectionCollapse(5, false);
  }

  // Sec 6: Covid & Flu
  const cfTbody = document.getElementById('sec6_covid_flu_tbody');
  if (cfTbody) {
    cfTbody.innerHTML = '';
    const canonicalRecords = typeof getCanonicalVaccineRecords === 'function' ? getCanonicalVaccineRecords(emp) : [];
    if (canonicalRecords && canonicalRecords.length > 0) {
      canonicalRecords.forEach(cd => addCovidFluDoseRow(cd));
    } else {
      addCovidFluDoseRow({ type: 'covid', doseType: 'first', date: '', mfr: '', lot: '' });
    }
    // Collapse Section 6 by default for all staff
    toggleSectionCollapse(6, false);
  }

  // Sec 7: PEP & Incident Follow-Up
  const pepTbody = document.getElementById('sec7_pep_tbody');
  if (pepTbody) {
    pepTbody.innerHTML = '';
    
    let allRecords = (pep.additionalPepRecords && Array.isArray(pep.additionalPepRecords)) ? [...pep.additionalPepRecords] : [];
    
    // Clean and filter out any fake dummy baseline records
    allRecords = allRecords.filter(r => r && r.protocol !== 'Baseline Exposure Surveillance' && r.indication !== 'No Active Incident Reported' && (r.serialNo || r.incidentDate || r.date || (r.protocol && r.protocol.trim())));

    // Also merge all SQE 02.01 injury reports matching this staff member
    const injuries = JSON.parse(localStorage.getItem('avh_injuries')) || [];
    const empNo = emp.empNo || emp.id || (emp.demographic ? emp.demographic.personNumber : '');
    const empName = (emp.name || (emp.demographic ? emp.demographic.fullName : '') || '').toLowerCase();

    injuries.forEach((inj, i) => {
      const p1 = inj.part1 || {};
      const injName = (inj.employeeName || p1.name || '').toLowerCase();
      const injFile = (p1.fileNo || '').toString();
      
      const isMatch = (empNo && injFile && injFile === String(empNo)) || (empName && injName && (empName.includes(injName) || injName.includes(empName)));
      
      if (isMatch) {
        const cleanFileDigits = String(empNo || '001').replace(/[^0-9]/g, '') || '001';
        const serialNo = inj.id || p1.serialNo || (`INC-2026-${cleanFileDigits}-${String(i + 1).padStart(2, '0')}`);
        const incidentDate = inj.incidentDate || p1.dateTime || new Date().toLocaleDateString();
        
        // Avoid duplicates by serial number
        if (!allRecords.some(r => r.serialNo === serialNo || r.incidentId === serialNo)) {
          allRecords.push({
            serialNo: serialNo,
            incidentDate: incidentDate,
            protocol: 'HBIG / Tetanus / PEP Baseline Protocol (SQE 02.01)',
            indication: p1.exposureType ? (`${p1.exposureType} Exposure`) : (p1.description ? p1.description.substring(0, 60) : 'Needlestick / Body Fluid Exposure'),
            status: inj.status || 'In Progress',
            date: incidentDate
          });
        }
      }
    });

    if (allRecords.length > 0) {
      allRecords.forEach(pd => addPepRow(pd));
    }

    // Collapse Section 7 by default for all staff
    toggleSectionCollapse(7, false);
    updateSec7IncidentBadges();
  }

  // Record freshly loaded: clear unsaved dirty flag
  if (typeof markStaffFormClean === 'function') {
    markStaffFormClean();
  }
}

function calculateAgeFromDOB(dobStr) {
  document.getElementById('sec1_age').value = calculateAgeVal(dobStr);
}

function calculateAgeVal(dobStr) {
  if (!dobStr) return '';
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const birth = new Date(dobStr);
  if (isNaN(birth.getTime())) return '';
  const now = new Date();
  const diffTime = Math.abs(now - birth);
  const diffYears = diffTime / (1000 * 60 * 60 * 24 * 365.25);
  if (diffYears <= 0) return '';
  return diffYears.toFixed(1) + (isAr ? ' سنة' : ' Years');
}

function resetFormForNewStaff(isNewButton = false) {
  currentEditingEmpNo = null;
  if (typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(null);
  }
  const t = key => window.i18n ? window.i18n.t(key) : key;
  const isAr = window.i18n ? window.i18n.isRTL() : false;

  const form = document.getElementById('unifiedStaffForm');
  if (form) {
    form.reset();
    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(el => {
      if (el.type === 'checkbox' || el.type === 'radio') {
        el.checked = false;
      } else if (el.id === 'sec1_orgName') {
        el.value = isAr ? 'مستشفى الأوغستا فكتوريا' : 'Augusta Victoria Hospital';
      } else if (el.id === 'sec1_personNumber' && isNewButton) {
        el.value = 'EMP-' + Math.floor(1000 + Math.random() * 9000);
      } else if (el.id === 'sec1_staffGroup') {
        el.value = 'Minimum Plan';
      } else {
        el.value = '';
      }
    });
    const customInputs = form.querySelectorAll('[id$="_custom"]');
    customInputs.forEach(ci => {
      ci.value = '';
      ci.style.display = 'none';
    });
    for (let i = 1; i <= 11; i++) {
      if (i === 3 || i === 4) {
        const radNA = document.getElementById(`sec2_q${i}_na`);
        if (radNA) radNA.checked = true;
      } else if (i === 5) {
        const radYes = document.getElementById(`sec2_q${i}_yes`);
        if (radYes) radYes.checked = true;
      } else {
        const radNo = document.getElementById(`sec2_q${i}_no`);
        if (radNo) radNo.checked = true;
      }
    }
  }

  const coreTbody = document.getElementById('sec4_core_vaccines_tbody');
  if (coreTbody) {
    coreTbody.querySelectorAll('.dynamic-core-dose-row').forEach(row => row.remove());
  }
  const customTbody = document.getElementById('sec4_custom_tbody');
  if (customTbody) {
    customTbody.querySelectorAll('.dynamic-vac-row').forEach(row => row.remove());
  }
  const spTbody = document.getElementById('sec5_special_vaccines_tbody');
  if (spTbody) {
    spTbody.querySelectorAll('.dynamic-special-dose-row').forEach(row => row.remove());
  }
  const cfTbody = document.getElementById('sec6_covid_flu_tbody');
  if (cfTbody) {
    cfTbody.querySelectorAll('.dynamic-cf-dose-row').forEach(row => row.remove());
  }

  const quickSelect = document.getElementById('staff_quick_select');
  if (quickSelect) quickSelect.value = '';

  toggleSectionCollapse(5, false);
  toggleSectionCollapse(6, false);
  toggleSectionCollapse(7, false);

  const searchInput = document.getElementById('staff_search_input');
  if (searchInput) searchInput.value = '';
  const resultsBox = document.getElementById('staff_search_results');
  if (resultsBox) resultsBox.style.display = 'none';

  const nameEl = document.getElementById('summary_emp_name');
  const detailsEl = document.getElementById('summary_emp_details');
  const statusEl = document.getElementById('summary_emp_status');

  if (isNewButton) {
    if (nameEl) nameEl.textContent = isAr ? 'تسجيل موظف جديد' : 'New Staff Registration';
    if (detailsEl) detailsEl.textContent = isAr ? 'أدخل معلومات الموظف الجديد في الأقسام الـ 7 أدناه' : 'Ready to enter new staff member across all 7 sections below';
    if (statusEl) statusEl.innerHTML = `➕ ${isAr ? 'نموذج موظف جديد' : 'New Employee Form Mode'}`;
    const stickyNameEl = document.getElementById('sticky_emp_name_display');
    if (stickyNameEl) stickyNameEl.textContent = isAr ? 'موظف جديد (غير محفوظ)' : 'New Staff (Not Saved)';
  } else {
    if (nameEl) nameEl.textContent = isAr ? '-- ابحث أو اختر موظفاً --' : '-- Search or Select Employee --';
    if (detailsEl) detailsEl.textContent = isAr ? 'يرجى البحث بالاسم أو الهوية أو الرقم الوظيفي، أو الاختيار من القائمة لعرض وتحديث السجل' : 'Please search by Name, Emp No, or ID, or select an employee from the dropdown to load saved data.';
    if (statusEl) statusEl.innerHTML = `🔍 ${isAr ? 'جاهز للبحث / الإدخال' : 'Ready for Search / Selection'}`;
    const stickyNameEl = document.getElementById('sticky_emp_name_display');
    if (stickyNameEl) stickyNameEl.textContent = isAr ? 'لم يتم تحديد موظف' : 'No staff selected';
  }
}

async function saveAndAutoFillStaffForm(sectionNum = null, actionType = null) {
  // Normalize arguments if an event object or action string was passed as first argument
  if (sectionNum && typeof sectionNum === 'object' && sectionNum.preventDefault) {
    sectionNum = null;
  } else if (typeof sectionNum === 'string' && (sectionNum === 'update' || sectionNum === 'save' || sectionNum === 'force_update')) {
    actionType = sectionNum;
    sectionNum = null;
  }
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);

  const personNo = document.getElementById('sec1_personNumber')?.value.trim() || '';
  const natId = document.getElementById('sec1_nationalId')?.value.trim() || '';
  const fullName = document.getElementById('sec1_fullName')?.value.trim() || '';

  if (!fullName && !personNo && !natId) {
    alert(isAr 
      ? '⚠️ يرجى إدخال الاسم أو الرقم الوظيفي أو رقم الهوية على الأقل لحفظ البيانات.' 
      : '⚠️ Please enter at least Full Name, Emp No, or National ID to save.'
    );
    return null;
  }

  // 1. Search existing employee by National ID FIRST, then Person Number
  const existingEmp = employees.find(e => {
    const eNatId = String(e.idNo || e.demographic?.nationalId || '').trim();
    if (natId && eNatId && eNatId.toLowerCase() !== 'n/a' && eNatId.toLowerCase() !== 'undefined' && eNatId === natId) return true;

    const eEmpNo = String(e.empNo || e.id || e.demographic?.personNumber || '').trim();
    if (personNo && eEmpNo && eEmpNo.toLowerCase() !== 'n/a' && eEmpNo.toLowerCase() !== 'undefined' && eEmpNo.toLowerCase() === personNo.toLowerCase()) return true;

    return false;
  }) || null;

  if (existingEmp) {
    currentEditingEmpNo = existingEmp.empNo || existingEmp.id;
  }

  const deptVal = document.getElementById('sec1_department')?.value?.trim() || (existingEmp ? (existingEmp.department || existingEmp.demographic?.department) : '') || 'General Medical';
  const unitVal = document.getElementById('sec1_deptTreating')?.value || (existingEmp ? (existingEmp.demographic?.deptTreating || existingEmp.unit) : '');
  const groupVal = document.getElementById('sec1_staffGroup')?.value || 'Extended Program';
  const invVal = document.getElementById('sec1_invasiveProcedure')?.value || 'No';

  // Build canonical COVID/Flu records array first to prevent referencing empData before initialization finishes
  const cfRows = Array.from(document.querySelectorAll('#sec6_covid_flu_tbody .dynamic-cf-dose-row'));
  const canonicalVaccineList = [];
  cfRows.forEach((row, idx) => {
    const doseSel = row.querySelector('.cf-dose-select')?.value || '';
    const fluYearVal = row.querySelector('.cf-flu-year')?.value?.trim() || '';
    const mfrVal = row.querySelector('.cf-manufacturer')?.value?.trim() || '';
    const dateVal = row.querySelector('.cf-date')?.value?.trim() || '';
    const lotVal = row.querySelector('.cf-batch')?.value?.trim() || '';

    if (!dateVal && !mfrVal && !lotVal) return;

    let parsed = typeof parseVaccineLabel === 'function' ? parseVaccineLabel(doseSel) : { type: 'covid', doseType: 'first' };
    if (doseSel === 'flu') {
      parsed = { type: 'flu', doseType: 'annual', fluYear: fluYearVal || '2025/2026' };
    } else if (doseSel === 'covid_first') {
      parsed = { type: 'covid', doseType: 'first' };
    } else if (doseSel === 'covid_second') {
      parsed = { type: 'covid', doseType: 'second' };
    } else if (doseSel === 'covid_third') {
      parsed = { type: 'covid', doseType: 'third' };
    } else if (doseSel === 'covid_booster') {
      parsed = { type: 'covid', doseType: 'booster' };
    }

    const rawObj = {
      id: `sec6_${idx}_${Date.now()}`,
      type: parsed.type,
      doseType: parsed.doseType,
      fluYear: parsed.fluYear || fluYearVal,
      mfr: mfrVal,
      date: dateVal,
      lot: lotVal
    };

    const rec = typeof normalizeSingleRecord === 'function' ? normalizeSingleRecord(rawObj, rawObj.id) : rawObj;
    canonicalVaccineList.push(rec);
  });

  const selectedGender = document.getElementById('sec1_gender')?.value || 'Male';
  const isMaleStaff = /^(male|m|ذكر)$/i.test(String(selectedGender).trim());

  const empData = {
    id: personNo || (existingEmp ? existingEmp.id : 'EMP-' + Date.now().toString().slice(-4)),
    empNo: personNo || (existingEmp ? existingEmp.empNo : 'EMP-' + Date.now().toString().slice(-4)),
    idNo: natId || (existingEmp ? existingEmp.idNo : 'N/A'),
    name: fullName || (existingEmp ? existingEmp.name : 'Staff Member'),
    gender: selectedGender,
    department: deptVal,
    unit: unitVal,
    jobTitle: document.getElementById('sec1_positionName')?.value.trim() || 'Healthcare Staff',
    staffGroup: groupVal,
    invasiveProcedure: invVal,
    employmentStatus: (typeof normalizeEmploymentStatus === 'function') ? normalizeEmploymentStatus(document.getElementById('sec1_employmentStatus')?.value) : (document.getElementById('sec1_employmentStatus')?.value || 'Active Staff'),
    workStatus: (typeof normalizeEmploymentStatus === 'function') ? normalizeEmploymentStatus(document.getElementById('sec1_employmentStatus')?.value) : (document.getElementById('sec1_employmentStatus')?.value || 'Active Staff'),
    isArchived: ((typeof normalizeEmploymentStatus === 'function' ? normalizeEmploymentStatus(document.getElementById('sec1_employmentStatus')?.value) : (document.getElementById('sec1_employmentStatus')?.value || 'Active Staff')) !== 'Active Staff'),
    archived: ((typeof normalizeEmploymentStatus === 'function' ? normalizeEmploymentStatus(document.getElementById('sec1_employmentStatus')?.value) : (document.getElementById('sec1_employmentStatus')?.value || 'Active Staff')) !== 'Active Staff'),
    immunityStatus: document.getElementById('sec3_manualImmunityStatus')?.value || (existingEmp ? existingEmp.immunityStatus : 'Fully Vaccinated'),
    hepbTiter: (document.getElementById('sec3_hbsabResult')?.value !== undefined && document.getElementById('sec3_hbsabResult')?.value !== null && document.getElementById('sec3_hbsabResult')?.value.trim() !== '') ? document.getElementById('sec3_hbsabResult')?.value.trim() : '>10 mIU/mL',
    lastVaccineDate: document.getElementById('sec3_engrixDose3')?.value || new Date().toLocaleDateString(),
    updated_at: new Date().toISOString(),
    updated_by: typeof getCurrentSystemUserName === 'function' ? getCurrentSystemUserName() : 'System User',

    demographic: {
      nationalId: document.getElementById('sec1_nationalId')?.value || '',
      personNumber: document.getElementById('sec1_personNumber')?.value || '',
      fullName: document.getElementById('sec1_fullName')?.value || '',
      arabicFullName: document.getElementById('sec1_arabicFullName')?.value || '',
      dob: document.getElementById('sec1_dob')?.value || '',
      age: document.getElementById('sec1_age')?.value || '',
      gender: selectedGender,
      idType: document.getElementById('sec1_idType')?.value || '',
      orgName: document.getElementById('sec1_orgName')?.value || '',
      positionName: document.getElementById('sec1_positionName')?.value || '',
      positionArabic: document.getElementById('sec1_positionArabic')?.value || '',
      startDate: document.getElementById('sec1_startDate') ? document.getElementById('sec1_startDate').value : '',
      assignmentEffectiveDate: document.getElementById('sec1_assignmentEffectiveDate')?.value || '',
      staffGroup: groupVal,
      deptTreating: unitVal,
      department: deptVal,
      invasiveProcedure: invVal,
      employmentStatus: (typeof normalizeEmploymentStatus === 'function') ? normalizeEmploymentStatus(document.getElementById('sec1_employmentStatus')?.value) : (document.getElementById('sec1_employmentStatus')?.value || 'Active Staff'),
      isArchived: ((typeof normalizeEmploymentStatus === 'function' ? normalizeEmploymentStatus(document.getElementById('sec1_employmentStatus')?.value) : (document.getElementById('sec1_employmentStatus')?.value || 'Active Staff')) !== 'Active Staff'),
      archived: ((typeof normalizeEmploymentStatus === 'function' ? normalizeEmploymentStatus(document.getElementById('sec1_employmentStatus')?.value) : (document.getElementById('sec1_employmentStatus')?.value || 'Active Staff')) !== 'Active Staff')
    },

    healthStatus: {
      pregnancyStatus: isMaleStaff ? 'Not Pregnant / N/A' : (document.getElementById('sec2_pregnancyStatus')?.value || ''),
      allergies: document.getElementById('sec2_allergies')?.value || '',
      feverToday: document.getElementById('sec2_feverToday') ? document.getElementById('sec2_feverToday').checked : false,
      immunodeficient: document.getElementById('sec2_immunodeficient') ? document.getElementById('sec2_immunodeficient').checked : false,
      steroids: document.getElementById('sec2_steroids') ? document.getElementById('sec2_steroids').checked : false
    },

    preVaccinationChecklist: (() => {
      const cl = {};
      for (let i = 1; i <= 11; i++) {
        const qKey = `q${i}`;
        if (isMaleStaff && (i === 3 || i === 4)) {
          cl[qKey] = 'N/A';
          continue;
        }
        const radYes = document.getElementById(`sec2_${qKey}_yes`);
        const radNo = document.getElementById(`sec2_${qKey}_no`);
        const radNA = document.getElementById(`sec2_${qKey}_na`);
        if (radYes && radYes.checked) {
          cl[qKey] = 'Yes';
        } else if (radNA && radNA.checked) {
          cl[qKey] = 'N/A';
        } else if (radNo && radNo.checked) {
          cl[qKey] = 'No';
        } else {
          cl[qKey] = ((existingEmp && (existingEmp.preVaccinationChecklist || existingEmp.checklist)) || {})[qKey] || (i === 5 ? 'Yes' : 'No');
        }
      }
      return cl;
    })(),

    checklist: (() => {
      const cl = {};
      for (let i = 1; i <= 11; i++) {
        const qKey = `q${i}`;
        if (isMaleStaff && (i === 3 || i === 4)) {
          cl[qKey] = 'N/A';
          continue;
        }
        const radYes = document.getElementById(`sec2_${qKey}_yes`);
        const radNo = document.getElementById(`sec2_${qKey}_no`);
        const radNA = document.getElementById(`sec2_${qKey}_na`);
        if (radYes && radYes.checked) {
          cl[qKey] = 'Yes';
        } else if (radNA && radNA.checked) {
          cl[qKey] = 'N/A';
        } else if (radNo && radNo.checked) {
          cl[qKey] = 'No';
        } else {
          cl[qKey] = ((existingEmp && (existingEmp.preVaccinationChecklist || existingEmp.checklist)) || {})[qKey] || (i === 5 ? 'Yes' : 'No');
        }
      }
      return cl;
    })(),

    labResults: (() => {
      const hbsabResult = document.getElementById('sec3_hbsabResult')?.value?.trim() ?? '';
      const hbsagResult = getSelectOrCustomVal('sec3_hbsagResult', 'sec3_hbsagResult_custom');
      const hcvResult = getSelectOrCustomVal('sec3_hcvResult', 'sec3_hcvResult_custom');
      const hivResult = getSelectOrCustomVal('sec3_hivResult', 'sec3_hivResult_custom');
      const ppdStep1Result = getSelectOrCustomVal('sec3_ppdStep1Result', 'sec3_ppdStep1Result_custom');
      const ppdStep2Result = getSelectOrCustomVal('sec3_ppdStep2Result', 'sec3_ppdStep2Result_custom');
      const varicellaIgG = getSelectOrCustomVal('sec3_varicellaIgG', 'sec3_varicellaIgG_custom') || document.getElementById('sec4_varicellaIgG')?.value?.trim() || '';
      const mumpsIgGTiter = getSelectOrCustomVal('sec3_mumpsIgGTiter', 'sec3_mumpsIgGTiter_custom');
      const measlesIgGTiter = getSelectOrCustomVal('sec3_measlesIgGTiter', 'sec3_measlesIgGTiter_custom');
      const rubellaIgGTiter = getSelectOrCustomVal('sec3_rubellaIgGTiter', 'sec3_rubellaIgGTiter_custom');
      const otherLabResult = document.getElementById('sec3_otherLabResult')?.value?.trim() ?? '';

      return {
        hbsabResult,
        hbsabDate: hbsabResult ? (document.getElementById('sec3_hbsabDate')?.value ?? '') : '',
        engrixDose1: document.getElementById('sec3_engrixDose1')?.value ?? '',
        engrixDose2: document.getElementById('sec3_engrixDose2')?.value ?? '',
        engrixDose3: document.getElementById('sec3_engrixDose3')?.value ?? '',
        engrixBooster: document.getElementById('sec3_engrixBooster')?.value ?? '',
        hbsagResult,
        hbsagDate: hbsagResult ? (document.getElementById('sec3_hbsagDate')?.value ?? '') : '',
        hcvResult,
        hcvDate: hcvResult ? (document.getElementById('sec3_hcvDate')?.value ?? '') : '',
        hivResult,
        hivDate: hivResult ? (document.getElementById('sec3_hivDate')?.value ?? '') : '',
        ppdStep1Result,
        ppdStep1Induration: ppdStep1Result ? (document.getElementById('sec3_ppdStep1Induration')?.value ?? '') : '',
        ppdStep1Date: ppdStep1Result ? (document.getElementById('sec3_ppdStep1Date')?.value ?? '') : '',
        ppdStep2Result,
        ppdStep2Induration: ppdStep2Result ? (document.getElementById('sec3_ppdStep2Induration')?.value ?? '') : '',
        ppdStep2Date: ppdStep2Result ? (document.getElementById('sec3_ppdStep2Date')?.value ?? '') : '',
        varicellaIgG,
        varicellaIgGDate: varicellaIgG ? (document.getElementById('sec3_varicellaIgGDate')?.value || document.getElementById('sec4_varicellaIgGDate')?.value || '') : '',
        mumpsIgGTiter,
        mumpsIgGTiterDate: mumpsIgGTiter ? (document.getElementById('sec3_mumpsIgGTiterDate')?.value ?? '') : '',
        measlesIgGTiter,
        measlesIgGTiterDate: measlesIgGTiter ? (document.getElementById('sec3_measlesIgGTiterDate')?.value ?? '') : '',
        rubellaIgGTiter,
        rubellaIgGTiterDate: rubellaIgGTiter ? (document.getElementById('sec3_rubellaIgGTiterDate')?.value ?? '') : '',
        otherLabResult,
        otherLabDate: otherLabResult ? (document.getElementById('sec3_otherLabDate')?.value ?? '') : ''
      };
    })(),

    vaccines: {
      ipvDate: document.getElementById('sec4_ipvDate')?.value?.trim() ?? '',
      tdapDate: document.getElementById('sec4_tdapDate')?.value?.trim() ?? '',
      mmrDose1: document.getElementById('sec4_mmrDose1')?.value?.trim() ?? '',
      mmrDose2: document.getElementById('sec4_mmrDose2')?.value?.trim() ?? '',
      MMR: {
        d1: document.getElementById('sec4_mmrDose1')?.value?.trim() ?? '',
        d2: document.getElementById('sec4_mmrDose2')?.value?.trim() ?? '',
        d5: document.getElementById('sec4_mmrDose2')?.value?.trim() ?? ''
      },
      IPV: {
        d1: document.getElementById('sec4_ipvDate')?.value?.trim() ?? '',
        d5: document.getElementById('sec4_ipvDate')?.value?.trim() ?? ''
      },
      Tdap: {
        d1: document.getElementById('sec4_tdapDate')?.value?.trim() ?? '',
        d5: document.getElementById('sec4_tdapDate')?.value?.trim() ?? ''
      },
      chickenpoxStatus: document.getElementById('sec4_chickenpoxStatus')?.value ?? '',
      chickenpoxDose1: document.getElementById('sec4_chickenpoxDose1')?.value ?? '',
      chickenpoxDose2: document.getElementById('sec4_chickenpoxDose2')?.value ?? '',
      varicellaIgG: document.getElementById('sec4_varicellaIgG')?.value?.trim() || getSelectOrCustomVal('sec3_varicellaIgG', 'sec3_varicellaIgG_custom') || '',
      varicellaIgGDate: document.getElementById('sec4_varicellaIgGDate')?.value?.trim() || document.getElementById('sec3_varicellaIgGDate')?.value?.trim() || '',
      additionalCoreDoses: (() => {
        const arr = [];
        document.querySelectorAll('#sec4_core_vaccines_tbody .dynamic-core-dose-row').forEach(row => {
          const doseLabel = row.cells[0]?.textContent || '';
          const ipvDate = row.querySelector('.core-ipv-date')?.value || '';
          const tdapDate = row.querySelector('.core-tdap-date')?.value || '';
          const mmrDose1 = row.querySelector('.core-mmr1-date')?.value || '';
          const mmrDose2 = row.querySelector('.core-mmr2-date')?.value || '';
          const chickenpoxStatus = row.querySelector('.core-cp-status')?.value || '';
          const chickenpoxDose1 = row.querySelector('.core-cp-dose1')?.value || '';
          const chickenpoxDose2 = row.querySelector('.core-cp-dose2')?.value || '';
          const varicellaIgG = row.querySelector('.core-var-igg')?.value || '';
          const varicellaIgGDate = row.querySelector('.core-var-date')?.value || '';
          if (ipvDate || tdapDate || mmrDose1 || mmrDose2 || chickenpoxStatus || chickenpoxDose1 || chickenpoxDose2 || varicellaIgG || varicellaIgGDate) {
            arr.push({ doseLabel, ipvDate, tdapDate, mmrDose1, mmrDose2, chickenpoxStatus, chickenpoxDose1, chickenpoxDose2, varicellaIgG, varicellaIgGDate });
          }
        });
        return arr;
      })()
    },

    specialVaccines: (() => {
      const rows = Array.from(document.querySelectorAll('#sec5_special_vaccines_tbody .dynamic-special-dose-row'));

      const hepA1Row = rows.find(r => {
        const nm = (r.querySelector('.sp-vac-name')?.value || '').toLowerCase();
        return (nm.includes('hep a') || nm.includes('hepatitis a')) && (nm.includes('1') || nm.includes('series 1') || nm.includes('dose 1') || nm.includes('first'));
      }) || rows.find(r => (r.querySelector('.sp-vac-name')?.value || '').toLowerCase().includes('hep a'));

      const hepA2Row = rows.find(r => {
        const nm = (r.querySelector('.sp-vac-name')?.value || '').toLowerCase();
        return (nm.includes('hep a') || nm.includes('hepatitis a')) && (nm.includes('2') || nm.includes('series 2') || nm.includes('dose 2') || nm.includes('second'));
      }) || (rows.filter(r => (r.querySelector('.sp-vac-name')?.value || '').toLowerCase().includes('hep a'))[1]);

      const menRow = rows.find(r => (r.querySelector('.sp-vac-name')?.value || '').toLowerCase().includes('mening'));
      const typRow = rows.find(r => (r.querySelector('.sp-vac-name')?.value || '').toLowerCase().includes('typhoid'));
      const pneRow = rows.find(r => {
        const nm = (r.querySelector('.sp-vac-name')?.value || '').toLowerCase();
        return nm.includes('pneumo') || nm.includes('pnemovax');
      });

      const hepA1Date = hepA1Row ? (hepA1Row.querySelector('.sp-date')?.value || '') : (existingEmp?.specialVaccines?.hepA1 || '');
      const hepA2Date = hepA2Row ? (hepA2Row.querySelector('.sp-date')?.value || '') : (existingEmp?.specialVaccines?.hepA2 || '');
      const menDate = menRow ? (menRow.querySelector('.sp-date')?.value || '') : (existingEmp?.specialVaccines?.meningococcal || '');
      const typDate = typRow ? (typRow.querySelector('.sp-date')?.value || '') : (existingEmp?.specialVaccines?.typhoid || '');
      const pneDate = pneRow ? (pneRow.querySelector('.sp-date')?.value || '') : (existingEmp?.specialVaccines?.pneumovax || existingEmp?.specialVaccines?.pnemovax || '');

      const arr = [];
      rows.forEach(row => {
        const vacName = row.querySelector('.sp-vac-name')?.value || '';
        const manufacturer = row.querySelector('.sp-manufacturer')?.value || '';
        const date = row.querySelector('.sp-date')?.value || '';
        const batch = row.querySelector('.sp-batch')?.value || '';
        if (vacName || manufacturer || date || batch) {
          arr.push({ vacName, manufacturer, date, batch });
        }
      });

      return {
        meningococcal: menDate,
        hepA1: hepA1Date,
        hepA2: hepA2Date,
        typhoid: typDate,
        pneumovax: pneDate,
        pnemovax: pneDate,
        additionalSpecialDoses: arr
      };
    })(),

    covidFlu: {},

    pep: {
      status: (() => {
        const rows = document.querySelectorAll('#sec7_pep_tbody .dynamic-pep-row');
        return rows.length > 0 ? Array.from(rows).map(r => (r.querySelector('.pep-protocol')?.value || '') + ': ' + (r.querySelector('.pep-status')?.value || '')).join(', ') : 'No Incident Reported';
      })(),
      additionalPepRecords: (() => {
        const arr = [];
        document.querySelectorAll('#sec7_pep_tbody .dynamic-pep-row').forEach(row => {
          const serialNo = row.querySelector('.pep-serial-no')?.value || '';
          const incidentDate = row.querySelector('.pep-incident-date')?.value || '';
          const protocol = row.querySelector('.pep-protocol')?.value || '';
          const indication = row.querySelector('.pep-indication')?.value || '';
          const status = row.querySelector('.pep-status')?.value || '';
          const date = row.querySelector('.pep-date')?.value || '';
          if (serialNo || incidentDate || protocol || indication || status || date) {
            arr.push({ serialNo, incidentDate, protocol, indication, status, date });
          }
        });
        return arr;
      })()
    }
  };

  // Sync canonical COVID/flu records to legacy fields after empData object initialization completes
  if (typeof syncCanonicalRecordsToLegacyFields === 'function') {
    syncCanonicalRecordsToLegacyFields(empData, canonicalVaccineList);
  }

  // Mirror flat root properties for 100% data source synchronization across all reports and forms
  empData.hepbTiter = empData.labResults.hbsabResult;
  empData.hbsabResult = empData.labResults.hbsabResult;
  empData.hbsabDate = empData.labResults.hbsabDate;
  delete empData.hbsAb;
  delete empData.hbsAbDate;

  empData.hbsagResult = empData.labResults.hbsagResult;
  empData.hbsagDate = empData.labResults.hbsagDate;
  delete empData.hbsAg;
  delete empData.hbsAgDate;

  empData.hcv = empData.labResults.hcvResult;
  empData.hcvResult = empData.labResults.hcvResult;
  empData.hcvDate = empData.labResults.hcvDate;

  empData.hiv = empData.labResults.hivResult;
  empData.hivResult = empData.labResults.hivResult;
  empData.hivDate = empData.labResults.hivDate;

  empData.mumpsIgG = empData.labResults.mumpsIgGTiter;
  empData.mumpsIgGTiter = empData.labResults.mumpsIgGTiter;
  empData.mumpsIgGDate = empData.labResults.mumpsIgGTiterDate;
  empData.mumpsIgGTiterDate = empData.labResults.mumpsIgGTiterDate;

  empData.measlesIgG = empData.labResults.measlesIgGTiter;
  empData.measlesIgGTiter = empData.labResults.measlesIgGTiter;
  empData.measlesIgGDate = empData.labResults.measlesIgGTiterDate;
  empData.measlesIgGTiterDate = empData.labResults.measlesIgGTiterDate;

  empData.rubellaIgG = empData.labResults.rubellaIgGTiter;
  empData.rubellaIgGTiter = empData.labResults.rubellaIgGTiter;
  empData.rubellaIgGDate = empData.labResults.rubellaIgGTiterDate;
  empData.rubellaIgGTiterDate = empData.labResults.rubellaIgGTiterDate;

  empData.varicellaIgG = empData.labResults.varicellaIgG;
  empData.varicellaIgGDate = empData.labResults.varicellaIgGDate;

  empData.engrixDose1 = empData.labResults.engrixDose1;
  empData.engrixDose2 = empData.labResults.engrixDose2;
  empData.engrixDose3 = empData.labResults.engrixDose3;
  empData.engrixBooster = empData.labResults.engrixBooster;
  empData.hbvBoosterDate = empData.labResults.engrixBooster;

  empData.ppdStep1Result = empData.labResults.ppdStep1Result;
  empData.ppdStep1Date = empData.labResults.ppdStep1Date;
  empData.ppdStep1Induration = empData.labResults.ppdStep1Induration;
  empData.ppdStep2Result = empData.labResults.ppdStep2Result;
  empData.ppdStep2Date = empData.labResults.ppdStep2Date;
  empData.ppdStep2Induration = empData.labResults.ppdStep2Induration;

  empData.dob = empData.demographic.dob;
  empData.age = empData.demographic.age;
  empData.gender = empData.demographic.gender;
  empData.idType = empData.demographic.idType;
  empData.arabicFullName = empData.demographic.arabicFullName;
  empData.positionName = empData.demographic.positionName;
  empData.positionArabic = empData.demographic.positionArabic;
  empData.assignmentEffectiveDate = empData.demographic.assignmentEffectiveDate;
  empData.startDate = empData.demographic.startDate;

  empData.ipvDate = empData.vaccines.ipvDate;
  empData.tdapDate = empData.vaccines.tdapDate;
  empData.mmrDose1 = empData.vaccines.mmrDose1;
  empData.mmrDose2 = empData.vaccines.mmrDose2;
  empData.chickenpoxStatus = empData.vaccines.chickenpoxStatus;
  empData.chickenpoxDose1 = empData.vaccines.chickenpoxDose1;
  empData.chickenpoxDose2 = empData.vaccines.chickenpoxDose2;

  empData.meningococcal = empData.specialVaccines.meningococcal;
  empData.hepA1 = empData.specialVaccines.hepA1;
  empData.hepA2 = empData.specialVaccines.hepA2;
  empData.typhoid = empData.specialVaccines.typhoid;
  empData.pneumovax = empData.specialVaccines.pneumovax;

  empData.fluDate = empData.covidFlu.fluDate || '';
  empData.covidBrandDate = empData.covidFlu.covidBrandDate || '';
  empData.covidDate = empData.covidFlu.covidDate || '';

  // Mirror all COVID-19 individual doses to empData root and vaccines['Covid - 19']
  empData.covidDose1Date = empData.covidFlu.covidDose1Date || '';
  empData.covidDose1Batch = empData.covidFlu.covidDose1Batch || '';
  empData.covidDose2Date = empData.covidFlu.covidDose2Date || '';
  empData.covidDose2Batch = empData.covidFlu.covidDose2Batch || '';
  empData.covidDose3Date = empData.covidFlu.covidDose3Date || '';
  empData.covidDose3Batch = empData.covidFlu.covidDose3Batch || '';
  empData.covidDose4Date = empData.covidFlu.covidDose4Date || '';
  empData.covidDose4Batch = empData.covidFlu.covidDose4Batch || '';

  if (!empData.vaccines) empData.vaccines = {};
  if (!empData.vaccines['Covid - 19']) empData.vaccines['Covid - 19'] = {};
  empData.vaccines['Covid - 19'].d1 = empData.covidDose1Date;
  empData.vaccines['Covid - 19'].p1 = empData.covidDose1Batch;
  empData.vaccines['Covid - 19'].d2 = empData.covidDose2Date;
  empData.vaccines['Covid - 19'].p2 = empData.covidDose2Batch;
  empData.vaccines['Covid - 19'].d3 = empData.covidDose3Date;
  empData.vaccines['Covid - 19'].p3 = empData.covidDose3Batch;

  empData.lab = { ...(empData.lab || {}), ...empData.labResults };
  empData.employment = {
    department: empData.department,
    unit: empData.demographic?.deptTreating || '',
    jobTitle: empData.jobTitle,
    profession: empData.jobTitle,
    staffGroup: empData.staffGroup,
    status: empData.employmentStatus,
    joiningDate: empData.startDate
  };

  const existingIdx = employees.findIndex(e => {
    const eNatId = String(e.idNo || e.demographic?.nationalId || '').trim();
    const empNatId = String(empData.idNo || empData.demographic?.nationalId || '').trim();
    if (eNatId && empNatId && eNatId.toLowerCase() !== 'n/a' && eNatId.toLowerCase() !== 'undefined' && eNatId === empNatId) return true;

    const eEmpNo = String(e.empNo || e.id || e.demographic?.personNumber || '').trim();
    const empEmpNo = String(empData.empNo || empData.id || empData.demographic?.personNumber || '').trim();
    if (eEmpNo && empEmpNo && eEmpNo.toLowerCase() !== 'n/a' && eEmpNo.toLowerCase() !== 'undefined' && eEmpNo.toLowerCase() === empEmpNo.toLowerCase()) return true;

    return false;
  });

  let merged = null;
  if (existingIdx !== -1) {
    const prev = employees[existingIdx];
    // Use overwriteWithBlanks = true so form inputs update target directly
    merged = (typeof window.deepMergeEmployeeObjects === 'function') 
      ? window.deepMergeEmployeeObjects(prev, empData, true)
      : { ...prev, ...empData };

    Object.keys(empData).forEach(k => {
      if (empData[k] !== undefined) {
        merged[k] = empData[k];
      }
    });

    merged.employmentStatus = empData.employmentStatus;
    merged.workStatus = empData.workStatus;
    merged.isArchived = empData.isArchived;
    merged.archived = empData.archived;

    // Explicitly overwrite vaccines and covidFlu to ensure old database caches do not linger
    if (!merged.vaccines) merged.vaccines = {};
    merged.vaccines.mmrDose1 = empData.vaccines.mmrDose1;
    merged.vaccines.mmrDose2 = empData.vaccines.mmrDose2;
    merged.vaccines.MMR = { d1: empData.vaccines.mmrDose1, d2: empData.vaccines.mmrDose2, d5: empData.vaccines.mmrDose2 };
    merged.vaccines.IPV = { d1: empData.vaccines.ipvDate, d5: empData.vaccines.ipvDate };
    merged.vaccines.Tdap = { d1: empData.vaccines.tdapDate, d5: empData.vaccines.tdapDate };
    merged.vaccines['Covid - 19'] = { ...(empData.vaccines['Covid - 19'] || {}) };
    merged.covidFlu = { ...(empData.covidFlu || {}) };
    merged.covidFluRecords = JSON.parse(JSON.stringify(canonicalVaccineList));
    merged.covidDose1Date = empData.covidDose1Date;
    merged.covidDose1Batch = empData.covidDose1Batch;
    merged.covidDose2Date = empData.covidDose2Date;
    merged.covidDose2Batch = empData.covidDose2Batch;
    merged.covidDose3Date = empData.covidDose3Date;
    merged.covidDose3Batch = empData.covidDose3Batch;
    merged.covidDose4Date = empData.covidDose4Date;
    merged.covidDose4Batch = empData.covidDose4Batch;
    merged.mmrDose1 = empData.mmrDose1;
    merged.mmrDose2 = empData.mmrDose2;
    merged.ipvDate = empData.ipvDate;
    merged.tdapDate = empData.tdapDate;

    if (merged.demographic) {
      merged.demographic.employmentStatus = empData.employmentStatus;
      merged.demographic.isArchived = empData.isArchived;
      merged.demographic.archived = empData.archived;
      merged.demographic.department = empData.department;
      merged.demographic.deptTreating = empData.department;
      merged.demographic.staffGroup = empData.staffGroup;
      merged.demographic.invasiveProcedure = empData.invasiveProcedure;
      merged.demographic.positionName = empData.jobTitle;
      merged.demographic.fullName = empData.name;
      merged.demographic.personNumber = empData.empNo;
      merged.demographic.nationalId = empData.idNo;
      merged.demographic.gender = empData.gender;
      merged.demographic.dob = empData.dob;
      merged.demographic.age = empData.age;
    }

    if (isMaleStaff) {
      if (!merged.preVaccinationChecklist) merged.preVaccinationChecklist = {};
      if (!merged.checklist) merged.checklist = {};
      if (!merged.healthStatus) merged.healthStatus = {};
      merged.preVaccinationChecklist.q3 = 'N/A';
      merged.preVaccinationChecklist.q4 = 'N/A';
      merged.checklist.q3 = 'N/A';
      merged.checklist.q4 = 'N/A';
      merged.healthStatus.pregnancyStatus = 'Not Pregnant / N/A';
    }

    employees[existingIdx] = merged;
  } else {
    employees.unshift(empData);
  }

  // 1. Save directly via EmployeeDataService with authoritative central database commit
  const targetToSave = (existingIdx !== -1 && merged) ? merged : empData;
  let saveRes = null;
  try {
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployee === 'function') {
      saveRes = await EmployeeDataService.saveEmployee(targetToSave, actionType || (existingIdx !== -1 ? 'update' : 'save'));
    } else {
      saveEmployeesToLocalStorage(employees);
      saveRes = { success: true, localSaved: true, serverSaved: false, action: (existingIdx !== -1 ? 'updated' : 'created'), employee: targetToSave };
    }
  } catch (dbErr) {
    console.error("Central database persistence failed:", dbErr);
    renderSaveStatusBanner('error', null, { err: (isAr ? 'فشل حفظ السجل في قاعدة البيانات: ' : 'Database persistence failed: ') + (dbErr.message || 'Database error') });
    return {
      empData: targetToSave,
      masterResult: null,
      localSaved: false,
      serverSaved: false,
      success: false,
      status: 'error',
      error: dbErr.message || 'Database persistence failed'
    };
  }

  // Handle OCC Conflict
  if (saveRes && saveRes.conflict) {
    renderSaveStatusBanner('conflict', null, { err: saveRes.message, serverEmp: saveRes.serverEmployee });
    return {
      empData: targetToSave,
      conflict: true,
      success: false,
      serverSaved: false,
      status: 'conflict',
      error: saveRes.message
    };
  }

  // Handle Permission Rejection
  if (saveRes && saveRes.forbidden) {
    renderSaveStatusBanner('forbidden', null, { err: saveRes.message });
    return {
      empData: targetToSave,
      forbidden: true,
      success: false,
      serverSaved: false,
      status: 'forbidden',
      error: saveRes.message
    };
  }

  // Handle Offline / Pending Sync
  if (saveRes && saveRes.pendingSync) {
    currentEditingEmpNo = targetToSave.empNo;
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(targetToSave);
    }
    renderSaveStatusBanner('pending', null, { time: new Date().toLocaleTimeString(), err: saveRes.message });
    return {
      empData: targetToSave,
      pendingSync: true,
      success: false,
      serverSaved: false,
      status: 'pending',
      error: saveRes.message
    };
  }

  // Handle General Error
  if (saveRes && (saveRes.success === false || saveRes.status === 'error')) {
    console.error("EmployeeDataService persistence error:", saveRes.message);
    renderSaveStatusBanner('error', null, { err: (isAr ? 'فشل حفظ السجل: ' : 'Failed to save staff record: ') + (saveRes.message || 'Database rejected save') });
    if (typeof showDangerToast === 'function') {
      showDangerToast((isAr ? 'فشل حفظ السجل: ' : 'Failed to save staff record: ') + (saveRes.message || ''));
    }
    return {
      empData: targetToSave,
      success: false,
      serverSaved: false,
      status: 'error',
      error: saveRes.message
    };
  }

  // CENTRAL DATABASE COMMIT CONFIRMED!
  const confirmedEmp = saveRes?.employee || targetToSave;
  currentEditingEmpNo = confirmedEmp.empNo || confirmedEmp.id;
  if (typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(confirmedEmp);
  }

  // Ensure employees array and localStorage are immediately updated with confirmedEmp
  if (typeof saveEmployeesToLocalStorage === 'function') {
    const k = (typeof getNormalizedEmpKey === 'function') ? getNormalizedEmpKey(confirmedEmp) : (confirmedEmp.empNo || confirmedEmp.id);
    const mIdx = employees.findIndex(e => ((typeof getNormalizedEmpKey === 'function') ? getNormalizedEmpKey(e) : (e.empNo || e.id)) === k);
    if (mIdx !== -1) {
      employees[mIdx] = confirmedEmp;
    } else {
      employees.unshift(confirmedEmp);
    }
    saveEmployeesToLocalStorage(employees);
  }

  // Clear unsaved changes flag & badge
  markStaffFormClean();

  // Invalidate all caches for instant application UI updates
  if (typeof invalidateEmployeesCache === 'function') {
    invalidateEmployeesCache(false);
  }

  // 2. Refresh active reports data list & Master Vaccination Reports UI
  if (typeof window.refreshReportsOnUpdate === 'function') {
    window.refreshReportsOnUpdate();
  } else if (typeof rptAllEmployeesList !== 'undefined') {
    rptAllEmployeesList = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : employees;
    if (typeof filterReportsTable === 'function') {
      filterReportsTable();
    }
  }
  const masterTable = document.getElementById('masterReportTable');
  if (masterTable && typeof renderVaccinationReports === 'function') {
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea) renderVaccinationReports(mainArea);
  }

  // Refresh quick select dropdown with newly saved/updated staff member
  if (typeof updateStaffQuickSelectOptions === 'function') {
    updateStaffQuickSelectOptions(confirmedEmp.empNo || confirmedEmp.id);
  }

  // 3. Auto fill saved data back into form
  loadStaffRecordIntoForm(confirmedEmp);

  // 4. Dispatch synchronization events across all open modules
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('staffDataUpdated'));
    window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: employees.length } }));
  }

  const action = saveRes?.action || (existingIdx !== -1 ? 'updated' : 'created');
  const isAct = (confirmedEmp.employmentStatus === 'Active Staff');
  renderSaveStatusBanner(action === 'created' ? 'created' : 'updated', {
    empNo: confirmedEmp.empNo,
    isArchived: !isAct,
    statusName: confirmedEmp.employmentStatus
  }, {
    time: new Date().toLocaleTimeString(),
    isArchived: !isAct,
    statusName: confirmedEmp.employmentStatus
  });

  if (typeof showSuccessToast === 'function') {
    showSuccessToast(
      isAr ? `تم حفظ وتحديث بيانات الموظف (${confirmedEmp.name || confirmedEmp.empNo}) بنجاح في قاعدة البيانات المركزية وكافة التقارير!` : `Staff record for ${confirmedEmp.name || confirmedEmp.empNo} successfully saved and updated in central database and all reports!`,
      isAr ? 'تم الحفظ والتحديث بنجاح 💾' : 'Record Saved Successfully 💾'
    );
  }

  return {
    empData: confirmedEmp,
    masterResult: saveRes?.masterRes,
    localSaved: true,
    serverSaved: true,
    success: true,
    action: action,
    status: 'success'
  };
}

function markStaffFormDirty() {
  window.isStaffFormDirty = true;
  const badge = document.getElementById('unsaved_changes_badge');
  if (badge) {
    badge.style.display = 'inline-flex';
  }
  const stickyBadge = document.getElementById('sticky_unsaved_badge');
  if (stickyBadge) {
    stickyBadge.style.display = 'inline-flex';
  }
}

function markStaffFormClean() {
  window.isStaffFormDirty = false;
  const badge = document.getElementById('unsaved_changes_badge');
  if (badge) {
    badge.style.display = 'none';
  }
  const stickyBadge = document.getElementById('sticky_unsaved_badge');
  if (stickyBadge) {
    stickyBadge.style.display = 'none';
  }
}
window.markStaffFormDirty = markStaffFormDirty;
window.markStaffFormClean = markStaffFormClean;

function renderSaveStatusBanner(status, options = null, extra = null) {
  const container = document.getElementById('portal_save_status_container');
  if (!container) return;

  const isAr = options?.isAr ?? (window.i18n ? window.i18n.isRTL() : false);
  const empNo = options?.empNo || currentEditingEmpNo || '';
  const err = extra?.err || options?.error || '';
  const time = extra?.time || new Date().toLocaleTimeString();
  const isArchived = extra?.isArchived ?? (options?.isArchived ?? false);
  const statusName = extra?.statusName || options?.statusName || '';

  let bannerHtml = '';

  if (status === 'saving') {
    bannerHtml = `
      <div style="background: #E0F2FE; border: 1.5px solid #0284C7; color: #0369A1; padding: 12px 16px; border-radius: 8px; font-weight: 700; font-size: 0.92rem; display: flex; align-items: center; justify-content: space-between; margin-top: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 1.2rem;">⏳</span>
          <span>${isAr ? 'جاري التحقق وحفظ بيانات الموظف في قاعدة البيانات المركزية...' : 'Validating and saving staff record to central database...'}</span>
        </div>
        <span style="font-size: 0.82rem; opacity: 0.85;">${time}</span>
      </div>
    `;
  } else if (status === 'created' || status === 'success' || status === 'updated') {
    if (isArchived) {
      bannerHtml = `
        <div style="background: #FEF3C7; border: 1.5px solid #F59E0B; color: #92400E; padding: 12px 16px; border-radius: 8px; font-weight: 700; font-size: 0.92rem; display: flex; align-items: center; justify-content: space-between; margin-top: 10px; box-shadow: 0 2px 6px rgba(245, 158, 11, 0.15);">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 1.2rem;">📁</span>
            <span>${isAr ? `تم حفظ وتحديث حالة الموظف بنجاح: نُقل إلى قائمة الكادر المؤرشف / السابق (${statusName}) واستثناؤه من الإحصائيات النشطة.` : `Staff record saved: Moved to Archived / Former Staff list (${statusName}) & excluded from active statistics.`}</span>
          </div>
          <span style="font-size: 0.82rem; background: #FDE68A; color: #78350F; padding: 2px 8px; border-radius: 4px;">${time}</span>
        </div>
      `;
    } else {
      bannerHtml = `
        <div style="background: #D1FAE5; border: 1.5px solid #10B981; color: #065F46; padding: 12px 16px; border-radius: 8px; font-weight: 700; font-size: 0.92rem; display: flex; align-items: center; justify-content: space-between; margin-top: 10px; box-shadow: 0 2px 6px rgba(16, 185, 129, 0.15);">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 1.2rem;">🟢</span>
            <span>${isAr ? 'تم حفظ وتحديث بيانات الموظف بنجاح: كادر نشط على رأس عمله في القائمة الرئيسية النشطة والإحصائيات.' : 'Saved successfully in central database: Active Staff on duty in Master List & Live Statistics.'}</span>
          </div>
          <span style="font-size: 0.82rem; background: #A7F3D0; padding: 2px 8px; border-radius: 4px;">${time}</span>
        </div>
      `;
    }
  } else if (status === 'conflict') {
    bannerHtml = `
      <div style="background: #FEF3C7; border: 2px solid #D97706; color: #92400E; padding: 14px 18px; border-radius: 8px; font-weight: 700; font-size: 0.92rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-top: 10px; box-shadow: 0 4px 12px rgba(217, 119, 6, 0.15);">
        <div style="display: flex; align-items: flex-start; gap: 10px;">
          <span style="font-size: 1.4rem;">⚠️</span>
          <div>
            <div style="font-size: 0.98rem; font-weight: 800; color: #B45309;">${isAr ? 'تعارض في التعديل المتزامن (Concurrent Edit Conflict)' : 'Concurrent Edit Conflict Detected'}</div>
            <div style="margin-top: 4px; font-size: 0.88rem; color: #78350F;">${isAr ? 'تم تعديل هذا السجل من قبل مستخدم أو جهاز آخر منذ أن فتحته. تعديلاتك ما زالت موجودة في النموذج ولم تُمسح.' : 'This record was modified by another user on another device since you loaded it. Your entered data remains in the form.'}</div>
          </div>
        </div>
        <div style="display: flex; gap: 8px; align-items: center;">
          <button type="button" class="btn btn-outline" style="padding: 6px 14px; font-size: 0.84rem; background: white; border: 1.5px solid #D97706; color: #92400E; font-weight: bold; border-radius: 6px; cursor: pointer;" onclick="if(confirm('${isAr ? 'هل تريد تحميل أحدث نسخة من السيرفر؟ ستفقد التعديلات غير المحفوظة.' : 'Reload latest version from server? Any unsaved edits will be discarded.'}')) { if(typeof fetchMasterEmployeesFromBackend === 'function') fetchMasterEmployeesFromBackend().then(() => loadStaffRecordIntoForm(EmployeeDataService.getEmployeeById('${empNo}'))); }">
            🔄 ${isAr ? 'تحميل السجل الأحدث' : 'Reload Latest Record'}
          </button>
          <button type="button" class="btn btn-primary" style="padding: 6px 14px; font-size: 0.84rem; background: #2563EB; color: white; border: none; font-weight: bold; border-radius: 6px; cursor: pointer;" onclick="handleSaveUnifiedStaffForm(event, 'update')">
            💾 ${isAr ? 'إعادة المحاولة' : 'Retry Save'}
          </button>
        </div>
      </div>
    `;
  } else if (status === 'pending') {
    bannerHtml = `
      <div style="background: #FFFBEB; border: 1.5px solid #F59E0B; color: #92400E; padding: 12px 16px; border-radius: 8px; font-weight: 700; font-size: 0.92rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 1.2rem;">🟠</span>
          <span>${isAr ? 'قيد المزامنة (Pending sync): تم حفظ البيانات كمسودة محلية على هذا الجهاز نظراً لعدم توفر اتصال بالخادم المركزي حالياً. سيتم الترحيل تلقائياً عند استعادة الاتصال.' : 'Pending sync: Saved as local draft on this device because central server is unreachable. It will synchronize automatically when connection is restored.'} ${err ? `(${err})` : ''}</span>
        </div>
        <div style="display: flex; gap: 8px; align-items: center;">
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.8rem; background: white; border: 1px solid #D97706; color: #92400E; font-weight: bold; border-radius: 4px; cursor: pointer;" onclick="if(typeof window.retryPendingSyncs === 'function') window.retryPendingSyncs();">
            🔄 ${isAr ? 'إعادة محاولة المزامنة' : 'Retry Remote Sync'}
          </button>
          <span style="font-size: 0.82rem; opacity: 0.85;">${time}</span>
        </div>
      </div>
    `;
  } else if (status === 'forbidden') {
    bannerHtml = `
      <div style="background: #FEE2E2; border: 1.5px solid #DC2626; color: #991B1B; padding: 12px 16px; border-radius: 8px; font-weight: 700; font-size: 0.92rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 1.2rem;">🚫</span>
          <span>${isAr ? 'تم رفض الصلاحية: حسابك لا يملك صلاحية تنفيذ هذا الإجراء.' : 'Permission Denied: Your account does not have permission for this action.'} ${err ? `(${err})` : ''}</span>
        </div>
        <span style="font-size: 0.82rem; opacity: 0.85;">${time}</span>
      </div>
    `;
  } else if (status === 'error') {
    bannerHtml = `
      <div style="background: #FEE2E2; border: 1.5px solid #EF4444; color: #991B1B; padding: 12px 16px; border-radius: 8px; font-weight: 700; font-size: 0.92rem; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-top: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 1.2rem;">🔴</span>
          <span>${isAr ? 'فشل حفظ البيانات في قاعدة البيانات المركزية! كافة القيم ما زالت محفوظة في النموذج.' : 'Failed to save to central database! All form inputs remain intact.'} ${err ? `(${err})` : ''}</span>
        </div>
        <button type="button" class="btn btn-danger" style="padding: 4px 12px; font-size: 0.8rem; background: #EF4444; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;" onclick="handleSaveUnifiedStaffForm(event, 'update')">
          🔄 ${isAr ? 'إعادة المحاولة' : 'Retry Save'}
        </button>
      </div>
    `;
  }

  container.innerHTML = bannerHtml;
}
window.renderSaveStatusBanner = renderSaveStatusBanner;

function saveSingleSectionAndSync(sectionNum) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  renderSaveStatusBanner('saving');
  saveAndAutoFillStaffForm(sectionNum).then(result => {
    if (result && result.empData && result.success) {
      const card = document.getElementById(`section_card_${sectionNum}`);
      if (card) {
        const origShadow = card.style.boxShadow;
        card.style.boxShadow = '0 0 0 4px rgba(16, 185, 129, 0.45), 0 8px 24px rgba(16, 185, 129, 0.18)';
        setTimeout(() => {
          card.style.boxShadow = origShadow || '';
        }, 2000);
      }
    }
  }).catch(err => {
    renderSaveStatusBanner('error', null, { err: err ? err.message : 'Save error' });
  });
}
window.saveSingleSectionAndSync = saveSingleSectionAndSync;

async function handleSaveUnifiedStaffForm(e, actionType = null) {
  if (e) e.preventDefault();

  if (window._isSavingInProgress) return;
  window._isSavingInProgress = true;

  const saveBtn = document.getElementById('portal_save_btn');
  const updateBtn = document.getElementById('portal_update_btn');
  const secSaveBtns = document.querySelectorAll('.sec-save-btn');
  secSaveBtns.forEach(btn => { btn.disabled = true; });
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.setAttribute('data-orig-html', saveBtn.innerHTML);
    saveBtn.innerHTML = '⏳ ' + (window.i18n && window.i18n.isRTL() ? 'جاري الحفظ...' : 'Saving...');
  }
  if (updateBtn) {
    updateBtn.disabled = true;
    updateBtn.setAttribute('data-orig-html', updateBtn.innerHTML);
    updateBtn.innerHTML = '⏳ ' + (window.i18n && window.i18n.isRTL() ? 'جاري التحديث...' : 'Updating...');
  }

  renderSaveStatusBanner('saving');

  try {
    await saveAndAutoFillStaffForm(null, actionType);
  } catch (err) {
    console.error('Unified save error:', err);
    renderSaveStatusBanner('error', null, { err: err ? err.message : 'Save error' });
  } finally {
    window._isSavingInProgress = false;
    secSaveBtns.forEach(btn => { btn.disabled = false; });
    if (saveBtn) {
      saveBtn.disabled = false;
      const orig = saveBtn.getAttribute('data-orig-html');
      if (orig) saveBtn.innerHTML = orig;
    }
    if (updateBtn) {
      updateBtn.disabled = false;
      const orig = updateBtn.getAttribute('data-orig-html');
      if (orig) updateBtn.innerHTML = orig;
    }
  }
}
window.handleSaveUnifiedStaffForm = handleSaveUnifiedStaffForm;

/* ==========================================================================
   OFFICIAL PRINT HANDLER FOR UNIFIED 7-SECTION STAFF MEDICAL RECORD
   ========================================================================== */
function printUnifiedStaffRecord() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const getVal = (id) => { const el = document.getElementById(id); return el ? el.value : ''; };
  const getChk = (id) => { const el = document.getElementById(id); return el ? el.checked : false; };

  const name = getVal('sec1_fullName') || 'Employee';
  const personNumber = getVal('sec1_personNumber') || 'EMP-N/A';
  const nationalId = getVal('sec1_nationalId') || 'N/A';
  const dept = getVal('sec1_deptTreating') || 'N/A';

  // Collect dynamic core & special vaccine rows
  const dynVacRows = [];
  document.querySelectorAll('.dynamic-vac-row, .dynamic-core-dose-row').forEach(tr => {
    const nameInput = tr.querySelector('.dyn-vac-name, input[type="text"]');
    const doseSelect = tr.querySelector('.dyn-vac-dose, select');
    const dateInput = tr.querySelector('.dyn-vac-date, input[type="date"]');
    const vName = nameInput ? nameInput.value : '';
    const vDose = doseSelect ? doseSelect.value : '';
    const vDate = dateInput ? dateInput.value : '';
    if (vName || vDate) {
      dynVacRows.push(`<tr><td>${vName}</td><td>${vDose}</td><td>${vDate}</td></tr>`);
    }
  });

  // Collect dynamic COVID & Flu dose rows
  const dynCfRows = [];
  document.querySelectorAll('.dynamic-cf-dose-row').forEach(tr => {
    const vName = tr.querySelector('.cf-vac-name')?.value || '';
    const vMfr = tr.querySelector('.cf-manufacturer')?.value || '';
    const vBatch = tr.querySelector('.cf-batch')?.value || '';
    const vDate = tr.querySelector('.cf-date')?.value || '';
    if (vName || vDate) {
      dynCfRows.push(`<tr><td>${vName}</td><td>${vMfr}</td><td>${vBatch}</td><td>${vDate}</td></tr>`);
    }
  });

  // Collect dynamic PEP rows
  const dynPepRows = [];
  document.querySelectorAll('.dynamic-pep-row').forEach(tr => {
    const serial = tr.querySelector('.pep-serial')?.value || '';
    const date = tr.querySelector('.pep-date')?.value || '';
    const protocol = tr.querySelector('.pep-protocol')?.value || '';
    const status = tr.querySelector('.pep-status')?.value || '';
    if (serial || date || protocol) {
      dynPepRows.push(`<tr><td>${serial}</td><td>${date}</td><td>${protocol}</td><td>${status}</td></tr>`);
    }
  });

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="${isAr ? 'ar' : 'en'}" dir="${isAr ? 'rtl' : 'ltr'}">
    <head>
      <meta charset="UTF-8">
      <title>AVH Medical Record - ${name}</title>
      <style>
        @page { size: A4 portrait; margin: 10mm 15mm; }
        * { box-sizing: border-box; }
        html, body { width: 100%; height: 100%; margin: 0 !important; padding: 0 !important; font-family: 'Segoe UI', Arial, sans-serif; font-size: 11px; color: #1E293B; line-height: 1.4; background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .page-container { width: 100% !important; max-width: 100% !important; margin: 0 auto !important; padding: 0 !important; box-sizing: border-box; min-height: 265mm; display: flex; flex-direction: column; justify-content: space-between; }
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #113F52; padding-bottom: 10px; margin-bottom: 12px; }
        .title { font-size: 16px; font-weight: 800; color: #113F52; text-align: center; }
        .subtitle { font-size: 11px; color: #64748B; text-align: center; margin-top: 2px; }
        .sec-box { border: 1px solid #CBD5E1; border-radius: 6px; padding: 10px; margin-bottom: 12px; page-break-inside: avoid; }
        .sec-header { background: #F1F5F9; color: #1E293B; padding: 4px 8px; font-weight: 800; font-size: 12px; margin: -10px -10px 8px -10px; border-bottom: 1px solid #CBD5E1; border-top-left-radius: 5px; border-top-right-radius: 5px; }
        .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
        .cell { padding: 4px; }
        .cell strong { display: block; font-size: 10px; color: #475569; }
        table { width: 100%; border-collapse: collapse; margin-top: 6px; table-layout: fixed; }
        th, td { border: 1px solid #CBD5E1; padding: 5px; text-align: center; font-size: 10px; word-break: break-word; }
        th { background: #F8FAFC; font-weight: bold; }
        .footer-sig { margin-top: 20px; display: flex; justify-content: space-between; page-break-inside: avoid; }
        .sig-block { border-top: 1px solid #000; width: 45%; text-align: center; padding-top: 4px; font-weight: bold; }
      </style>
    </head>
    <body>
      <div class="page-container">
        <div>
          <div class="header">
            <div>
              <h3 style="margin:0; color:#113F52;">AUGUSTA VICTORIA HOSPITAL</h3>
              <small>مستشفى الأوغستا فكتوريا (المُطلع)</small>
            </div>
            <div class="title">
              UNIFIED STAFF MEDICAL & IMMUNIZATION RECORD
              <div class="subtitle">السجل الطبي الموحد وتطعيمات الموظف - ISO 9001:2015</div>
            </div>
            <div style="text-align:right;">
              <small>Infectious Disease Unit</small><br>
              <small>Date: ${new Date().toLocaleDateString()}</small>
            </div>
          </div>
          <small>مستشفى الأوغستا فكتوريا (المُطلع)</small>
        </div>
        <div class="title">
          UNIFIED STAFF MEDICAL & IMMUNIZATION RECORD
          <div class="subtitle">السجل الطبي الموحد وتطعيمات الموظف - ISO 9001:2015</div>
        </div>
        <div style="text-align:right;">
          <small>Infectious Disease Unit</small><br>
          <small>Date: ${new Date().toLocaleDateString()}</small>
        </div>
      </div>

      <!-- SEC 1 -->
      <div class="sec-box">
        <div class="sec-header">1. Demographic Information (البيانات الشخصية)</div>
        <div class="grid">
          <div class="cell"><strong>Full Name / الاسم:</strong> ${name}</div>
          <div class="cell"><strong>Emp No / الرقم الوظيفي:</strong> ${personNumber}</div>
          <div class="cell"><strong>National ID / الهوية:</strong> ${nationalId}</div>
          <div class="cell"><strong>DOB / الميلاد:</strong> ${getVal('sec1_dob') || 'N/A'}</div>
          <div class="cell"><strong>Age / العمر:</strong> ${getVal('sec1_age') || 'N/A'}</div>
          <div class="cell"><strong>Position / المسمى:</strong> ${getVal('sec1_positionName') || 'N/A'}</div>
          <div class="cell"><strong>Department / القسم:</strong> ${dept}</div>
          <div class="cell"><strong>Staff Group / الفئة:</strong> ${getVal('sec1_staffGroup') || 'Staff'}</div>
          <div class="cell"><strong>Start Date / بداية التوظيف:</strong> ${getVal('sec1_startDate') || 'N/A'}</div>
        </div>
      </div>

      <!-- SEC 2 -->
      <div class="sec-box">
        <div class="sec-header">2. Health Status & Check List (الحالة الصحية والتقييم)</div>
        <div class="grid">
          <div class="cell"><strong>Pregnancy Status:</strong> ${getVal('sec2_pregnancyStatus') || 'N/A'}</div>
          <div class="cell"><strong>Allergies:</strong> ${getVal('sec2_allergies') || 'None'}</div>
          <div class="cell"><strong>Checklist:</strong> Fever: ${getChk('sec2_feverToday') ? 'Yes' : 'No'} | Immune Deficient: ${getChk('sec2_immunodeficient') ? 'Yes' : 'No'}</div>
        </div>
      </div>

      <!-- SEC 3 -->
      <div class="sec-box">
        <div class="sec-header">3. Laboratory Test Results (نتائج الفحوصات المخبرية)</div>
        <table>
          <thead>
            <tr>
              <th>HBsAb Result</th>
              <th>HBsAb Date</th>
              <th>Engrix 1</th>
              <th>Engrix 2</th>
              <th>Engrix 3</th>
              <th>Booster</th>
              <th>HCV</th>
              <th>HIV</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>${getVal('sec3_hbsabResult') || '-'}</td>
              <td>${getVal('sec3_hbsabDate') || '-'}</td>
              <td>${getVal('sec3_engrixDose1') || '-'}</td>
              <td>${getVal('sec3_engrixDose2') || '-'}</td>
              <td>${getVal('sec3_engrixDose3') || '-'}</td>
              <td>${getVal('sec3_engrixBooster') || '-'}</td>
              <td>${getVal('sec3_hcvResult') || '-'}</td>
              <td>${getVal('sec3_hivResult') || '-'}</td>
            </tr>
          </tbody>
        </table>

        <table style="margin-top:8px;">
          <thead>
            <tr>
              <th>PPD 1st Step Result</th>
              <th>Induration (mm)</th>
              <th>PPD 2nd Step Result</th>
              <th>Induration (mm)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>${getVal('sec3_ppdStep1Result') || '-'}</td>
              <td>${getVal('sec3_ppdStep1Induration') || '-'}</td>
              <td>${getVal('sec3_ppdStep2Result') || '-'}</td>
              <td>${getVal('sec3_ppdStep2Induration') || '-'}</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- SEC 4 & 5 -->
      <div class="sec-box">
        <div class="sec-header">4 & 5. Vaccination History & Special Vaccines (التطعيمات السابقة والخاصة)</div>
        <table>
          <thead>
            <tr>
              <th>IPV (>18y)</th>
              <th>Tdap (>7y)</th>
              <th>MMR 1</th>
              <th>MMR 2</th>
              <th>Chickenpox Status</th>
              <th>Varicella IgG</th>
              <th>Meningococcal</th>
              <th>Hep A 1&2</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>${getVal('sec4_ipvDate') || '-'}</td>
              <td>${getVal('sec4_tdapDate') || '-'}</td>
              <td>${getVal('sec4_mmrDose1') || '-'}</td>
              <td>${getVal('sec4_mmrDose2') || '-'}</td>
              <td>${getVal('sec4_chickenpoxStatus') || '-'}</td>
              <td>${getVal('sec4_varicellaIgG') || '-'}</td>
              <td>${getVal('sec5_meningococcal') || '-'}</td>
              <td>${getVal('sec5_hepA1') || '-'} / ${getVal('sec5_hepA2') || '-'}</td>
            </tr>
          </tbody>
        </table>

        ${dynVacRows.length > 0 ? `
          <div style="margin-top: 8px; font-weight: bold;">Additional Core / Special Vaccine Doses:</div>
          <table style="margin-top:4px;">
            <thead>
              <tr>
                <th>Vaccine Name</th>
                <th>Dose</th>
                <th>Date Administered</th>
              </tr>
            </thead>
            <tbody>
              ${dynVacRows.join('')}
            </tbody>
          </table>
        ` : ''}
      </div>

      <!-- SEC 6 & 7 -->
      <div class="sec-box">
        <div class="sec-header">6 & 7. Seasonal Flu, Covid-19 & PEP Status</div>
        <div class="grid">
          <div class="cell"><strong>Flu Vaccine Date:</strong> ${getVal('sec6_fluDate') || 'N/A'}</div>
          <div class="cell"><strong>Covid-19 Booster:</strong> ${getVal('sec6_covidBrandDate') || 'N/A'}</div>
          <div class="cell"><strong>PEP Status:</strong> ${getVal('sec7_pepStatus') || 'No Incident Reported'}</div>
        </div>

        ${dynCfRows.length > 0 ? `
          <div style="margin-top: 8px; font-weight: bold;">Dynamic COVID-19 / Flu Dose Log:</div>
          <table style="margin-top:4px;">
            <thead>
              <tr>
                <th>Vaccine / Dose</th>
                <th>Manufacturer</th>
                <th>Batch / Lot No</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              ${dynCfRows.join('')}
            </tbody>
          </table>
        ` : ''}

        ${dynPepRows.length > 0 ? `
          <div style="margin-top: 8px; font-weight: bold;">Occupational Exposure & PEP Incident Log:</div>
          <table style="margin-top:4px;">
            <thead>
              <tr>
                <th>Serial / Inc No</th>
                <th>Incident Date</th>
                <th>Protocol</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${dynPepRows.join('')}
            </tbody>
          </table>
        ` : ''}
      </div>

      <div class="footer-sig">
        <div class="sig-block">Employee Signature / توقيع الموظف</div>
        <div class="sig-block">Occupational Health Officer / مسؤول الصحة المهنية</div>
      </div>

      <div style="margin-top: auto; padding-top: 10px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; max-width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto; image-rendering: -webkit-optimize-contrast;" />
      </div>
    </div>
  </body>
  </html>
  `;

  if (typeof executeSameWindowPrint === 'function') {
    executeSameWindowPrint(htmlContent);
  } else {
    window.print();
  }
}

function toggleSectionCollapse(secNum, forceState = null) {
  const body = document.getElementById(`section_body_${secNum}`);
  const btn = document.getElementById(`section_toggle_btn_${secNum}`);
  if (!body) return;

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const isCurrentlyClosed = (body.style.display === 'none');
  const shouldOpen = forceState !== null ? forceState : isCurrentlyClosed;

  if (shouldOpen) {
    body.style.display = 'block';
    if (btn) {
      btn.innerHTML = `🔼 ${isAr ? 'إغلاق القسم' : 'Collapse'}`;
    }
  } else {
    body.style.display = 'none';
    if (btn) {
      btn.innerHTML = `🔽 ${isAr ? 'فتح القسم' : 'Expand'}`;
    }
  }
}
window.toggleSectionCollapse = toggleSectionCollapse;

function focusAndEditSection(inputId, cardId) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  let secNum = 1;
  if (cardId) {
    const m = cardId.match(/\d+/);
    if (m) secNum = parseInt(m[0], 10);
  }

  if (secNum >= 5) toggleSectionCollapse(secNum, true);

  const card = document.getElementById(cardId || `section_card_${secNum}`);
  if (card) {
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const originalShadow = card.style.boxShadow;
    card.style.boxShadow = '0 0 0 4px rgba(37, 99, 235, 0.45), 0 8px 24px rgba(37, 99, 235, 0.18)';
    setTimeout(() => {
      card.style.boxShadow = originalShadow || '';
    }, 2000);
  }

  if (inputId) {
    const input = document.getElementById(inputId);
    if (input) {
      setTimeout(() => input.focus(), 250);
    }
  }

  const msg = isAr
    ? `✏️ تم تفعيل وضع تعديل القسم (${secNum}) - أدخل التعديلات ثم انقر على "حفظ ومزامنة".`
    : `✏️ Section ${secNum} Edit Mode Active - Make your edits and click 'Save Section & Sync'.`;
  
  if (typeof showSuccessToast === 'function') {
    showSuccessToast(msg, isAr ? 'وضع التعديل نشط ✏️' : 'Section Edit Mode ✏️');
  }
}
window.focusAndEditSection = focusAndEditSection;

function createNewStaffFromSearch(queryStr) {
  const resultsBox = document.getElementById('staff_search_results');
  if (resultsBox) resultsBox.style.display = 'none';

  resetFormForNewStaff();

  const isNum = /^\d+$/.test(queryStr);
  if (isNum && queryStr.length >= 8) {
    document.getElementById('sec1_nationalId').value = queryStr;
  } else if (queryStr.toUpperCase().startsWith('EMP-') || (isNum && queryStr.length < 8)) {
    document.getElementById('sec1_personNumber').value = queryStr.toUpperCase().startsWith('EMP-') ? queryStr.toUpperCase() : 'EMP-' + queryStr;
  } else {
    document.getElementById('sec1_fullName').value = queryStr;
  }

  const card1 = document.getElementById('section_card_1');
  if (card1) {
    card1.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function deleteCurrentLoadedEmployee() {
  if (!currentEditingEmpNo) {
    const isAr = window.i18n.isRTL();
    alert(isAr ? 'يرجى اختيار موظف أولاً للحذف.' : 'Please select an employee first to delete.');
    return;
  }
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  const emp = employees.find(e => e.empNo === currentEditingEmpNo || e.id === currentEditingEmpNo);
  const empName = emp ? emp.name : currentEditingEmpNo;
  deleteEmployeeRecord(currentEditingEmpNo, empName);
}

function importStaffFromExcelFile(event) {
  const file = event.target.files[0];
  if (!file) return;

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const reader = new FileReader();

  reader.onload = function(e) {
    try {
      let importedEmployees = [];
      const data = new Uint8Array(e.target.result);

      if (typeof XLSX !== 'undefined') {
        const workbook = XLSX.read(data, { type: 'array' });
        
        // Find all sheets that represent employee rosters (e.g. Main Employee list, Gaza staff, etc.)
        const candidateSheetNames = [];
        (workbook.SheetNames || []).forEach(sName => {
          const sLower = String(sName).trim().toLowerCase();
          // Skip known template, certificate, legend, or instructions sheets
          if (sLower.includes('template') || sLower.includes('certificate') || sLower.includes('legend') || sLower.includes('guideline')) {
            return;
          }
          candidateSheetNames.push(sName);
        });
        if (candidateSheetNames.length === 0 && workbook.SheetNames && workbook.SheetNames.length > 0) {
          candidateSheetNames.push(workbook.SheetNames[0]);
        }

        candidateSheetNames.forEach(sheetName => {
          const worksheet = workbook.Sheets[sheetName];
          if (!worksheet) return;
          const rawGrid = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });
          if (!rawGrid || rawGrid.length === 0) return;

          let headerRowIndex = -1;
          for (let r = 0; r < Math.min(rawGrid.length, 6); r++) {
            const rowStr = (rawGrid[r] || []).join(' ').toLowerCase();
            if (rowStr.includes('national identifier') || rowStr.includes('full name') || rowStr.includes('person number') || rowStr.includes('national id') || rowStr.includes('staff id') || rowStr.includes('emp no')) {
              headerRowIndex = r;
              break;
            }
          }
          if (headerRowIndex === -1) return; // Not an employee roster sheet

          const h1 = rawGrid[headerRowIndex] || [];
          const h2 = rawGrid[headerRowIndex + 1] || [];

          // Determine if h2 is a REAL second header row or actual employee data row (Row 1)
          let isSecondHeaderRow = false;
          if (h2 && h2.length > 0 && headerRowIndex + 1 < rawGrid.length) {
            const h2Str = h2.join(' ').toLowerCase();
            const subHeaderKeywords = ['dose 1', 'dose 2', 'dose 3', 'batch #', '1st step', '2nd step', 'induration', 'titer', 'result date', 'patch #'];
            const hasSubHeaderKeywords = subHeaderKeywords.some(kw => h2Str.includes(kw));

            // Check if h2 contains actual employee data values (e.g. National ID numbers, dates of birth, person numbers)
            const h2HasDataValues = h2.some(cell => {
              const str = String(cell !== undefined && cell !== null ? cell : '').trim();
              return /^\d{7,10}$/.test(str) || /^\d{2}\/\d{2}\/\d{4}$/.test(str) || /^\d{4}-\d{2}-\d{2}$/.test(str) || /^EMP-\d+$/i.test(str);
            });

            if (hasSubHeaderKeywords && !h2HasDataValues) {
              isSecondHeaderRow = true;
            }
          }

          const colKeys = [];
          for (let c = 0; c < Math.max(h1.length, (isSecondHeaderRow ? h2.length : 0)); c++) {
            const k1 = String(h1[c] || '').trim();
            const k2 = isSecondHeaderRow ? String(h2[c] || '').trim() : '';
            let combined = k1;
            if (k2 && k2 !== k1) {
              combined = k1 ? (k1 + ' (' + k2 + ')') : k2;
            }
            colKeys.push(combined || `Col_${c}`);
          }

          const startDataRow = isSecondHeaderRow ? (headerRowIndex + 2) : (headerRowIndex + 1);

          for (let r = startDataRow; r < rawGrid.length; r++) {
            const gridRow = rawGrid[r];
            if (!gridRow || !gridRow.some(cell => String(cell).trim())) continue;

            const rowObj = {};
            colKeys.forEach((key, c) => {
              rowObj[key] = String(gridRow[c] !== undefined && gridRow[c] !== null ? gridRow[c] : '').trim();
            });

            if (sheetName.toLowerCase().includes('gaza') && !rowObj['Organization Name'] && !rowObj['Organization']) {
              rowObj['Organization Name'] = 'Gaza Project';
            }

            const emp = mapExcelRowToEmployee(rowObj);
            if (emp && (emp.name || (emp.demographic && emp.demographic.fullName))) {
              if (sheetName.toLowerCase().includes('gaza')) {
                if (!emp.department) emp.department = 'Gaza Project';
                if (!emp.demographic) emp.demographic = {};
                if (!emp.demographic.orgName) emp.demographic.orgName = 'Gaza Project';
                if (!emp.demographic.department) emp.demographic.department = 'Gaza Project';
              }

              const empKey = typeof getNormalizedEmpKey === 'function' ? getNormalizedEmpKey(emp) : (emp.empNo || emp.idNo || '').toString().trim();
              const existingIdx = importedEmployees.findIndex(item => {
                const itemKey = typeof getNormalizedEmpKey === 'function' ? getNormalizedEmpKey(item) : (item.empNo || item.idNo || '').toString().trim();
                return itemKey && empKey && itemKey === empKey;
              });
              if (existingIdx !== -1) {
                importedEmployees[existingIdx] = (typeof window.deepMergeEmployeeObjects === 'function')
                  ? window.deepMergeEmployeeObjects(importedEmployees[existingIdx], emp, true)
                  : Object.assign({}, importedEmployees[existingIdx], emp);
              } else {
                importedEmployees.push(emp);
              }
            }
          }
        });
      } else {
        const text = new TextDecoder().decode(data);
        const lines = text.split('\n').map(l => l.trim()).filter(l => l);
        if (lines.length > 1) {
          const headers = lines[0].split(',').map(h => h.replace(/^"|"$/g, '').trim());
          for (let i = 1; i < lines.length; i++) {
            const vals = lines[i].split(',').map(v => v.replace(/^"|"$/g, '').trim());
            const row = {};
            headers.forEach((h, idx) => row[h] = vals[idx] || '');
            const emp = mapExcelRowToEmployee(row);
            if (emp && emp.name) importedEmployees.push(emp);
          }
        }
      }

      if (importedEmployees.length === 0) {
        alert(isAr ? '⚠️ لم يتم العثور على بيانات موظفين صالحة في ملف الإكسل.' : '⚠️ No valid employee rows found in the selected Excel file.');
        return;
      }

      let existing = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
      const mergeFn = (typeof window.deepMergeEmployeeObjects === 'function') ? window.deepMergeEmployeeObjects : ((a, b) => Object.assign({}, a, b));
      importedEmployees.forEach(imp => {
        const impKey = typeof getNormalizedEmpKey === 'function' ? getNormalizedEmpKey(imp) : (imp.empNo || imp.idNo || '').toString().trim();
        const idx = existing.findIndex(e => {
          const eKey = typeof getNormalizedEmpKey === 'function' ? getNormalizedEmpKey(e) : (e.empNo || e.idNo || '').toString().trim();
          return eKey && impKey && eKey === impKey;
        });
        if (idx !== -1) {
          existing[idx] = mergeFn(existing[idx], imp, true);
        } else {
          existing.push(imp);
        }
      });
      if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployees === 'function') {
        EmployeeDataService.saveEmployees(existing).catch(err => console.error("Import saveEmployees error:", err));
      } else {
        saveEmployeesToLocalStorage(existing);
      }

      // Asynchronously trigger Google Sheets UPSERT for imported/merged records if connected
      if (window.googleSheetsSync && window.googleSheetsSync.isConnected()) {
        importedEmployees.forEach(imp => {
          if (typeof window.googleSheetsSync.saveEmployeeToGoogleSheets === 'function') {
            window.googleSheetsSync.saveEmployeeToGoogleSheets(imp).catch(err => console.warn('Google Sheets import sync info:', err));
          }
        });
      }

      if (typeof _masterEmployeesList !== 'undefined') {
        _masterEmployeesList = existing;
      }
      if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
        AVH_MASTER_EXCEL_EMPLOYEES.length = 0;
        existing.forEach(e => AVH_MASTER_EXCEL_EMPLOYEES.push(e));
      }
      if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event('staffDataUpdated'));
        window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: existing.length } }));
      }

      if (typeof showSuccessToast === 'function') {
        showSuccessToast(
          isAr 
            ? `تم استيراد وتحديث (${importedEmployees.length}) سجل موظف بنجاح من ملف الإكسل!` 
            : `Successfully imported & updated (${importedEmployees.length}) staff records from Excel!`,
          'Import Complete / تم الاستيراد بنجاح'
        );
      } else {
        alert(isAr 
          ? `✅ تم استيراد وتحديث (${importedEmployees.length}) سجل موظف بنجاح من ملف الإكسل وتقييد كافة بياناتهم بالنظام!` 
          : `✅ Successfully imported & updated (${importedEmployees.length}) staff records from Excel! All data is synced.`
        );
      }

      const mainArea = document.getElementById('mainAppArea') || document.body;
      if (typeof renderVaccinationReports === 'function') {
        renderVaccinationReports(mainArea);
      } else if (document.getElementById('unifiedStaffForm')) {
        if (importedEmployees.length > 0 && typeof loadStaffRecordIntoForm === 'function') {
          loadStaffRecordIntoForm(importedEmployees[0]);
        }
      }

    } catch(err) {
      console.error('Error importing Excel file:', err);
      alert(isAr 
        ? '❌ حدث خطأ أثناء قراءة ملف الإكسل. يرجى التأكد من صيغة الملف (.xlsx أو .csv).' 
        : '❌ Error reading Excel file. Please ensure it is a valid .xlsx or .csv file.'
      );
    }
  };

  reader.readAsArrayBuffer(file);
}

function mapExcelRowToEmployee(row) {
  const getVal = (...keys) => {
    if (!row || typeof row !== 'object') return '';
    const rowKeys = Object.keys(row);

    // Pass 1: Exact Match (Normalized Alphanumeric & Arabic)
    for (let k of keys) {
      if (!k) continue;
      const targetClean = String(k).trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]/g, '');
      if (!targetClean) continue;

      for (let rKey of rowKeys) {
        const rClean = String(rKey).trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]/g, '');
        if (rClean === targetClean) {
          const val = row[rKey];
          if (val !== null && val !== undefined && String(val).trim() !== '') {
            return String(val).trim();
          }
        }
      }
    }

    // Pass 2: Substring Match
    for (let k of keys) {
      if (!k) continue;
      const targetClean = String(k).trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]/g, '');
      if (!targetClean || targetClean.length < 3) continue;

      for (let rKey of rowKeys) {
        const rClean = String(rKey).trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]/g, '');
        if (rClean.includes(targetClean)) {
          const val = row[rKey];
          if (val !== null && val !== undefined && String(val).trim() !== '') {
            return String(val).trim();
          }
        }
      }
    }

    return '';
  };

  let name = getVal('Full Name', 'Name', 'Staff Name', 'fullName', 'اسم الموظف', 'الاسم', 'Person Name', 'Employee Name', 'arabicFullName', 'الاسم بالعربية', 'Arabic Full Name');
  if (!name || name.trim() === '') {
    const candidates = Object.keys(row).filter(k => /name|اسم|full|person|staff|employee/i.test(k));
    for (let c of candidates) {
      if (row[c] && String(row[c]).trim()) {
        name = String(row[c]).trim();
        break;
      }
    }
  }
  if (!name || name.trim() === '') {
    for (let k in row) {
      if (row[k] && typeof row[k] === 'string' && row[k].trim().length >= 3 && !/^\d+$/.test(row[k].trim())) {
        name = row[k].trim();
        break;
      }
    }
  }
  if (!name || name.trim() === '') return null;

  let empNoRaw = getVal('Person Number', 'Emp No', 'EmpNo', 'personNumber', 'ID', 'الرقم الوظيفي');
  let empNo = empNoRaw ? (String(empNoRaw).toUpperCase().startsWith('EMP-') ? String(empNoRaw).toUpperCase() : (/^\d+$/.test(String(empNoRaw).trim()) ? 'EMP-' + String(empNoRaw).trim() : String(empNoRaw).trim())) : ('EMP-' + Math.floor(1000 + Math.random() * 9000));
  
  let idNoRaw = getVal('National Identifier', 'National ID', 'ID No', 'idNo', 'nationalId', 'رقم الهوية', 'الهوية') || 'N/A';
  let idNo = (idNoRaw !== 'N/A' && /^\d{1,8}$/.test(String(idNoRaw).trim())) ? String(idNoRaw).trim().padStart(9, '0') : String(idNoRaw).trim();
  const arName = getVal('Arabic Full Name', 'arabicFullName', 'الاسم بالعربية');
  const rawDob = getVal('Date Of Birth', 'Date of Birth', 'DOB', 'tariq', 'تاريخ الميلاد');
  const dob = typeof standardizeDateStr === 'function' ? standardizeDateStr(rawDob) : rawDob;
  const age = getVal('Age', 'العمر');
  
  let rawGender = getVal('Gender', 'Sex', 'الجنس');
  let gender = rawGender;
  if (!gender || gender.toLowerCase() === 'n/a' || gender.toLowerCase() === 'male' || gender === '') {
    const text = `${name || ''} ${arName || ''}`.toLowerCase();
    const femalePattern = /\b(hala|mays|maysaa|salma|fatima|fatmeh|fateh|may|rania|reem|rima|ruba|amani|amal|khuloud|sahar|dina|mona|nisreen|samar|suha|nour|yasmin|layla|laila|hanan|huda|heba|nadia|najwa|nibal|manal|majda|maha|lina|lema|ghada|fida|basma|eman|iman|amira|aida|intisar|insaf|khetam|taghreed|zeinab|zainab|zaina|maryam|mariam|noor|rawan|raghad|razan|shireen|shirin|shadia|sawsan|sirin|wafa|wafaa|yara|mervat|nadine|suhad|ola|ula|dalal|kholoud|souad|suad|sohad|huba|neda|nada|ruwaida|rula|subhiya|sumaya)\b/i;
    const femaleArPattern = /(هالة|ميس|سلمى|فاطمة|مريم|مي|رانية|رانيا|ريم|ريما|ربى|أماني|اماني|أمل|امل|خلود|سحر|دينا|منى|نسرين|سمر|سهى|نور|ياسمين|ليلى|حنان|هدى|هبة|نادية|نجوى|نبال|منال|ماجدة|مها|لينا|غادة|فداء|بسمة|إيمان|ايمان|أميرة|اميرة|عائدة|انتصار|إنصاف|ختام|تغريد|زينب|زينة|راوان|رغد|رزان|شرين|شيرين|شادية|سوسن|وفاء|يارا|ميرفت|نادين|سهاد|علا|دلال|سعاد|نداء|ندى|رويدة|رولا|صباح|سمية)/;

    if (femalePattern.test(text) || femaleArPattern.test(text)) {
      gender = 'Female';
    } else {
      gender = 'Male';
    }
  }
  const idType = getVal('National Identifier Type', 'ID Type', 'نوع الهوية') || 'National ID';
  const orgName = getVal('Organization Name', 'Organization', 'المؤسسة') || 'Augusta Victoria Hospital';
  const positionName = getVal('Position Name', 'Job Title', 'Position', 'المسمى الوظيفي') || 'Healthcare Staff';
  const positionArabic = getVal('Position Arabic', 'المسمى بالعربية');
  const startDate = getVal('Start Date', 'تاريخ البدء');
  const assignEffectiveDate = getVal('Assignment Effective Date', 'Assignment Effective', 'Effective Date', 'assignmentEffectiveDate', 'تاريخ التكليف');
  const staffGroup = getVal('staff Group', 'Staff Group', 'الفئة الوظيفية') || 'Minimum Plan';
  const deptTreating = getVal('departments/units/clinics treating', 'Departments/Units/Clinics Treating', 'deptTreating', 'Treating Units');
  const dept = getVal('Organization Name', 'Department', 'Dept', 'القسم') || deptTreating || 'General Medical';

  const hbsab = getVal('HBsAb Result', 'HBsAb Titer', 'HBsAb', 'نتيجة HBsAb') || '> 1000 mIU/mL';
  const hbsabDate = getVal('HBsAb Result Date', 'HBsAb Date', 'تاريخ HBsAb');
  const hbsag = getVal('HBsAg Result', 'HBsAg', 'نتيجة HBsAg') || 'Negative';
  const hbsagDate = getVal('HBsAg Result Date', 'HBsAg Date', 'تاريخ HBsAg') || hbsabDate;
  const engrix1 = getVal('Date of Engrix first dose', 'Engrix 1');
  const engrix2 = getVal('Date of 2nd Engrix dose', 'Engrix 2');
  const engrix3 = getVal('Date of 3rd Engrix dose', 'Engrix 3');
  const engrixBooster = getVal('Engrix Booster dose', 'Engrix Booster');

  const hcv = getVal('HCV Result', 'HCV') || 'Negative';
  const hcvDate = getVal('HCV Result date', 'HCV Date');
  const hiv = getVal('HIV Result', 'HIV') || 'Negative';
  const hivDate = getVal('HIV Result date', 'HIV Date');

  const ppdRes = getVal('PPD Result', '1st step result') || 'Negative';
  const ppdStep1Ind = getVal('1st step induration');
  const ppdStep1Date = getVal('1st step result date', 'PPD 1st Test Date');
  const ppdStep2Res = getVal('2nd step result');
  const ppdStep2Ind = getVal('2nd step induration');
  const ppdStep2Date = getVal('2nd step result date', 'PPD 2nd Test Date');

  const ipvDate = getVal('IPV Vaccine at Age >18 year', 'IPV');
  const tdapDate = getVal('Tdap Vaccine at age >7 years', 'Tdap');
  const mmrDose1 = getVal('MMR Vaccine first dose at Age >1 year', 'MMR1');
  const mmrDose2 = getVal('MMR Vaccine Second dose at Age >1 year', 'MMR2');
  const chickenpoxStatus = getVal('Chicken pox infected or Vaccinated', 'Chickenpox');
  const chickenpoxDose1 = getVal('Chicken pox vaccine date dose 1', 'Chicken pox vaccine dose 1', 'Chickenpox Dose 1');
  const chickenpoxDose2 = getVal('Chicken pox Vaccine 2nd dose', 'Chicken pox Vaccine 2nd dose or IGG level');
  const varicellaIgG = getVal('Varicella Zoster, IgG', 'Varicella IgG');
  const varicellaIgGDate = getVal('Varicella Zoster, IgG date', 'Varicella Date');
  const mumpsIgGTiter = getVal('Mumps IgG Titer', 'Mumps IgG', 'Mumps');
  const mumpsIgGTiterDate = getVal('Mumps IgG Titer date', 'Mumps Date');
  const measlesIgGTiter = getVal('Measles IgG Titer', 'Measles IgG', 'Measles');
  const measlesIgGTiterDate = getVal('Measles IgG Titer date', 'Measles Date');
  const rubellaIgGTiter = getVal('Rubella IgG Titer', 'Rubella IgG', 'Rubella');
  const rubellaIgGTiterDate = getVal('Rubella IgG Titer date', 'Rubella Date');

  const allergies = getVal('Allergies (Eggs, Neomycin)', 'Allergies') || 'None';
  const meningococcal = getVal('Meningiococcal A, C', 'Meningiococcal');
  const hepA1 = getVal('hep A SERIES 1', 'Hep A 1');
  const hepA2 = getVal('hep A SERIES2', 'Hep A 2');
  const typhoid = getVal('typhoid', 'Typhoid');
  const pneumovax = getVal('Pnemovax', 'Pneumovax', 'Pnemovax ', 'Pneumovax ', 'Pneumovax 23', 'Pnemovax 23', 'Pneumococcal');
  const note = getVal('Note', 'ملاحظات');
  const pcrIgg = getVal('PCR / IGG', 'PCR');

  const covidDose1Date = getVal('Covid Vaccine DATE OF FIRST DOSE', 'Covid1 Date');
  const covidDose1Batch = getVal('PATCH #', 'Batch 1');
  const covidDose2Date = getVal('Covid Vaccine DATE OF SECOUND DOSE', 'Covid2 Date');
  const covidDose2Batch = getVal('PATCH #', 'Batch 2');
  const covidDose3Date = getVal('Covid Vaccine DATE OF THIRD DOSE', 'Covid3 Date');
  const covidDose3Batch = getVal('PATCH #', 'Batch 3');

  const flu2324 = getVal('flu vaccine 2023-2024', 'Flu 23-24');
  const flu2425 = getVal('flu vaccine 2024-2025', 'Flu 24-25');
  const immunityStatus = getVal('Immunity Status', 'حالة الحصانة') || 'Fully Immune';

  return {
    id: empNo,
    empNo: empNo,
    idNo: idNo,
    name: name,
    department: dept,
    jobTitle: positionName,
    dob: dob,
    hepbTiter: hbsab,
    immunityStatus: immunityStatus,
    lastVaccineDate: new Date().toISOString().slice(0, 10),
    demographic: {
      personNumber: empNo,
      nationalId: idNo,
      fullName: name,
      arabicFullName: arName,
      dob: dob,
      age: age,
      gender: gender,
      idType: idType,
      department: dept,
      deptTreating: deptTreating,
      positionName: positionName,
      positionArabic: positionArabic,
      startDate: startDate,
      assignmentEffectiveDate: assignEffectiveDate,
      staffGroup: staffGroup,
      orgName: orgName,
      allergies: allergies
    },
    healthStatus: {
      pregnancyStatus: (gender === 'Female' || (gender && gender.toLowerCase() === 'female')) ? 'Not Pregnant' : 'Not Applicable',
      tbHistory: 'No history of active TB',
      chronicConditions: 'None Reported',
      allergies: allergies
    },
    labResults: {
      hbsabResult: hbsab,
      hbsabDate: hbsabDate,
      hbsagResult: hbsag,
      hbsagDate: hbsagDate,
      engrixDose1: engrix1,
      engrixDose2: engrix2,
      engrixDose3: engrix3,
      engrixBooster: engrixBooster,
      hcvResult: hcv,
      hcvDate: hcvDate,
      hivResult: hiv,
      hivDate: hivDate,
      ppdStep1Result: ppdRes,
      ppdStep1Induration: ppdStep1Ind,
      ppdStep1Date: ppdStep1Date,
      ppdStep2Result: ppdStep2Res,
      ppdStep2Induration: ppdStep2Ind,
      ppdStep2Date: ppdStep2Date,
      varicellaIgG: varicellaIgG,
      varicellaIgGDate: varicellaIgGDate,
      mumpsIgGTiter: mumpsIgGTiter,
      mumpsIgGTiterDate: mumpsIgGTiterDate,
      measlesIgGTiter: measlesIgGTiter,
      measlesIgGTiterDate: measlesIgGTiterDate,
      rubellaIgGTiter: rubellaIgGTiter,
      rubellaIgGTiterDate: rubellaIgGTiterDate,
      pcrIgg: pcrIgg,
      note: note
    },
    vaccines: {
      ipvDate: ipvDate,
      tdapDate: tdapDate,
      mmrDose1: mmrDose1,
      mmrDose2: mmrDose2,
      chickenpoxStatus: chickenpoxStatus,
      chickenpoxDose1: chickenpoxDose1,
      chickenpoxDose2: chickenpoxDose2
    },
    specialVaccines: {
      meningococcal: meningococcal,
      hepA1: hepA1,
      hepA2: hepA2,
      typhoid: typhoid,
      pneumovax: pneumovax
    },
    covidFlu: {
      covidDose1Date: covidDose1Date,
      covidDose1Batch: covidDose1Batch,
      covidDose2Date: covidDose2Date,
      covidDose2Batch: covidDose2Batch,
      covidDose3Date: covidDose3Date,
      covidDose3Batch: covidDose3Batch,
      flu2324: flu2324,
      flu2425: flu2425,
      fluDate: flu2425 || flu2324
    },
    pep: {
      status: 'No Incident Reported'
    }
  };
}

function printStaffForm() {
  if (typeof printUnifiedStaffRecord === 'function') {
    printUnifiedStaffRecord();
  } else {
    window.print();
  }
}

// Global Window Exports for Inline HTML Event Handlers
window.handleSaveUnifiedStaffForm = handleSaveUnifiedStaffForm;
window.saveSingleSectionAndSync = saveSingleSectionAndSync;
window.saveAndAutoFillStaffForm = saveAndAutoFillStaffForm;
window.loadStaffRecordIntoForm = loadStaffRecordIntoForm;
window.resetFormForNewStaff = resetFormForNewStaff;
window.createNewStaffFromSearch = createNewStaffFromSearch;
window.selectStaffFromSearch = selectStaffFromSearch;
window.deleteCurrentLoadedEmployee = deleteCurrentLoadedEmployee;
window.printStaffForm = printStaffForm;
window.printUnifiedStaffRecord = printUnifiedStaffRecord;
window.addCoreVaccineDoseRow = typeof addCoreVaccineDoseRow === 'function' ? addCoreVaccineDoseRow : undefined;
window.addSpecialVaccineDoseRow = typeof addSpecialVaccineDoseRow === 'function' ? addSpecialVaccineDoseRow : undefined;
window.addCovidFluDoseRow = typeof addCovidFluDoseRow === 'function' ? addCovidFluDoseRow : undefined;
window.addPepRow = typeof addPepRow === 'function' ? addPepRow : undefined;
window.autoLinkInjuryReportsToSec7 = typeof autoLinkInjuryReportsToSec7 === 'function' ? autoLinkInjuryReportsToSec7 : undefined;
window.toggleSectionCollapse = typeof toggleSectionCollapse === 'function' ? toggleSectionCollapse : undefined;
window.focusAndEditSection = typeof focusAndEditSection === 'function' ? focusAndEditSection : undefined;
window.renderUnifiedStaffEntryForm = typeof renderUnifiedStaffEntryForm === 'function' ? renderUnifiedStaffEntryForm : undefined;

function handleChickenpoxStatusChange(selectElem) {
  if (!selectElem) return;
  const val = selectElem.value;
  const d1 = document.getElementById('sec4_chickenpoxDose1');
  const d2 = document.getElementById('sec4_chickenpoxDose2');
  if (val === '2 doses vaccine' || val === 'Vaccinated') {
    if (d1) {
      d1.style.background = '#ECFDF5';
      d1.style.borderColor = '#10B981';
      d1.focus();
    }
    if (d2) {
      d2.style.background = '#ECFDF5';
      d2.style.borderColor = '#10B981';
    }
  } else {
    if (d1) {
      d1.style.background = 'white';
      d1.style.borderColor = 'var(--border-color)';
    }
    if (d2) {
      d2.style.background = 'white';
      d2.style.borderColor = 'var(--border-color)';
    }
  }
}
window.handleChickenpoxStatusChange = handleChickenpoxStatusChange;
window.importStaffFromExcelFile = typeof importStaffFromExcelFile === 'function' ? importStaffFromExcelFile : undefined;

function updateStaffQuickSelectOptions(selectedEmpNo = null) {
  const quickSelect = document.getElementById('staff_quick_select');
  if (!quickSelect) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  quickSelect.innerHTML = typeof buildStaffQuickSelectOptionsHtml === 'function'
    ? buildStaffQuickSelectOptionsHtml(employees, isAr, selectedEmpNo)
    : employees.map(e => `<option value="${e.empNo || e.id}">${e.name} (${e.empNo || e.id})</option>`).join('');
  if (selectedEmpNo) {
    quickSelect.value = String(selectedEmpNo);
  }
}
window.updateStaffQuickSelectOptions = updateStaffQuickSelectOptions;

if (typeof window !== 'undefined') {
  window.addEventListener('staffDataUpdated', () => {
    updateStaffQuickSelectOptions(typeof currentEditingEmpNo !== 'undefined' ? currentEditingEmpNo : null);
  });
  window.addEventListener('avh_data_updated', () => {
    updateStaffQuickSelectOptions(typeof currentEditingEmpNo !== 'undefined' ? currentEditingEmpNo : null);
  });
}


window.renderStaffEntryForm = renderStaffEntryForm;
