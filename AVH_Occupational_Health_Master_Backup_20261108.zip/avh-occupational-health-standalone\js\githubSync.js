/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - GITHUB AUTOMATED REPOSITORY SYNC ENGINE
   Real-Time Direct Browser-to-GitHub REST API Sync for Repository & GitHub Pages
   ========================================================================== */

(function() {
  const STORAGE_KEY_TOKEN = 'avh_github_token';
  const STORAGE_KEY_OWNER = 'avh_github_owner';
  const STORAGE_KEY_REPO = 'avh_github_repo';
  const STORAGE_KEY_BRANCH = 'avh_github_branch';
  const STORAGE_KEY_LAST_SYNC = 'avh_github_last_sync';

  const DEFAULT_OWNER = 'hammamrjoup';
  const DEFAULT_REPO = 'AVH-occupational-health-dashboard';
  const DEFAULT_BRANCH = 'main';

  // Helper for UTF-8 to Base64 encoding (supports Arabic & Special Characters)
  function utf8ToBase64(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
      return String.fromCharCode('0x' + p1);
    }));
  }

  window.githubSync = {
    getToken: function() {
      return localStorage.getItem(STORAGE_KEY_TOKEN) || '';
    },

    setToken: function(token) {
      if (token !== undefined && token !== null) {
        localStorage.setItem(STORAGE_KEY_TOKEN, token.trim());
      }
    },

    getOwner: function() {
      return localStorage.getItem(STORAGE_KEY_OWNER) || DEFAULT_OWNER;
    },

    setOwner: function(owner) {
      if (owner && owner.trim()) {
        localStorage.setItem(STORAGE_KEY_OWNER, owner.trim());
      }
    },

    getRepo: function() {
      return localStorage.getItem(STORAGE_KEY_REPO) || DEFAULT_REPO;
    },

    setRepo: function(repo) {
      if (repo && repo.trim()) {
        localStorage.setItem(STORAGE_KEY_REPO, repo.trim());
      }
    },

    getBranch: function() {
      return localStorage.getItem(STORAGE_KEY_BRANCH) || DEFAULT_BRANCH;
    },

    setBranch: function(branch) {
      if (branch && branch.trim()) {
        localStorage.setItem(STORAGE_KEY_BRANCH, branch.trim());
      }
    },

    getLastSync: function() {
      return localStorage.getItem(STORAGE_KEY_LAST_SYNC) || 'Never';
    },

    isConnected: function() {
      return !!this.getToken();
    },

    // Commit file directly to GitHub Repository via REST API
    commitFileToGitHub: async function(filePath, fileContentStr, commitMsg) {
      const token = this.getToken();
      if (!token) return { success: false, reason: 'unconfigured' };

      const owner = this.getOwner();
      const repo = this.getRepo();
      const branch = this.getBranch();

      const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}`;

      try {
        // 1. Fetch current file SHA if file already exists on GitHub
        let sha = null;
        try {
          const getRes = await fetch(`${apiUrl}?ref=${encodeURIComponent(branch)}`, {
            headers: {
              'Authorization': `token ${token}`,
              'Accept': 'application/vnd.github.v3+json'
            }
          });
          if (getRes.ok) {
            const getData = await getRes.json();
            if (getData && getData.sha) {
              sha = getData.sha;
            }
          }
        } catch(e) {}

        // 2. Base64 encode content (UTF-8 safe)
        const base64Content = utf8ToBase64(fileContentStr);

        const payload = {
          message: commitMsg || `Auto-sync ${filePath} from AVH Occupational Health System`,
          content: base64Content,
          branch: branch
        };

        if (sha) {
          payload.sha = sha;
        }

        // 3. Send PUT request to GitHub API
        const putRes = await fetch(apiUrl, {
          method: 'PUT',
          headers: {
            'Authorization': `token ${token}`,
            'Content-Type': 'application/json',
            'Accept': 'application/vnd.github.v3+json'
          },
          body: JSON.stringify(payload)
        });

        if (!putRes.ok) {
          const errJson = await putRes.json().catch(() => ({}));
          throw new Error(errJson.message || `GitHub API error: ${putRes.status}`);
        }

        const nowStr = new Date().toLocaleString();
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, nowStr);
        return { success: true, timestamp: nowStr };

      } catch (err) {
        console.error(`Error committing ${filePath} to GitHub:`, err);
        return { success: false, error: err.message };
      }
    },

    // Commit master employee list to GitHub repository (both JSON & JS files)
    syncMasterDatasetToGitHub: async function() {
      if (!this.isConnected()) return false;

      const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
      if (!Array.isArray(employees) || employees.length === 0) return false;

      const jsonStr = JSON.stringify(employees, null, 2);
      const jsStr = `/* ==========================================================================\n   AUGUSTA VICTORIA HOSPITAL - MASTER STAFF DATASET\n   ========================================================================== */\nconst AVH_MASTER_EXCEL_EMPLOYEES = ${JSON.stringify(employees)};\n`;

      const msg = `Auto-sync Master Staff Dataset (${employees.length} Records) [${new Date().toLocaleString()}]`;

      // 1. Sync JSON file
      const r1 = await this.commitFileToGitHub('js/avh_staff_2026_master.json', jsonStr, msg);
      // 2. Sync JS fallback file
      const r2 = await this.commitFileToGitHub('js/avh_staff_master_data.js', jsStr, msg);

      if (r1.success || r2.success) {
        const nowStr = new Date().toLocaleString();
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, nowStr);
        return true;
      }
      return false;
    }
  };
})();
