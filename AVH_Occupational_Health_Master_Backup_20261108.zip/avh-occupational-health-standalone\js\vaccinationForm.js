
// Uses canonical toSafeLabString and getFirstDefinedLabValue from js/data.js

function escapeHtmlAttr(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
if (typeof window !== 'undefined') {
  window.escapeHtmlAttr = escapeHtmlAttr;
}

/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - VACCINATION AND TEST HISTORY FORM CONTROLLER
   ========================================================================== */

function updateEmployeeImmunityStatus(empIdxOrPersonNo, newStatus) {
  if (empIdxOrPersonNo === undefined || empIdxOrPersonNo === null) return;
  let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  let emp;
  if (typeof empIdxOrPersonNo === 'string' || typeof empIdxOrPersonNo === 'number') {
    emp = employees.find(e => String(e.empNo || e.personNumber || e.id) === String(empIdxOrPersonNo) || String(e.idNo || e.nationalId) === String(empIdxOrPersonNo));
  }
  if (!emp && typeof empIdxOrPersonNo === 'number' && empIdxOrPersonNo >= 0 && empIdxOrPersonNo < employees.length) {
    emp = employees[empIdxOrPersonNo];
  }
  if (emp) {
    emp.immunityStatus = newStatus;
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployee === 'function') {
      EmployeeDataService.saveEmployee(emp, 'update').catch(err => console.error("Error updating immunity status:", err));
    } else if (typeof saveEmployeesToLocalStorage === 'function') {
      saveEmployeesToLocalStorage(employees);
    }
    if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();
    window.dispatchEvent(new CustomEvent('avh_data_updated'));
    window.dispatchEvent(new CustomEvent('staffDataUpdated'));

    const isAr = window.i18n ? window.i18n.isRTL() : false;
    if (typeof window.showSuccessToast === 'function') {
      window.showSuccessToast(isAr ? `تم تحديث حالة التطعيم إلى: (${newStatus})` : `Immunity status updated to: (${newStatus})`);
    } else {
      alert(isAr
        ? `✅ تم تحديث حالة التطعيم والمناعة بنجاح إلى: (${newStatus})`
        : `✅ Employee Immunity & Vaccination Status updated successfully to: (${newStatus})`
      );
    }

    const container = document.getElementById('mainAppArea');
    if (container && typeof renderVaccinationForm === 'function') renderVaccinationForm(container);
  }
}
window.updateEmployeeImmunityStatus = updateEmployeeImmunityStatus;

let currentSubTab = 'exemption';
let activeEmpIndex = -1;

function getCurrentSystemUserName() {
  if (window.authManager && window.authManager.currentUser) {
    if (window.authManager.currentUser.name) return window.authManager.currentUser.name;
    if (window.authManager.currentUser.username) return window.authManager.currentUser.username;
  }
  const stored = sessionStorage.getItem('avh_current_user');
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      if (parsed) {
        if (parsed.name) return parsed.name;
        if (parsed.username) return parsed.username;
      }
    } catch(e) {}
  }
  return 'System User';
}

function renderVaccinationForm(container) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const t = key => window.i18n ? window.i18n.t(key) : key;
  let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (!employees || employees.length === 0) {
    if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES) && AVH_MASTER_EXCEL_EMPLOYEES.length > 0) {
      employees = AVH_MASTER_EXCEL_EMPLOYEES;
    }
  }

  let selEmp = typeof window.getGlobalSelectedStaff === 'function' ? window.getGlobalSelectedStaff() : null;
  if (selEmp) {
    const sEmpNo = String(selEmp.empNo || selEmp.id || selEmp.demographic?.personNumber || selEmp.idNo || '').trim();
    if (sEmpNo) {
      const sIdx = employees.findIndex(e => String(e.empNo || e.id || e.demographic?.personNumber || e.idNo || '').trim() === sEmpNo);
      if (sIdx !== -1) {
        activeEmpIndex = sIdx;
      }
    }
  }

  const isBlankState = (activeEmpIndex === -1 || activeEmpIndex >= employees.length);
  const blankEmp = {
    name: '',
    idNo: '',
    empNo: '',
    id: '',
    department: '',
    jobTitle: '',
    dob: '',
    gender: '',
    immunityStatus: '',
    demographic: { fullName: '', arabicFullName: '', nationalId: '', personNumber: '', deptTreating: '', positionName: '', assignmentEffectiveDate: '' },
    healthStatus: {},
    labResults: {},
    vaccines: {},
    specialVaccines: {},
    covidFlu: {},
    pep: {},
    feeExemption: {
      startDate: '',
      tests: { HBsAg: true, HBsAb: true, HCV: true, HIV: true, Pregnancy: false, PPD: true, Stool: false, Urine: false },
      approvedBy: "ط·ظˆظ†ظٹ طھط¨ط§ظ† ظ…ط¯ظٹط± ط§ظ„ظ…ظˆط§ط±ط¯ ط§ظ„ط¨ط´ط±ظٹط© / ط¨ط¯ظٹط¹ط© ط¨ط¬ط§ظ„ظٹ ظ…ط¯ظٹط±ط© ط§ظ„ط¹ظ…ظ„ظٹط§طھ ط§ظ„طھط´ط؛ظٹظ„ظٹط©",
      approvalDate: new Date().toISOString().slice(0, 10)
    },
    preVaccinationChecklist: {},
    oldVaccination: {},
    chickenpoxDeclaration: {}
  };
  
  const emp = isBlankState ? blankEmp : (employees[activeEmpIndex] || blankEmp);
  console.log("4 VACCINATION FORM DATA:", emp);

  container.innerHTML = `
    <!-- LIVE SEARCH BAR & RECORD CONTROLS (QUICK SEARCH OR SELECT FROM LIST) -->
    <div class="card no-print" style="border-left: 4px solid var(--accent-teal); margin-bottom: 20px; padding: 18px 22px; background: #FAFDFD;">
      <div style="display: flex; gap: 14px; align-items: flex-end; flex-wrap: wrap;">
        <div style="flex: 2; min-width: 280px; position: relative;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            🔍 ${isAr ? 'البحث السريع عن موظف (الاسم / الهوية / الرقم الوظيفي):' : 'Quick Search Staff (Name, ID, or Emp No):'}
          </label>
          <div class="search-flex-group" style="display: flex; gap: 8px;">
            <input type="text" id="vac_header_search_input" 
              placeholder="${isAr ? 'اكتب اسم الموظف أو الهوية أو الرقم الوظيفي...' : 'Type Name, ID, or Emp No...'}" 
              value="${escapeHtmlAttr(vacSearchQuery || (emp && emp.name ? (emp.name + (emp.idNo ? ' (ID: ' + emp.idNo + ')' : '')) : ''))}"
              onfocus="showVacSearchResults(this.value)" 
              oninput="handleVacHeaderSearch(this.value)" 
              onkeydown="handleVacSearchKeyDown(event)"
              autocomplete="off"
              style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.95rem; font-weight: 600; background: white;">
            <button type="button" class="btn btn-outline" style="padding: 8px 14px; font-weight: bold; background: white; white-space: nowrap; border-color: #94A3B8; color: #475569;" onclick="clearVacSearch()">
              🧹 ${isAr ? 'تفريغ الشاشة' : 'Clear Form'}
            </button>
          </div>
          <!-- FLOATING LIVE SEARCH RESULTS DROPDOWN -->
          <div id="vac_search_results" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1.5px solid var(--accent-teal); border-radius: 6px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); z-index: 100; max-height: 280px; overflow-y: auto;"></div>
        </div>

        <div style="flex: 1.5; min-width: 240px;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            👤 ${isAr ? 'أو اختر موظفاً من القائمة مباشرة:' : 'Or Select Employee from List:'}
          </label>
          <select id="vac_quick_select" style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.92rem; font-weight: 600; background: white;" onchange="selectVacStaffFromDropdown(this.value)">
            ${typeof buildStaffQuickSelectOptionsHtml === 'function' ? buildStaffQuickSelectOptionsHtml(employees, isAr, emp && (emp.empNo || emp.id)) : ''}
          </select>
        </div>
      </div>
    </div>

    <!-- MANDATORY EMPLOYEE HEADER CARD (HIDDEN IN PRINT) -->
    <div class="employee-header-card no-print">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 12px;">
        <div style="font-size: 0.88rem; text-transform: uppercase; font-weight: 800; color: #008080;">
          🏥 Augusta Victoria Hospital | Staff Occupational Health Record Header
        </div>
        ${!isBlankState ? `
          <span style="background: #ECFDF5; color: #065F46; border: 1px solid #10B981; padding: 4px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 700;">
            🟢 ${isAr ? 'تم تحميل بيانات الموظف المختار بنجاح' : 'Selected Staff Loaded'}
          </span>
        ` : ''}
      </div>
      <div class="employee-header-grid">
        <div class="emp-field">
          <label>Employee Name / اسم الموظف</label>
          <input type="text" value="${escapeHtmlAttr(emp.name || (emp.demographic ? emp.demographic.fullName : ''))}" readonly placeholder="${isBlankState ? (isAr ? 'يرجى البحث أو اختيار الموظف أعلاه...' : 'Select or search staff member above...') : ''}">
        </div>
        <div class="emp-field">
          <label>ID No. / رقم الهوية</label>
          <input type="text" value="${escapeHtmlAttr(emp.idNo || (emp.demographic ? emp.demographic.nationalId : ''))}" readonly style="font-weight: 800; color: #0284C7; background: #F0F9FF;">
        </div>
        <div class="emp-field">
          <label>Employment NO / الرقم الوظيفي</label>
          <input type="text" value="${escapeHtmlAttr(emp.empNo || emp.id || (emp.demographic ? emp.demographic.personNumber : ''))}" readonly style="font-weight: 800; color: #0D9488; background: #F0FDF4;">
        </div>
        <div class="emp-field">
          <label>Department / القسم</label>
          <input type="text" value="${escapeHtmlAttr(emp.demographic?.orgName || emp.organizationName || emp.orgName || emp.department || (emp.demographic ? emp.demographic.deptTreating : ''))}" readonly>
        </div>
        <div class="emp-field">
          <label>Job Title / المسمى الوظيفي</label>
          <input type="text" value="${escapeHtmlAttr(emp.jobTitle || (emp.demographic ? emp.demographic.positionName : ''))}" readonly>
        </div>
        <div class="emp-field" style="background: #F0F9FF; padding: 6px 10px; border-radius: 6px; border: 1.5px solid #0284C7;">
          <label style="font-weight: 800; color: #0369A1;">🛡️ Immunity Status (حالة التطعيم والمناعة)</label>
          <select style="padding: 5px 8px; border-radius: 6px; font-weight: 800; border: 1.5px solid #0284C7; color: #0C4A6E; background: white; font-size: 0.88rem; cursor: pointer; width: 100%;" onchange="updateEmployeeImmunityStatus(${activeEmpIndex}, this.value)">
            <option value="Fully Vaccinated" ${emp.immunityStatus === 'Fully Vaccinated' || emp.immunityStatus === 'Fully Immune' || !emp.immunityStatus ? 'selected' : ''}>🟢 Fully Vaccinated / Fully Immune (مُلقح بالكامل)</option>
            <option value="Partially Vaccinated" ${emp.immunityStatus === 'Partially Vaccinated' ? 'selected' : ''}>🟡 Partially Vaccinated (مُلقح جزئياً)</option>
            <option value="Ongoing" ${emp.immunityStatus === 'Ongoing' || emp.immunityStatus === 'In Progress' ? 'selected' : ''}>🔵 Ongoing / In Progress (قيد التطعيم المستمر)</option>
            <option value="Not Vaccinated" ${emp.immunityStatus === 'Not Vaccinated' ? 'selected' : ''}>🔴 Not Vaccinated (غير مُلقح)</option>
            <option value="Contraindication" ${emp.immunityStatus === 'Contraindication' || emp.immunityStatus === 'Medical Exemption' ? 'selected' : ''}>⚠️ Contraindication / Medical Exemption (موانع تطبيق التطعيم)</option>
          </select>
        </div>
      </div>
    <!-- SUB-TITLES FORM NAVIGATION TABS (HIDDEN IN PRINT) -->
    <div class="vac-subtitles-bar no-print" style="display: flex; gap: 8px; flex-wrap: wrap; margin: 16px 0 20px 0; padding: 12px 14px; background: white; border-radius: 10px; border: 1.5px solid #CBD5E1; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <button class="btn ${currentSubTab === 'exemption' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('exemption')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        📄 ${t('sub_exemption')}
      </button>
      <button class="btn ${currentSubTab === 'checklist' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('checklist')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        📋 ${t('sub_checklist')}
      </button>
      <button class="btn ${currentSubTab === 'history' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('history')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        📊 ${t('sub_history')}
      </button>
      <button class="btn ${currentSubTab === 'old_vac' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('old_vac')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        📜 ${t('sub_old_vac')}
      </button>
      <button class="btn ${currentSubTab === 'chickenpox' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('chickenpox')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        🐔 ${t('sub_chickenpox')}
      </button>
      <button class="btn ${currentSubTab === 'covid_flu' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('covid_flu')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        💉 ${t('sub_covid_flu')}
      </button>
      <button class="btn ${currentSubTab === 'special' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('special')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        ⭐ ${t('sub_special')}
      </button>
      <button class="btn ${currentSubTab === 'pep' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('pep')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        🩹 ${t('sub_pep')}
      </button>
      <button class="btn ${currentSubTab === 'refusal' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('refusal')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        🚫 ${t('sub_refusal')}
      </button>
      <button class="btn ${currentSubTab === 'infection_control' ? 'btn-primary' : 'btn-outline'}" onclick="switchSubTab('infection_control')" style="font-weight: 700; font-size: 0.84rem; padding: 8px 12px; border-radius: 6px;">
        🛡️ ${t('sub_infection_control')}
      </button>
    </div>

    <!-- SUB TAB CONTENT CONTAINER -->
    <div id="subTabContent">
      ${isBlankState ? `
        <div style="background: white; padding: 40px; border-radius: 8px; text-align: center; border: 1.5px dashed #0284C7; margin: 20px 0; color: #0369A1;" class="no-print">
          <div style="font-size: 2.5rem; margin-bottom: 12px;">👤🔍</div>
          <h3 style="margin: 0 0 8px 0; font-size: 1.25rem; font-weight: 800;">
            ${isAr ? 'يرجى البحث عن موظف أو اختياره من القائمة أعلاه لعرض وتعبئة النموذج' : 'Please Search or Select a Staff Member Above'}
          </h3>
          <p style="margin: 0; font-size: 0.95rem; color: #475569;">
            ${isAr ? 'استخدم مربع البحث أو القائمة المنسدلة في الأعلى لاختيار الموظف واستيراد بياناته تلقائياً في كافة النماذج.' : 'Use the search box or dropdown above to select a staff member and auto-populate their records.'}
          </p>
        </div>
      ` : ''}
      ${renderSubTabContent(currentSubTab, emp)}
    </div>
  `;
}

let vacSearchQuery = '';

function showVacSearchResults(query) {
  const resultsBox = document.getElementById('vac_search_results');
  if (!resultsBox) return;
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const q = (query || '').trim().toLowerCase();

  let matches = [];
  if (!q) {
    matches = employees.slice(0, 10);
  } else {
    matches = employees.filter(e => {
      const demo = e.demographic || {};
      const idNo = (e.idNo || demo.nationalId || '').toString().toLowerCase();
      const empNo = (e.empNo || e.id || demo.personNumber || '').toString().toLowerCase();
      const name = (e.name || demo.fullName || '').toString().toLowerCase();
      const arName = (demo.arabicFullName || '').toString().toLowerCase();
      const dept = (demo.orgName || e.organizationName || demo.organizationName || e.orgName || e.department || demo.deptTreating || '').toString().toLowerCase();
      const job = (e.jobTitle || demo.positionName || '').toString().toLowerCase();
      return idNo.includes(q) || empNo.includes(q) || name.includes(q) || arName.includes(q) || dept.includes(q) || job.includes(q);
    }).slice(0, 15);
  }

  if (matches.length === 0) {
    resultsBox.innerHTML = `
      <div style="padding: 14px 16px; color: #64748B; font-size: 0.9rem; text-align: center;">
        ${isAr ? '❌ لا توجد نتائج مطابقة لبحثك' : '❌ No matching staff members found'}
      </div>
    `;
    resultsBox.style.display = 'block';
    return;
  }

  resultsBox.innerHTML = `
    <div style="padding: 6px 12px; background: #F1F5F9; border-bottom: 1px solid #CBD5E1; font-size: 0.78rem; font-weight: bold; color: var(--primary-blue); display: flex; justify-content: space-between;">
      <span>⚡ ${isAr ? 'انقر على أي موظف لاختياره مباشرة:' : 'Click any staff member to select:'}</span>
      <span style="color: #64748B;">${matches.length} ${isAr ? 'نتائج' : 'results'}</span>
    </div>
  ` + matches.map(e => {
    const origIdx = employees.indexOf(e);
    const demo = e.demographic || {};
    const idStr = e.idNo || demo.nationalId || 'N/A';
    const empStr = e.empNo || e.id || demo.personNumber || 'N/A';
    const nameStr = e.name || demo.fullName || 'Staff Member';
    const deptStr = demo.orgName || e.organizationName || demo.organizationName || e.orgName || e.department || demo.deptTreating || 'Hospital Staff';
    const jobStr = e.jobTitle || demo.positionName || '';
    const isSel = origIdx === activeEmpIndex;

    return `
      <div style="padding: 10px 14px; border-bottom: 1px solid #E2E8F0; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: ${isSel ? '#F0FDFA' : '#FFFFFF'}; transition: background 0.15s;" 
           onmouseover="this.style.background='#F0F9FF'" 
           onmouseout="this.style.background='${isSel ? '#F0FDFA' : '#FFFFFF'}'"
           onclick="selectVacStaffFromSearch(${origIdx})">
        <div>
          <div style="font-weight: 700; font-size: 0.95rem; color: #0F172A;">
            ${escapeHtmlAttr(nameStr)}
            <span style="font-size: 0.8rem; font-weight: normal; color: #64748B; margin-left: 6px;">(${escapeHtmlAttr(deptStr)}${jobStr ? ' - ' + escapeHtmlAttr(jobStr) : ''})</span>
          </div>
          <div style="font-size: 0.82rem; color: #0284C7; margin-top: 2px;">
            <strong style="color: #0D9488;">${isAr ? 'الرقم الوظيفي:' : 'Emp No:'}</strong> ${escapeHtmlAttr(empStr)} | 
            <strong>${isAr ? 'الهوية:' : 'ID:'}</strong> ${escapeHtmlAttr(idStr)}
          </div>
        </div>
        <span style="background: ${isSel ? '#0D9488' : '#E0F2FE'}; color: ${isSel ? '#FFFFFF' : '#0369A1'}; padding: 3px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: bold; white-space: nowrap;">
          ${isSel ? (isAr ? '✓ المختار' : '✓ Current') : (isAr ? 'اختيار' : 'Select')}
        </span>
      </div>
    `;
  }).join('');

  resultsBox.style.display = 'block';
}
window.showVacSearchResults = showVacSearchResults;

function handleVacHeaderSearch(query) {
  vacSearchQuery = query || '';
  showVacSearchResults(query);
}
window.handleVacHeaderSearch = handleVacHeaderSearch;

function selectVacStaffFromDropdown(empNoOrId) {
  if (!empNoOrId) {
    clearVacSearch();
    return;
  }
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const targetStr = String(empNoOrId).trim().toLowerCase();
  const targetClean = targetStr.replace(/^emp-/i, '').replace(/^0+/, '');
  const sIdx = employees.findIndex(e => {
    if (!e) return false;
    const demo = e.demographic || {};
    const eNo = String(e.empNo || e.id || demo.personNumber || '').trim().toLowerCase();
    const eCleanNo = eNo.replace(/^emp-/i, '').replace(/^0+/, '');
    const eId = String(e.idNo || demo.nationalId || '').trim().toLowerCase();
    const eCleanId = eId.replace(/^0+/, '');
    return eNo === targetStr || eCleanNo === targetClean || eId === targetStr || eCleanId === targetClean || String(e.empNo) === String(empNoOrId) || String(e.id) === String(empNoOrId);
  });
  if (sIdx !== -1) {
    selectVacStaffFromSearch(sIdx);
  }
}
window.selectVacStaffFromDropdown = selectVacStaffFromDropdown;

function selectVacStaffFromSearch(idx) {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  if (idx >= 0 && employees[idx]) {
    activeEmpIndex = idx;
    const e = employees[idx];
    vacSearchQuery = e.name || (e.demographic ? e.demographic.fullName : '');
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(e);
    }
  }
  const resultsBox = document.getElementById('vac_search_results');
  if (resultsBox) resultsBox.style.display = 'none';
  const container = document.getElementById('mainAppArea');
  renderVaccinationForm(container);
}
window.selectVacStaffFromSearch = selectVacStaffFromSearch;

function handleVacSearchKeyDown(event) {
  if (event.key === 'Escape') {
    const resultsBox = document.getElementById('vac_search_results');
    if (resultsBox) resultsBox.style.display = 'none';
  } else if (event.key === 'Enter') {
    event.preventDefault();
    const resultsBox = document.getElementById('vac_search_results');
    const firstOption = resultsBox ? resultsBox.querySelector('[onclick^="selectVacStaffFromSearch"]') : null;
    if (firstOption) {
      firstOption.click();
    }
  }
}
window.handleVacSearchKeyDown = handleVacSearchKeyDown;

function clearVacSearch() {
  vacSearchQuery = '';
  activeEmpIndex = -1;
  if (typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(null);
  }
  const input = document.getElementById('vac_header_search_input');
  if (input) {
    input.value = '';
    input.focus();
  }
  const resultsBox = document.getElementById('vac_search_results');
  if (resultsBox) resultsBox.style.display = 'none';
  const container = document.getElementById('mainAppArea');
  if (container) renderVaccinationForm(container);
}
window.clearVacSearch = clearVacSearch;

if (typeof document !== 'undefined') {
  document.addEventListener('click', function(e) {
    const box = document.getElementById('vac_search_results');
    const input = document.getElementById('vac_header_search_input');
    if (box && input && !box.contains(e.target) && e.target !== input) {
      box.style.display = 'none';
    }
  });
}

function switchEmployee(idx) {
  activeEmpIndex = parseInt(idx, 10);
  let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex >= 0 && employees[activeEmpIndex] && typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(employees[activeEmpIndex]);
  }
  const container = document.getElementById('mainAppArea');
  renderVaccinationForm(container);
}

function switchSubTab(tabKey) {
  currentSubTab = tabKey;
  const container = document.getElementById('mainAppArea');
  renderVaccinationForm(container);
  if (typeof renderSidebar === 'function') {
    renderSidebar();
  }
}

function renderSubTabContent(tabKey, emp) {
  switch (tabKey) {
    case 'exemption':
      return renderFeeExemptionForm(emp);
    case 'history':
      return renderHistoryTable(emp);
    case 'checklist':
      return renderPreVaccinationChecklist(emp);
    case 'old_vac':
      return renderOldVaccinationForm(emp);
    case 'chickenpox':
      return renderChickenpoxDeclaration(emp);
    case 'covid_flu':
      return renderCovidFluForm(emp);
    case 'special':
      return renderSpecialVaccinationForm(emp);
    case 'pep':
      return renderPEPForm(emp);
    case 'refusal':
      return renderRefusalForm(emp);
    case 'infection_control':
      return renderInfectionControlApprovalForm(emp);
    default:
      return renderFeeExemptionForm(emp);
  }
}

/* ==========================================================
   SUB TAB 1: EXACT MATCH FOR FORM HR-02 (إعفاء من رسوم الفحوصات الطبية للموظفين)
   ========================================================== */
function renderFeeExemptionForm(emp) {
  const ex = emp.feeExemption || {
    startDate: emp.demographic?.assignmentEffectiveDate || emp.assignmentEffectiveDate || emp.startDate || '',
    tests: { HBsAg: true, HBsAb: true, HCV: true, HIV: true, Pregnancy: false, PPD: true, Stool: false, Urine: false },
    approvedBy: "طوني تبان مدير الموارد البشرية / بديعة بجالي مديرة العمليات التشغيلية",
    approvalDate: new Date().toISOString().slice(0, 10)
  };

  return `
    <div class="card" style="border: 2px solid var(--primary-blue); background: #FFFFFF; color: #0F172A;" id="exemptionPrintArea">
      <!-- DOCUMENT HEADER MATCHING FORM HR-02 -->
      <div style="margin-bottom: 20px; width: 100%; direction: rtl;">
        <!-- 1. HEADER ROW: LOGO ON RIGHT (R.T SIDE) & TITLE ON LEFT -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; direction: rtl; width: 100%;">
          <div style="text-align: right;">
            <img src="assets/avh_logo.png" alt="Augusta Victoria Hospital" style="height: 60px; max-width: 320px; object-fit: contain; display: inline-block;" />
          </div>
          <div style="text-align: left; direction: rtl;">
            <div style="font-size: 1.35rem; font-weight: 800; color: var(--primary-blue);">نموذج إعفاء من رسوم الفحوصات الطبية</div>
            <div style="font-size: 1.05rem; font-weight: bold; color: #64748B; text-align: left;">للموظفين الجدد</div>
          </div>
        </div>

        <!-- 2. DIVIDING LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 6px 0 14px 0; width: 100%;"></div>

        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl; width: 100%;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: <input type="date" id="ex_appdate" value="${ex.approvalDate || new Date().toISOString().slice(0, 10)}" style="padding: 4px 8px; font-weight: bold; border: 1.5px solid #CBD5E1; border-radius: 4px; color: #0F172A; background: #FFFFFF;">
          </div>
        </div>
      </div>

      <!-- EMPLOYEE METADATA FIELDS -->
      <div style="direction: rtl; font-size: 1rem; line-height: 2.2; margin-bottom: 24px; background: #F8FAFC; padding: 16px 20px; border-radius: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; width: 100%;">
        <div style="display: flex; gap: 12px; align-items: center;">
          <strong style="min-width: 150px; color: #0F172A !important; font-size: 1.05rem;">إسم الموظف :</strong>
          <input type="text" id="ex_name" value="${escapeHtmlAttr(emp.name || (emp.demographic ? emp.demographic.fullName : ''))}" style="flex: 1; padding: 7px 12px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; border: 1.5px solid #CBD5E1; border-radius: 4px; background: #FFFFFF; color: #0F172A;">
        </div>
        <div style="display: flex; gap: 12px; align-items: center; margin-top: 8px;">
          <strong style="min-width: 150px; color: #0F172A !important; font-size: 1.05rem;">القسم :</strong>
          <input type="text" id="ex_dept" value="${escapeHtmlAttr(emp.demographic?.orgName || emp.organizationName || emp.orgName || emp.department || (emp.demographic ? emp.demographic.deptTreating : ''))}" style="flex: 1; padding: 7px 12px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; border: 1.5px solid #CBD5E1; border-radius: 4px; background: #FFFFFF; color: #0F172A;">
        </div>
        <div style="display: flex; gap: 12px; align-items: center; margin-top: 8px;">
          <strong style="min-width: 150px; color: #0F172A !important; font-size: 1.05rem;">تاريخ بداية التوظيف :</strong>
          <input type="text" id="ex_startdate" value="${escapeHtmlAttr(formatDateDDMMYYYY(emp.demographic?.assignmentEffectiveDate || emp.assignmentEffectiveDate || ex.startDate || ''))}" placeholder="dd/mm/yyyy" style="width: 220px; padding: 7px 12px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; border: 1.5px solid #CBD5E1; border-radius: 4px; background: #FFFFFF; color: #0F172A;">
        </div>
      </div>

      <!-- TABLE 1: REQUIRED MEDICAL EXAMINATIONS -->
      <h4 style="direction: rtl; color: var(--primary-blue); margin-bottom: 8px; font-size: 1.05rem; font-weight: bold;">الفحوصات الطبيّة المطلوبة فقط:</h4>
      <div style="margin-bottom: 24px; overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; table-layout: fixed; direction: rtl; background: #FFFFFF; border: 1.5px solid #94A3B8;">
          <thead>
            <tr style="background: #E2E8F0;">
              <th style="width: 70px; text-align: center; padding: 10px; border: 1.5px solid #94A3B8; color: #0F172A; font-weight: 800; font-size: 0.95rem;">إختيار</th>
              <th style="text-align: left; direction: ltr; padding: 10px 14px; border: 1.5px solid #94A3B8; color: #0F172A; font-weight: 800; font-size: 0.95rem;">Test Name</th>
              <th style="width: 130px; text-align: center; direction: ltr; padding: 10px; border: 1.5px solid #94A3B8; color: #0F172A; font-weight: 800; font-size: 0.95rem;">Code</th>
            </tr>
          </thead>
          <tbody>
            <tr style="background: #FFFFFF;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_HBsAg" ${ex.tests?.HBsAg !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">Hepatitis B Surface Antigen (HBsAg)</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 800; font-size: 0.95rem;">TST0042</td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_HBsAb" ${ex.tests?.HBsAb !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">Hepatitis B Virus Surface Antibodies (HBsAb)</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 800; font-size: 0.95rem;">TST0040</td>
            </tr>
            <tr style="background: #FFFFFF;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_HCV" ${ex.tests?.HCV !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">Hepatitis C Virus - IgG (HCV)</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 800; font-size: 0.95rem;">TST0056</td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_HIV" ${ex.tests?.HIV !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">Human Immunodeficiency Virus (HIV)</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 800; font-size: 0.95rem;">TST0039</td>
            </tr>
            <tr style="background: #FFFFFF;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_Pregnancy" ${ex.tests?.Pregnancy ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">Pregnancy test, serum</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 800; font-size: 0.95rem;">TST0038</td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_PPD" ${ex.tests?.PPD !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">PPD (Tuberculin Skin Test)</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #64748B; font-weight: 800; font-size: 0.95rem;">-</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- TABLE 2: ADDITIONAL REQUIRED MEDICAL EXAMINATIONS AS NEEDED -->
      <h4 style="direction: rtl; color: var(--primary-blue); margin-bottom: 8px; font-size: 1.05rem; font-weight: bold;">الفحوصات الطبيّة الإضافية المطلوبة عند اللزوم:</h4>
      <div style="margin-bottom: 24px; overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; table-layout: fixed; direction: rtl; background: #FFFFFF; border: 1.5px solid #94A3B8;">
          <thead>
            <tr style="background: #E2E8F0;">
              <th style="width: 70px; text-align: center; padding: 10px; border: 1.5px solid #94A3B8; color: #0F172A; font-weight: 800; font-size: 0.95rem;">إختيار</th>
              <th style="text-align: left; direction: ltr; padding: 10px 14px; border: 1.5px solid #94A3B8; color: #0F172A; font-weight: 800; font-size: 0.95rem;">Test Name</th>
              <th style="width: 130px; text-align: center; direction: ltr; padding: 10px; border: 1.5px solid #94A3B8; color: #0F172A; font-weight: 800; font-size: 0.95rem;">Code</th>
            </tr>
          </thead>
          <tbody>
            <tr style="background: #FFFFFF;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_Stool" ${ex.tests?.Stool ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">Stool Analysis</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 800; font-size: 0.95rem;">TST0025</td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="text-align: center; padding: 8px; border: 1.5px solid #CBD5E1;"><input type="checkbox" id="ex_Urine" ${ex.tests?.Urine ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #0284C7;"></td>
              <td style="text-align: left; direction: ltr; padding: 8px 14px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 600; font-size: 0.95rem;">Urine Analysis</td>
              <td style="text-align: center; direction: ltr; padding: 8px; border: 1.5px solid #CBD5E1; color: #0F172A; font-weight: 800; font-size: 0.95rem;">TST0022</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- MANDATORY POLICY NOTICE -->
      <div style="direction: rtl; text-align: center; background: #FEF3C7; border: 1.5px solid #FCD34D; color: #78350F; padding: 12px; border-radius: 6px; font-weight: bold; margin-bottom: 24px; font-size: 1rem; line-height: 1.6;">
        هذه الفحوصات تُعمل مرة واحدة فقط عند التوظيف وهي متطلب أساسي لاكتمال عملية التوظيف.
      </div>

      <!-- APPROVAL SIGNATURES -->
      <div style="direction: rtl; border-top: 2px solid #CBD5E1; padding-top: 20px; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 20px;">
          <div>
            <div style="font-size: 1.1rem; font-weight: bold; color: var(--primary-blue);">الموافقة: ____________________</div>
            <div style="margin-top: 8px; font-weight: bold; color: #0F172A;">
              طوني تبان مدير الموارد البشرية / بديعة بجالي مديرة العمليات التشغيلية
            </div>
          </div>
          <div>
            <div style="font-size: 1.05rem; font-weight: bold; color: var(--primary-blue);">
              التاريخ: <input type="date" id="ex_appdate_display" value="${ex.approvalDate || new Date().toISOString().slice(0, 10)}" style="padding: 4px 8px; font-weight: bold; border: 1.5px solid #CBD5E1; border-radius: 4px; color: #0F172A; background: #FFFFFF;">
            </div>
          </div>
        </div>
      </div>

      <!-- OFFICIAL FORM CODE ROW -->
      <div style="display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: bold; border: 1px solid #94A3B8; padding: 6px 12px; margin-bottom: 16px; background: #F8FAFC; color: #334155; direction: ltr;">
        <div>Form Code: HR-01</div>
        <div>Issue No.: 1/5</div>
        <div>Issue Date: 06/06/2022</div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 10px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 55px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- ACTION BUTTONS -->
      <div style="display: flex; gap: 16px; justify-content: flex-end; align-items: center; margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1;" class="no-print">
        <button class="btn btn-outline" onclick="printFeeExemptionForm()" style="font-weight: 700;">🖨️ Print Completed Exemption Form (HR-02)</button>
        <button class="btn btn-success" onclick="saveExemptionForm()" style="font-weight: 700;">💾 Save Exemption Form in Application</button>
      </div>
    </div>
  `;
}

function executeSameWindowPrint(htmlContent) {
  let iframe = document.getElementById('avh_same_window_print_iframe');
  if (iframe) {
    try { iframe.remove(); } catch (e) {}
  }
  iframe = document.createElement('iframe');
  iframe.id = 'avh_same_window_print_iframe';
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.top = '0';
  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = 'none';
  iframe.style.opacity = '0';
  iframe.style.zIndex = '-9999';
  iframe.style.pointerEvents = 'none';
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument || iframe.contentWindow.document;
  doc.open();
  doc.write(htmlContent);
  doc.close();

  const triggerPrint = () => {
    try {
      iframe.contentWindow.focus();
      iframe.contentWindow.print();
    } catch (e) {
      window.print();
    }
  };

  const imgs = doc.images;
  if (imgs && imgs.length > 0) {
    let loaded = 0;
    const total = imgs.length;
    let printed = false;
    const checkDone = () => {
      loaded++;
      if (loaded >= total && !printed) {
        printed = true;
        setTimeout(triggerPrint, 200);
      }
    };
    for (let i = 0; i < total; i++) {
      if (imgs[i].complete) {
        checkDone();
      } else {
        imgs[i].onload = checkDone;
        imgs[i].onerror = checkDone;
      }
    }
    setTimeout(() => {
      if (!printed) {
        printed = true;
        triggerPrint();
      }
    }, 800);
  } else {
    setTimeout(triggerPrint, 400);
  }
}
window.executeSameWindowPrint = executeSameWindowPrint;

function printFeeExemptionForm() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  let emp = (activeEmpIndex >= 0 && employees[activeEmpIndex]) ? employees[activeEmpIndex] : {};

  const rawName = document.getElementById('ex_name')?.value || emp.name || (emp.demographic ? emp.demographic.fullName : '') || '........................................';
  const name = String(rawName).replace(/^["'\s]+|["'\s]+$/g, '').trim() || rawName;

  const rawDept = document.getElementById('ex_dept')?.value || emp.demographic?.orgName || emp.organizationName || emp.orgName || emp.department || (emp.demographic ? emp.demographic.deptTreating : '') || '........................................';
  const dept = String(rawDept).replace(/^["'\s]+|["'\s]+$/g, '').trim() || rawDept;

  const rawStartDate = document.getElementById('ex_startdate')?.value || emp.demographic?.assignmentEffectiveDate || emp.assignmentEffectiveDate || emp.startDate || '';
  const startDate = (typeof standardizeDateStr === 'function' && rawStartDate) ? standardizeDateStr(rawStartDate, false) : (rawStartDate || '....................');

  let rawAppDate = document.getElementById('ex_appdate')?.value || '';
  let appDate = (typeof standardizeDateStr === 'function' && rawAppDate) ? standardizeDateStr(rawAppDate, false) : (rawAppDate || new Date().toLocaleDateString('en-GB'));

  const isHBsAg = document.getElementById('ex_HBsAg')?.checked ?? true;
  const isHBsAb = document.getElementById('ex_HBsAb')?.checked ?? true;
  const isHCV = document.getElementById('ex_HCV')?.checked ?? true;
  const isHIV = document.getElementById('ex_HIV')?.checked ?? true;
  const isPreg = document.getElementById('ex_Pregnancy')?.checked ?? false;
  const isPPD = document.getElementById('ex_PPD')?.checked ?? true;
  const isStool = document.getElementById('ex_Stool')?.checked ?? false;
  const isUrine = document.getElementById('ex_Urine')?.checked ?? false;

  const htmlContent = `
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
      <meta charset="UTF-8">
      <title></title>
      <style>
        @page {
          size: A4 portrait;
          margin: 0 !important;
        }
        * {
          box-sizing: border-box !important;
        }
        html, body {
          width: 100% !important;
          max-width: 100% !important;
          min-height: 100% !important;
          height: 100% !important;
          margin: 0 !important;
          padding: 0 !important;
          font-family: 'Times New Roman', Times, serif;
          font-size: 11pt;
          color: #000000 !important;
          background: #FFFFFF !important;
          -webkit-print-color-adjust: exact !important;
          print-color-adjust: exact !important;
          direction: rtl !important;
          text-align: right !important;
          box-sizing: border-box !important;
        }
        .page-container {
          box-sizing: border-box !important;
          width: 100% !important;
          max-width: 100% !important;
          min-height: 297mm !important;
          height: 297mm !important;
          padding: 8mm 14mm 8mm 14mm !important;
          margin: 0 auto !important;
          display: flex !important;
          flex-direction: column !important;
          justify-content: space-between !important;
          page-break-inside: avoid !important;
          break-inside: avoid !important;
          direction: rtl !important;
          text-align: right !important;
        }
        .form-top-section {
          width: 100% !important;
          direction: rtl !important;
        }
        .meta-box {
          background: #F8FAFC;
          border: 1.5px solid #94A3B8;
          padding: 12px 18px;
          border-radius: 6px;
          margin-bottom: 14px;
          font-size: 11.5pt;
          line-height: 2.2;
          width: 100% !important;
          direction: rtl !important;
        }
        .meta-row {
          display: flex;
          gap: 12px;
          align-items: center;
          direction: rtl;
        }
        .meta-val {
          font-weight: bold;
          font-size: 12pt;
          border-bottom: 1.5px dotted #000;
          flex: 1;
          padding: 0 10px;
          color: #000;
          text-align: right;
        }
        .form-body-section {
          width: 100% !important;
          direction: rtl !important;
        }
        table {
          width: 100% !important;
          max-width: 100% !important;
          border-collapse: collapse !important;
          table-layout: fixed !important;
          margin-bottom: 12px !important;
          direction: rtl !important;
          box-sizing: border-box !important;
        }
        th, td {
          border: 1.5px solid #000000 !important;
          padding: 6px 10px !important;
          font-size: 10.5pt !important;
          color: #000000 !important;
          vertical-align: middle !important;
          box-sizing: border-box !important;
        }
        th {
          background: #E2E8F0 !important;
          font-weight: bold !important;
          font-size: 11pt !important;
        }
        .chk {
          text-align: center !important;
          font-weight: bold !important;
          font-size: 14pt !important;
          width: 60px !important;
        }
        .test-name {
          text-align: left !important;
          direction: ltr !important;
          font-weight: 600 !important;
          padding-left: 12px !important;
        }
        .code-cell {
          text-align: center !important;
          direction: ltr !important;
          font-weight: 800 !important;
          width: 115px !important;
        }
        .notice {
          text-align: center;
          background: #FEF3C7;
          border: 1.5px solid #FCD34D;
          color: #78350F;
          padding: 10px 16px;
          border-radius: 6px;
          font-weight: bold;
          margin-top: 10px;
          margin-bottom: 10px;
          font-size: 10.5pt;
          line-height: 1.5;
          width: 100% !important;
        }
        .form-bottom-section {
          width: 100% !important;
          direction: rtl !important;
        }
        .signatures {
          display: flex;
          justify-content: space-between;
          align-items: flex-end;
          margin-top: 10px;
          border-top: 1.5px solid #000;
          padding-top: 10px;
          font-size: 11.5pt;
          line-height: 1.8;
          width: 100% !important;
          direction: rtl !important;
        }
        .doc-code-row {
          display: flex;
          justify-content: space-between;
          font-size: 8.5pt;
          font-weight: bold;
          border: 1px solid #000;
          padding: 3px 8px;
          margin-top: 10px;
          margin-bottom: 8px;
          direction: ltr;
          background: #F8FAFC;
          width: 100% !important;
        }
        .branded-footer {
          margin-top: 6px;
          width: 100% !important;
          text-align: center;
        }
        .branded-footer img {
          width: 100% !important;
          max-width: 100% !important;
          height: auto;
          max-height: 52px;
          object-fit: contain;
          display: block;
          margin: 0 auto;
          image-rendering: -webkit-optimize-contrast;
        }
        @media print {
          @page {
            size: A4 portrait;
            margin: 0 !important;
          }
          html, body {
            width: 100% !important;
            max-width: 100% !important;
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            direction: rtl !important;
            text-align: right !important;
          }
          .page-container {
            width: 100% !important;
            max-width: 100% !important;
            min-height: 297mm !important;
            height: 297mm !important;
            padding: 8mm 14mm 8mm 14mm !important;
            margin: 0 !important;
            direction: rtl !important;
            text-align: right !important;
          }
        }
      </style>
    </head>
    <body>
      <div class="page-container">
        <!-- TOP SECTION: HEADER, TITLE, METADATA -->
        <div class="form-top-section">
          <!-- 1. HEADER ROW: LOGO ON RIGHT (R.T SIDE) & TITLE ON LEFT -->
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; direction: rtl; width: 100%;">
            <!-- LOGO ON RIGHT SIDE -->
            <div style="text-align: right;">
              <img src="assets/avh_logo.png" alt="Augusta Victoria Hospital" style="height: 56px; max-width: 320px; object-fit: contain; display: inline-block; image-rendering: -webkit-optimize-contrast;" />
            </div>
            <!-- TITLE ON LEFT SIDE -->
            <div style="text-align: left; direction: rtl;">
              <div style="font-size: 14pt; font-weight: 800; color: #1A5F7A; white-space: nowrap;">نموذج إعفاء من رسوم الفحوصات الطبية</div>
              <div style="font-size: 11pt; font-weight: bold; color: #475569; text-align: left;">للموظفين الجدد</div>
            </div>
          </div>

          <!-- 2. DIVIDING LINE -->
          <div style="border-bottom: 2px solid #1A5F7A; margin: 4px 0 10px 0; width: 100%;"></div>

          <!-- 3. DATE ON RIGHT SIDE -->
          <div style="text-align: right; margin-bottom: 8px; direction: rtl; width: 100%;">
            <div style="font-weight: bold; font-size: 11pt; color: #000;">
              التاريخ: ${appDate}
            </div>
          </div>

          <!-- 4. METADATA BOX -->
          <div class="meta-box">
            <div class="meta-row">
              <strong style="min-width: 130px; font-size: 12pt;">إسم الموظف :</strong>
              <div class="meta-val">${name}</div>
            </div>
            <div class="meta-row" style="margin-top: 6px;">
              <strong style="min-width: 130px; font-size: 12pt;">القسم :</strong>
              <div class="meta-val">${dept}</div>
            </div>
            <div class="meta-row" style="margin-top: 6px;">
              <strong style="min-width: 130px; font-size: 12pt;">تاريخ بداية التوظيف :</strong>
              <div class="meta-val" style="flex: none; width: 220px;">${startDate}</div>
            </div>
          </div>
        </div>

        <!-- BODY SECTION: TABLES & NOTICE -->
        <div class="form-body-section">
          <h4 style="color: #1A5F7A; margin-top: 10px; margin-bottom: 6px; font-size: 11.5pt; font-weight: bold; text-align: right; direction: rtl;">الفحوصات الطبيّة المطلوبة فقط:</h4>
          <table>
            <thead>
              <tr>
                <th style="width: 60px; text-align: center;">إختيار</th>
                <th style="text-align: left; direction: ltr; padding-left: 12px;">Test Name</th>
                <th style="width: 115px; text-align: center; direction: ltr;">Code</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="chk">${isHBsAg ? '☑' : '☐'}</td>
                <td class="test-name">Hepatitis B Surface Antigen (HBsAg)</td>
                <td class="code-cell">TST0042</td>
              </tr>
              <tr>
                <td class="chk">${isHBsAb ? '☑' : '☐'}</td>
                <td class="test-name">Hepatitis B Virus Surface Antibodies (HBsAb)</td>
                <td class="code-cell">TST0040</td>
              </tr>
              <tr>
                <td class="chk">${isHCV ? '☑' : '☐'}</td>
                <td class="test-name">Hepatitis C Virus - IgG (HCV)</td>
                <td class="code-cell">TST0056</td>
              </tr>
              <tr>
                <td class="chk">${isHIV ? '☑' : '☐'}</td>
                <td class="test-name">Human Immunodeficiency Virus (HIV)</td>
                <td class="code-cell">TST0039</td>
              </tr>
              <tr>
                <td class="chk">${isPreg ? '☑' : '☐'}</td>
                <td class="test-name">Pregnancy test, serum</td>
                <td class="code-cell">TST0038</td>
              </tr>
              <tr>
                <td class="chk">${isPPD ? '☑' : '☐'}</td>
                <td class="test-name">PPD (Tuberculin Skin Test)</td>
                <td class="code-cell">-</td>
              </tr>
            </tbody>
          </table>

          <h4 style="color: #1A5F7A; margin-top: 12px; margin-bottom: 6px; font-size: 11.5pt; font-weight: bold; text-align: right; direction: rtl;">الفحوصات الطبيّة الإضافية المطلوبة عند اللزوم:</h4>
          <table>
            <thead>
              <tr>
                <th style="width: 60px; text-align: center;">إختيار</th>
                <th style="text-align: left; direction: ltr; padding-left: 12px;">Test Name</th>
                <th style="width: 115px; text-align: center; direction: ltr;">Code</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="chk">${isStool ? '☑' : '☐'}</td>
                <td class="test-name">Stool Analysis</td>
                <td class="code-cell">TST0025</td>
              </tr>
              <tr>
                <td class="chk">${isUrine ? '☑' : '☐'}</td>
                <td class="test-name">Urine Analysis</td>
                <td class="code-cell">TST0022</td>
              </tr>
            </tbody>
          </table>

          <div class="notice">
            هذه الفحوصات تُعمل مرة واحدة فقط عند التوظيف وهي متطلب أساسي لاكتمال عملية التوظيف.
          </div>
        </div>

        <!-- BOTTOM SECTION: SIGNATURES, DOC CODE, BRANDED FOOTER -->
        <div class="form-bottom-section">
          <div class="signatures">
            <div style="text-align: right;">
              <div style="font-weight: bold; font-size: 11.5pt;">الموافقة: ____________________</div>
              <div style="margin-top: 6px; font-weight: bold; font-size: 10.5pt;">
                طوني تبان مدير الموارد البشرية / بديعة بجالي مديرة العمليات التشغيلية
              </div>
            </div>
            <div style="text-align: left; direction: rtl;">
              <div style="font-weight: bold; font-size: 11pt;">
                التاريخ: ${appDate}
              </div>
            </div>
          </div>

          <div class="doc-code-row">
            <div>Form Code: HR-01</div>
            <div>Issue No.: 1/5</div>
            <div>Issue Date: 06/06/2022</div>
          </div>

          <!-- BRANDED FOOTER IMAGE -->
          <div class="branded-footer">
            <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" />
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
  executeSameWindowPrint(htmlContent);
}

window.printFeeExemptionForm = printFeeExemptionForm;

function printSubForm(containerId, docTitle) {
  const container = document.getElementById(containerId);
  if (!container) {
    window.print();
    return;
  }

  const clone = container.cloneNode(true);
  const originalInputs = container.querySelectorAll('input, select, textarea');
  const cloneInputs = clone.querySelectorAll('input, select, textarea');

  for (let i = 0; i < originalInputs.length; i++) {
    const orig = originalInputs[i];
    const cln = cloneInputs[i];
    if (!orig || !cln) continue;

    const span = document.createElement('span');
    span.style.fontFamily = "'Times New Roman', Times, serif";
    span.style.fontWeight = "bold";

    if (orig.type === 'checkbox') {
      span.innerHTML = orig.checked ? ' ☑ ' : ' ☐ ';
      cln.parentNode.replaceChild(span, cln);
    } else if (orig.type === 'radio') {
      span.innerHTML = orig.checked ? ' 🔘 ' : ' ⚪ ';
      cln.parentNode.replaceChild(span, cln);
    } else if (orig.tagName.toLowerCase() === 'select') {
      const selectedOpt = orig.options[orig.selectedIndex];
      span.textContent = selectedOpt ? selectedOpt.text : orig.value;
      span.style.borderBottom = "1px dotted #000";
      span.style.padding = "0 4px";
      cln.parentNode.replaceChild(span, cln);
    } else {
      const val = orig.value || '';
      span.textContent = val;
      if (orig.style.borderBottom || orig.style.border) {
        span.style.borderBottom = "1.5px dotted #000";
        span.style.padding = "0 6px";
        span.style.display = "inline-block";
        span.style.minWidth = orig.style.width || "100px";
      }
      cln.parentNode.replaceChild(span, cln);
    }
  }

  clone.querySelectorAll('.no-print').forEach(el => el.remove());

  // Replace text footer boxes with official branded footer image
  clone.querySelectorAll('.form-footer-box, .footer-code').forEach(el => {
    const footerDiv = document.createElement('div');
    footerDiv.className = 'branded-footer-print';
    footerDiv.style.marginTop = 'auto';
    footerDiv.style.paddingTop = '10px';
    footerDiv.style.width = '100%';
    footerDiv.style.textAlign = 'center';
    footerDiv.innerHTML = `<img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; max-width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto; image-rendering: -webkit-optimize-contrast;" />`;
    el.parentNode.replaceChild(footerDiv, el);
  });

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const htmlContent = `
    <!DOCTYPE html>
    <html lang="${isAr ? 'ar' : 'en'}" dir="${isAr ? 'rtl' : 'ltr'}">
    <head>
      <meta charset="UTF-8">
      <title></title>
      <style>
        @page { size: A4 portrait; margin: 10mm 15mm; }
        * { box-sizing: border-box; }
        html, body { width: 100%; height: 100%; margin: 0 !important; padding: 0 !important; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; color: #000; line-height: 1.4; background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .page-container { width: 100% !important; max-width: 100% !important; margin: 0 auto !important; padding: 0 !important; box-sizing: border-box; page-break-inside: avoid; break-inside: avoid; min-height: 265mm; display: flex; flex-direction: column; justify-content: space-between; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 12px; }
        th, td { border: 1.5px solid #000; padding: 5px 8px; font-size: 9.5pt; }
        th { background: #F1F5F9; font-weight: bold; }
        .no-print { display: none !important; }
        .card { border: none !important; box-shadow: none !important; padding: 0 !important; }
        @media print {
          html, body { width: 100% !important; margin: 0 !important; padding: 0 !important; }
          .page-container { width: 100% !important; max-width: 100% !important; margin: 0 !important; padding: 0 !important; page-break-inside: avoid !important; break-inside: avoid !important; min-height: 265mm !important; }
        }
      </style>
    </head>
    <body>
      <div class="page-container">
        ${clone.innerHTML}
      </div>
    </body>
    </html>
  `;
  executeSameWindowPrint(htmlContent);
}
window.printSubForm = printSubForm;

async function saveExemptionForm() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  emp.feeExemption = {
    startDate: document.getElementById('ex_startdate')?.value || '',
    tests: {
      HBsAg: document.getElementById('ex_HBsAg')?.checked,
      HBsAb: document.getElementById('ex_HBsAb')?.checked,
      HCV: document.getElementById('ex_HCV')?.checked,
      HIV: document.getElementById('ex_HIV')?.checked,
      Pregnancy: document.getElementById('ex_Pregnancy')?.checked,
      PPD: document.getElementById('ex_PPD')?.checked,
      Stool: document.getElementById('ex_Stool')?.checked,
      Urine: document.getElementById('ex_Urine')?.checked
    },
    approvedBy: "طوني تبان مدير الموارد البشرية / بديعة بجالي مديرة العمليات التشغيلية",
    approvalDate: document.getElementById('ex_appdate')?.value || new Date().toISOString().slice(0, 10)
  };

  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

/* ==========================================================
   SUB TAB 3: VACCINATION & TEST HISTORY (EXACT MATCH FOR USER IMAGES)
   ========================================================== */
function renderHistoryTable(emp) {
  const v = emp.vaccines || {};
  const lab = emp.labResults || {};
  const currentDate = new Date().toISOString().slice(0, 10);

  const mainVaccines = [
    { key: "IPV", name: "IPV", flatProps: { d5: 'ipvDate' } },
    { key: "OPV", name: "OPV", flatProps: {} },
    { key: "DPT/dT", name: "DPT/dT", flatProps: {} },
    { key: "Tdap", name: "Tdap", flatProps: { d5: 'tdapDate' } },
    { key: "MMR", name: "MMR", flatProps: { d1: 'mmrDose1', d5: 'mmrDose2' } },
    { key: "Hepatitis B", name: "Hepatitis B", flatProps: { d5: 'hbvDose1', d6: 'hbvDose2', d7: 'hbvDose3' } },
    { key: "Varicella Zoster (Chicken pox)", name: "Chicken pox", flatProps: { d1: 'chickenpoxStatus', d2: 'chickenpoxDose1', d3: 'chickenpoxDose2' } }
  ];

  // Helper getters for lab results & vaccine dates imported from Master Data
  const getLabVal = (key, flatProp, fallback = '') => {
    let raw = getFirstDefinedLabValue(
      (lab[key] && typeof lab[key] === 'object' ? lab[key].result : undefined),
      lab[flatProp],
      emp[flatProp]
    );
    if (raw === '' || raw === null || raw === undefined) raw = fallback;
    if (raw === '' || raw === null || raw === undefined) return '';
    return typeof formatDateDDMMYYYY === 'function' ? formatDateDDMMYYYY(raw) : toSafeLabString(raw);
  };
  const effectiveDate = emp.demographic?.assignmentEffectiveDate || emp.assignmentEffectiveDate || emp.demographic?.startDate || emp.startDate || '';

  const getLabDateVal = (key, flatProp) => {
    let raw = '';
    if (lab[key] && lab[key].date !== undefined && lab[key].date !== '') raw = lab[key].date;
    else if (lab[flatProp] !== undefined && lab[flatProp] !== null && lab[flatProp] !== '') raw = lab[flatProp].toString().trim();
    else if (emp[flatProp] !== undefined && emp[flatProp] !== null && emp[flatProp] !== '') raw = emp[flatProp].toString().trim();
    else if (emp.demographic && emp.demographic[flatProp] !== undefined && emp.demographic[flatProp] !== null && emp.demographic[flatProp] !== '') raw = emp.demographic[flatProp].toString().trim();
    
    if (!raw) return '';
    return typeof formatDateDDMMYYYY === 'function' ? formatDateDDMMYYYY(raw) : raw;
  };
  const getVaccineDoseVal = (item, doseKey) => {
    const rec = v[item.key] || {};

    // 1. Special auto-import for MMR (Dose 1 in Dose 1 out of hospital, Dose 2 in Dose 5 inside hospital)
    if (item.key === 'MMR') {
      if (doseKey === 'd1') {
        const val = rec.d1 || v.mmrDose1 || emp.mmrDose1 || (emp.demographic ? emp.demographic.mmrDose1 : '') || '';
        return val ? formatDateDDMMYYYY(val) : '';
      }
      if (doseKey === 'd5') {
        const val = rec.d5 || rec.d2 || v.mmrDose2 || emp.mmrDose2 || (emp.demographic ? emp.demographic.mmrDose2 : '') || '';
        return val ? formatDateDDMMYYYY(val) : '';
      }
      if (doseKey === 'd2') {
        if (rec.d2 && rec.d5 && rec.d2 !== rec.d5) return formatDateDDMMYYYY(rec.d2);
        return '';
      }
      if (rec[doseKey] !== undefined && rec[doseKey] !== null && rec[doseKey] !== '') {
        return formatDateDDMMYYYY(rec[doseKey]);
      }
      return '';
    }

    // 3. Auto-import for Chicken pox (Varicella Zoster) from original master data sources
    if (item.key === 'Varicella Zoster (Chicken pox)') {
      if (doseKey === 'd1' || doseKey === 'd5') {
        let val = v.chickenpoxStatus || emp.chickenpoxStatus || (emp.demographic ? emp.demographic.chickenpoxStatus : '') || '';
        if (val.toLowerCase().includes('declaration') || val.toLowerCase().includes('having varicella') || val.toLowerCase().includes('natural')) {
          val = 'Natural Immunity';
        }
        return val ? formatDateDDMMYYYY(val) : '';
      }
      if (doseKey === 'd2') {
        const val = v.chickenpoxDose2 || emp.chickenpoxDose2 || (emp.demographic ? emp.demographic.chickenpoxDose2 : '') || '';
        return val ? formatDateDDMMYYYY(val) : '';
      }
    }

    // 4. Auto-import for Hepatitis B Engrix doses (moved to Dose 5, Dose 6, Dose 7 inside hospital)
    if (item.key === 'Hepatitis B') {
      const e1 = lab.engrixDose1 || emp.engrixDose1 || (emp.demographic ? emp.demographic.engrixDose1 : '') || v.hbvDose1 || '';
      const e2 = lab.engrixDose2 || emp.engrixDose2 || (emp.demographic ? emp.demographic.engrixDose2 : '') || v.hbvDose2 || '';
      const e3 = lab.engrixDose3 || emp.engrixDose3 || (emp.demographic ? emp.demographic.engrixDose3 : '') || v.hbvDose3 || '';

      if (doseKey === 'd5') return e1 ? formatDateDDMMYYYY(e1) : '';
      if (doseKey === 'd6') return e2 ? formatDateDDMMYYYY(e2) : '';
      if (doseKey === 'd7') return e3 ? formatDateDDMMYYYY(e3) : '';
    }

    // 5. For other vaccines, out-of-hospital doses (d1-d4) are manual entry only
    if (['d1', 'd2', 'd3', 'd4'].includes(doseKey)) {
      return '';
    }

    const flatProp = item.flatProps ? item.flatProps[doseKey] : null;
    if (flatProp) {
      if (v[flatProp] !== undefined && v[flatProp] !== null && v[flatProp] !== '') {
        return formatDateDDMMYYYY(v[flatProp]);
      }
      if (emp[flatProp] !== undefined && emp[flatProp] !== null && emp[flatProp] !== '') {
        return formatDateDDMMYYYY(emp[flatProp]);
      }
      if (lab[flatProp] !== undefined && lab[flatProp] !== null && lab[flatProp] !== '') {
        return formatDateDDMMYYYY(lab[flatProp]);
      }
    }
    return '';
  };
  const getPpdQual = (resultKey, fallbackVal = 'Negative') => {
    if (lab.PPD && lab.PPD[resultKey] !== undefined && lab.PPD[resultKey] !== '') {
      return lab.PPD[resultKey];
    }
    if (lab[resultKey] !== undefined && lab[resultKey] !== null && lab[resultKey].toString().trim() !== '') {
      return lab[resultKey].toString().trim();
    }
    if (lab.ppdResult !== undefined && lab.ppdResult !== null && lab.ppdResult.toString().trim() !== '') {
      return lab.ppdResult.toString().trim();
    }
    if (emp.name) return fallbackVal;
    return '';
  };

  const getPpdInd = (testKey, indurationKey, fallbackVal = '0') => {
    if (lab.PPD && lab.PPD[testKey] !== undefined && lab.PPD[testKey] !== '') {
      const match = lab.PPD[testKey].toString().match(/(\d+)/);
      if (match) return match[1];
    }
    if (lab[indurationKey] !== undefined && lab[indurationKey] !== null && lab[indurationKey].toString().trim() !== '') {
      const match = lab[indurationKey].toString().match(/(\d+)/);
      if (match) return match[1];
    }
    if (emp.name) return fallbackVal;
    return '';
  };

  const hbsabRes = getLabVal('HBsAb', 'hbsabResult');
  const hbsabDt = getLabDateVal('HBsAb', 'hbsabDate');
  const hbsagRes = getLabVal('HBsAg', 'hbsagResult') || (emp.name ? 'Negative' : '');
  const hbsagDt = getLabDateVal('HBsAg', 'hbsagDate') || hbsabDt;
  const hcvRes = getLabVal('HCV', 'hcvResult');
  const hcvDt = getLabDateVal('HCV', 'hcvDate');
  const hivRes = getLabVal('HIV', 'hivResult');
  const hivDt = getLabDateVal('HIV', 'hivDate');
  const ppd1Qual = getPpdQual('ppdStep1Result', 'Negative');
  const ppd1Ind = getPpdInd('test1', 'ppdStep1Induration', '0');
  const ppd2Qual = getPpdQual('ppdStep2Result', 'Negative');
  const ppd2Ind = getPpdInd('test2', 'ppdStep2Induration', '0');
  const ppd1Dt = getLabDateVal('PPD', 'ppdStep1Date') || getLabDateVal('PPD', 'ppdDate');
  const ppd2Dt = getLabDateVal('PPD', 'ppdStep2Date');
  const varicellaRaw = getLabVal('Varicella_IgG', 'varicellaIgG') || emp.chickenpoxStatus || emp.vaccines?.chickenpoxStatus || emp.vaccines?.['Varicella Zoster (Chicken pox)']?.d1 || '';
  const varicellaRes = varicellaRaw ? formatDateDDMMYYYY(varicellaRaw) : (emp.name ? 'Natural Immunity' : '');
  const varicellaDt = getLabDateVal('Varicella_IgG', 'varicellaIgGDate');
  const mumpsRes = getLabVal('Mumps_IgG', 'mumpsIgGTiter');
  const mumpsDt = getLabDateVal('Mumps_IgG', 'mumpsIgGTiterDate');
  const measlesRes = getLabVal('Measles_IgG', 'measlesIgGTiter');
  const measlesDt = getLabDateVal('Measles_IgG', 'measlesIgGTiterDate');
  const rubellaRes = getLabVal('Rubella_IgG', 'rubellaIgGTiter');
  const rubellaDt = getLabDateVal('Rubella_IgG', 'rubellaIgGTiterDate');
  const otherRes = getLabVal('Other', 'otherResult');
  const otherDt = getLabDateVal('Other', 'otherDate');

  return `
    <div style="background: white; padding: 20px 28px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;" id="historyPrintArea">
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${typeof formatDateDDMMYYYY === 'function' ? formatDateDDMMYYYY(currentDate) : currentDate}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Vaccination and Test History of a Healthcare Worker</h2>
        </div>
      </div>

      <!-- METADATA BLOCK -->
      <div style="font-size: 0.98rem; line-height: 1.7; margin-bottom: 12px;">
        <div><strong>Date:</strong> <input type="text" id="vh_date" value="${currentDate}" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; width: 160px;"></div>
        <div><strong>Name of employee:</strong> <input type="text" id="vh_name" value="${emp.name}" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; width: 400px;"></div>
        <div><strong>ID No. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <input type="text" id="vh_idNo" value="${emp.idNo}" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; width: 400px;"></div>
        <div><strong>Date of birth &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <input type="text" id="vh_dob" value="${formatDateDDMMYYYY(emp.dob || (emp.demographic ? emp.demographic.dob : ''))}" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; width: 160px;"></div>
        <div style="display: flex; align-items: center; gap: 14px; margin-top: 2px;">
          <strong>Female worker, pregnant:</strong>
          <label style="display: inline-flex; align-items: center; gap: 6px; cursor: pointer;">
            <input type="checkbox" id="vh_preg_no" ${emp.contraindications?.pregnancy ? '' : 'checked'} style="width: 16px; height: 16px;"> No /
          </label>
          <label style="display: inline-flex; align-items: center; gap: 6px; cursor: pointer;">
            <input type="checkbox" id="vh_preg_yes" ${emp.contraindications?.pregnancy ? 'checked' : ''} style="width: 16px; height: 16px;"> Yes
          </label>
        </div>
      </div>

      <!-- SECTION 1: VACCINATION TABLE -->
      <div style="font-size: 1.05rem; font-weight: bold; margin-bottom: 4px;">1. Vaccination</div>
      <div style="overflow-x: auto; margin-bottom: 12px;">
        <table style="width: 100%; border-collapse: collapse; border: 1.5px solid black; font-size: 0.88rem; text-align: left; background: white;" id="vh_vac_table">
          <thead>
            <tr>
              <th rowspan="2" style="border: 1.5px solid black; padding: 4px; width: 130px; vertical-align: middle; font-weight: normal;">Vaccine</th>
              <th colspan="4" style="border: 1.5px solid black; padding: 4px; text-align: center; font-weight: normal;">Vaccination history out of hospital</th>
              <th colspan="3" style="border: 1.5px solid black; border-left: 2.5px solid black; padding: 4px; text-align: center; font-weight: normal;">Vaccination inside of hospital</th>
            </tr>
            <tr>
              <th style="border: 1px solid black; padding: 2px; text-align: center; font-weight: normal; width: 11%;">Dose 1<br><span style="font-size: 0.8rem;">Date</span></th>
              <th style="border: 1px solid black; padding: 2px; text-align: center; font-weight: normal; width: 11%;">Dose 2<br><span style="font-size: 0.8rem;">Date</span></th>
              <th style="border: 1px solid black; padding: 2px; text-align: center; font-weight: normal; width: 11%;">Dose 3<br><span style="font-size: 0.8rem;">Date</span></th>
              <th style="border: 1px solid black; padding: 2px; text-align: center; font-weight: normal; width: 11%;">Dose 4<br><span style="font-size: 0.8rem;">Date</span></th>
              <th style="border: 1px solid black; border-left: 2.5px solid black; padding: 2px; text-align: center; font-weight: normal; width: 11%;">Dose 5<br><span style="font-size: 0.8rem;">Date</span></th>
              <th style="border: 1px solid black; padding: 2px; text-align: center; font-weight: normal; width: 11%;">Dose 6<br><span style="font-size: 0.8rem;">Date</span></th>
              <th style="border: 1px solid black; padding: 2px; text-align: center; font-weight: normal; width: 11%;">Dose 7<br><span style="font-size: 0.8rem;">Date</span></th>
            </tr>
          </thead>
          <tbody>
            ${mainVaccines.map(item => {
              const getVacDoseStyle = (dKey) => {
                const val = String(getVaccineDoseVal(item, dKey) || '');
                let sz = '10.5pt';
                if (val.length > 25) sz = '7pt';
                else if (val.length > 18) sz = '8pt';
                else if (val.length > 12) sz = '9pt';
                return `width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: ${sz}; font-weight: bold; text-align: center; background: transparent; padding: 2px 0; box-sizing: border-box; text-overflow: ellipsis;`;
              };
              return `
                <tr data-vac-key="${item.key}">
                  <td style="border: 1px solid black; padding: 3px 6px; font-weight: normal;">${item.name}</td>
                  <td style="border: 1px solid black; padding: 1px;"><input type="text" data-dose="d1" value="${getVaccineDoseVal(item, 'd1')}" style="${getVacDoseStyle('d1')}" title="${getVaccineDoseVal(item, 'd1')}"></td>
                  <td style="border: 1px solid black; padding: 1px;"><input type="text" data-dose="d2" value="${getVaccineDoseVal(item, 'd2')}" style="${getVacDoseStyle('d2')}" title="${getVaccineDoseVal(item, 'd2')}"></td>
                  <td style="border: 1px solid black; padding: 1px;"><input type="text" data-dose="d3" value="${getVaccineDoseVal(item, 'd3')}" style="${getVacDoseStyle('d3')}" title="${getVaccineDoseVal(item, 'd3')}"></td>
                  <td style="border: 1px solid black; padding: 1px;"><input type="text" data-dose="d4" value="${getVaccineDoseVal(item, 'd4')}" style="${getVacDoseStyle('d4')}" title="${getVaccineDoseVal(item, 'd4')}"></td>
                  <td style="border: 1px solid black; border-left: 2.5px solid black; padding: 1px;"><input type="text" data-dose="d5" value="${getVaccineDoseVal(item, 'd5')}" style="${getVacDoseStyle('d5')}" title="${getVaccineDoseVal(item, 'd5')}"></td>
                  <td style="border: 1px solid black; padding: 1px;"><input type="text" data-dose="d6" value="${getVaccineDoseVal(item, 'd6')}" style="${getVacDoseStyle('d6')}" title="${getVaccineDoseVal(item, 'd6')}"></td>
                  <td style="border: 1px solid black; padding: 1px;"><input type="text" data-dose="d7" value="${getVaccineDoseVal(item, 'd7')}" style="${getVacDoseStyle('d7')}" title="${getVaccineDoseVal(item, 'd7')}"></td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>

      <!-- OTHER VACCINATIONS & COUNTER INSTRUCTIONS WRITABLE INPUT BLOCKS -->
      <div style="font-size: 0.95rem; margin-bottom: 12px; line-height: 1.5;">
        <div><span style="text-decoration: underline; font-weight: bold;">Other Vaccinations:</span></div>
        <input type="text" id="vh_other_vaccines" value="${emp.otherVaccines || ''}" placeholder="Type any additional vaccinations here..." style="width: 100%; border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; background: transparent; padding: 2px 0; margin-bottom: 8px;">

        <div>In the event that a counter instruction exists against receipt of one of the vaccinations, note the name of the vaccination here:</div>
        <input type="text" id="vh_counter_instructions" value="${emp.counterInstructions || ''}" placeholder="Type counter instructions or contraindications here..." style="width: 100%; border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; background: transparent; padding: 2px 0; margin-bottom: 12px;">
      </div>

      <!-- SECTION 2: LABORATORY RESULT TABLE -->
      <div style="font-size: 1.05rem; font-weight: bold; margin-bottom: 4px;">2. Laboratory Result</div>
      <div style="margin-bottom: 14px;">
        <table style="width: 100%; border-collapse: collapse; border: 1.5px solid black; font-size: 0.92rem; text-align: left; background: white;">
          <thead>
            <tr>
              <th style="border: 1.5px solid black; padding: 4px 8px; width: 200px; font-weight: normal; text-align: center;">Test</th>
              <th style="border: 1.5px solid black; padding: 4px 8px; font-weight: normal; text-align: center;">Result</th>
              <th style="border: 1.5px solid black; padding: 4px 8px; width: 160px; font-weight: normal; text-align: center;">Date</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">HBsAb</td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hbsab_result" value="${hbsabRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hbsab_date" value="${hbsabDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">HBsAg</td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hbsag_result" value="${hbsagRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hbsag_date" value="${hbsagDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">HCV</td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hcv_result" value="${hcvRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hcv_date" value="${hcvDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">HIV</td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hiv_result" value="${hivRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_hiv_date" value="${hivDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td rowspan="2" style="border: 1px solid black; padding: 4px 8px; vertical-align: middle;">PPD</td>
              <td style="border: 1px solid black; padding: 4px 8px;">
                <strong>1<sup>st</sup> test:</strong> &nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" id="lab_ppd_qual1" value="${ppd1Qual}" placeholder="Result" style="width: 90px; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center;"> &nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" id="lab_ppd_test1" value="${ppd1Ind}" placeholder="0" style="width: 40px; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center;"> <strong>mm</strong>
              </td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_ppd_date1" value="${ppd1Dt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">
                <strong>2<sup>nd</sup> test:</strong> &nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" id="lab_ppd_qual2" value="${ppd2Qual}" placeholder="Result" style="width: 90px; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center;"> &nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" id="lab_ppd_test2" value="${ppd2Ind}" placeholder="0" style="width: 40px; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center;"> <strong>mm</strong>
              </td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_ppd_date2" value="${ppd2Dt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">Varicella Zoster, IgG</td>
              <td style="border: 1px solid black; padding: 4px 8px;"><input type="text" id="lab_varicella_result" value="${varicellaRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_varicella_date" value="${varicellaDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">Mumps IgG Titer</td>
              <td style="border: 1px solid black; padding: 4px 8px;"><input type="text" id="lab_mumps_result" value="${mumpsRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_mumps_date" value="${mumpsDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">Measles IgG Titer</td>
              <td style="border: 1px solid black; padding: 4px 8px;"><input type="text" id="lab_measles_result" value="${measlesRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_measles_date" value="${measlesDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">Rubella IgG Titer</td>
              <td style="border: 1px solid black; padding: 4px 8px;"><input type="text" id="lab_rubella_result" value="${rubellaRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_rubella_date" value="${rubellaDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
            <tr>
              <td style="border: 1px solid black; padding: 4px 8px;">Other</td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_other_result" value="${otherRes}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; padding: 2px 4px;"></td>
              <td style="border: 1px solid black; padding: 1px;"><input type="text" id="lab_other_date" value="${otherDt}" style="width: 100%; border: none; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; padding: 2px 4px;"></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 0.98rem; margin-bottom: 12px; margin-top: 10px; line-height: 1.8;">
        <div><strong>Infection Prevention and control Officer Signature.:</strong> <input type="text" id="vh_sign" value="${emp.signature || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 260px;"></div>
        <div style="margin-top: 4px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="vh_stamp" value="${emp.stamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 260px;"></div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- ACTION BUTTONS BELOW -->
      <div style="display: flex; gap: 16px; justify-content: flex-end; align-items: center; margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1;" class="no-print">
        <button class="btn btn-outline" onclick="printSubForm('historyPrintArea', 'Vaccination and Test History (SQE 02.01)')">🖨️ Print Form Layout (SQE 02.01 /Vaccination-01)</button>
        <button class="btn btn-success" onclick="saveHistoryRecord()">💾 Save History Record</button>
      </div>
    </div>
  `;
}

async function saveHistoryRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  emp.otherVaccines = document.getElementById('vh_other_vaccines')?.value || '';
  emp.counterInstructions = document.getElementById('vh_counter_instructions')?.value || '';
  emp.signature = document.getElementById('vh_sign')?.value || '';

  // Save Lab Results Table
  if (!emp.labResults) emp.labResults = {};
  const hbsabRes = document.getElementById('lab_hbsab_result')?.value?.trim() || '';
  const hbsabDt = hbsabRes ? (document.getElementById('lab_hbsab_date')?.value || '') : '';
  const hbsagRes = document.getElementById('lab_hbsag_result')?.value?.trim() || '';
  const hbsagDt = hbsagRes ? (document.getElementById('lab_hbsag_date')?.value || '') : '';
  const hcvRes = document.getElementById('lab_hcv_result')?.value?.trim() || '';
  const hcvDt = hcvRes ? (document.getElementById('lab_hcv_date')?.value || '') : '';
  const hivRes = document.getElementById('lab_hiv_result')?.value?.trim() || '';
  const hivDt = hivRes ? (document.getElementById('lab_hiv_date')?.value || '') : '';
  const varRes = document.getElementById('lab_varicella_result')?.value?.trim() || '';
  const varDt = varRes ? (document.getElementById('lab_varicella_date')?.value || '') : '';

  emp.labResults.HBsAb = { result: hbsabRes, date: hbsabDt };
  emp.labResults.hbsabResult = hbsabRes;
  emp.labResults.hbsabDate = hbsabDt;

  emp.labResults.HBsAg = { result: hbsagRes, date: hbsagDt };
  emp.labResults.hbsagResult = hbsagRes;
  emp.labResults.hbsagDate = hbsagDt;

  emp.labResults.HCV = { result: hcvRes, date: hcvDt };
  emp.labResults.hcvResult = hcvRes;
  emp.labResults.hcvDate = hcvDt;

  emp.labResults.HIV = { result: hivRes, date: hivDt };
  emp.labResults.hivResult = hivRes;
  emp.labResults.hivDate = hivDt;

  emp.labResults.Varicella_IgG = { result: varRes, date: varDt };
  emp.labResults.varicellaIgG = varRes;
  emp.labResults.varicellaIgGDate = varDt;

  const mumpsRes = document.getElementById('lab_mumps_result')?.value?.trim() || '';
  const mumpsDt = mumpsRes ? (document.getElementById('lab_mumps_date')?.value || '') : '';
  const measlesRes = document.getElementById('lab_measles_result')?.value?.trim() || '';
  const measlesDt = measlesRes ? (document.getElementById('lab_measles_date')?.value || '') : '';
  const rubellaRes = document.getElementById('lab_rubella_result')?.value?.trim() || '';
  const rubellaDt = rubellaRes ? (document.getElementById('lab_rubella_date')?.value || '') : '';

  emp.labResults.Mumps_IgG = { result: mumpsRes, date: mumpsDt };
  emp.labResults.mumpsIgGTiter = mumpsRes;
  emp.labResults.mumpsIgGTiterDate = mumpsDt;

  emp.labResults.Measles_IgG = { result: measlesRes, date: measlesDt };
  emp.labResults.measlesIgGTiter = measlesRes;
  emp.labResults.measlesIgGTiterDate = measlesDt;

  emp.labResults.Rubella_IgG = { result: rubellaRes, date: rubellaDt };
  emp.labResults.rubellaIgGTiter = rubellaRes;
  emp.labResults.rubellaIgGTiterDate = rubellaDt;

  emp.mumpsIgGTiterDate = mumpsDt;
  emp.measlesIgGTiterDate = measlesDt;
  emp.rubellaIgGTiterDate = rubellaDt;
  
  const ppdQual1 = document.getElementById('lab_ppd_qual1')?.value?.trim() || '';
  const ppdTest1 = document.getElementById('lab_ppd_test1')?.value?.trim() || '';
  const ppdQual2 = document.getElementById('lab_ppd_qual2')?.value?.trim() || '';
  const ppdTest2 = document.getElementById('lab_ppd_test2')?.value?.trim() || '';
  const ppdDate1 = (ppdQual1 || ppdTest1) ? (document.getElementById('lab_ppd_date1')?.value || '') : '';
  const ppdDate2 = (ppdQual2 || ppdTest2) ? (document.getElementById('lab_ppd_date2')?.value || '') : '';

  emp.labResults.ppdStep1Result = ppdQual1;
  emp.labResults.ppdStep1Induration = ppdTest1 ? ppdTest1 + 'mm' : '0mm';
  emp.labResults.ppdStep2Result = ppdQual2;
  emp.labResults.ppdStep2Induration = ppdTest2 ? ppdTest2 + 'mm' : '0mm';
  emp.labResults.ppdStep1Date = ppdDate1;
  emp.labResults.ppdStep2Date = ppdDate2;

  emp.labResults.PPD = { 
    qual1: ppdQual1,
    test1: ppdTest1, 
    qual2: ppdQual2,
    test2: ppdTest2, 
    date1: ppdDate1,
    date2: ppdDate2,
    date: ppdDate1 
  };

  // Mirror flat root properties for 100% data source synchronization
  emp.hepbTiter = hbsabRes;
  emp.hbsabDate = hbsabDt;
  emp.hcvDate = hcvDt;
  emp.hivDate = hivDt;
  emp.ppdStep1Date = ppdDate1;
  emp.ppdStep2Date = ppdDate2;
  emp.varicellaIgGDate = varDt;
  emp.lab = { ...(emp.lab || {}), ...emp.labResults };
  // Save Vaccination Table Doses (d1 - d7)
  if (!emp.vaccines) emp.vaccines = {};
  const vacTableRows = document.querySelectorAll('#vh_vac_table tbody tr');
  vacTableRows.forEach(tr => {
    const key = tr.getAttribute('data-vac-key');
    if (key) {
      if (!emp.vaccines[key]) emp.vaccines[key] = {};
      const inputs = tr.querySelectorAll('input[data-dose]');
      inputs.forEach(inp => {
        const doseKey = inp.getAttribute('data-dose');
        if (doseKey) {
          emp.vaccines[key][doseKey] = inp.value;
        }
      });

      // Sync MMR doses
      if (key === 'MMR') {
        const d1Val = emp.vaccines[key].d1 || '';
        const d2Val = emp.vaccines[key].d2 || '';
        const d5Val = emp.vaccines[key].d5 || '';
        if (d1Val) {
          emp.mmrDose1 = d1Val;
          emp.vaccines.mmrDose1 = d1Val;
        }
        const dose2Val = d2Val || d5Val;
        if (dose2Val) {
          emp.mmrDose2 = dose2Val;
          emp.vaccines.mmrDose2 = dose2Val;
          emp.vaccines[key].d2 = dose2Val;
          emp.vaccines[key].d5 = dose2Val;
        }
      }

      // Sync Chicken pox doses
      if (key === 'Varicella Zoster (Chicken pox)') {
        const d1Val = emp.vaccines[key].d1 || '';
        const d2Val = emp.vaccines[key].d2 || '';
        const d3Val = emp.vaccines[key].d3 || '';
        if (d1Val) {
          emp.chickenpoxStatus = d1Val;
          emp.vaccines.chickenpoxStatus = d1Val;
        }
        if (d2Val) {
          emp.chickenpoxDose1 = d2Val;
          emp.vaccines.chickenpoxDose1 = d2Val;
        }
        if (d3Val) {
          emp.chickenpoxDose2 = d3Val;
          emp.vaccines.chickenpoxDose2 = d3Val;
        }
      }

      // Sync Hepatitis B Engrix doses back into lab / labResults
      if (key === 'Hepatitis B') {
        if (!emp.lab) emp.lab = {};
        if (!emp.labResults) emp.labResults = {};
        const d5Val = emp.vaccines[key].d5 || emp.vaccines[key].d1 || '';
        const d6Val = emp.vaccines[key].d6 || emp.vaccines[key].d2 || '';
        const d7Val = emp.vaccines[key].d7 || emp.vaccines[key].d3 || '';

        emp.lab.engrixDose1 = d5Val;
        emp.lab.engrixDose2 = d6Val;
        emp.lab.engrixDose3 = d7Val;

        emp.labResults.engrixDose1 = d5Val;
        emp.labResults.engrixDose2 = d6Val;
        emp.labResults.engrixDose3 = d7Val;
      }
    }
  });

  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

/* ==========================================================
   OTHER CLINICAL SUB-FORMS (2, 4-10)
   ========================================================== */
function renderPreVaccinationChecklist(emp) {
  const cl = emp.preVaccinationChecklist || {};
  const currentDate = new Date().toISOString().slice(0, 10);
  const formattedCurrentDate = typeof formatDateDDMMYYYY === 'function' ? formatDateDDMMYYYY(currentDate) : currentDate;

  const questions = [
    { id: "q1", text: "Did you receive Vaccination during adult Hood? (Tdap, MMR, IPV, other )" },
    { id: "q2", text: "Do you have a document for vaccination during adult hood?" },
    { id: "q3", text: "Positive pregnancy test for married females (qualitative test)" },
    { id: "q4", text: "Plan for pregnancy next 3 months" },
    { id: "q5", text: "Absence of any previous hypersensitivity to any vaccine, yeast, streptomycin, neomycin, eggs or polymixin B." },
    { id: "q6", text: "Asplenia, complement deficiencies" },
    { id: "q7", text: "Immune-compromised" },
    { id: "q8", text: "End stage renal disease, on hemodialysis" },
    { id: "q9", text: "Heart or lung disease, alcoholism" },
    { id: "q10", text: "Chronic liver disease" },
    { id: "q11", text: "diabetic" }
  ];

  return `
    <div style="background: white; padding: 36px 45px; font-family: 'Times New Roman', Times, serif; color: #000000; border: 1px solid #CBD5E1; max-width: 840px; margin: 0 auto; box-shadow: 0 4px 16px rgba(0,0,0,0.06);" id="checklistPrintArea">
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE & FORM CODE -->
        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${cl.date || formattedCurrentDate}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Pre-Vaccination Check List</h2>
          <div style="font-size: 1.05rem; color: var(--text-muted); font-weight: 600; margin-top: 4px;">Vaccination and Test History of a Healthcare Worker</div>
        </div>
      </div>

      <!-- EMPLOYEE METADATA BLOCK WITH DOTTED UNDERLINES -->
      <div style="font-size: 1.05rem; line-height: 2.2; margin-bottom: 24px; font-family: 'Times New Roman', Times, serif;">
        <div style="display: flex; align-items: center; margin-bottom: 4px;">
          <strong style="min-width: 140px; color: #000000;">Date:</strong>
          <input type="text" id="cl_date" value="${cl.date || formattedCurrentDate}" style="border: none; border-bottom: 1.5px dotted #000000; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 220px; background: transparent; padding: 0 4px; color: #000000;">
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 4px;">
          <strong style="min-width: 140px; color: #000000;">Name of employee:</strong>
          <input type="text" id="cl_name" value="${cl.name || emp.name}" style="flex: 1; border: none; border-bottom: 1.5px dotted #000000; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; background: transparent; padding: 0 4px; color: #000000;">
        </div>
        <div style="display: flex; align-items: center; margin-bottom: 4px;">
          <strong style="min-width: 140px; color: #000000;">ID No. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong>
          <input type="text" id="cl_idNo" value="${cl.idNo || emp.idNo}" style="flex: 1; border: none; border-bottom: 1.5px dotted #000000; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; background: transparent; padding: 0 4px; color: #000000;">
        </div>
      </div>

      <!-- 11 QUESTIONS TABLE (CRISP 1PX BLACK BORDER GRID) -->
      <div style="margin-bottom: 32px;">
        <table style="width: 100%; border-collapse: collapse; border: 1px solid #000000; font-size: 1.02rem; background: white; font-family: 'Times New Roman', Times, serif;">
          <thead>
            <tr>
              <th style="border: 1px solid #000000; padding: 8px 12px; text-align: left; font-weight: normal;"></th>
              <th style="border: 1px solid #000000; padding: 8px 12px; width: 65px; text-align: center; font-weight: bold; font-size: 1.05rem;">Yes</th>
              <th style="border: 1px solid #000000; padding: 8px 12px; width: 65px; text-align: center; font-weight: bold; font-size: 1.05rem;">No</th>
              <th style="border: 1px solid #000000; padding: 8px 12px; width: 65px; text-align: center; font-weight: bold; font-size: 1.05rem;">N/A</th>
            </tr>
          </thead>
          <tbody>
            ${(() => {
              const demo = emp.demographic || {};
              const rawGen = String(demo.gender || emp.gender || '').trim().toLowerCase();
              const isMale = (rawGen === 'male' || rawGen === 'm' || rawGen === 'ذكر' || (rawGen !== 'female' && rawGen !== 'انثى' && rawGen !== 'أنثى'));
              return questions.map((q) => {
                const isQ34 = (q.id === 'q3' || q.id === 'q4');
                let val = cl[q.id];
                if (isQ34 && isMale) {
                  val = 'N/A';
                } else if (!val) {
                  if (q.id === 'q5') {
                    val = 'Yes';
                  } else {
                    val = 'No';
                  }
                }
                const isNA = (val === 'N/A' || val === 'NA' || val === 'n/a');
                const isQ34MaleDisabled = isQ34 && isMale;
                return `
                  <tr>
                    <td style="border: 1px solid #000000; padding: 7px 10px; font-family: 'Times New Roman', Times, serif; line-height: 1.35; color: #000000;">${q.text}</td>
                    <td style="border: 1px solid #000000; padding: 4px; text-align: center; vertical-align: middle;">
                      <input type="radio" name="${q.id}" value="Yes" ${val === 'Yes' ? 'checked' : ''} ${isQ34MaleDisabled ? 'disabled style="width: 16px; height: 16px; cursor: not-allowed; opacity: 0.35;"' : 'style="width: 16px; height: 16px; cursor: pointer; accent-color: #000000;"'}>
                    </td>
                    <td style="border: 1px solid #000000; padding: 4px; text-align: center; vertical-align: middle;">
                      <input type="radio" name="${q.id}" value="No" ${val === 'No' && !isNA ? 'checked' : ''} ${isQ34MaleDisabled ? 'disabled style="width: 16px; height: 16px; cursor: not-allowed; opacity: 0.35;"' : 'style="width: 16px; height: 16px; cursor: pointer; accent-color: #000000;"'}>
                    </td>
                    <td style="border: 1px solid #000000; padding: 4px; text-align: center; vertical-align: middle;">
                      <input type="radio" name="${q.id}" value="N/A" ${isNA ? 'checked' : ''} style="width: 16px; height: 16px; cursor: pointer; accent-color: #000000;">
                    </td>
                  </tr>
                `;
              }).join('');
            })()}
          </tbody>
        </table>
      </div>

      <!-- EMPLOYEE SIGN BLOCK -->
      <div style="font-size: 1.05rem; margin-bottom: 25px; margin-top: 25px; font-family: 'Times New Roman', Times, serif;">
        <strong style="color: #000000;">Employee Sign:</strong> <input type="text" id="cl_sign" value="${cl.sign || ''}" placeholder="...................................................................." style="border: none; border-bottom: 1.5px dotted #000000; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 450px; background: transparent; padding: 0 4px;">
      </div>

      <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 1.1rem; margin-bottom: 24px; margin-top: 20px; line-height: 2;">
        <div><strong>Infection Prevention and control Officer Signature.:</strong> <input type="text" id="cl_ic_sign" value="${cl.icSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
        <div style="margin-top: 10px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="cl_ic_stamp" value="${cl.icStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- ACTION BUTTONS BELOW -->
      <div style="display: flex; gap: 16px; justify-content: flex-end; align-items: center; margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1;" class="no-print">
        <button class="btn btn-outline" onclick="printSubForm('checklistPrintArea', 'Pre-Vaccination Check List (SQE 02.01)')">🖨️ Print Pre-Vaccination Check List (SQE 02.01)</button>
        <button class="btn btn-success" onclick="saveChecklistRecord()">💾 Save Checklist</button>
      </div>
    </div>
  `;
}

async function saveChecklistRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  let empIdx = activeEmpIndex;

  if (empIdx === -1 || !employees[empIdx]) {
    const idVal = document.getElementById('cl_idNo') ? document.getElementById('cl_idNo').value.trim() : '';
    const nameVal = document.getElementById('cl_name') ? document.getElementById('cl_name').value.trim().toLowerCase() : '';
    if (idVal || nameVal) {
      empIdx = employees.findIndex(e => {
        const demo = e.demographic || {};
        const idStr = (e.idNo || demo.nationalId || '').toString().trim();
        const nmStr = (e.name || demo.fullName || '').toString().trim().toLowerCase();
        return (idVal && idStr === idVal) || (nameVal && nmStr === nameVal);
      });
    }
  }

  if (empIdx === -1 || !employees[empIdx]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }

  activeEmpIndex = empIdx;
  const emp = employees[empIdx];

  const cl = {
    date: document.getElementById('cl_date') ? document.getElementById('cl_date').value : '',
    name: document.getElementById('cl_name') ? document.getElementById('cl_name').value : '',
    idNo: document.getElementById('cl_idNo') ? document.getElementById('cl_idNo').value : '',
    sign: document.getElementById('cl_sign') ? document.getElementById('cl_sign').value : '',
    icSign: document.getElementById('cl_ic_sign') ? document.getElementById('cl_ic_sign').value : '',
    icStamp: document.getElementById('cl_ic_stamp') ? document.getElementById('cl_ic_stamp').value : ''
  };

  const demo = emp.demographic || {};
  const rawGen = String(demo.gender || emp.gender || '').trim().toLowerCase();
  const isMale = (rawGen === 'male' || rawGen === 'm' || rawGen === 'ذكر' || (rawGen !== 'female' && rawGen !== 'انثى' && rawGen !== 'أنثى'));

  for (let i = 1; i <= 11; i++) {
    const qKey = `q${i}`;
    if ((i === 3 || i === 4) && isMale) {
      cl[qKey] = 'N/A';
      continue;
    }
    const selected = document.querySelector(`input[name="${qKey}"]:checked`);
    if (selected) {
      cl[qKey] = selected.value;
    } else if (i === 5) {
      cl[qKey] = 'Yes';
    } else {
      cl[qKey] = 'No';
    }
  }

  if (isMale) {
    if (!emp.healthStatus) emp.healthStatus = {};
    emp.healthStatus.pregnancyStatus = 'Not Pregnant / N/A';
  }

  emp.preVaccinationChecklist = cl;
  emp.checklist = cl;
  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

function renderOldVaccinationForm(emp) {
  const ov = emp.oldVaccination || {};
  const currentDate = new Date().toISOString().slice(0, 10);

  return `
    <div style="background: white; padding: 36px 40px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;" id="oldVacPrintArea">
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${formatDateDDMMYYYY(ov.date || currentDate)}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Old Vaccination Declaration Form</h2>
          <div style="font-size: 1.05rem; color: var(--text-muted); font-weight: 600; margin-top: 4px;">Vaccination and Test History of a Healthcare Worker</div>
        </div>
      </div>

      <!-- DATE -->
      <div style="font-size: 1.1rem; margin-bottom: 20px;">
        <strong>Date:</strong> <input type="text" id="ov_date" value="${formatDateDDMMYYYY(ov.date || currentDate)}" oninput="syncOldVacFields(this, 'ov_date_ar')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 180px;">
      </div>

      <!-- ENGLISH DECLARATION BLOCK -->
      <div style="font-size: 1.1rem; line-height: 2.2; margin-bottom: 24px;">
        <div>
          <strong>I the undersigned</strong> <input type="text" id="ov_name_en" value="${emp.name}" oninput="syncOldVacFields(this, 'ov_name_ar')" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 440px;">
        </div>
        <div>
          <strong>Holding ID #:</strong> <input type="text" id="ov_idNo_en" value="${emp.idNo}" oninput="syncOldVacFields(this, 'ov_idNo_ar')" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 280px;">
          <strong>Declare that I received all child hood</strong>
        </div>
        <div>
          <strong>vaccinations at the</strong> <input type="text" id="ov_center_en" value="${ov.maternalCenter || ''}" oninput="syncOldVacFields(this, 'ov_center_ar')" placeholder="................................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;">
          <strong>Maternal and child health centers and</strong>
        </div>
        <div>
          <strong>my school vaccine at</strong> <input type="text" id="ov_school_en" value="${ov.schoolCenter || ''}" oninput="syncOldVacFields(this, 'ov_school_ar')" placeholder="................................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 320px;">
        </div>
      </div>

      <div style="font-size: 1.1rem; font-weight: bold; margin-bottom: 30px; margin-top: 24px;">
        I declare that this information is accurate, and I take all the legal responsibility.
      </div>

      <!-- EMPLOYEE SIGNATURE (ENGLISH) -->
      <div style="font-size: 1.1rem; margin-bottom: 24px;">
        <strong>Employee Signature:</strong> <input type="text" id="ov_sign_en" value="${ov.signEn || ''}" oninput="syncOldVacFields(this, 'ov_sign_ar')" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 320px;">
      </div>

      <!-- SEPARATOR LINE -->
      <div style="border-bottom: 3.5px solid black; margin: 24px 0;"></div>

      <!-- ARABIC DECLARATION BLOCK (RTL) -->
      <div style="direction: rtl; font-size: 1.15rem; line-height: 2.3; margin-bottom: 24px; text-align: right;">
        <div>
          <strong>التاريخ:</strong> <input type="text" id="ov_date_ar" value="${formatDateDDMMYYYY(ov.date || currentDate)}" oninput="syncOldVacFields(this, 'ov_date')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 180px;">
        </div>
        <div>
          <strong>انا الموقع ادناه: السيد/ة:</strong> <input type="text" id="ov_name_ar" value="${emp.name}" oninput="syncOldVacFields(this, 'ov_name_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 320px;">
          &nbsp;&nbsp;
          <strong>حامل هوية رقم:</strong> <input type="text" id="ov_idNo_ar" value="${emp.idNo}" oninput="syncOldVacFields(this, 'ov_idNo_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 220px;">
        </div>
        <div>
          <strong>أقر باني اخذت كافة التطعيمات التي تعطى في مراكز الأمومة والطفولة في مركز</strong>
          <input type="text" id="ov_center_ar" value="${ov.maternalCenter || ''}" oninput="syncOldVacFields(this, 'ov_center_en')" placeholder="................................................" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 320px;">
        </div>
        <div>
          <strong>وأيضاً التي اعطيت في مرحلة المدرسة في مدرسة</strong>
          <input type="text" id="ov_school_ar" value="${ov.schoolCenter || ''}" oninput="syncOldVacFields(this, 'ov_school_en')" placeholder="................................................" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 320px;">
        </div>
        <div style="font-weight: bold; margin-top: 10px;">
          أتعهد ان كافة المعلومات دقيقة وصحيحة واني اتحمل كافة المسؤولية القانونية.
        </div>
        <div style="margin-top: 24px;">
          <strong>توقيع الموظف:</strong> <input type="text" id="ov_sign_ar" value="${ov.signAr || ''}" oninput="syncOldVacFields(this, 'ov_sign_en')" placeholder="........................................................................" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 420px;">
        </div>
      </div>

      <!-- SEPARATOR LINE -->
      <div style="border-bottom: 3.5px solid black; margin: 24px 0;"></div>

      <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 1.1rem; margin-bottom: 30px; margin-top: 24px; line-height: 2;">
        <div><strong>Infection Prevention and control Officer Signature.:</strong> <input type="text" id="ov_ic_sign" value="${ov.icSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
        <div style="margin-top: 10px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="ov_ic_stamp" value="${ov.icStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- ACTION BUTTONS BELOW -->
      <div style="display: flex; gap: 16px; justify-content: flex-end; align-items: center; margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1;" class="no-print">
        <button class="btn btn-outline" onclick="printSubForm('oldVacPrintArea', 'Old Vaccination Declaration Form (SQE 02.01)')">🖨️ Print Old Vaccination Declaration Form</button>
        <button class="btn btn-success" onclick="saveOldVaccinationRecord()">💾 Save Declaration</button>
      </div>
    </div>
  `;
}

function syncOldVacFields(sourceEl, targetId) {
  const targetEl = document.getElementById(targetId);
  if (targetEl) {
    if (sourceEl.type === 'checkbox') {
      targetEl.checked = sourceEl.checked;
    } else {
      targetEl.value = sourceEl.value;
    }
  }
}

async function saveOldVaccinationRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  emp.oldVaccination = {
    date: document.getElementById('ov_date').value,
    maternalCenter: document.getElementById('ov_center_en').value,
    schoolCenter: document.getElementById('ov_school_en').value,
    signEn: document.getElementById('ov_sign_en').value,
    signAr: document.getElementById('ov_sign_ar').value,
    icSign: document.getElementById('ov_ic_sign').value
  };

  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

function renderChickenpoxDeclaration(emp) {
  const cp = emp.chickenpoxDeclaration || {};
  const currentDate = new Date().toISOString().slice(0, 10);

  return `
    <div style="background: white; padding: 36px 40px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;" id="chickenpoxPrintArea">
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${formatDateDDMMYYYY(cp.date || currentDate)}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Declaration About Chickenpox</h2>
          <div style="font-size: 1.05rem; color: var(--text-muted); font-weight: 600; margin-top: 4px;">Vaccination and Test History of a Healthcare Worker</div>
        </div>
      </div>

      <!-- DATE -->
      <div style="font-size: 1.1rem; margin-bottom: 20px;">
        <strong>Date:</strong> <input type="text" id="cp_date" value="${formatDateDDMMYYYY(cp.date || currentDate)}" oninput="syncOldVacFields(this, 'cp_date_ar')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 180px;">
      </div>

      <!-- ENGLISH DECLARATION BLOCK -->
      <div style="font-size: 1.1rem; line-height: 2.2; margin-bottom: 20px;">
        <div>
          <strong>I the undersigned</strong> <input type="text" id="cp_name_en" value="${emp.name}" oninput="syncOldVacFields(this, 'cp_name_ar')" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;">
          <strong>holding ID #:</strong> <input type="text" id="cp_idNo_en" value="${emp.idNo}" oninput="syncOldVacFields(this, 'cp_idNo_ar')" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 220px;">
          <strong>Declare that:</strong>
        </div>

        <div style="margin-top: 14px; padding-left: 10px;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <input type="checkbox" id="cp_opt1_en" ${cp.opt1 !== false ? 'checked' : ''} onchange="syncOldVacFields(this, 'cp_opt1_ar')" style="width: 20px; height: 20px; cursor: pointer;">
            <span><strong>1. I was exposed to chickenpox in the past.</strong></span>
          </div>
          <div style="display: flex; align-items: center; gap: 10px;">
            <input type="checkbox" id="cp_opt2_en" ${cp.opt2 ? 'checked' : ''} onchange="syncOldVacFields(this, 'cp_opt2_ar')" style="width: 20px; height: 20px; cursor: pointer;">
            <span><strong>2. I received two doses of chickenpox vaccine.</strong></span>
          </div>
        </div>
      </div>

      <div style="font-size: 1.1rem; font-weight: bold; margin-bottom: 30px; margin-top: 24px;">
        I declare that this information is accurate, and I take all legal responsibility.
      </div>

      <!-- EMPLOYEE SIGNATURE (ENGLISH) -->
      <div style="font-size: 1.1rem; margin-bottom: 24px;">
        <strong>Employee Signature:</strong> <input type="text" id="cp_sign_en" value="${cp.signEn || ''}" oninput="syncOldVacFields(this, 'cp_sign_ar')" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 320px;">
      </div>

      <!-- SEPARATOR LINE -->
      <div style="border-bottom: 3.5px solid black; margin: 24px 0;"></div>

      <!-- ARABIC DECLARATION BLOCK (RTL) -->
      <div style="direction: rtl; font-size: 1.15rem; line-height: 2.3; margin-bottom: 24px; text-align: right;">
        <div>
          <strong>التاريخ:</strong> <input type="text" id="cp_date_ar" value="${formatDateDDMMYYYY(cp.date || currentDate)}" oninput="syncOldVacFields(this, 'cp_date')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 180px;">
        </div>
        <div>
          <strong>انا الموقع ادناه: السيد/ة:</strong> <input type="text" id="cp_name_ar" value="${emp.name}" oninput="syncOldVacFields(this, 'cp_name_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 300px;">
          &nbsp;&nbsp;
          <strong>حامل هوية رقم:</strong> <input type="text" id="cp_idNo_ar" value="${emp.idNo}" oninput="syncOldVacFields(this, 'cp_idNo_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 200px;">
        </div>
        <div style="font-weight: bold; margin-top: 6px;">
          أقر بأني:
        </div>

        <div style="padding-right: 14px; margin-top: 6px;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <input type="checkbox" id="cp_opt1_ar" ${cp.opt1 !== false ? 'checked' : ''} onchange="syncOldVacFields(this, 'cp_opt1_en')" style="width: 20px; height: 20px; cursor: pointer;">
            <span><strong>1. اصبت بمرض الجدري في الماضي.</strong></span>
          </div>
          <div style="display: flex; align-items: center; gap: 10px;">
            <input type="checkbox" id="cp_opt2_ar" ${cp.opt2 ? 'checked' : ''} onchange="syncOldVacFields(this, 'cp_opt2_en')" style="width: 20px; height: 20px; cursor: pointer;">
            <span><strong>2. تلقيت جرعتين تطعيم لمرض الجدري.</strong></span>
          </div>
        </div>

        <div style="font-weight: bold; margin-top: 16px;">
          اتعهد ان كافة المعلومات دقيقة وصحيحة واني اتحمل كافة المسؤولية القانونية.
        </div>
        <div style="margin-top: 24px;">
          <strong>توقيع الموظف:</strong> <input type="text" id="cp_sign_ar" value="${cp.signAr || ''}" oninput="syncOldVacFields(this, 'cp_sign_en')" placeholder="........................................................................" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 400px;">
        </div>
      </div>

      <!-- SEPARATOR LINE -->
      <div style="border-bottom: 3.5px solid black; margin: 24px 0;"></div>

      <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 1.1rem; margin-bottom: 30px; margin-top: 24px; line-height: 2;">
        <div><strong>Infection Prevention and control Officer Signature.:</strong> <input type="text" id="cp_ic_sign" value="${cp.icSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
        <div style="margin-top: 10px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="cp_ic_stamp" value="${cp.icStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- ACTION BUTTONS BELOW -->
      <div style="display: flex; gap: 16px; justify-content: flex-end; align-items: center; margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1;" class="no-print">
        <button class="btn btn-outline" onclick="printSubForm('chickenpoxPrintArea', 'Chickenpox Assessment & Immunity Form')">🖨️ Print Chickenpox Declaration Form</button>
        <button class="btn btn-success" onclick="saveChickenpoxRecord()">💾 Save Declaration</button>
      </div>
    </div>
  `;
}

async function saveChickenpoxRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  emp.chickenpoxDeclaration = {
    date: document.getElementById('cp_date').value,
    opt1: document.getElementById('cp_opt1_en').checked,
    opt2: document.getElementById('cp_opt2_en').checked,
    signEn: document.getElementById('cp_sign_en').value,
    signAr: document.getElementById('cp_sign_ar').value,
    icSign: document.getElementById('cp_ic_sign').value
  };

  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

function renderCovidFluForm(emp) {
  const records = typeof getCanonicalVaccineRecords === 'function' 
    ? getCanonicalVaccineRecords(emp) 
    : [];

  let logs = records.map(r => ({
    name: typeof getVaccineLabel === 'function' ? getVaccineLabel(r) : (r.vacName || r.name || ''),
    mfr: r.mfr || r.manufacturer || '',
    date: r.date || '',
    lot: r.lot || r.batch || ''
  }));

  if (logs.length === 0) {
    logs = [
      { name: "COVID -19 first dose", mfr: "", date: "", lot: "" },
      { name: "COVID -19 second dose", mfr: "", date: "", lot: "" },
      { name: "COVID -19 third dose", mfr: "", date: "", lot: "" },
      { name: "COVID -19 booster dose", mfr: "", date: "", lot: "" },
      { name: "flu vaccine year (2025/2026)", mfr: "", date: "", lot: "" }
    ];
  }

  return `
    <div class="card" id="covidFluPrintArea" style="background: white; padding: 36px 40px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;">
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${formatDateDDMMYYYY(new Date().toISOString().slice(0,10))}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Covid-19 & Annual Seasonal Flu Immunization Record</h2>
          <div style="font-size: 1.05rem; color: var(--text-muted); font-weight: 600; margin-top: 4px;">Vaccination and Test History of a Healthcare Worker</div>
        </div>
      </div>

      <!-- OFFICIAL EMPLOYEE HEADER BLOCK -->
      <div style="font-family: 'Times New Roman', Times, serif; font-size: 1.1rem; line-height: 2.2; margin-bottom: 24px; color: black; text-align: left;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;"><strong>Date:</strong> <input type="text" value="${formatDateDDMMYYYY(new Date().toISOString().slice(0,10))}" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 220px;"></div>
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;"><strong>Name of employee:</strong> <input type="text" value="${emp.name || ''}" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; flex: 1; max-width: 440px;"></div>
        <div style="display: flex; align-items: center; gap: 8px;"><strong>ID No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <input type="text" value="${emp.idNo || ''}" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 260px;"></div>
      </div>

      <div class="clinical-table-wrapper" style="margin-top: 16px;">
        <table class="clinical-table" id="covidFluTable">
          <thead>
            <tr>
              <th style="width: 25%;">Vaccine / Booster</th>
              <th style="width: 30%;">Manufacturer / Type</th>
              <th style="width: 22%;">Date Administered</th>
              <th style="width: 15%;">Patch / Lot #</th>
              <th style="width: 8%; text-align: center;" class="no-print">Action</th>
            </tr>
          </thead>
          <tbody id="covidFluTbody">
            ${logs.map((log, i) => `
              <tr id="cf_row_${i}">
                <td><input type="text" value="${log.name || ''}" placeholder="e.g. COVID -19 first dose" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td><input type="text" value="${log.mfr || ''}" placeholder="e.g. Pfizer-BioNTech / Moderna" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td><input type="text" value="${formatDateDDMMYYYY(log.date)}" placeholder="dd/mm/yyyy" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td><input type="text" value="${log.lot || ''}" placeholder="e.g. LOT-991" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td style="text-align: center;" class="no-print"><button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.75rem;" onclick="this.closest('tr').remove()">🗑️</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 1.1rem; margin-bottom: 24px; margin-top: 20px; line-height: 2;">
        <div><strong>Infection Prevention and control Officer Signature.:</strong> <input type="text" id="cf_ic_sign" value="${emp.covidFluIcSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
        <div style="margin-top: 10px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="cf_ic_stamp" value="${emp.covidFluIcStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- SINGLE ACTION BUTTONS ROW BELOW TABLE -->
      <div style="margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;" class="no-print">
        <div style="display: flex; gap: 12px;">
          <button class="btn btn-outline" onclick="printSubForm('covidFluPrintArea', 'Annual Flu & Covid-19 Immunization Record')">🖨️ Print Form Layout</button>
          <button class="btn btn-outline" onclick="addCovidFluRow()">➕ Add Vaccine Row</button>
        </div>
        <button class="btn btn-success" onclick="saveCovidFluRecord()">💾 Save Record</button>
      </div>
    </div>
  `;
}

function addCovidFluRow() {
  const tbody = document.getElementById('covidFluTbody');
  if (!tbody) return;
  const rowId = `cf_row_${Date.now()}`;
  const tr = document.createElement('tr');
  tr.id = rowId;
  tr.innerHTML = `
    <td><input type="text" value="" placeholder="e.g. COVID -19 booster dose" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td><input type="text" value="" placeholder="e.g. Manufacturer / Type" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td><input type="text" value="${formatDateDDMMYYYY(new Date().toISOString().slice(0,10))}" placeholder="dd/mm/yyyy" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td><input type="text" value="" placeholder="e.g. Patch / Lot #" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td style="text-align: center;"><button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.75rem;" onclick="this.closest('tr').remove()">🗑️</button></td>
  `;
  tbody.appendChild(tr);
}

async function saveCovidFluRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  const tbody = document.getElementById('covidFluTbody');
  if (!tbody) return;
  const rows = tbody.querySelectorAll('tr');
  const logs = [];
  const canonicalRecords = [];

  rows.forEach((tr, idx) => {
    const inputs = tr.querySelectorAll('input');
    if (inputs.length >= 4) {
      const nameVal = inputs[0].value.trim();
      const mfrVal = inputs[1].value.trim();
      const dateVal = inputs[2].value.trim();
      const lotVal = inputs[3].value.trim();

      if (nameVal || dateVal || lotVal || mfrVal) {
        logs.push({
          name: nameVal,
          mfr: mfrVal,
          date: dateVal,
          lot: lotVal
        });

        const parsed = typeof parseVaccineLabel === 'function' ? parseVaccineLabel(nameVal) : { type: 'covid', doseType: 'first' };
        const rec = {
          id: `rec_${Date.now()}_${idx}`,
          type: parsed.type,
          doseType: parsed.doseType,
          fluYear: parsed.fluYear || '',
          mfr: mfrVal,
          date: dateVal,
          lot: lotVal,
          vacName: nameVal
        };
        canonicalRecords.push(rec);
      }
    }
  });

  emp.covidFluRecords = canonicalRecords;
  if (!emp.covidFlu) emp.covidFlu = {};
  emp.covidFlu.covidFluRecords = canonicalRecords;
  emp.covidFluLogs = logs;

  if (typeof syncCanonicalRecordsToLegacyFields === 'function') {
    syncCanonicalRecordsToLegacyFields(emp, canonicalRecords);
  }

  const icSign = document.getElementById('cf_ic_sign');
  const icStamp = document.getElementById('cf_ic_stamp');
  if (icSign) emp.covidFluIcSign = icSign.value;
  if (icStamp) emp.covidFluIcStamp = icStamp.value;

  // Authoritative Central Database Commit via saveEmployeeRecord
  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

function renderSpecialVaccinationForm(emp) {
  const sp = emp.specialVaccines || {};
  const pneDate = sp.pneumovax || sp.pnemovax || '';
  const hepA1Date = sp.hepA1 || '';
  const hepA2Date = sp.hepA2 || '';
  const menDate = sp.meningococcal || '';
  const typhDate = sp.typhoid || '';

  let logs = emp.specialVaccineLogs;
  if (!logs || !Array.isArray(logs) || logs.length === 0) {
    logs = [
      { name: "Hepatitis A (Series 1 & 2)", indication: "Lab / Food Handlers", status: (hepA1Date || hepA2Date) ? "Completed" : "Completed", date: hepA1Date || hepA2Date || "" },
      { name: "Meningococcal A, C, W135", indication: "Infectious Disease / Lab", status: menDate ? "Completed" : "Completed", date: menDate || "" },
      { name: "Typhoid Conjugate", indication: "Microbiology Staff", status: typhDate ? "Completed" : "Completed", date: typhDate || "" },
      { name: "Pneumococcal (Pneumovax 23)", indication: "High Risk Clinical", status: pneDate ? "Completed" : "Not Required", date: pneDate || "" }
    ].filter(r => r.date && r.date.toString().trim() !== "");
  } else {
    logs = logs.map(l => {
      const nLower = (l.name || '').toLowerCase();
      let d = l.date || '';
      if (!d) {
        if ((nLower.includes('pneumo') || nLower.includes('pnemovax')) && pneDate) d = pneDate;
        else if ((nLower.includes('mening')) && menDate) d = menDate;
        else if ((nLower.includes('hep a') || nLower.includes('hepatitis a')) && (hepA1Date || hepA2Date)) d = hepA1Date || hepA2Date;
        else if ((nLower.includes('typhoid')) && typhDate) d = typhDate;
      }
      return { ...l, date: d };
    }).filter(r => r.date && r.date.toString().trim() !== "");

    if (pneDate && !logs.some(l => (l.name || '').toLowerCase().includes('pneumo') || (l.name || '').toLowerCase().includes('pnemovax'))) {
      logs.push({ name: "Pneumococcal (Pneumovax 23)", indication: "High Risk Clinical", status: "Completed", date: pneDate });
    }
    if (menDate && !logs.some(l => (l.name || '').toLowerCase().includes('mening'))) {
      logs.push({ name: "Meningococcal A, C, W135", indication: "Infectious Disease / Lab", status: "Completed", date: menDate });
    }
    if ((hepA1Date || hepA2Date) && !logs.some(l => (l.name || '').toLowerCase().includes('hep a') || (l.name || '').toLowerCase().includes('hepatitis a'))) {
      logs.push({ name: "Hepatitis A (Series 1 & 2)", indication: "Lab / Food Handlers", status: "Completed", date: hepA1Date || hepA2Date });
    }
    if (typhDate && !logs.some(l => (l.name || '').toLowerCase().includes('typhoid'))) {
      logs.push({ name: "Typhoid Conjugate", indication: "Microbiology Staff", status: "Completed", date: typhDate });
    }
  }

  return `
    <div class="card" id="specialVacPrintArea" style="background: white; padding: 36px 40px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;">
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE & FORM CODE -->
        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${formatDateDDMMYYYY(new Date().toISOString().slice(0,10))}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Special & High-Risk Occupational Vaccinations</h2>
          <div style="font-size: 1.05rem; color: var(--text-muted); font-weight: 600; margin-top: 4px;">Vaccination and Test History of a Healthcare Worker</div>
        </div>
      </div>

      <!-- OFFICIAL EMPLOYEE HEADER BLOCK -->
      <div style="font-family: 'Times New Roman', Times, serif; font-size: 1.1rem; line-height: 2.2; margin-bottom: 24px; color: black; text-align: left;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;"><strong>Date:</strong> <input type="text" value="${formatDateDDMMYYYY(new Date().toISOString().slice(0,10))}" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 220px;"></div>
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;"><strong>Name of employee:</strong> <input type="text" value="${emp.name}" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; flex: 1; max-width: 440px;"></div>
        <div style="display: flex; align-items: center; gap: 8px;"><strong>ID No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <input type="text" value="${emp.idNo}" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 260px;"></div>
      </div>

      <p style="color: var(--text-muted); margin-bottom: 16px;">For staff working in Laboratory, Dialysis, Oncology, and Pediatric ICU.</p>

      <div class="clinical-table-wrapper">
        <table class="clinical-table" id="specialVacTable">
          <thead>
            <tr>
              <th style="width: 30%;">Vaccine</th>
              <th style="width: 30%;">Indication</th>
              <th style="width: 18%;">Status</th>
              <th style="width: 14%;">Date</th>
              <th style="width: 8%; text-align: center;" class="no-print">Action</th>
            </tr>
          </thead>
          <tbody id="specialVacTbody">
            ${logs.map((log, i) => `
              <tr id="sv_row_${i}">
                <td><input type="text" value="${log.name || ''}" placeholder="e.g. Vaccine Name" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td><input type="text" value="${log.indication || ''}" placeholder="e.g. Lab / ICU Staff" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td>
                  <select style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;">
                    <option value="Completed" ${log.status === 'Completed' ? 'selected' : ''}>Completed</option>
                    <option value="Pending" ${log.status === 'Pending' ? 'selected' : ''}>Pending</option>
                    <option value="Not Required" ${log.status === 'Not Required' ? 'selected' : ''}>Not Required</option>
                    <option value="Refused" ${log.status === 'Refused' ? 'selected' : ''}>Refused</option>
                  </select>
                </td>
                <td><input type="text" value="${formatDateDDMMYYYY(log.date)}" placeholder="dd/mm/yyyy" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td style="text-align: center;" class="no-print"><button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.75rem;" onclick="this.closest('tr').remove()">🗑️</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 1.1rem; margin-bottom: 24px; margin-top: 20px; line-height: 2;">
        <div><strong>Infection Prevention and control Officer Signature.:</strong> <input type="text" id="sv_ic_sign" value="${emp.specialVacIcSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
        <div style="margin-top: 10px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="sv_ic_stamp" value="${emp.specialVacIcStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- SINGLE ACTION BUTTONS ROW BELOW TABLE -->
      <div style="margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;" class="no-print">
        <div style="display: flex; gap: 12px;">
          <button class="btn btn-outline" onclick="printSubForm('specialVacPrintArea', 'Special & High-Risk Occupational Vaccinations')">🖨️ Print Form Layout</button>
          <button class="btn btn-outline" onclick="addSpecialVaccineRow()">➕ Add Vaccine Row</button>
        </div>
        <button class="btn btn-success" onclick="saveSpecialVaccineRecord()">💾 Save Record</button>
      </div>
    </div>
  `;
}

function addSpecialVaccineRow() {
  const tbody = document.getElementById('specialVacTbody');
  if (!tbody) return;
  const rowId = `sv_row_${Date.now()}`;
  const tr = document.createElement('tr');
  tr.id = rowId;
  tr.innerHTML = `
    <td><input type="text" value="" placeholder="e.g. Vaccine Name" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td><input type="text" value="" placeholder="e.g. Indication / Clinical Unit" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td>
      <select style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;">
        <option value="Completed">Completed</option>
        <option value="Pending">Pending</option>
        <option value="Not Required">Not Required</option>
        <option value="Refused">Refused</option>
      </select>
    </td>
    <td><input type="text" value="${formatDateDDMMYYYY(new Date().toISOString().slice(0,10))}" placeholder="dd/mm/yyyy" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td style="text-align: center;" class="no-print"><button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.75rem;" onclick="this.closest('tr').remove()">🗑️</button></td>
  `;
  tbody.appendChild(tr);
}

async function saveSpecialVaccineRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  const tbody = document.getElementById('specialVacTbody');
  const rows = tbody.querySelectorAll('tr');
  const logs = [];
  if (!emp.specialVaccines) emp.specialVaccines = {};

  rows.forEach(tr => {
    const inputs = tr.querySelectorAll('input, select');
    if (inputs.length >= 4) {
      const nameVal = inputs[0].value;
      const indVal = inputs[1].value;
      const statVal = inputs[2].value;
      const dateVal = inputs[3].value;

      logs.push({
        name: nameVal,
        indication: indVal,
        status: statVal,
        date: dateVal
      });

      const nLower = (nameVal || '').toLowerCase();
      if (nLower.includes('pneumo') || nLower.includes('pnemovax')) {
        emp.specialVaccines.pneumovax = dateVal;
      } else if (nLower.includes('mening')) {
        emp.specialVaccines.meningococcal = dateVal;
      } else if (nLower.includes('hep a') || nLower.includes('hepatitis a')) {
        if (nLower.includes('2') || nLower.includes('series 2') || nLower.includes('dose 2') || nLower.includes('second')) {
          emp.specialVaccines.hepA2 = dateVal;
        } else if (nLower.includes('1') || nLower.includes('series 1') || nLower.includes('dose 1') || nLower.includes('first')) {
          emp.specialVaccines.hepA1 = dateVal;
        } else {
          if (!emp.specialVaccines.hepA1) emp.specialVaccines.hepA1 = dateVal;
          else emp.specialVaccines.hepA2 = dateVal;
        }
      } else if (nLower.includes('typhoid')) {
        emp.specialVaccines.typhoid = dateVal;
      }
    }
  });

  emp.specialVaccineLogs = logs;
  emp.specialVacIcSign = document.getElementById('sv_ic_sign') ? document.getElementById('sv_ic_sign').value : '';
  emp.specialVacIcStamp = document.getElementById('sv_ic_stamp') ? document.getElementById('sv_ic_stamp').value : '';

  // Authoritative Central Database Commit via saveEmployeeRecord
  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

function renderPEPForm(emp) {
  const currentDate = new Date().toISOString().slice(0, 10);
  const pepObj = emp.pep || {};
  let logs = emp.pepLogs;

  if (!logs || !Array.isArray(logs) || logs.length === 0) {
    if (pepObj.additionalPepRecords && Array.isArray(pepObj.additionalPepRecords) && pepObj.additionalPepRecords.length > 0) {
      logs = pepObj.additionalPepRecords.map(p => ({
        name: p.protocol || p.vacName || 'PEP Protocol',
        indication: p.indication || 'Needlestick / Exposure Intervention',
        status: p.status || 'Completed',
        date: p.incidentDate || p.date || ''
      }));
    } else if (pepObj.status && pepObj.status !== 'No Incident Reported' && pepObj.status !== 'Clear') {
      logs = [
        {
          name: pepObj.protocol || 'PEP Protocol',
          indication: 'Occupational Exposure',
          status: pepObj.status || 'Completed',
          date: pepObj.incidentDate || pepObj.date || ''
        }
      ];
    } else {
      logs = [];
    }
  }

  logs = (logs || []).filter(r => (r.date && r.date.toString().trim() !== '') || (r.name && r.name.toString().trim() !== ''));

  return `
    <div class="card" id="pepPrintArea" style="background: white; padding: 36px 40px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;">
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${formatDateDDMMYYYY(currentDate)}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Post-Exposure Prophylaxis (PEP) & Sharps Injury Record</h2>
          <div style="font-size: 1.05rem; color: var(--text-muted); font-weight: 600; margin-top: 4px;">Vaccination and Test History of a Healthcare Worker</div>
        </div>
      </div>

      <!-- OFFICIAL EMPLOYEE HEADER BLOCK -->
      <div style="font-family: 'Times New Roman', Times, serif; font-size: 1.1rem; line-height: 2.2; margin-bottom: 24px; color: black; text-align: left;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;"><strong>Date:</strong> <input type="text" value="${formatDateDDMMYYYY(currentDate)}" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 220px;"></div>
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;"><strong>Name of employee:</strong> <input type="text" value="${emp.name}" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; flex: 1; max-width: 440px;"></div>
        <div style="display: flex; align-items: center; gap: 8px;"><strong>ID No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <input type="text" value="${emp.idNo}" style="border: none; border-bottom: 1.5px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 260px;"></div>
      </div>

      <div style="background: #FEF3C7; padding: 14px 18px; border-radius: 8px; border: 1px solid #FCD34D; margin-bottom: 20px; font-family: system-ui, sans-serif;">
        <strong>PEP Protocol Status:</strong> Record of occupational blood / body fluid exposure interventions and prophylaxis regimens.
      </div>

      <div class="clinical-table-wrapper">
        <table class="clinical-table" id="pepTable">
          <thead>
            <tr>
              <th style="width: 30%;">Vaccine / Medication / Protocol</th>
              <th style="width: 30%;">Indication</th>
              <th style="width: 18%;">Status</th>
              <th style="width: 14%;">Date</th>
              <th style="width: 8%; text-align: center;" class="no-print">Action</th>
            </tr>
          </thead>
          <tbody id="pepTbody">
            ${logs.map((log, i) => `
              <tr id="pep_row_${i}">
                <td><input type="text" value="${log.name || ''}" placeholder="e.g. HBIG / PEP Medication" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td><input type="text" value="${log.indication || ''}" placeholder="e.g. Needlestick Injury" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td>
                  <select style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;">
                    <option value="Completed" ${log.status === 'Completed' ? 'selected' : ''}>Completed</option>
                    <option value="In Progress" ${log.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                    <option value="Pending" ${log.status === 'Pending' ? 'selected' : ''}>Pending</option>
                    <option value="Not Required" ${log.status === 'Not Required' ? 'selected' : ''}>Not Required</option>
                    <option value="Discontinued" ${log.status === 'Discontinued' ? 'selected' : ''}>Discontinued</option>
                  </select>
                </td>
                <td><input type="text" value="${formatDateDDMMYYYY(log.date)}" placeholder="dd/mm/yyyy" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
                <td style="text-align: center;" class="no-print"><button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.75rem;" onclick="this.closest('tr').remove()">🗑️</button></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 1.1rem; margin-bottom: 24px; margin-top: 20px; line-height: 2;">
        <div><strong>Infection Prevention and control Officer Signature.:</strong> <input type="text" id="pep_ic_sign" value="${emp.pepIcSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
        <div style="margin-top: 10px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="pep_ic_stamp" value="${emp.pepIcStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px;"></div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- SINGLE ACTION BUTTONS ROW BELOW TABLE -->
      <div style="margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;" class="no-print">
        <div style="display: flex; gap: 12px;">
          <button class="btn btn-outline" onclick="printSubForm('pepPrintArea', 'Post-Exposure Prophylaxis & Sharps Injury Record')">🖨️ Print Form Layout</button>
          <button class="btn btn-outline" onclick="addPEPRow()">➕ Add PEP Row</button>
        </div>
        <button class="btn btn-success" onclick="savePEPRecord()">💾 Save Record</button>
      </div>
    </div>
  `;
}

function addPEPRow() {
  const tbody = document.getElementById('pepTbody');
  if (!tbody) return;
  const rowId = `pep_row_${Date.now()}`;
  const tr = document.createElement('tr');
  tr.id = rowId;
  tr.innerHTML = `
    <td><input type="text" value="" placeholder="e.g. Vaccine / Medication / Protocol" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td><input type="text" value="" placeholder="e.g. Indication / Source Exposure" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td>
      <select style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;">
        <option value="Completed">Completed</option>
        <option value="In Progress">In Progress</option>
        <option value="Pending">Pending</option>
        <option value="Not Required">Not Required</option>
        <option value="Discontinued">Discontinued</option>
      </select>
    </td>
    <td><input type="text" value="${formatDateDDMMYYYY(new Date().toISOString().slice(0,10))}" placeholder="dd/mm/yyyy" style="width: 100%; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center;"></td>
    <td style="text-align: center;" class="no-print"><button class="btn btn-danger" style="padding: 4px 8px; font-size: 0.75rem;" onclick="this.closest('tr').remove()">🗑️</button></td>
  `;
  tbody.appendChild(tr);
}

async function savePEPRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  const tbody = document.getElementById('pepTbody');
  const rows = tbody.querySelectorAll('tr');
  const logs = [];

  rows.forEach(tr => {
    const inputs = tr.querySelectorAll('input, select');
    if (inputs.length >= 4) {
      logs.push({
        name: inputs[0].value,
        indication: inputs[1].value,
        status: inputs[2].value,
        date: inputs[3].value
      });
    }
  });

  emp.pepLogs = logs;
  if (!emp.pep) emp.pep = {};
  emp.pep.additionalPepRecords = logs.map(l => ({
    protocol: l.name,
    indication: l.indication,
    status: l.status,
    date: l.date,
    incidentDate: l.date
  }));
  emp.pep.status = logs.length > 0 ? logs.map(l => (l.name + ': ' + l.status)).join(', ') : 'No Incident Reported';

  emp.pepIcSign = document.getElementById('pep_ic_sign') ? document.getElementById('pep_ic_sign').value : '';
  emp.pepIcStamp = document.getElementById('pep_ic_stamp') ? document.getElementById('pep_ic_stamp').value : '';

  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

let currentRefusalSubTab = 'flu';

function switchRefusalSubTab(typeKey) {
  currentRefusalSubTab = typeKey;
  const container = document.getElementById('mainAppArea');
  renderVaccinationForm(container);
}

function renderRefusalForm(emp) {
  const rf = emp.refusalForm || {};
  const currentDate = new Date().toISOString().slice(0, 10);

  return `
    <div style="background: white; padding: 20px 24px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;" id="refusalPrintArea">
      <!-- 2 FORM CHOICES SELECTOR HEADER (HIDDEN IN PRINT) -->
      <div style="display: flex; gap: 12px; margin-bottom: 16px; font-family: system-ui, sans-serif;" class="no-print">
        <button class="btn ${currentRefusalSubTab === 'flu' ? 'btn-primary' : 'btn-outline'}" onclick="switchRefusalSubTab('flu')">
          📋 1. Seasonal Flu Vaccine Refusal Form (SQE 02.01 / Flu)
        </button>
        <button class="btn ${currentRefusalSubTab === 'general' ? 'btn-primary' : 'btn-outline'}" onclick="switchRefusalSubTab('general')">
          📋 2. General Mandatory Vaccination Refusal Form (SQE 02.01 / Refusal)
        </button>
      </div>

      ${currentRefusalSubTab === 'flu' ? `
        <!-- CHOICE 1: SEASONAL FLU VACCINE REFUSAL FORM -->
        <!-- DOCUMENT HEADER -->
        <div style="margin-bottom: 10px;">
          <!-- 1. LOGO AT MIDDLE PAGE -->
          <div style="text-align: center; margin-bottom: 6px;">
            ${getAVHLogoHTML(85)}
          </div>

          <!-- 2. THEN LINE -->
          <div style="border-bottom: 2px solid var(--primary-blue); margin: 6px 0 8px 0;"></div>

          <!-- 3. THEN DATE ON R.T SIDE -->
          <div style="text-align: right; margin-bottom: 8px; direction: rtl;">
            <div style="font-weight: bold; font-size: 0.95rem; color: var(--primary-blue);">
              التاريخ: ${formatDateDDMMYYYY(rf.date || currentDate)}
            </div>
          </div>

          <!-- 4. THEN NAME OF FORM -->
          <div style="text-align: center; margin-bottom: 10px;">
            <h2 style="color: var(--primary-blue); font-size: 1.25rem; font-weight: 800; margin: 0;">Seasonal Influenza (Flu) Vaccine Refusal Form</h2>
            <h3 style="color: var(--primary-blue); font-size: 1.05rem; font-weight: 700; margin-top: 2px; direction: rtl;">نموذج إقرار ورفض تلقي تطعيم الأنفلونزا الموسمية</h3>
          </div>
        </div>

        <!-- OFFICIAL EMPLOYEE HEADER BLOCK -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 0.95rem; line-height: 1.6; margin-bottom: 10px; color: black; text-align: left;">
          <div><strong>Date:</strong> <input type="text" id="rf_date" value="${formatDateDDMMYYYY(rf.date || currentDate)}" oninput="syncOldVacFields(this, 'rf_date_ar')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 150px;"></div>
          <div><strong>Name of employee:</strong> <input type="text" id="rf_name_en" value="${emp.name}" oninput="syncOldVacFields(this, 'rf_name_ar')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 300px;"></div>
          <div><strong>ID No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <input type="text" id="rf_idNo_en" value="${emp.idNo}" oninput="syncOldVacFields(this, 'rf_idNo_ar')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 200px;"></div>
        </div>

        <!-- ENGLISH DECLARATION BODY -->
        <div style="font-size: 0.9rem; line-height: 1.35; margin-bottom: 10px;">
          <p style="margin-bottom: 6px;">
            I declare that I have been fully informed by Augusta Victoria Hospital Infection Control & Occupational Health Department regarding the medical benefits and importance of receiving the <strong>Seasonal Influenza (Flu) Vaccine</strong>.
          </p>
          <p style="margin-bottom: 8px;">
            I understand that by declining this immunization, I may endanger myself, my family, and high-risk vulnerable patients under my clinical care (Oncology, Dialysis, Pediatric ICU, Immunocompromised).
          </p>

          <div style="font-weight: bold; margin-bottom: 4px;">Reason for Refusal / Declination:</div>
          <div style="padding-left: 10px; line-height: 1.4;">
            <div><label><input type="checkbox" id="rf_reason1_en" ${rf.reason1 !== false ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason1_ar')"> 1. Medical Contraindication (History of Anaphylaxis / Guillain-Barré Syndrome)</label></div>
            <div><label><input type="checkbox" id="rf_reason2_en" ${rf.reason2 ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason2_ar')"> 2. Personal / Religious Beliefs or Preference</label></div>
            <div><label><input type="checkbox" id="rf_reason3_en" ${rf.reason3 ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason3_ar')"> 3. Already Received Flu Vaccine Outside Hospital (Documentation Attached)</label></div>
            <div style="display: flex; align-items: center; gap: 6px; margin-top: 2px;">
              <label><input type="checkbox" id="rf_reason4_en" ${rf.reason4 ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason4_ar')"> 4. Other Reason:</label>
              <input type="text" id="rf_otherText_en" value="${rf.otherTextEn || ''}" oninput="syncOldVacFields(this, 'rf_otherText_ar')" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; flex: 1;">
            </div>
          </div>

          <div style="margin-top: 10px;">
            <strong>Employee Signature:</strong> <input type="text" id="rf_sign_en" value="${rf.signEn || ''}" oninput="syncOldVacFields(this, 'rf_sign_ar')" placeholder="........................................................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 300px;">
          </div>
        </div>

        <!-- SEPARATOR LINE -->
        <div style="border-bottom: 2px solid black; margin: 10px 0;"></div>

        <!-- ARABIC DECLARATION BODY (RTL) -->
        <div style="direction: rtl; font-size: 0.9rem; line-height: 1.35; margin-bottom: 10px; text-align: right;">
          <div style="margin-bottom: 6px;">
            <strong>التاريخ:</strong> <input type="text" id="rf_date_ar" value="${formatDateDDMMYYYY(rf.date || currentDate)}" oninput="syncOldVacFields(this, 'rf_date')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 150px;">
          </div>
          <div>
            <strong>إسم الموظف:</strong> <input type="text" id="rf_name_ar" value="${emp.name}" oninput="syncOldVacFields(this, 'rf_name_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 260px;">
            &nbsp;&nbsp;
            <strong>رقم الهوية:</strong> <input type="text" id="rf_idNo_ar" value="${emp.idNo}" oninput="syncOldVacFields(this, 'rf_idNo_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 180px;">
          </div>

          <p style="margin-top: 6px; margin-bottom: 6px;">
            أقر أنا الموظف المذكور أعلاه بصفاتي وبكامل إرادتي بأني قد تم إعلامي وتوعيتي من قبل قسم ضبط العدوى والصحة المهنية بمستشفى الأوغستا فكتوريا (المُطلع) بشأن أهمية وفوائد تلقي <strong>طُعم الأنفلونزا الموسمية</strong>.
          </p>
          <p style="margin-bottom: 8px;">
            وأدرك تماماً أن عدم تلقي المطعوم قد يعرضني ويعرض عائلتي والمرضى الأكثر عرضة للخطر (مرضى الأورام، غسيل الكلى، والعناية المكثفة) لخطر العدوى.
          </p>

          <div style="font-weight: bold; margin-bottom: 4px;">سبب عدم تلقي طُعم الأنفلونزا الموسمية:</div>
          <div style="padding-right: 10px; line-height: 1.4;">
            <div><label><input type="checkbox" id="rf_reason1_ar" ${rf.reason1 !== false ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason1_en')"> 1. مانع طبي (حساسية مفرطة سابقة / متلازمة غيلان باريه)</label></div>
            <div><label><input type="checkbox" id="rf_reason2_ar" ${rf.reason2 ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason2_en')"> 2. سبب شخصي / قناعة خاصة</label></div>
            <div><label><input type="checkbox" id="rf_reason3_ar" ${rf.reason3 ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason3_en')"> 3. تلقيت التطعيم خارج المستشفى (مرفق إثبات التطعيم)</label></div>
            <div style="display: flex; align-items: center; gap: 6px; margin-top: 2px;">
              <label><input type="checkbox" id="rf_reason4_ar" ${rf.reason4 ? 'checked' : ''} onchange="syncOldVacFields(this, 'rf_reason4_en')"> 4. سبب آخر:</label>
              <input type="text" id="rf_otherText_ar" value="${rf.otherTextAr || ''}" oninput="syncOldVacFields(this, 'rf_otherText_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; flex: 1;">
            </div>
          </div>

          <div style="margin-top: 10px;">
            <strong>توقيع الموظف:</strong> <input type="text" id="rf_sign_ar" value="${rf.signAr || ''}" oninput="syncOldVacFields(this, 'rf_sign_en')" placeholder="........................................................................" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 320px;">
          </div>
        </div>

        <!-- SEPARATOR LINE -->
        <div style="border-bottom: 2px solid black; margin: 10px 0;"></div>

        <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
        <div style="font-size: 0.92rem; margin-bottom: 12px; margin-top: 8px; line-height: 1.6;">
          <div><strong>Infection Prevention and Control Officer Signature:</strong> <input type="text" id="rf_ic_sign" value="${rf.icSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 280px;"></div>
          <div style="margin-top: 6px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="rf_ic_stamp" value="${rf.icStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 280px;"></div>
        </div>

        <!-- BRANDED FOOTER IMAGE -->
        <div style="margin-top: 16px; width: 100%; text-align: center;">
          <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
        </div>
      ` : `
        <!-- CHOICE 2: GENERAL MANDATORY VACCINATION REFUSAL FORM -->
        <!-- DOCUMENT HEADER -->
        <div style="margin-bottom: 10px;">
          <!-- 1. LOGO AT MIDDLE PAGE -->
          <div style="text-align: center; margin-bottom: 6px;">
            ${getAVHLogoHTML(85)}
          </div>

          <!-- 2. THEN LINE -->
          <div style="border-bottom: 2px solid var(--primary-blue); margin: 6px 0 8px 0;"></div>

          <!-- 3. THEN DATE ON R.T SIDE -->
          <div style="text-align: right; margin-bottom: 8px; direction: rtl;">
            <div style="font-weight: bold; font-size: 0.95rem; color: var(--primary-blue);">
              التاريخ: ${formatDateDDMMYYYY(rf.date || currentDate)}
            </div>
          </div>

          <!-- 4. THEN NAME OF FORM -->
          <div style="text-align: center; margin-bottom: 10px;">
            <h2 style="color: var(--primary-blue); font-size: 1.25rem; font-weight: 800; margin: 0;">Mandatory Vaccination Refusal Form</h2>
            <h3 style="color: var(--primary-blue); font-size: 1.05rem; font-weight: 700; margin-top: 2px; direction: rtl;">نموذج إقرار ورفض تلقي التطعيمات الإلزامية العامة</h3>
          </div>
        </div>

        <!-- OFFICIAL EMPLOYEE HEADER BLOCK -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 0.95rem; line-height: 1.6; margin-bottom: 10px; color: black; text-align: left;">
          <div><strong>Date:</strong> <input type="text" id="rf_date" value="${formatDateDDMMYYYY(rf.date || currentDate)}" oninput="syncOldVacFields(this, 'rf_date_ar')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 150px;"></div>
          <div><strong>Name of employee:</strong> <input type="text" id="rf_name_en" value="${emp.name}" oninput="syncOldVacFields(this, 'rf_name_ar')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 300px;"></div>
          <div><strong>ID No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> <input type="text" id="rf_idNo_en" value="${emp.idNo}" oninput="syncOldVacFields(this, 'rf_idNo_ar')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 200px;"></div>
        </div>

        <!-- ENGLISH DECLARATION BODY -->
        <div style="font-size: 0.9rem; line-height: 1.35; margin-bottom: 10px;">
          <p style="margin-bottom: 6px;">
            I declare that I have been fully counseled by Augusta Victoria Hospital Occupational Health Department regarding mandatory healthcare worker immunizations (Hepatitis B, Tdap, MMR, Varicella).
          </p>
          <p style="margin-bottom: 8px;">
            I understand that declining these mandatory immunizations increases my occupational risk of acquiring and transmitting vaccine-preventable infectious diseases to patients and staff.
          </p>

          <div style="font-weight: bold; margin-bottom: 4px;">Refused Mandatory Vaccine(s):</div>
          <div style="padding-left: 10px; line-height: 1.4;">
            <div><label><input type="checkbox" id="gen_v1" ${rf.genV1 !== false ? 'checked' : ''}> Hepatitis B Vaccine Series (3 Doses)</label></div>
            <div><label><input type="checkbox" id="gen_v2" ${rf.genV2 ? 'checked' : ''}> Tdap (Tetanus, Diphtheria, Pertussis Booster)</label></div>
            <div><label><input type="checkbox" id="gen_v3" ${rf.genV3 ? 'checked' : ''}> MMR (Measles, Mumps, Rubella Vaccine)</label></div>
            <div><label><input type="checkbox" id="gen_v4" ${rf.genV4 ? 'checked' : ''}> Varicella / Other Mandatory Clinical Immunization</label></div>
          </div>

          <div style="font-weight: bold; margin-top: 10px; margin-bottom: 4px;">Reason for Refusal:</div>
          <div style="padding-left: 10px; line-height: 1.4;">
            <div><label><input type="checkbox" id="gen_r1" ${rf.genR1 !== false ? 'checked' : ''}> Medical Contraindication (Exemption Approved by Occupational Health Physician)</label></div>
            <div><label><input type="checkbox" id="gen_r2" ${rf.genR2 ? 'checked' : ''}> Personal / Religious Belief Exemption</label></div>
          </div>

          <div style="margin-top: 10px;">
            <strong>Employee Signature:</strong> <input type="text" id="rf_sign_en" value="${rf.signEn || ''}" oninput="syncOldVacFields(this, 'rf_sign_ar')" placeholder="........................................................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 300px;">
          </div>
        </div>

        <!-- SEPARATOR LINE -->
        <div style="border-bottom: 2px solid black; margin: 10px 0;"></div>

        <!-- ARABIC DECLARATION BODY (RTL) -->
        <div style="direction: rtl; font-size: 0.9rem; line-height: 1.35; margin-bottom: 10px; text-align: right;">
          <div style="margin-bottom: 6px;">
            <strong>التاريخ:</strong> <input type="text" id="rf_date_ar" value="${formatDateDDMMYYYY(rf.date || currentDate)}" oninput="syncOldVacFields(this, 'rf_date')" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 150px;">
          </div>
          <div>
            <strong>إسم الموظف:</strong> <input type="text" id="rf_name_ar" value="${emp.name}" oninput="syncOldVacFields(this, 'rf_name_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 260px;">
            &nbsp;&nbsp;
            <strong>رقم الهوية:</strong> <input type="text" id="rf_idNo_ar" value="${emp.idNo}" oninput="syncOldVacFields(this, 'rf_idNo_en')" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-align: center; width: 180px;">
          </div>

          <p style="margin-top: 6px; margin-bottom: 6px;">
            أقر أنا الموظف المذكور أعلاه بأني قد تم إعلامي وتوعيتي بالمخاطر المهنية والصحية المترتبة على عدم تلقي التطعيمات الوقائية الإلزامية في مستشفى الأوغستا فكتوريا (المُطلع)، وأتحمل كامل المسؤولية عن هذا القرار.
          </p>

          <div style="font-weight: bold; margin-bottom: 4px;">التطعيم الإلزامي المرفوض:</div>
          <div style="padding-right: 10px; line-height: 1.4;">
            <div><label><input type="checkbox" ${rf.genV1 !== false ? 'checked' : ''}> تطعيم التهاب الكبد الوبائي ب (Hepatitis B)</label></div>
            <div><label><input type="checkbox" ${rf.genV2 ? 'checked' : ''}> طُعم الكزاز والديفتيريا والشحار (Tdap)</label></div>
            <div><label><input type="checkbox" ${rf.genV3 ? 'checked' : ''}> طُعم الحصبة والنكاف والحصبة الألمانية (MMR)</label></div>
          </div>

          <div style="margin-top: 10px;">
            <strong>توقيع الموظف:</strong> <input type="text" id="rf_sign_ar" value="${rf.signAr || ''}" oninput="syncOldVacFields(this, 'rf_sign_en')" placeholder="........................................................................" style="border: none; border-bottom: 1px dotted black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 320px;">
          </div>
        </div>

        <!-- SEPARATOR LINE -->
        <div style="border-bottom: 2px solid black; margin: 10px 0;"></div>

        <!-- INFECTION CONTROL SIGNATURE & STAMP BLOCK -->
        <div style="font-size: 0.92rem; margin-bottom: 12px; margin-top: 8px; line-height: 1.6;">
          <div><strong>Infection Prevention and Control Officer Signature:</strong> <input type="text" id="rf_ic_sign" value="${rf.icSign || ''}" placeholder="........................................" style="border: none; border-bottom: 1px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 280px;"></div>
          <div style="margin-top: 6px;"><strong>Infectious Disease Unit Stamp:</strong> <input type="text" id="rf_ic_stamp" value="${rf.icStamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10pt; font-weight: bold; text-align: center; width: 280px;"></div>
        </div>

        <!-- BRANDED FOOTER IMAGE -->
        <div style="margin-top: 16px; width: 100%; text-align: center;">
          <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
        </div>
      `}

      <!-- ACTION BUTTONS BELOW (HIDDEN IN PRINT) -->
      <div style="margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1; display: flex; justify-content: flex-end; align-items: center; gap: 16px;" class="no-print">
        <button class="btn btn-outline" onclick="printSubForm('refusalPrintArea', 'Vaccine Refusal Declaration Form (1 Page)')">🖨️ Print Refusal Form (1 Page A4)</button>
        <button class="btn btn-danger" onclick="saveRefusalRecord()">💾 Save Refusal Waiver</button>
      </div>
    </div>
  `;
}

async function saveRefusalRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  emp.refusalForm = {
    date: document.getElementById('rf_date').value,
    reason1: document.getElementById('rf_reason1_en').checked,
    reason2: document.getElementById('rf_reason2_en').checked,
    reason3: document.getElementById('rf_reason3_en').checked,
    reason4: document.getElementById('rf_reason4_en').checked,
    otherTextEn: document.getElementById('rf_otherText_en').value,
    otherTextAr: document.getElementById('rf_otherText_ar').value,
    signEn: document.getElementById('rf_sign_en').value,
    signAr: document.getElementById('rf_sign_ar').value,
    icSign: document.getElementById('rf_ic_sign').value
  };

  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

function renderInfectionControlApprovalForm(emp) {
  const ic = emp.infectionControlApproval || {};
  const currentDate = new Date().toISOString().slice(0, 10);

  // Auto-extract Engrix / Hep B dates from Lab/Vaccine history (Date of Engrix 1st Dose & Date of Engrix 2nd Dose)
  const lab = emp.lab || emp.labResults || {};
  const vac = emp.vaccines || {};
  const hepB = vac['Hepatitis B'] || vac['Engrix'] || {};

  const rawHepB1 = lab.engrixDose1 || hepB.d1 || emp.engrixDose1 || (emp.demographic ? emp.demographic.engrixDose1 : '') || '';
  const rawHepB2 = lab.engrixDose2 || hepB.d2 || emp.engrixDose2 || (emp.demographic ? emp.demographic.engrixDose2 : '') || '';

  const autoHepB1 = rawHepB1 ? formatDateDDMMYYYY(rawHepB1) : '';
  const autoHepB2 = rawHepB2 ? formatDateDDMMYYYY(rawHepB2) : '';

  const valHepB1 = (ic.hepB1 !== undefined && ic.hepB1 !== '' && !ic.hepB1.includes('.')) ? ic.hepB1 : autoHepB1;
  const valHepB2 = (ic.hepB2 !== undefined && ic.hepB2 !== '' && !ic.hepB2.includes('.')) ? ic.hepB2 : autoHepB2;

  // Determine auto recommendation states
  const hasHepBDoses = !!(autoHepB1 || autoHepB2 || (ic.hepB1 && !ic.hepB1.includes('.')) || (ic.hepB2 && !ic.hepB2.includes('.')));
  const isRecAfterChecked = ic.recAfter !== undefined ? ic.recAfter : hasHepBDoses;
  const isRecImmChecked = ic.recImm !== undefined ? ic.recImm : !isRecAfterChecked;

  return `
    <div style="background: white; padding: 36px 44px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid #CBD5E1;" id="icApprovalPrintArea">
      <!-- TOP PRINT ACTION BAR (HIDDEN IN PRINT) -->
      <div style="display: flex; justify-content: flex-end; gap: 12px; margin-bottom: 20px;" class="no-print">
        <button class="btn btn-outline" onclick="printSubForm('icApprovalPrintArea', 'Infection Control Approval Card (SQE 02.01)')" style="font-weight: 700;">
          🖨️ Print Infection Control Approval Card (SQE 02.01)
        </button>
      </div>

      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <!-- 1. LOGO AT MIDDLE PAGE -->
        <div style="text-align: center; margin-bottom: 10px;">
          ${getAVHLogoHTML(115)}
        </div>

        <!-- 2. THEN LINE -->
        <div style="border-bottom: 2px solid var(--primary-blue); margin: 10px 0 14px 0;"></div>

        <!-- 3. THEN DATE ON R.T SIDE -->
        <div style="text-align: right; margin-bottom: 14px; direction: rtl;">
          <div style="font-weight: bold; font-size: 1.05rem; color: var(--primary-blue);">
            التاريخ: ${formatDateDDMMYYYY(ic.date || currentDate)}
          </div>
        </div>

        <!-- 4. THEN NAME OF FORM -->
        <div style="text-align: center; margin-bottom: 20px;">
          <h2 style="color: var(--primary-blue); font-size: 1.4rem; font-weight: 800; margin: 0;">Infection Control Approval Card</h2>
          <div style="font-size: 1.05rem; color: var(--text-muted); font-weight: 600; margin-top: 4px;">Vaccination and Test History of a Healthcare Worker</div>
        </div>
      </div>

      <!-- DATE LINE -->
      <div style="font-size: 1.15rem; font-weight: bold; margin-bottom: 24px; font-family: 'Times New Roman', Times, serif;">
        Date: <input type="text" id="ic_date" value="${formatDateDDMMYYYY(ic.date || currentDate)}" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 200px; color: #000000; background: transparent;">
      </div>

      <!-- CERTIFICATION STATEMENT -->
      <div style="font-size: 1.15rem; line-height: 2.5; margin-bottom: 24px; font-family: 'Times New Roman', Times, serif;">
        <div style="display: flex; align-items: center; margin-bottom: 8px;">
          <strong style="white-space: nowrap; color: #000000;">This is to certify that &nbsp;</strong>
          <input type="text" id="ic_cert_name" value="${ic.certName || emp.name}" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; flex: 1; max-width: 480px; padding: 0 6px; color: #000000; background: transparent;">
        </div>
        <div style="display: flex; align-items: center;">
          <strong style="white-space: nowrap; color: #000000;">Holding ID #: &nbsp;</strong>
          <input type="text" id="ic_cert_id" value="${ic.certId || emp.idNo}" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 360px; padding: 0 6px; color: #000000; background: transparent;">
        </div>
      </div>

      <!-- CHECKBOX CERTIFICATION LIST -->
      <div style="font-size: 1.1rem; line-height: 2.3; margin-bottom: 30px; padding-left: 6px; font-family: 'Times New Roman', Times, serif;">
        <div style="display: flex; align-items: baseline; gap: 10px;">
          <input type="checkbox" id="ic_check1" ${ic.check1 !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #000000;">
          <label for="ic_check1" style="cursor: pointer;"><strong>1. Received all vaccination required by the Ministry of Health according to his /her profession.</strong></label>
        </div>
        <div style="display: flex; align-items: baseline; gap: 10px;">
          <input type="checkbox" id="ic_check2" ${ic.check2 !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #000000;">
          <label for="ic_check2" style="cursor: pointer;"><strong>2. Performed tuberculin test (Mantoox).</strong></label>
        </div>
        <div style="display: flex; align-items: baseline; gap: 10px;">
          <input type="checkbox" id="ic_check3" ${ic.check3 !== false ? 'checked' : ''} style="width: 20px; height: 20px; cursor: pointer; accent-color: #000000;">
          <label for="ic_check3" style="cursor: pointer;"><strong>3. Did all tests required by Ministry of health according to AVH policy</strong></label>
        </div>
      </div>

      <!-- RECOMMENDATIONS SECTION -->
      <div style="font-size: 1.15rem; margin-bottom: 40px; font-family: 'Times New Roman', Times, serif;">
        <div style="font-weight: bold; margin-bottom: 12px; font-size: 1.2rem;">Recommendations</div>
        <div style="padding-left: 20px; line-height: 2.2;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <input type="checkbox" id="ic_rec_imm" ${isRecImmChecked ? 'checked' : ''} onchange="if(this.checked){ const ra = document.getElementById('ic_rec_after'); if(ra) ra.checked = false; }" style="width: 18px; height: 18px; cursor: pointer; accent-color: #000000;">
            <label for="ic_rec_imm" style="cursor: pointer;"><strong>can start work immediately.</strong></label>
          </div>
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <input type="checkbox" id="ic_rec_after" ${isRecAfterChecked ? 'checked' : ''} onchange="if(this.checked){ const ri = document.getElementById('ic_rec_imm'); if(ri) ri.checked = false; const b1 = document.getElementById('ic_hep_b1'); const b2 = document.getElementById('ic_hep_b2'); if(b1 && (!b1.value || b1.value.includes('.'))) b1.value = '${autoHepB1}'; if(b2 && (!b2.value || b2.value.includes('.'))) b2.value = '${autoHepB2}'; }" style="width: 18px; height: 18px; cursor: pointer; accent-color: #000000;">
            <label for="ic_rec_after" style="cursor: pointer;"><strong>Can start work after receiving the following vaccines</strong></label>
          </div>
          <div style="padding-left: 36px; line-height: 2.4;">
            <div style="display: flex; align-items: center; margin-bottom: 4px;">
              <strong style="min-width: 190px;">Hep B vaccine 1<sup>st</sup> dose: &nbsp;</strong>
              <input type="text" id="ic_hep_b1" value="${valHepB1}" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px; color: #000000; background: transparent;">
            </div>
            <div style="display: flex; align-items: center;">
              <strong style="min-width: 190px;">Hep B vaccine 2<sup>nd</sup> dose: &nbsp;</strong>
              <input type="text" id="ic_hep_b2" value="${valHepB2}" placeholder="dd/mm/yyyy" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 340px; color: #000000; background: transparent;">
            </div>
          </div>
        </div>
      </div>

      <!-- SIGNATURE & STAMP BLOCK -->
      <div style="font-size: 1.15rem; margin-bottom: 36px; margin-top: 28px; line-height: 2.5; font-family: 'Times New Roman', Times, serif;">
        <div style="display: flex; align-items: center; margin-bottom: 10px;">
          <strong style="white-space: nowrap;">Infectious Disease Specialist: &nbsp;</strong>
          <input type="text" id="ic_specialist" value="${ic.specialist || ''}" placeholder="........................................" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 380px; color: #000000; background: transparent;">
        </div>
        <div style="display: flex; align-items: center;">
          <strong style="white-space: nowrap;">Infectious Disease Unit Stamp: &nbsp;</strong>
          <input type="text" id="ic_stamp" value="${ic.stamp || ''}" placeholder="........................................" style="border: none; border-bottom: 1.5px solid black; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-align: center; width: 380px; color: #000000; background: transparent;">
        </div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 16px; width: 100%; text-align: center;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 52px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- ACTION BUTTONS BELOW (HIDDEN IN PRINT) -->
      <div style="margin-top: 24px; padding-top: 16px; border-top: 1px dashed #CBD5E1; display: flex; justify-content: flex-end; align-items: center; gap: 16px;" class="no-print">
        <button class="btn btn-outline" onclick="printSubForm('icApprovalPrintArea', 'Infection Control Approval Card (SQE 02.01)')" style="font-weight: 700;">🖨️ Print Infection Control Approval Card (SQE 02.01)</button>
        <button class="btn btn-success" onclick="saveInfectionControlApprovalRecord()">💾 Save Approval Record</button>
      </div>
    </div>
  `;
}

async function saveInfectionControlApprovalRecord() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeEmpIndex === -1 || !employees[activeEmpIndex]) {
    alert('⚠️ Please select or search for a staff member first before saving.');
    return;
  }
  const emp = employees[activeEmpIndex];

  emp.infectionControlApproval = {
    date: document.getElementById('ic_date')?.value || new Date().toLocaleDateString(),
    certName: document.getElementById('ic_cert_name')?.value || emp.name,
    certId: document.getElementById('ic_cert_id')?.value || emp.idNo,
    check1: document.getElementById('ic_check1')?.checked !== false,
    check2: document.getElementById('ic_check2')?.checked !== false,
    check3: document.getElementById('ic_check3')?.checked !== false,
    recImm: document.getElementById('ic_rec_imm')?.checked,
    recAfter: document.getElementById('ic_rec_after')?.checked,
    hepB1: document.getElementById('ic_hep_b1')?.value || '',
    hepB2: document.getElementById('ic_hep_b2')?.value || '',
    specialist: document.getElementById('ic_specialist')?.value || 'Infection Control Specialist',
    stamp: document.getElementById('ic_stamp')?.value || ''
  };

  const saveRes = await saveEmployeeRecord(emp);
  return saveRes;
}

async function saveEmployeeRecord(empOverride = null) {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  let targetEmp = empOverride || (activeEmpIndex !== -1 ? employees[activeEmpIndex] : null);
  if (!targetEmp) {
    alert(isAr ? 'âڑ ï¸ڈ ظٹط±ط¬ظ‰ ط§ظ„ط¨ط­ط« ط¹ظ† ط§ظ„ظ…ظˆط¸ظپ ط£ظˆ ط§ط®طھظٹط§ط±ظ‡ ط£ظˆظ„ط§ظ‹ ظ‚ط¨ظ„ ط§ظ„ط­ظپط¸.' : 'âڑ ï¸ڈ Please search or select a staff member first before saving.');
    return null;
  }

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  let saveRes = null;

  try {
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployee === 'function') {
      saveRes = await EmployeeDataService.saveEmployee(targetEmp, 'update');
    } else if (typeof saveEmployeesToLocalStorage === 'function') {
      saveEmployeesToLocalStorage(employees);
      saveRes = { success: true, localSaved: true, serverSaved: false, pendingSync: true, message: 'Saved locally as draft' };
    }
  } catch (err) {
    console.error("saveEmployeeRecord error:", err);
    if (typeof showDangerToast === 'function') {
      showDangerToast(isAr ? `❌ فشل الحفظ: ${err.message}` : `❌ Save Failed: ${err.message}`, isAr ? 'خطأ في الحفظ' : 'Save Error');
    } else {
      alert(isAr ? `❌ فشل الحفظ: ${err.message}` : `❌ Save Failed: ${err.message}`);
    }
    return { success: false, status: 'error', error: err.message };
  }

  // Handle OCC Conflict
  if (saveRes && saveRes.conflict) {
    const conflictMsg = isAr 
      ? '⚠️ تعارض في التعديل: تم تعديل هذا السجل من جهاز آخر. يرجى إعادة تحميل السجل للحصول على أحدث البيانات.'
      : '⚠️ Concurrent edit conflict: This record was modified from another device. Please reload the record before updating.';
    if (typeof showDangerToast === 'function') {
      showDangerToast(conflictMsg, isAr ? 'تعارض في التعديل' : 'Concurrency Conflict');
    } else {
      alert(conflictMsg);
    }
    return saveRes;
  }

  // Handle Forbidden / Permission Error
  if (saveRes && (saveRes.forbidden || saveRes.status === 'forbidden')) {
    const forbMsg = (isAr ? '❌ تم رفض الإذن: ليس لديك الصلاحيات الكافية لتعديل السجل: ' : '❌ Permission Denied: Insufficient privileges: ') + (saveRes.message || '');
    if (typeof showDangerToast === 'function') {
      showDangerToast(forbMsg, isAr ? 'صلاحيات غير كافية' : 'Permission Denied');
    } else {
      alert(forbMsg);
    }
    return saveRes;
  }

  // Handle General Error
  if (saveRes && (saveRes.success === false || saveRes.status === 'error')) {
    const errMsg = (isAr ? '❌ فشل حفظ السجل: ' : '❌ Failed to save staff record: ') + (saveRes.message || 'Database rejected save');
    if (typeof showDangerToast === 'function') {
      showDangerToast(errMsg, isAr ? 'خطأ في الحفظ' : 'Save Error');
    } else {
      alert(errMsg);
    }
    return saveRes;
  }

  // Server Confirms Saving
  if (saveRes && saveRes.serverSaved) {
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(
        isAr ? 'تم تحديث سجل التطعيمات بنجاح في قاعدة البيانات المركزية 🟢' : 'Updated successfully in central database 🟢',
        isAr ? 'تم التحديث بنجاح 🟢' : 'Updated successfully 🟢'
      );
    }
  } else if (saveRes && saveRes.pendingSync) {
    if (typeof showWarningToast === 'function') {
      showWarningToast(
        isAr ? 'تم حفظ التعديلات كمسودة محلية (قيد المزامنة) 🟠' : 'Changes saved locally as draft (Pending sync) 🟠',
        isAr ? 'قيد المزامنة 🟠' : 'Pending sync 🟠'
      );
    } else if (typeof showSuccessToast === 'function') {
      showSuccessToast(
        isAr ? 'تم حفظ التعديلات كمسودة محلية (قيد المزامنة) 🟠' : 'Changes saved locally as draft (Pending sync) 🟠',
        isAr ? 'قيد المزامنة 🟠' : 'Pending sync 🟠'
      );
    }
  }

  if (window.googleSheetsSync && window.googleSheetsSync.isConnected() && typeof saveEmployeeToMasterSheet === 'function') {
    saveEmployeeToMasterSheet(targetEmp, 'update').catch(e => console.warn("Sheets sync warning:", e));
  }

  return saveRes;
}
window.saveEmployeeRecord = saveEmployeeRecord;

if (typeof window !== 'undefined') {
  const refreshVacFormOnUpdate = () => {
    // STRICT GUARD: Only refresh vaccination form if the user is currently on vaccination forms tab!
    // Never hijack or switch pages when the user is on injury report, certificates, dashboard, or staff entry.
    if (typeof activeNavTab !== 'undefined' && activeNavTab !== 'vaccination-forms' && activeNavTab !== 'vaccinationForm' && activeNavTab !== 'forms') {
      return;
    }
    const container = document.getElementById('mainAppArea');
    if (container && document.getElementById('vac_header_search_input')) {
      if (typeof renderVaccinationForm === 'function') {
        renderVaccinationForm(container);
      }
    }
  };
  window.addEventListener('staffDataUpdated', refreshVacFormOnUpdate);
  window.addEventListener('avh_data_updated', refreshVacFormOnUpdate);
}

