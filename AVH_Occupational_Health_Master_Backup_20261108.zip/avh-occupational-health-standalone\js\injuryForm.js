/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - INJURY REPORT FORM (SQE 02.01) CONTROLLER
   ========================================================================== */

let activeInjuryEmpIndex = -1;
let activeInjurySerial = '';
let isManualBlankMode = false;
let currentInjurySubTab = 'form';
let injuryLogPeriodFrom = '2026-01-01';
let injuryLogPeriodTo = new Date().toISOString().slice(0, 10);
let injuryLogSearchQuery = '';
let injuryLogTypeFilter = 'ALL';

function formatToDDMMYYYY(dateStr) {
  if (!dateStr) return '';
  let str = String(dateStr).trim().replace('T', ' ');

  // 1. Separate Date portion from Time portion if present
  let datePart = str;
  let timePart = '';

  const timeMatch = str.match(/\b(\d{1,2}:\d{2}(?::\d{2})?)\b/);
  if (timeMatch) {
    timePart = timeMatch[1].substring(0, 5);
    datePart = str.replace(timeMatch[0], '').trim();
  }

  // 2. Check if datePart is an Excel serial number (e.g. 39264, 41415, 44200)
  if (/^\d{4,5}(\.\d+)?$/.test(datePart)) {
    const num = parseFloat(datePart);
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const utcDays = Math.floor(num);
    const msPerDay = 24 * 60 * 60 * 1000;
    const dateObj = new Date(excelEpoch.getTime() + utcDays * msPerDay);
    if (!isNaN(dateObj.getTime())) {
      const d = String(dateObj.getUTCDate()).padStart(2, '0');
      const m = String(dateObj.getUTCMonth() + 1).padStart(2, '0');
      const y = dateObj.getUTCFullYear();
      datePart = `${d}/${m}/${y}`;
    }
  } else {
    // 3. Format datePart to DD/MM/YYYY
    const dParts = datePart.split(/[-/.]/).filter(p => p.trim());
    if (dParts.length === 3) {
      let [p1, p2, p3] = dParts.map(p => p.trim());

      if (p1.length === 4) {
        // YYYY-MM-DD -> p1=YYYY, p2=MM, p3=DD
        const day = p3.padStart(2, '0');
        const month = p2.padStart(2, '0');
        const year = p1;
        datePart = `${day}/${month}/${year}`;
      } else if (p3.length === 4 || p3.length === 2) {
        // DD/MM/YYYY or DD/MM/YY -> p1=DD, p2=MM, p3=YYYY/YY
        let year = p3;
        if (year.length === 2) {
          year = (parseInt(year, 10) > 30 ? '19' : '20') + year;
        }
        const day = p1.padStart(2, '0');
        const month = p2.padStart(2, '0');
        datePart = `${day}/${month}/${year}`;
      }
    }
  }

  return timePart ? `${datePart} ${timePart}` : datePart;
}

let injurySearchQuery = '';

function showInjurySearchResults(query) {
  const resultsBox = document.getElementById('injury_search_results');
  if (!resultsBox) return;
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const q = (query || '').trim().toLowerCase();

  let matches = [];
  if (!q) {
    matches = employees.slice(0, 10);
  } else {
    matches = employees.filter(e => {
      const demo = e.demographic || {};
      const idNo = (e.idNo || demo.nationalId || '').toString().toLowerCase();
      const empNo = (e.empNo || e.id || demo.personNumber || '').toString().toLowerCase();
      const name = (e.name || demo.fullName || '').toString().toLowerCase();
      const arName = (demo.arabicFullName || '').toString().toLowerCase();
      const dept = (demo.orgName || e.organizationName || demo.organizationName || e.orgName || e.department || demo.deptTreating || '').toString().toLowerCase();
      const job = (e.jobTitle || demo.positionName || '').toString().toLowerCase();
      return idNo.includes(q) || empNo.includes(q) || name.includes(q) || arName.includes(q) || dept.includes(q) || job.includes(q);
    }).slice(0, 15);
  }

  if (matches.length === 0) {
    resultsBox.innerHTML = `
      <div style="padding: 14px 16px; color: #64748B; font-size: 0.9rem; text-align: center;">
        ${isAr ? '❌ لا توجد نتائج مطابقة لبحثك' : '❌ No matching staff members found'}
      </div>
    `;
    resultsBox.style.display = 'block';
    return;
  }

  resultsBox.innerHTML = `
    <div style="padding: 6px 12px; background: #F1F5F9; border-bottom: 1px solid #CBD5E1; font-size: 0.78rem; font-weight: bold; color: var(--primary-blue); display: flex; justify-content: space-between;">
      <span>⚡ ${isAr ? 'انقر على أي موظف لاختياره مباشرة:' : 'Click any staff member to select:'}</span>
      <span style="color: #64748B;">${matches.length} ${isAr ? 'نتائج' : 'results'}</span>
    </div>
  ` + matches.map(e => {
    const origIdx = employees.indexOf(e);
    const demo = e.demographic || {};
    const idStr = e.idNo || demo.nationalId || 'N/A';
    const empStr = e.empNo || e.id || demo.personNumber || 'N/A';
    const nameStr = e.name || demo.fullName || 'Staff Member';
    const deptStr = demo.orgName || e.organizationName || demo.organizationName || e.orgName || e.department || demo.deptTreating || 'Hospital Staff';
    const jobStr = e.jobTitle || demo.positionName || '';
    const isSel = origIdx === activeInjuryEmpIndex;

    return `
      <div style="padding: 10px 14px; border-bottom: 1px solid #E2E8F0; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: ${isSel ? '#F0FDFA' : '#FFFFFF'}; transition: background 0.15s;" 
           onmouseover="this.style.background='#F0F9FF'" 
           onmouseout="this.style.background='${isSel ? '#F0FDFA' : '#FFFFFF'}'"
           onclick="selectInjuryStaffFromSearch(${origIdx})">
        <div>
          <div style="font-weight: 700; font-size: 0.95rem; color: #0F172A;">
            ${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(nameStr) : nameStr}
            <span style="font-size: 0.8rem; font-weight: normal; color: #64748B; margin-left: 6px;">(${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(deptStr) : deptStr}${jobStr ? ' - ' + (typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(jobStr) : jobStr) : ''})</span>
          </div>
          <div style="font-size: 0.82rem; color: #0284C7; margin-top: 2px;">
            <strong style="color: #0D9488;">${isAr ? 'الرقم الوظيفي:' : 'Emp No:'}</strong> ${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(empStr) : empStr} | 
            <strong>${isAr ? 'الهوية:' : 'ID:'}</strong> ${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(idStr) : idStr}
          </div>
        </div>
        <span style="background: ${isSel ? '#0D9488' : '#E0F2FE'}; color: ${isSel ? '#FFFFFF' : '#0369A1'}; padding: 3px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: bold; white-space: nowrap;">
          ${isSel ? (isAr ? '✓ المختار' : '✓ Current') : (isAr ? 'اختيار' : 'Select')}
        </span>
      </div>
    `;
  }).join('');

  resultsBox.style.display = 'block';
}
window.showInjurySearchResults = showInjurySearchResults;

function handleInjuryHeaderSearch(query) {
  injurySearchQuery = query || '';
  showInjurySearchResults(query);
}
window.handleInjuryHeaderSearch = handleInjuryHeaderSearch;

function selectInjuryStaffFromDropdown(empNoOrId) {
  if (!empNoOrId) {
    clearInjurySearch();
    return;
  }
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const targetStr = String(empNoOrId).trim().toLowerCase();
  const targetClean = targetStr.replace(/^emp-/i, '').replace(/^0+/, '');
  const sIdx = employees.findIndex(e => {
    if (!e) return false;
    const demo = e.demographic || {};
    const eNo = String(e.empNo || e.id || demo.personNumber || '').trim().toLowerCase();
    const eCleanNo = eNo.replace(/^emp-/i, '').replace(/^0+/, '');
    const eId = String(e.idNo || demo.nationalId || '').trim().toLowerCase();
    const eCleanId = eId.replace(/^0+/, '');
    return eNo === targetStr || eCleanNo === targetClean || eId === targetStr || eCleanId === targetClean || String(e.empNo) === String(empNoOrId) || String(e.id) === String(empNoOrId);
  });
  if (sIdx !== -1) {
    selectInjuryStaffFromSearch(sIdx);
  }
}
window.selectInjuryStaffFromDropdown = selectInjuryStaffFromDropdown;

function selectInjuryStaffFromSearch(idx) {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  if (idx >= 0 && employees[idx]) {
    activeInjuryEmpIndex = idx;
    isManualBlankMode = false;
    activeInjurySerial = '';
    const e = employees[idx];
    injurySearchQuery = e.name || (e.demographic ? e.demographic.fullName : '');
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(e);
    }
  }
  const resultsBox = document.getElementById('injury_search_results');
  if (resultsBox) resultsBox.style.display = 'none';
  const container = document.getElementById('mainAppArea');
  if (container) renderInjuryReportForm(container);
}
window.selectInjuryStaffFromSearch = selectInjuryStaffFromSearch;

function handleInjurySearchKeyDown(event) {
  if (event.key === 'Escape') {
    const resultsBox = document.getElementById('injury_search_results');
    if (resultsBox) resultsBox.style.display = 'none';
  } else if (event.key === 'Enter') {
    event.preventDefault();
    const resultsBox = document.getElementById('injury_search_results');
    const firstOption = resultsBox ? resultsBox.querySelector('[onclick^="selectInjuryStaffFromSearch"]') : null;
    if (firstOption) {
      firstOption.click();
    }
  }
}
window.handleInjurySearchKeyDown = handleInjurySearchKeyDown;

function clearInjurySearch() {
  injurySearchQuery = '';
  activeInjuryEmpIndex = -1;
  activeInjurySerial = '';
  isManualBlankMode = true;
  if (typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(null);
  }
  const input = document.getElementById('injury_header_search_input');
  if (input) {
    input.value = '';
    input.focus();
  }
  const quickSelect = document.getElementById('injury_quick_select');
  if (quickSelect) {
    quickSelect.value = '';
  }
  const resultsBox = document.getElementById('injury_search_results');
  if (resultsBox) resultsBox.style.display = 'none';
  const container = document.getElementById('mainAppArea');
  if (container) renderInjuryReportForm(container);
}
window.clearInjurySearch = clearInjurySearch;

if (typeof document !== 'undefined') {
  document.addEventListener('click', function(e) {
    const box = document.getElementById('injury_search_results');
    const input = document.getElementById('injury_header_search_input');
    if (box && input && !box.contains(e.target) && e.target !== input) {
      box.style.display = 'none';
    }
  });
}

function selectInjuryStaff(idx, preserveSerial = false) {
  activeInjuryEmpIndex = parseInt(idx, 10);
  isManualBlankMode = false;
  if (!preserveSerial) {
    activeInjurySerial = '';
  }
  let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (activeInjuryEmpIndex >= 0 && employees[activeInjuryEmpIndex] && typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(employees[activeInjuryEmpIndex]);
  }
  const container = document.getElementById('mainAppArea');
  if (container) renderInjuryReportForm(container);
}
window.selectInjuryStaff = selectInjuryStaff;

function getInjurySelectDisplay(val, isBilingual = false) {
  if (!val) return '';
  const v = String(val).trim().toLowerCase();
  if (v.includes('pos')) return isBilingual ? 'Positive (إيجابي)' : 'Positive';
  if (v.includes('neg')) return isBilingual ? 'Negative (سلبي)' : 'Negative';
  if (v.includes('unk')) return isBilingual ? 'Unknown (غير معروف)' : 'Unknown';
  if (v === '-- select --' || v === '') return '';
  return val;
}
window.getInjurySelectDisplay = getInjurySelectDisplay;

function renderInjuryReportForm(container) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  if (!employees || employees.length === 0) {
    if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES) && AVH_MASTER_EXCEL_EMPLOYEES.length > 0) {
      employees = AVH_MASTER_EXCEL_EMPLOYEES;
    }
  }

  let selEmp = typeof window.getGlobalSelectedStaff === 'function' ? window.getGlobalSelectedStaff() : null;
  if (selEmp) {
    const sEmpNo = String(selEmp.empNo || selEmp.id || selEmp.demographic?.personNumber || selEmp.idNo || '').trim();
    if (sEmpNo) {
      const sIdx = employees.findIndex(e => String(e.empNo || e.id || e.demographic?.personNumber || e.idNo || '').trim() === sEmpNo);
      if (sIdx !== -1) {
        activeInjuryEmpIndex = sIdx;
      }
    }
  }

  const isBlankState = (isManualBlankMode || activeInjuryEmpIndex === -1 || activeInjuryEmpIndex >= employees.length);
  const selectedEmp = isBlankState ? null : (employees[activeInjuryEmpIndex] || null);

  const injuries = (typeof InjuryDataService !== 'undefined' && InjuryDataService._cache)
    ? InjuryDataService._cache
    : (JSON.parse(localStorage.getItem('avh_injuries')) || []);
  
  // Find report for selected staff member, or active serial, or empty if blank state
  let currentInj = {};
  if (activeInjurySerial && !isManualBlankMode && !isBlankState) {
    currentInj = injuries.find(i => {
      const p1 = i.part1 || {};
      const sId = (i.id || '').toString().toLowerCase();
      const sNo = (p1.serialNo || i.serialNo || '').toString().toLowerCase();
      const target = activeInjurySerial.toLowerCase();
      return sId === target || sNo === target;
    }) || {};
  }

  if ((!currentInj || !currentInj.id) && selectedEmp && !isManualBlankMode && !isBlankState) {
    const sEmpNo = (selectedEmp.empNo || selectedEmp.id || selectedEmp.demographic?.personNumber || '').toString();
    const sEmpName = (selectedEmp.name || selectedEmp.demographic?.fullName || '').toLowerCase();

    // Prefer most recent injury for this staff member
    const matching = injuries.filter(i => {
      const p1 = i.part1 || {};
      const iFile = (p1.fileNo || i.empNo || '').toString();
      const iName = (i.employeeName || p1.name || '').toLowerCase();
      return (sEmpNo && iFile && iFile === sEmpNo) || (sEmpName && iName && (iName.includes(sEmpName) || sEmpName.includes(iName)));
    });

    if (matching.length > 0) {
      currentInj = matching[0];
      activeInjurySerial = currentInj.id || currentInj.serialNo || currentInj.part1?.serialNo || '';
    }
  }

  if (isBlankState) {
    currentInj = {};
    activeInjurySerial = '';
  } else if (currentInj && (currentInj.id || currentInj.serialNo || currentInj.part1?.serialNo)) {
    activeInjurySerial = currentInj.id || currentInj.serialNo || currentInj.part1?.serialNo;
  }

  const p1 = currentInj.part1 || {};
  const p2 = currentInj.part2 || {};
  const p3 = currentInj.part3 || {};

  // Compute staff properties if selected, empty strings if blank state
  const demo = selectedEmp ? (selectedEmp.demographic || {}) : {};
  const empName = isBlankState ? '' : (p1.name || (selectedEmp ? (selectedEmp.name || demo.fullName || '') : currentInj.employeeName || ''));
  const empIdNo = isBlankState ? '' : ((selectedEmp ? (selectedEmp.idNo || demo.nationalId || '') : '') || p1.nationalId || '');
  const empNo = isBlankState ? '' : (p1.fileNo || (selectedEmp ? (selectedEmp.empNo || selectedEmp.id || demo.personNumber || '') : currentInj.empNo || ''));
  const empDept = isBlankState ? '' : (p1.department || (selectedEmp ? (demo.orgName || selectedEmp.organizationName || demo.organizationName || selectedEmp.orgName || selectedEmp.department || demo.deptTreating || '') : currentInj.department || ''));
  const empJob = isBlankState ? '' : (p1.position || (selectedEmp ? (selectedEmp.jobTitle || demo.positionName || '') : currentInj.jobTitle || ''));
  let empGenderRaw = (p1.gender || (selectedEmp ? (selectedEmp.gender || demo.gender || '') : '') || currentInj.gender || '').toString().trim().toUpperCase();
  let isMale = empGenderRaw.startsWith('M') || empGenderRaw.includes('MALE') || empGenderRaw.includes('ذكر');
  let isFemale = empGenderRaw.startsWith('F') || empGenderRaw.includes('FEMALE') || empGenderRaw.includes('أنثى') || empGenderRaw.includes('انثى');

  if (!isMale && !isFemale && selectedEmp) {
    const text = `${selectedEmp.name || ''} ${demo.fullName || ''} ${demo.arabicFullName || ''}`.toLowerCase();
    const femalePattern = /\b(hala|mays|maysaa|salma|fatima|fatmeh|may|rania|reem|rima|ruba|amani|amal|khuloud|sahar|dina|mona|nisreen|samar|suha|nour|yasmin|layla|laila|hanan|huda|heba|nadia|najwa|nibal|manal|majda|maha|lina|lema|ghada|fida|basma|eman|iman|amira|aida|intisar|insaf|khetam|taghreed|zeinab|zainab|zaina|maryam|mariam|noor|rawan|raghad|razan|shireen|shirin|shadia|sawsan|sirin|wafa|wafaa|yara|mervat|nadine|suhad|ola|ula|dalal|kholoud|souad|suad|sohad|huba|neda|nada|ruwaida|rula|subhiya|sumaya)\b/i;
    const femaleArPattern = /(هالة|ميس|سلمى|فاطمة|مريم|مي|رانية|رانيا|ريم|ريما|ربى|أماني|اماني|أمل|امل|خلود|سحر|دينا|منى|نسرين|سمر|سهى|نور|ياسمين|ليلى|حنان|هدى|هبة|نادية|نجوى|نبال|منال|ماجدة|مها|لينا|غادة|فداء|بسمة|إيمان|ايمان|أميرة|اميرة|عائدة|انتصار|إنصاف|ختام|تغريد|زينب|زينة|راوان|رغد|رزان|شرين|شيرين|شادية|سوسن|وفاء|يارا|ميرفت|نادين|سهاد|علا|دلال|سعاد|نداء|ندى|رويدة|رولا|صباح|سمية)/;

    if (femalePattern.test(text) || femaleArPattern.test(text)) {
      isFemale = true;
    } else {
      isMale = true;
    }
  }

  let empAge = '';
  if (selectedEmp) {
    empAge = p1.age || selectedEmp.age || demo.age || '';
    if (!empAge) {
      const rawDob = selectedEmp.dob || demo.dob || selectedEmp.dateOfBirth || demo.dateOfBirth || selectedEmp.birthDate || demo.birthDate || '';
      if (rawDob) {
        let birth = new Date(rawDob);
        if (isNaN(birth.getTime())) {
          const parts = String(rawDob).split(/[\/\-\.]/);
          if (parts.length === 3) {
            if (parts[0].length === 4) birth = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
            else if (parts[2].length === 4) birth = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
          }
        }
        if (!isNaN(birth.getTime())) {
          const now = new Date();
          let ageYears = now.getFullYear() - birth.getFullYear();
          const monthDiff = now.getMonth() - birth.getMonth();
          if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
            ageYears--;
          }
          if (ageYears > 0 && ageYears < 120) {
            empAge = ageYears.toString();
          }
        }
      }
    }
    if (!empAge && (empIdNo || demo.nationalId)) {
      const idStr = String(empIdNo || demo.nationalId).trim();
      const yearMatch = idStr.match(/\b(19\d{2}|20[01]\d)\b/);
      if (yearMatch) {
        const bYear = parseInt(yearMatch[1], 10);
        const ageEst = new Date().getFullYear() - bYear;
        if (ageEst > 18 && ageEst < 80) empAge = ageEst.toString();
      }
    }
  }
  if (!empAge && p1.age) {
    empAge = p1.age;
  }
  if (typeof formatAgeToOneDecimal === 'function' && empAge) {
    empAge = formatAgeToOneDecimal(empAge);
  }

  const rawDateTime = selectedEmp ? (p1.dateTime || (new Date().toISOString().slice(0, 10) + ' 10:30')) : '';
  const formattedDateTime = formatToDDMMYYYY(rawDateTime);

  const rawReportDateTime = selectedEmp ? (p1.reportDateTime || p1.reportingDate || (new Date().toISOString().slice(0, 10) + ' 11:00')) : '';
  const formattedReportDateTime = formatToDDMMYYYY(rawReportDateTime);

  let rawHbvBooster = '';
  if (selectedEmp) {
    const vacHepB = (selectedEmp.vaccines && selectedEmp.vaccines['Hepatitis B']) ? selectedEmp.vaccines['Hepatitis B'] : {};
    const hepBObj = selectedEmp.hepb || selectedEmp.hepB || {};
    const labRes = selectedEmp.labResults || {};
    const demo = selectedEmp.demographic || {};

    rawHbvBooster = p1.hbvBoosterDate 
                 || labRes.hbsabDate 
                 || labRes.hbsAbDate 
                 || labRes.hbvBoosterDate
                 || vacHepB.hbsabDate 
                 || vacHepB.hbsAbDate 
                 || hepBObj.hbsabDate 
                 || hepBObj.hbsAbDate 
                 || selectedEmp.hbsabDate 
                 || selectedEmp.hbsAbDate 
                 || selectedEmp.hbvBoosterDate 
                 || vacHepB.d4 
                 || vacHepB.booster 
                 || hepBObj.d4 
                 || selectedEmp.engrixBooster 
                 || demo.hbsabDate 
                 || demo.hbvBoosterDate 
                 || '';
  }
  const hbvBooster = formatToDDMMYYYY(rawHbvBooster);

  const srcHbsAgVal = p1.sourceLab?.hbsAg || '';
  const srcHcvVal = p1.sourceLab?.hcv || '';
  const srcHivVal = p1.sourceLab?.hiv || '';
  const srcOthersVal = p1.sourceLab?.others || '';

  const viralHbsAgVal = p3.injuredViralProfile?.hbsAg || '';
  const viralHcvVal = p3.injuredViralProfile?.hcv || '';
  const viralHivVal = p3.injuredViralProfile?.hiv || '';
  const viralAntiSVal = p3.injuredViralProfile?.antiS || '';

  const assessmentVal = p3.assessmentStatus || '';
  const vacActionVal = p3.vaccinationAction || '';
  const pepActionVal = p3.pepAction || '';
  const physiciansNotesVal = p3.physiciansNotes || (
    (p3.physiciansAction && !p3.physiciansAction.includes('Assessment:')) ? p3.physiciansAction : ''
  );

  const activeExpMatrix = p1.exposureMatrix || (
    p1.exposureType === 'Sharp Instrument' ? 'Contaminated - Sharp Instrument' :
    p1.exposureType === 'Others' ? 'Contaminated - Others' :
    'Contaminated - Needle Prick'
  );

  const inputStyle = `font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; vertical-align: middle; border: none; outline: none; background: transparent;`;
  const tdStyle = `border: 1px solid black; padding: 3px 6px; vertical-align: middle; font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold;`;

  container.innerHTML = `
    <!-- INJURY TAB SUB-MENU TOOLBAR -->
    <div class="sub-tabs-container no-print" style="margin-bottom: 20px; background: white; padding: 10px 16px; border-radius: 8px; border: 1px solid var(--border-color); box-shadow: var(--shadow-sm); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <button class="sub-tab-btn ${currentInjurySubTab === 'form' ? 'active' : ''}" onclick="switchInjurySubTab('form')" style="padding: 8px 16px; font-weight: bold; border-radius: 6px;">
          📋 ${isAr ? '1. نموذج الإصابة الفردي (SQE 02.01)' : '1. SQE 02.01 Individual Injury Report'}
        </button>
        <button class="sub-tab-btn ${currentInjurySubTab === 'periodic_log' ? 'active' : ''}" onclick="switchInjurySubTab('periodic_log')" style="padding: 8px 16px; font-weight: bold; border-radius: 6px; background: ${currentInjurySubTab === 'periodic_log' ? '#DC2626' : '#FEF2F2'}; color: ${currentInjurySubTab === 'periodic_log' ? 'white' : '#991B1B'}; border-color: #FCA5A5;">
          📊 ${isAr ? '2. سجل حوادث الإصابات الشامل حسب الفترة (Period Incidents Log)' : '2. All Incidents Log (By Period)'}
        </button>
      </div>
      <div style="font-size: 0.85rem; font-weight: bold; color: var(--primary-blue);">
        Augusta Victoria Hospital | Infection Control & Occupational Health Registry
      </div>
    </div>

    <!-- LIVE SEARCH BAR & RECORD CONTROLS (QUICK SEARCH OR SELECT FROM LIST) -->
    <div class="card no-print" style="border-left: 4px solid var(--accent-teal); margin-bottom: 20px; padding: 18px 22px; background: #FAFDFD;">
      <div style="display: flex; gap: 14px; align-items: flex-end; flex-wrap: wrap;">
        <div style="flex: 2; min-width: 280px; position: relative;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            🔍 ${isAr ? 'البحث السريع عن موظف (الاسم / الهوية / الرقم الوظيفي):' : 'Quick Search Staff (Name, ID, or Emp No):'}
          </label>
          <div class="search-flex-group" style="display: flex; gap: 8px;">
            <input type="text" id="injury_header_search_input" 
              placeholder="${isAr ? 'اكتب اسم الموظف أو الهوية أو الرقم الوظيفي...' : 'Type Name, ID, or Emp No...'}" 
              value="${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(injurySearchQuery || (empName ? (empName + (empIdNo ? ' (ID: ' + empIdNo + ')' : '')) : '')) : (injurySearchQuery || empName)}"
              onfocus="showInjurySearchResults(this.value)" 
              oninput="handleInjuryHeaderSearch(this.value)" 
              onkeydown="handleInjurySearchKeyDown(event)"
              autocomplete="off"
              style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.95rem; font-weight: 600; background: white;">
            <button type="button" class="btn btn-outline" style="padding: 8px 14px; font-weight: bold; background: white; white-space: nowrap; border-color: #94A3B8; color: #475569;" onclick="clearInjurySearch()">
              🧹 ${isAr ? 'تفريغ الشاشة' : 'Clear Form'}
            </button>
          </div>
          <!-- FLOATING LIVE SEARCH RESULTS DROPDOWN -->
          <div id="injury_search_results" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1.5px solid var(--accent-teal); border-radius: 6px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); z-index: 100; max-height: 280px; overflow-y: auto;"></div>
        </div>

        <div style="flex: 1.5; min-width: 240px;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            👤 ${isAr ? 'أو اختر موظفاً من القائمة مباشرة:' : 'Or Select Employee from List:'}
          </label>
          <select id="injury_quick_select" style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.92rem; font-weight: 600; background: white;" onchange="selectInjuryStaffFromDropdown(this.value)">
            ${typeof buildStaffQuickSelectOptionsHtml === 'function' ? buildStaffQuickSelectOptionsHtml(employees, isAr, selectedEmp ? (selectedEmp.empNo || selectedEmp.id) : null) : ''}
          </select>
        </div>
      </div>
    </div>

    <!-- MANDATORY EMPLOYEE HEADER CARD (HIDDEN IN PRINT) -->
    <div class="employee-header-card no-print" style="margin-bottom: 20px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 12px;">
        <div style="font-size: 0.88rem; text-transform: uppercase; font-weight: 800; color: #DC2626;">
          ⚠️ Augusta Victoria Hospital | Healthcare Worker Injury Record Header
        </div>
        ${!isBlankState ? `
          <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
            <span style="background: #ECFDF5; color: #065F46; border: 1px solid #10B981; padding: 4px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 700;">
              🟢 ${isAr ? 'تم تحميل بيانات الموظف المختار بنجاح' : 'Selected Staff Loaded'}
            </span>
            <button type="button" class="btn btn-outline" style="padding: 4px 12px; font-size: 0.8rem; font-weight: 700; color: #DC2626; border-color: #FCA5A5; background: #FEF2F2; cursor: pointer; border-radius: 6px;" onclick="clearInjurySearch()" title="${isAr ? 'إلغاء اختيار هذا الموظف لاختيار موظف آخر' : 'Deselect this staff member to choose another'}">
              ✕ ${isAr ? 'إلغاء الموظف / اختيار آخر' : 'Clear / Choose Other Staff'}
            </button>
          </div>
        ` : ''}
      </div>
      <div class="employee-header-grid">
        <div class="emp-field">
          <label>Employee Name / اسم الموظف</label>
          <input type="text" value="${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(empName) : empName}" readonly placeholder="${isBlankState ? (isAr ? 'يرجى البحث أو اختيار الموظف أعلاه...' : 'Select or search staff member above...') : ''}">
        </div>
        <div class="emp-field">
          <label>ID No. / رقم الهوية</label>
          <input type="text" value="${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(empIdNo) : empIdNo}" readonly style="font-weight: 800; color: #0284C7; background: #F0F9FF;">
        </div>
        <div class="emp-field">
          <label>Employment NO / الرقم الوظيفي</label>
          <input type="text" value="${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(empNo) : empNo}" readonly style="font-weight: 800; color: #0D9488; background: #F0FDF4;">
        </div>
        <div class="emp-field">
          <label>Department / القسم</label>
          <input type="text" value="${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(empDept) : empDept}" readonly>
        </div>
        <div class="emp-field">
          <label>Job Title / المسمى الوظيفي</label>
          <input type="text" value="${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(empJob) : empJob}" readonly>
        </div>
      </div>
    </div>

    <!-- ACTIVE INCIDENT STATUS & UPDATE MODE CONTROLS -->
    <div class="card no-print" style="margin-bottom: 16px; padding: 12px 18px; background: #F8FAFC; border: 1.5px solid #CBD5E1; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
      <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
        <span style="font-weight: 800; font-size: 0.95rem; color: #1E293B;">
          🔖 ${isAr ? 'رقم البلاغ المرجعي (Serial / Ref No):' : 'Incident Serial / Ref No:'}
        </span>
        <span id="inj_serial_badge" style="font-family: monospace; font-size: 1.1rem; font-weight: 800; color: #DC2626; background: #FEF2F2; padding: 4px 12px; border-radius: 6px; border: 1.5px solid #FCA5A5;">
          ${activeInjurySerial || (isAr ? 'جديد (سيتم تعيينه تلقائياً عند أول حفظ)' : 'NEW (Auto-assigned on first save)')}
        </span>
        <span id="inj_mode_indicator" style="background: ${activeInjurySerial ? '#EFF6FF' : '#F0FDF4'}; color: ${activeInjurySerial ? '#1D4ED8' : '#15803D'}; border: 1px solid ${activeInjurySerial ? '#93C5FD' : '#86EFAC'}; padding: 3px 10px; border-radius: 20px; font-size: 0.82rem; font-weight: 800;">
          ${activeInjurySerial ? (isAr ? '🔄 وضع تحديث النموذج (يحدّث التقرير الحالي بدون رقم جديد)' : '🔄 UPDATE MODE (Updates this report without new serial)') : (isAr ? '➕ تسجيل بلاغ جديد' : '➕ NEW INCIDENT RECORD')}
        </span>
      </div>
      <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
        <button type="button" class="btn btn-outline" style="padding: 6px 14px; font-size: 0.85rem; font-weight: 800; border-color: #94A3B8; color: #334155; background: white;" onclick="clearInjuryFormForManualEntry()" title="${isAr ? 'تفريغ النموذج لإدخال يدوي جديد أو اختيار موظف آخر' : 'Clear all fields for manual fill or choose other staff'}">
          📄 📝 ${isAr ? 'نموذج فارغ (تعبئة يدوية)' : 'Blank Form (Manual Fill)'}
        </button>
        ${(selectedEmp && activeInjurySerial) ? `
          <button type="button" class="btn btn-outline" style="padding: 6px 12px; font-size: 0.85rem; font-weight: 800; border-color: #0284C7; color: #0284C7; background: white;" onclick="createNewIncidentForStaff()" title="${isAr ? 'تسجيل حادثة جديدة لنفس الموظف برقم جديد' : 'Record a new incident for this staff member with a new serial'}">
            ➕ ${isAr ? 'تسجيل حادثة جديدة لهذا الموظف' : 'New Incident for this Staff'}
          </button>
        ` : ''}
        <button type="button" class="btn btn-success" style="padding: 6px 16px; font-size: 0.88rem; font-weight: 800; background: #16A34A; border-color: #16A34A;" onclick="saveInjuryReport()">
          💾 ${activeInjurySerial ? (isAr ? 'حفظ التعديلات على نفس التقرير' : 'Update This Report') : (isAr ? 'حفظ التقرير' : 'Save Report')}
        </button>
      </div>
    </div>
    <input type="hidden" id="inj_current_serial" value="${activeInjurySerial}">

    <!-- INJURY REPORT PRINT CONTAINER -->
    <div style="background: white; padding: 12px 18px; font-family: 'Times New Roman', Times, serif; color: black; border: 1px solid black;" id="injuryPrintArea">
      <!-- OFFICIAL HEADER (LOGO CENTERED AT MIDDLE) -->
      <div class="official-doc-header" style="text-align: center; border-bottom: 1.5px solid black; padding-bottom: 4px; margin-bottom: 6px;">
        <div class="official-doc-logo" style="display: flex; justify-content: center; align-items: center; margin: 0 auto; text-align: center; width: 100%;">
          ${typeof getAVHLogoHTML === 'function' ? getAVHLogoHTML(60) : `<img class="avh-logo-img" src="assets/avh_logo.png" alt="Augusta Victoria Hospital" style="height: 55px; width: auto; margin: 0 auto; display: block;" />`}
        </div>
      </div>

      <!-- BELOW LINE: DOCUMENT TITLE & SERIAL NUMBER -->
      <table style="width: 100%; border-collapse: collapse; border: none; margin-top: 2px; margin-bottom: 8px; font-family: 'Times New Roman', Times, serif;">
        <tbody>
          <tr>
            <td style="width: 25%; border: none; padding: 0;"></td>
            <td style="width: 50%; border: none; text-align: center; padding: 0;">
              <div class="official-doc-title-main" style="font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; text-align: center; color: #000000; margin: 0; line-height: 1.25;">Injury Report for Health Care Worker</div>
              <div class="official-doc-subtitle" style="font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; text-align: center; color: #000000; margin: 0; line-height: 1.25;">Involving Blood and Body Fluid</div>
            </td>
            <td style="width: 25%; border: none; text-align: right; vertical-align: top; padding: 0;">
              <div style="font-size: 9.5pt; font-weight: bold; color: black; line-height: 1.2;">Serial / Ref No:</div>
              <div style="font-size: 11pt; font-weight: bold; font-family: monospace; color: black;" id="inj_print_serial_text">${activeInjurySerial || 'INC-2026-PENDING'}</div>
            </td>
          </tr>
        </tbody>
      </table>

      <!-- PART I -->
      <div style="margin-bottom: 8px;">
        <div class="official-part-title" style="font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; margin-bottom: 3px;">Part I: To be filled by the injured except the italics</div>
        
        <table class="injury-table" style="width: 100%; border-collapse: collapse; border: 1.5px solid black; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; margin-bottom: 6px;">
          <tbody>
            <tr>
              <td style="${tdStyle} width: 40%;">Name: <input type="text" id="inj_name" value="${empName}" placeholder="${isAr ? 'اسم الموظف...' : 'Full Name...'}" style="${inputStyle} width: 75%;"></td>
              <td style="${tdStyle} width: 30%;">Age: <input type="text" id="inj_age" value="${empAge}" placeholder="${isAr ? 'العمر...' : 'Age...'}" style="${inputStyle} width: 60%;"></td>
              <td style="${tdStyle} width: 30%;">
                Gender &nbsp; 
                <label style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; cursor: pointer; display: inline-flex; align-items: center; gap: 3px;">
                  <input type="radio" id="inj_gender_m" name="g" value="M" ${isMale ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;"> M
                  <span class="print-only print-radio-indicator" id="inj_gender_m_print">${isMale ? '●' : '○'}</span>
                </label> 
                &nbsp; 
                <label style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; cursor: pointer; display: inline-flex; align-items: center; gap: 3px;">
                  <input type="radio" id="inj_gender_f" name="g" value="F" ${isFemale ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;"> F
                  <span class="print-only print-radio-indicator" id="inj_gender_f_print">${isFemale ? '●' : '○'}</span>
                </label>
              </td>
            </tr>
            <tr>
              <td style="${tdStyle}">Department: <input type="text" id="inj_dept" value="${empDept}" placeholder="${isAr ? 'القسم / اسم المؤسسة...' : 'Department / Organization Name...'}" style="${inputStyle} width: 65%;"></td>
              <td colspan="2" style="${tdStyle}">Position: <input type="text" id="inj_position" value="${empJob}" placeholder="${isAr ? 'المسمى الوظيفي...' : 'Position / Job Title...'}" style="${inputStyle} width: 75%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle} width: 34%;">Medical Record No: <input type="text" id="inj_fileNo" value="${p1.fileNo || ''}" placeholder="${isAr ? 'تعبئة يدوية...' : 'Manual fill...'}" style="${inputStyle} width: 52%;"></td>
              <td style="${tdStyle} width: 33%;">Date & time of Injury: <input type="text" id="inj_dateTime" value="${formattedDateTime}" style="${inputStyle} width: 45%;" placeholder="DD/MM/YYYY HH:MM" title="Editable Date & Time of Injury"></td>
              <td style="${tdStyle} width: 33%;">Date & time of Reporting: <input type="text" id="inj_reportDateTime" value="${formattedReportDateTime}" style="${inputStyle} width: 42%;" placeholder="DD/MM/YYYY HH:MM" title="Editable Date & Time of Reporting"></td>
            </tr>
            <tr>
              <td colspan="3" style="${tdStyle}">
                Date of last booster dose of HBV vaccine: <input type="text" id="inj_hbvBoosterDate" value="${hbvBooster}" placeholder="${isAr ? 'تاريخ الجرعة المعززة DD/MM/YYYY...' : 'DD/MM/YYYY'}" style="${inputStyle} width: 50%;">
              </td>
            </tr>
            <tr>
              <td colspan="3" style="${tdStyle}">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                  <span>Description of the Incident:</span>
                  <button type="button" class="no-print" style="padding: 1px 6px; font-size: 0.75rem; background: #F1F5F9; border: 1px solid #CBD5E1; border-radius: 4px; cursor: pointer; color: #475569; font-weight: bold;" onclick="document.getElementById('inj_description').value = '';">🧹 Clear Text / تفريغ النص</button>
                </div>
                <textarea id="inj_description" placeholder="${isAr ? 'اكتب تفاصيل الحادثة وكيفية وقوع الإصابة هنا...' : 'Type or edit description of the incident here (or click Clear to start blank)...'}" style="width: 100%; min-height: 38px; height: 38px; border: 1px dashed #94A3B8; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; resize: vertical; margin-top: 2px; padding: 4px; background: #FFFDF5;">${p1.description || ''}</textarea>
                <div style="font-size: 0.78rem; font-style: italic; font-weight: normal; text-align: right;">(If more space is needed, attach additional sheet)</div>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- EXPOSURE TYPE MATRIX TABLE -->
        <table class="injury-table" style="width: 100%; border-collapse: collapse; border: 1.5px solid black; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; margin-bottom: 6px;">
          <thead>
            <tr>
              <th style="${tdStyle} width: 25%;"></th>
              <th style="${tdStyle} text-align: center;">Needle Prick</th>
              <th style="${tdStyle} text-align: center;">Sharp Instrument</th>
              <th style="${tdStyle} text-align: center;">Others (specify)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="${tdStyle}">Contaminated</td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_c_needle" value="Contaminated - Needle Prick" ${activeExpMatrix === 'Contaminated - Needle Prick' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_c_needle_print">${activeExpMatrix === 'Contaminated - Needle Prick' ? '●' : '○'}</span>
                </label>
              </td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_c_sharp" value="Contaminated - Sharp Instrument" ${activeExpMatrix === 'Contaminated - Sharp Instrument' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_c_sharp_print">${activeExpMatrix === 'Contaminated - Sharp Instrument' ? '●' : '○'}</span>
                </label>
              </td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_c_other" value="Contaminated - Others" ${activeExpMatrix === 'Contaminated - Others' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_c_other_print">${activeExpMatrix === 'Contaminated - Others' ? '●' : '○'}</span>
                </label>
              </td>
            </tr>
            <tr>
              <td style="${tdStyle}">Clean</td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_cl_needle" value="Clean - Needle Prick" ${activeExpMatrix === 'Clean - Needle Prick' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_cl_needle_print">${activeExpMatrix === 'Clean - Needle Prick' ? '●' : '○'}</span>
                </label>
              </td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_cl_sharp" value="Clean - Sharp Instrument" ${activeExpMatrix === 'Clean - Sharp Instrument' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_cl_sharp_print">${activeExpMatrix === 'Clean - Sharp Instrument' ? '●' : '○'}</span>
                </label>
              </td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_cl_other" value="Clean - Others" ${activeExpMatrix === 'Clean - Others' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_cl_other_print">${activeExpMatrix === 'Clean - Others' ? '●' : '○'}</span>
                </label>
              </td>
            </tr>
            <tr>
              <td style="${tdStyle}">Unknown</td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_u_needle" value="Unknown - Needle Prick" ${activeExpMatrix === 'Unknown - Needle Prick' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_u_needle_print">${activeExpMatrix === 'Unknown - Needle Prick' ? '●' : '○'}</span>
                </label>
              </td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_u_sharp" value="Unknown - Sharp Instrument" ${activeExpMatrix === 'Unknown - Sharp Instrument' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_u_sharp_print">${activeExpMatrix === 'Unknown - Sharp Instrument' ? '●' : '○'}</span>
                </label>
              </td>
              <td style="${tdStyle} text-align: center;">
                <label style="cursor: pointer; display: inline-flex; align-items: center; justify-content: center; width: 100%; margin: 0;">
                  <input type="radio" name="matrix_exposure_type" id="inj_mat_u_other" value="Unknown - Others" ${activeExpMatrix === 'Unknown - Others' ? 'checked' : ''} onchange="updateInjuryPrintState()" style="cursor: pointer;">
                  <span class="print-only print-radio-indicator" id="inj_mat_u_other_print">${activeExpMatrix === 'Unknown - Others' ? '●' : '○'}</span>
                </label>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- SOURCE OF CONTAMINATION TABLE -->
        <table class="injury-table" style="width: 100%; border-collapse: collapse; border: 1.5px solid black; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold;">
          <thead>
            <tr>
              <th style="${tdStyle} width: 35%;">Source of Contamination</th>
              <th style="${tdStyle} width: 35%;">Patient</th>
              <th style="${tdStyle}">Others</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="${tdStyle}">Name</td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_patient_name" value="${p1.sourcePatientName || ''}" style="${inputStyle} width: 100%;"></td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_other_name" style="${inputStyle} width: 100%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle}">File Number</td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_file_no" value="${p1.sourceFileNo || ''}" style="${inputStyle} width: 100%;"></td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_other_file_no" style="${inputStyle} width: 100%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle} font-style: italic;">HBsAg (42) (filled by the lab)</td>
              <td style="${tdStyle} padding: 1px 4px;">
                <select id="inj_src_hbsag" style="${inputStyle} width: 100%; cursor: pointer;" onchange="updateInjuryPrintState()">
                  <option value="" ${!srcHbsAgVal ? 'selected' : ''}>-- Select --</option>
                  <option value="Negative" ${srcHbsAgVal.toLowerCase().includes('neg') ? 'selected' : ''}>Negative (سلبي)</option>
                  <option value="Positive" ${srcHbsAgVal.toLowerCase().includes('pos') ? 'selected' : ''}>Positive (إيجابي)</option>
                  <option value="Unknown" ${srcHbsAgVal.toLowerCase().includes('unk') ? 'selected' : ''}>Unknown (غير معروف)</option>
                </select>
                <span class="print-only print-select-text" id="inj_src_hbsag_print">${getInjurySelectDisplay(srcHbsAgVal, true)}</span>
              </td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_hbsag_other" style="${inputStyle} width: 100%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle} font-style: italic;">HCV (41) (filled by the lab)</td>
              <td style="${tdStyle} padding: 1px 4px;">
                <select id="inj_src_hcv" style="${inputStyle} width: 100%; cursor: pointer;" onchange="updateInjuryPrintState()">
                  <option value="" ${!srcHcvVal ? 'selected' : ''}>-- Select --</option>
                  <option value="Negative" ${srcHcvVal.toLowerCase().includes('neg') ? 'selected' : ''}>Negative (سلبي)</option>
                  <option value="Positive" ${srcHcvVal.toLowerCase().includes('pos') ? 'selected' : ''}>Positive (إيجابي)</option>
                  <option value="Unknown" ${srcHcvVal.toLowerCase().includes('unk') ? 'selected' : ''}>Unknown (غير معروف)</option>
                </select>
                <span class="print-only print-select-text" id="inj_src_hcv_print">${getInjurySelectDisplay(srcHcvVal, true)}</span>
              </td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_hcv_other" style="${inputStyle} width: 100%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle} font-style: italic;">HIV (39) (filled by the lab)</td>
              <td style="${tdStyle} padding: 1px 4px;">
                <select id="inj_src_hiv" style="${inputStyle} width: 100%; cursor: pointer;" onchange="updateInjuryPrintState()">
                  <option value="" ${!srcHivVal ? 'selected' : ''}>-- Select --</option>
                  <option value="Negative" ${srcHivVal.toLowerCase().includes('neg') ? 'selected' : ''}>Negative (سلبي)</option>
                  <option value="Positive" ${srcHivVal.toLowerCase().includes('pos') ? 'selected' : ''}>Positive (إيجابي)</option>
                  <option value="Unknown" ${srcHivVal.toLowerCase().includes('unk') ? 'selected' : ''}>Unknown (غير معروف)</option>
                </select>
                <span class="print-only print-select-text" id="inj_src_hiv_print">${getInjurySelectDisplay(srcHivVal, true)}</span>
              </td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_hiv_other" style="${inputStyle} width: 100%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle} font-style: italic;">Others</td>
              <td style="${tdStyle} padding: 1px 4px;">
                <select id="inj_src_others" style="${inputStyle} width: 100%; cursor: pointer;" onchange="updateInjuryPrintState()">
                  <option value="" ${!srcOthersVal ? 'selected' : ''}>-- Select --</option>
                  <option value="Negative" ${srcOthersVal.toLowerCase().includes('neg') ? 'selected' : ''}>Negative (سلبي)</option>
                  <option value="Positive" ${srcOthersVal.toLowerCase().includes('pos') ? 'selected' : ''}>Positive (إيجابي)</option>
                  <option value="Unknown" ${srcOthersVal.toLowerCase().includes('unk') ? 'selected' : ''}>Unknown (غير معروف)</option>
                </select>
                <span class="print-only print-select-text" id="inj_src_others_print">${getInjurySelectDisplay(srcOthersVal, true)}</span>
              </td>
              <td style="${tdStyle} padding: 1px 4px;"><input type="text" id="inj_src_others_other" style="${inputStyle} width: 100%;"></td>
            </tr>
          </tbody>
        </table>
        <div style="font-size: 0.78rem; font-style: italic; font-weight: normal; text-align: right; margin-top: 2px;">(If more space is needed, attach additional sheet)</div>
      </div>

      <!-- PART II -->
      <div style="margin-bottom: 8px;">
        <div class="official-part-title" style="font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; margin-bottom: 3px;">Part II: To be filled by person the in-charge:</div>
        <table class="injury-table" style="width: 100%; border-collapse: collapse; border: 1.5px solid black; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold;">
          <tbody>
            <tr>
              <td style="${tdStyle} width: 50%;">Name: <input type="text" id="inj_incharge_name" value="${p2.inChargeName || ''}" style="${inputStyle} width: 75%;"></td>
              <td style="${tdStyle}">Position: <input type="text" id="inj_incharge_position" value="${p2.position || ''}" style="${inputStyle} width: 70%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle}">Date: <input type="text" id="inj_incharge_date" value="${formatToDDMMYYYY(p2.date || '')}" style="${inputStyle} width: 75%;"></td>
              <td style="${tdStyle}">Time reported: <input type="text" id="inj_incharge_time" value="${p2.timeReported || ''}" style="${inputStyle} width: 60%;"></td>
            </tr>
            <tr>
              <td style="${tdStyle}">Place of incident: <input type="text" id="inj_incharge_place" value="${p2.place || ''}" style="${inputStyle} width: 60%;"></td>
              <td style="${tdStyle}">Signature: <input type="text" id="inj_incharge_sig" value="${p2.signature || ''}" style="${inputStyle} width: 70%;"></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- ROUTING BANNER -->
      <div class="routing-banner" style="font-size: 1rem; font-family: 'Times New Roman', Times, serif; font-weight: bold; text-align: center; margin: 8px 0; text-decoration: underline;">
        Provide This Form to the Laboratory after Filling Part I and II
      </div>

      <!-- PART III -->
      <div style="margin-bottom: 6px;">
        <div class="official-part-title" style="font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; margin-bottom: 3px;">Part III: To be filled by the Laboratory:</div>
        
        <table class="injury-table" style="width: 100%; border-collapse: collapse; border: 1.5px solid black; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; margin-bottom: 6px;">
          <thead>
            <tr>
              <th style="${tdStyle} text-align: left;" colspan="2">Injured viral profile status</th>
              <th style="${tdStyle} text-align: left;" colspan="2">Request number: <input type="text" id="inj_lab_req_no" value="${p3.requestNo || ''}" style="${inputStyle} width: 140px;"></th>
            </tr>
            <tr>
              <th style="${tdStyle} font-weight: normal;">HBsAg: (TST0042)</th>
              <th style="${tdStyle} font-weight: normal;">HCV: (TST0041)</th>
              <th style="${tdStyle} font-weight: normal;">HIV: (TST0039)</th>
              <th style="${tdStyle} font-weight: normal;">Anti-S: (TST0040)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="${tdStyle} padding: 2px;">
                <select id="inj_viral_hbsag" style="${inputStyle} width: 100%; cursor: pointer;" onchange="updateInjuryPrintState()">
                  <option value="" ${!viralHbsAgVal ? 'selected' : ''}>-- Select --</option>
                  <option value="Negative" ${viralHbsAgVal.toLowerCase().includes('neg') ? 'selected' : ''}>Negative</option>
                  <option value="Positive" ${viralHbsAgVal.toLowerCase().includes('pos') ? 'selected' : ''}>Positive</option>
                  <option value="Unknown" ${viralHbsAgVal.toLowerCase().includes('unk') ? 'selected' : ''}>Unknown</option>
                </select>
                <span class="print-only print-select-text" id="inj_viral_hbsag_print">${getInjurySelectDisplay(viralHbsAgVal, false)}</span>
              </td>
              <td style="${tdStyle} padding: 2px;">
                <select id="inj_viral_hcv" style="${inputStyle} width: 100%; cursor: pointer;" onchange="updateInjuryPrintState()">
                  <option value="" ${!viralHcvVal ? 'selected' : ''}>-- Select --</option>
                  <option value="Negative" ${viralHcvVal.toLowerCase().includes('neg') ? 'selected' : ''}>Negative</option>
                  <option value="Positive" ${viralHcvVal.toLowerCase().includes('pos') ? 'selected' : ''}>Positive</option>
                  <option value="Unknown" ${viralHcvVal.toLowerCase().includes('unk') ? 'selected' : ''}>Unknown</option>
                </select>
                <span class="print-only print-select-text" id="inj_viral_hcv_print">${getInjurySelectDisplay(viralHcvVal, false)}</span>
              </td>
              <td style="${tdStyle} padding: 2px;">
                <select id="inj_viral_hiv" style="${inputStyle} width: 100%; cursor: pointer;" onchange="updateInjuryPrintState()">
                  <option value="" ${!viralHivVal ? 'selected' : ''}>-- Select --</option>
                  <option value="Negative" ${viralHivVal.toLowerCase().includes('neg') ? 'selected' : ''}>Negative</option>
                  <option value="Positive" ${viralHivVal.toLowerCase().includes('pos') ? 'selected' : ''}>Positive</option>
                  <option value="Unknown" ${viralHivVal.toLowerCase().includes('unk') ? 'selected' : ''}>Unknown</option>
                </select>
                <span class="print-only print-select-text" id="inj_viral_hiv_print">${getInjurySelectDisplay(viralHivVal, false)}</span>
              </td>
              <td style="${tdStyle} padding: 2px;"><input type="text" id="inj_viral_antis" value="${viralAntiSVal}" style="${inputStyle} width: 100%;"></td>
            </tr>
            <tr>
              <td colspan="4" style="${tdStyle} padding: 4px 6px;">
                <div style="font-size: 10pt; font-weight: bold; margin-bottom: 3px; color: #000000;">Physicians Action:</div>
                
                <table style="width: 100%; border-collapse: collapse; border: 1px solid black; margin-bottom: 4px;">
                  <tbody>
                    <tr>
                      <!-- Assessment Status -->
                      <td style="width: 33.3%; border: 1px solid black; padding: 2px 5px; vertical-align: top; background: white;">
                        <div style="font-size: 8.8pt; font-weight: bold; margin-bottom: 2px; color: black;">Assessment Status:</div>
                        <select id="inj_action_assessment" class="no-print" style="${inputStyle} width: 100%; border: 1px solid #94A3B8; border-radius: 3px; padding: 1px 3px; font-size: 8.8pt; cursor: pointer; background: white;" onchange="updateInjuryPrintState()">
                          <option value="" ${!assessmentVal ? 'selected' : ''}>-- Select --</option>
                          <option value="Assessment in Progress" ${assessmentVal === 'Assessment in Progress' ? 'selected' : ''}>Assessment in Progress</option>
                          <option value="Awaiting Test Results" ${assessmentVal === 'Awaiting Test Results' ? 'selected' : ''}>Awaiting Test Results</option>
                          <option value="Follow-up Required" ${assessmentVal === 'Follow-up Required' ? 'selected' : ''}>Follow-up Required</option>
                          <option value="Assessment Completed" ${assessmentVal === 'Assessment Completed' ? 'selected' : ''}>Assessment Completed</option>
                        </select>
                        <div class="print-only print-select-text" id="inj_action_assessment_print" style="font-size: 9pt; font-weight: bold; color: black; min-height: 12pt;">${assessmentVal || ''}</div>
                      </td>

                      <!-- Vaccination -->
                      <td style="width: 33.3%; border: 1px solid black; padding: 2px 5px; vertical-align: top; background: white;">
                        <div style="font-size: 8.8pt; font-weight: bold; margin-bottom: 2px; color: black;">Vaccination:</div>
                        <select id="inj_action_vaccination" class="no-print" style="${inputStyle} width: 100%; border: 1px solid #94A3B8; border-radius: 3px; padding: 1px 3px; font-size: 8.8pt; cursor: pointer; background: white;" onchange="updateInjuryPrintState()">
                          <option value="" ${!vacActionVal ? 'selected' : ''}>-- Select --</option>
                          <option value="Not Required" ${vacActionVal === 'Not Required' ? 'selected' : ''}>Not Required</option>
                          <option value="Required — Not Started" ${vacActionVal === 'Required — Not Started' ? 'selected' : ''}>Required — Not Started</option>
                          <option value="Started — More Doses Needed" ${vacActionVal === 'Started — More Doses Needed' ? 'selected' : ''}>Started — More Doses Needed</option>
                          <option value="All Doses Completed" ${vacActionVal === 'All Doses Completed' ? 'selected' : ''}>All Doses Completed</option>
                          <option value="Declined by Worker" ${vacActionVal === 'Declined by Worker' ? 'selected' : ''}>Declined by Worker</option>
                        </select>
                        <div class="print-only print-select-text" id="inj_action_vaccination_print" style="font-size: 9pt; font-weight: bold; color: black; min-height: 12pt;">${vacActionVal || ''}</div>
                      </td>

                      <!-- PEP (Post-Exposure Prophylaxis) -->
                      <td style="width: 33.4%; border: 1px solid black; padding: 2px 5px; vertical-align: top; background: white;">
                        <div style="font-size: 8.8pt; font-weight: bold; margin-bottom: 2px; color: black;">PEP (Post-Exposure Prophylaxis):</div>
                        <select id="inj_action_pep" class="no-print" style="${inputStyle} width: 100%; border: 1px solid #94A3B8; border-radius: 3px; padding: 1px 3px; font-size: 8.8pt; cursor: pointer; background: white;" onchange="updateInjuryPrintState()">
                          <option value="" ${!pepActionVal ? 'selected' : ''}>-- Select --</option>
                          <option value="Not Required" ${pepActionVal === 'Not Required' ? 'selected' : ''}>Not Required</option>
                          <option value="Required — Not Started" ${pepActionVal === 'Required — Not Started' ? 'selected' : ''}>Required — Not Started</option>
                          <option value="Treatment Started" ${pepActionVal === 'Treatment Started' ? 'selected' : ''}>Treatment Started</option>
                          <option value="Treatment Completed" ${pepActionVal === 'Treatment Completed' ? 'selected' : ''}>Treatment Completed</option>
                          <option value="Declined by Worker" ${pepActionVal === 'Declined by Worker' ? 'selected' : ''}>Declined by Worker</option>
                        </select>
                        <div class="print-only print-select-text" id="inj_action_pep_print" style="font-size: 9pt; font-weight: bold; color: black; min-height: 12pt;">${pepActionVal || ''}</div>
                      </td>
                    </tr>
                  </tbody>
                </table>

                <!-- Below note blank -->
                <div style="margin-top: 2px;">
                  <span style="font-size: 9pt; font-weight: bold; color: black;">Note:</span>
                  <textarea id="inj_physicians_notes" placeholder="${isAr ? 'ملاحظات الطبيب وتوصيات المتابعة السريرية...' : 'Physician notes, clinical recommendations, or follow-up instructions...'}" style="width: 100%; height: 24px; min-height: 22px; border: 1px dashed #94A3B8; outline: none; font-family: 'Times New Roman', Times, serif; font-size: 9.5pt; font-weight: bold; resize: vertical; padding: 2px 4px; background: #FFFFFF; vertical-align: middle; margin-top: 1px;">${physiciansNotesVal || ''}</textarea>
                </div>
              </td>
            </tr>
            <tr>
              <td style="${tdStyle}">Date: <input type="text" id="inj_lab_date" value="${formatToDDMMYYYY(p3.date || '')}" style="${inputStyle} width: 60%;"></td>
              <td style="${tdStyle}">Time: <input type="text" id="inj_lab_time" value="${p3.time || ''}" style="${inputStyle} width: 60%;"></td>
              <td colspan="2" style="${tdStyle}">Signature: <input type="text" id="inj_lab_sig" value="${p3.signature || ''}" style="${inputStyle} width: 70%;"></td>
            </tr>
          </tbody>
        </table>

        <div class="cc-block" style="font-size: 9.5pt; font-family: 'Times New Roman', Times, serif; font-weight: bold; line-height: 1.2;">
          Cc:<br>
          ICC<br>
          HR File
        </div>
      </div>

      <!-- BRANDED FOOTER IMAGE -->
      <div style="margin-top: 10px; width: 100%; text-align: center;">
        <img class="footer-branded-img" src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; max-height: 48px; object-fit: contain; display: block; margin: 0 auto;" />
      </div>

      <!-- ACTION BUTTONS BELOW -->
      <div style="display: flex; gap: 16px; justify-content: flex-end; align-items: center; margin-top: 20px; padding-top: 14px; border-top: 1px dashed #CBD5E1;" class="no-print">
        <button class="btn btn-outline" style="background: #F1F5F9; border-color: #94A3B8; color: #334155; font-weight: bold;" onclick="clearInjuryFormForManualEntry()">
          📝 ${isAr ? 'نموذج فارغ (تعبئة يدوي)' : '📝 Blank Form (Manual Fill)'}
        </button>
        <button class="btn btn-outline" onclick="printSharpsInjuryReport()">🖨️ Print SQE 02.01 Form</button>
        <button class="btn btn-success" onclick="saveInjuryReport()">💾 ${activeInjurySerial ? (isAr ? 'حفظ التعديلات على نفس التقرير' : 'Update This Report') : (isAr ? 'حفظ التقرير' : 'Save Report')}</button>
      </div>
    </div>
  `;
}

async function saveInjuryReport() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const injuries = (typeof InjuryDataService !== 'undefined' && InjuryDataService._cache)
    ? InjuryDataService._cache
    : (JSON.parse(localStorage.getItem('avh_injuries')) || []);
  
  const empName = document.getElementById('inj_name')?.value || 'Staff Member';
  const empAge = document.getElementById('inj_age')?.value || '';
  const empDept = document.getElementById('inj_dept')?.value || '';
  const empPosition = document.getElementById('inj_position')?.value || '';
  const empFileNo = document.getElementById('inj_fileNo')?.value || '';
  const dateTime = document.getElementById('inj_dateTime')?.value || formatToDDMMYYYY(new Date().toLocaleDateString());
  const reportDateTime = document.getElementById('inj_reportDateTime')?.value || formatToDDMMYYYY(new Date().toLocaleDateString());
  const hbvBooster = document.getElementById('inj_hbvBoosterDate')?.value || '';
  const description = document.getElementById('inj_description')?.value || '';

  // Check if updating an existing report in-place without generating a new serial
  const existingSerial = (document.getElementById('inj_current_serial')?.value || activeInjurySerial || '').trim();
  let isUpdatingExisting = false;
  let serialNo = '';

  if (existingSerial && existingSerial !== 'NEW' && !existingSerial.includes('PENDING')) {
    serialNo = existingSerial;
    isUpdatingExisting = true;
  } else {
    const cleanFileNo = String(empFileNo || '001').replace(/[^0-9]/g, '') || '001';
    const currentYear = new Date().getFullYear();
    const existingWithPrefix = injuries.filter(i => {
      const s = String(i.id || i.serialNo || i.part1?.serialNo || '');
      return s.startsWith(`INC-${currentYear}-${cleanFileNo}-`);
    });
    const nextSeq = existingWithPrefix.length + 1;
    serialNo = `INC-${currentYear}-${cleanFileNo}-${String(nextSeq).padStart(2, '0')}`;
  }

  const isFemaleChecked = document.getElementById('inj_gender_f')?.checked;
  const isMaleChecked = document.getElementById('inj_gender_m')?.checked;
  const genderCode = isFemaleChecked ? 'F' : (isMaleChecked ? 'M' : 'M');

  const srcHbsAg = document.getElementById('inj_src_hbsag')?.value || '';
  const srcHcv = document.getElementById('inj_src_hcv')?.value || '';
  const srcHiv = document.getElementById('inj_src_hiv')?.value || '';
  const srcOthers = document.getElementById('inj_src_others')?.value || '';
  const srcPatientName = document.getElementById('inj_src_patient_name')?.value || '';
  const srcFileNo = document.getElementById('inj_src_file_no')?.value || '';
  const srcOtherName = document.getElementById('inj_src_other_name')?.value || '';
  const srcOtherFileNo = document.getElementById('inj_src_other_file_no')?.value || '';

  const viralHbsAg = document.getElementById('inj_viral_hbsag')?.value || '';
  const viralHcv = document.getElementById('inj_viral_hcv')?.value || '';
  const viralHiv = document.getElementById('inj_viral_hiv')?.value || '';
  const viralAntiS = document.getElementById('inj_viral_antis')?.value || '';

  const checkedMatrix = document.querySelector('input[name="matrix_exposure_type"]:checked');
  const matrixVal = checkedMatrix ? checkedMatrix.value : 'Contaminated - Needle Prick';
  let inferredExposureType = 'Needle Prick';
  let inferredContamStatus = 'Contaminated';
  if (matrixVal.includes('Sharp')) inferredExposureType = 'Sharp Instrument';
  else if (matrixVal.includes('Others')) inferredExposureType = 'Others';
  if (matrixVal.includes('Clean')) inferredContamStatus = 'Clean';
  else if (matrixVal.includes('Unknown')) inferredContamStatus = 'Unknown';

  const actionAssessment = document.getElementById('inj_action_assessment')?.value || '';
  const actionVaccination = document.getElementById('inj_action_vaccination')?.value || '';
  const actionPep = document.getElementById('inj_action_pep')?.value || '';
  const physiciansNotes = document.getElementById('inj_physicians_notes')?.value || '';

  let pepInit = true;
  if (actionPep === 'Not Required' || actionPep === 'Declined by Worker') {
    pepInit = false;
  }
  let finalStatus = actionAssessment || 'In Progress';

  const newReport = {
    id: serialNo,
    serialNo: serialNo,
    incidentDate: dateTime,
    reportDate: reportDateTime,
    employeeName: empName,
    department: empDept,
    jobTitle: empPosition,
    exposureType: inferredExposureType,
    exposureMatrix: matrixVal,
    contaminationStatus: inferredContamStatus,
    bodyPart: 'Hand/Finger',
    pepInitiated: pepInit,
    status: finalStatus,
    part1: {
      name: empName,
      age: empAge,
      gender: genderCode,
      department: empDept,
      position: empPosition,
      fileNo: empFileNo,
      dateTime: dateTime,
      reportDateTime: reportDateTime,
      hbvBoosterDate: hbvBooster,
      description: description,
      exposureType: inferredExposureType,
      exposureMatrix: matrixVal,
      contaminationStatus: inferredContamStatus,
      serialNo: serialNo,
      sourcePatientName: srcPatientName,
      sourceFileNo: srcFileNo,
      sourceOtherName: srcOtherName,
      sourceOtherFileNo: srcOtherFileNo,
      sourceLab: {
        hbsAg: srcHbsAg,
        hcv: srcHcv,
        hiv: srcHiv,
        others: srcOthers
      }
    },
    part2: {
      inChargeName: document.getElementById('inj_incharge_name')?.value || '',
      position: document.getElementById('inj_incharge_position')?.value || '',
      date: document.getElementById('inj_incharge_date')?.value || '',
      timeReported: document.getElementById('inj_incharge_time')?.value || '',
      place: document.getElementById('inj_incharge_place')?.value || '',
      signature: document.getElementById('inj_incharge_sig')?.value || ''
    },
    part3: {
      requestNo: document.getElementById('inj_lab_req_no')?.value || '',
      assessmentStatus: actionAssessment,
      vaccinationAction: actionVaccination,
      pepAction: actionPep,
      physiciansNotes: physiciansNotes,
      physiciansAction: physiciansNotes || [
        actionAssessment ? `Assessment: ${actionAssessment}` : '',
        actionVaccination ? `Vaccination: ${actionVaccination}` : '',
        actionPep ? `PEP: ${actionPep}` : ''
      ].filter(Boolean).join(' | '),
      date: document.getElementById('inj_lab_date')?.value || '',
      time: document.getElementById('inj_lab_time')?.value || '',
      signature: document.getElementById('inj_lab_sig')?.value || '',
      injuredViralProfile: {
        hbsAg: viralHbsAg,
        hcv: viralHcv,
        hiv: viralHiv,
        antiS: viralAntiS
      }
    }
  };

  // 1. Authoritative central SQLite save via InjuryDataService
  let saveRes = null;
  if (typeof InjuryDataService !== 'undefined' && typeof InjuryDataService.saveInjury === 'function') {
    saveRes = await InjuryDataService.saveInjury(newReport);
  } else {
    const sId = newReport.id || newReport.serialNo;
    const idx = injuries.findIndex(i => (i.id === sId || i.serialNo === sId || i.part1?.serialNo === sId));
    if (idx !== -1) {
      injuries[idx] = newReport;
    } else {
      injuries.unshift(newReport);
    }
    localStorage.setItem('avh_injuries', JSON.stringify(injuries));
    saveRes = { success: true, serverSaved: false, injury: newReport };
  }

  // Authoritatively lock activeInjurySerial to saved record
  activeInjurySerial = saveRes?.injury?.id || saveRes?.injury?.serialNo || serialNo;

  // 2. Auto-sync into employee PEP Section 7 records in central DB
  let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  const empIdx = employees.findIndex(e => {
    const d = e.demographic || {};
    const eNo = (e.empNo || e.id || d.personNumber || '').toString();
    const eName = (e.name || d.fullName || '').toString().toLowerCase();
    return (empFileNo && eNo === String(empFileNo)) || (empName && eName && (eName.includes(empName.toLowerCase()) || empName.toLowerCase().includes(eName)));
  });

  if (empIdx !== -1) {
    if (!employees[empIdx].pep) employees[empIdx].pep = {};
    if (!employees[empIdx].pep.additionalPepRecords) employees[empIdx].pep.additionalPepRecords = [];
    
    const pepRec = {
      serialNo: activeInjurySerial,
      incidentDate: dateTime,
      protocol: 'HBIG / Tetanus / PEP Baseline Protocol (SQE 02.01)',
      indication: description ? (`Needlestick Injury: ${description.substring(0, 50)}...`) : 'Occupational Exposure (SQE 02.01)',
      status: 'In Progress',
      date: dateTime
    };

    // Update in-place if existing PEP record with matching serialNo exists, else unshift
    const existingPepIdx = employees[empIdx].pep.additionalPepRecords.findIndex(r => r.serialNo === activeInjurySerial);
    if (existingPepIdx !== -1) {
      employees[empIdx].pep.additionalPepRecords[existingPepIdx] = pepRec;
    } else {
      employees[empIdx].pep.additionalPepRecords.unshift(pepRec);
    }

    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployee === 'function') {
      EmployeeDataService.saveEmployee(employees[empIdx], 'update').catch(err => console.error("Error saving PEP record to employee:", err));
    } else if (typeof saveEmployeesToLocalStorage === 'function') {
      saveEmployeesToLocalStorage(employees);
    }
  }

  if (window.googleSheetsSync && window.googleSheetsSync.isConnected()) {
    window.googleSheetsSync.syncInjuryReport(saveRes?.injury || newReport);
  }

  // Update DOM badges and fields in-place without page reload
  const badge = document.getElementById('inj_serial_badge');
  if (badge) {
    badge.textContent = activeInjurySerial;
    badge.style.color = '#DC2626';
    badge.style.background = '#FEF2F2';
    badge.style.borderColor = '#FCA5A5';
  }
  const modeInd = document.getElementById('inj_mode_indicator');
  if (modeInd) {
    modeInd.textContent = isAr ? '🔄 وضع تحديث النموذج (تم الحفظ على نفس الرقم)' : '🔄 UPDATE MODE (Saved & In Sync)';
    modeInd.style.color = '#1D4ED8';
    modeInd.style.background = '#EFF6FF';
    modeInd.style.borderColor = '#93C5FD';
  }
  const curSerialInp = document.getElementById('inj_current_serial');
  if (curSerialInp) curSerialInp.value = activeInjurySerial;
  const printSerial = document.getElementById('inj_print_serial_text');
  if (printSerial) printSerial.textContent = activeInjurySerial;

  // Ensure all save buttons reflect update mode in-place
  document.querySelectorAll('button[onclick="saveInjuryReport()"]').forEach(btn => {
    btn.innerHTML = `💾 ${isAr ? 'حفظ التعديلات على نفس التقرير' : 'Update This Report'}`;
  });

  if (typeof updateInjuryPrintState === 'function') {
    updateInjuryPrintState();
  }

  if (typeof showSuccessToast === 'function') {
    if (isUpdatingExisting) {
      showSuccessToast(
        isAr ? `تم تحديث بلاغ الإصابة (${activeInjurySerial}) بنجاح دون تغيير رقم المتابعة 🟢` : `Injury Report (${activeInjurySerial}) updated in-place successfully (Ref No preserved) 🟢`,
        isAr ? 'تم التحديث بنجاح 🟢' : 'Updated In-Place 🟢'
      );
    } else {
      showSuccessToast(
        isAr ? `تم تسجيل بلاغ الإصابة الجديد (${activeInjurySerial}) بنجاح في قاعدة البيانات المركزية 🟢` : `New Injury Report (${activeInjurySerial}) registered successfully in central database 🟢`,
        isAr ? 'تم الحفظ بنجاح 🟢' : 'Saved Successfully 🟢'
      );
    }
  }
}

function clearAllInjuryReports() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const msg = isAr 
    ? '⚠️ هل أنت تأكد من مسح جميع بلاغات حوادث الإصابات المسجلة؟' 
    : '⚠️ Are you sure you want to clear all saved Injury Incident Reports?';
  if (!confirm(msg)) return;

  localStorage.setItem('avh_injuries', JSON.stringify([]));
  const container = document.getElementById('mainAppArea');
  if (container) renderPeriodicIncidentLog(container);

  if (typeof showSuccessToast === 'function') {
    showSuccessToast(
      isAr ? 'تم مسح جميع بيانات الحوادث بنجاح 🟢' : 'All injury incident data cleared successfully 🟢',
      'ACTION DONE SUCCESSFULLY 🟢'
    );
  }
}
window.clearAllInjuryReports = clearAllInjuryReports;

function openInjuryReportBySerial(serialNo) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  if (!serialNo || !serialNo.trim()) {
    alert(isAr ? '⚠️ لا يوجد رقم متابعة لبلاغ الإصابة (SQE 02.01).' : '⚠️ No serial number available for this injury report.');
    return;
  }
  const cleanSerial = String(serialNo).trim();

  // 1. Lock active serial and switch active tab to individual injury report form
  activeInjurySerial = cleanSerial;
  isManualBlankMode = false;
  currentInjurySubTab = 'form';
  if (typeof switchNav === 'function') {
    switchNav('injury-report');
  }

  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  const injuries = (typeof InjuryDataService !== 'undefined' && InjuryDataService._cache)
    ? InjuryDataService._cache
    : (JSON.parse(localStorage.getItem('avh_injuries')) || []);

  // 2. Find matching injury record by serial, refNo, or id
  let targetInj = injuries.find(i => {
    const p1 = i.part1 || {};
    const sId = (i.id || '').toString().toLowerCase();
    const sNo = (p1.serialNo || i.serialNo || '').toString().toLowerCase();
    const doc = (i.docCode || '').toString().toLowerCase();
    const ref = (i.refNo || '').toString().toLowerCase();
    const target = cleanSerial.toLowerCase();
    return sId === target || sNo === target || doc.includes(target) || ref === target || target.includes(sId) || target.includes(sNo);
  });

  let targetEmpIdx = -1;

  if (targetInj) {
    const p1 = targetInj.part1 || {};
    const iFile = (p1.fileNo || '').toString();
    const iName = (targetInj.employeeName || p1.name || '').toLowerCase();

    targetEmpIdx = employees.findIndex(e => {
      const demo = e.demographic || {};
      const eNo = (e.empNo || e.id || demo.personNumber || '').toString();
      const eName = (e.name || demo.fullName || '').toLowerCase();
      return (eNo && iFile && eNo === iFile) || (eName && iName && (eName.includes(iName) || iName.includes(eName)));
    });
  }

  if (targetEmpIdx === -1 && cleanSerial) {
    // Fallback: search employees directly by cleanSerial or matching digits
    const digits = cleanSerial.replace(/[^0-9]/g, '');
    targetEmpIdx = employees.findIndex(e => {
      const demo = e.demographic || {};
      const eNo = (e.empNo || e.id || demo.personNumber || '').toString();
      const idNo = (e.idNo || demo.nationalId || '').toString();
      const eName = (e.name || demo.fullName || '').toLowerCase();
      const target = cleanSerial.toLowerCase();
      return (eNo && target.includes(eNo.toLowerCase())) || (idNo && target.includes(idNo)) || (digits && eNo.includes(digits)) || (eName && target.includes(eName));
    });
  }

  if (targetEmpIdx !== -1) {
    activeInjuryEmpIndex = targetEmpIdx;
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(employees[targetEmpIdx]);
    }
  }

  const container = document.getElementById('mainAppArea');
  if (container) {
    renderInjuryReportForm(container);
  }

  if (typeof showSuccessToast === 'function') {
    showSuccessToast(
      isAr 
        ? `تم فتح تقرير إصابة العمل SQE 02.01 (رقم المتابعة: ${cleanSerial}) 🟢` 
        : `Opened Injury Incident Report SQE 02.01 (Serial: ${cleanSerial}) 🟢`, 
      'SQE 02.01 Report'
    );
  }
}
window.openInjuryReportBySerial = openInjuryReportBySerial;

function createNewIncidentForStaff() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  activeInjurySerial = '';
  isManualBlankMode = false;

  const badge = document.getElementById('inj_serial_badge');
  if (badge) {
    badge.textContent = isAr ? 'جديد (سيتم تعيينه تلقائياً عند أول حفظ)' : 'NEW (Auto-assigned on first save)';
    badge.style.color = '#15803D';
    badge.style.background = '#F0FDF4';
    badge.style.borderColor = '#86EFAC';
  }
  const modeInd = document.getElementById('inj_mode_indicator');
  if (modeInd) {
    modeInd.textContent = isAr ? '➕ تسجيل بلاغ جديد' : '➕ NEW INCIDENT RECORD';
    modeInd.style.color = '#15803D';
    modeInd.style.background = '#F0FDF4';
    modeInd.style.borderColor = '#86EFAC';
  }
  const curSerialInp = document.getElementById('inj_current_serial');
  if (curSerialInp) curSerialInp.value = '';

  const printSerial = document.getElementById('inj_print_serial_text');
  if (printSerial) printSerial.textContent = 'INC-2026-PENDING';

  // Reset incident-specific fields while keeping demographic inputs
  const now = new Date();
  const nowStr = formatToDDMMYYYY(now.toISOString().slice(0, 10) + ' ' + String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0'));
  if (document.getElementById('inj_dateTime')) document.getElementById('inj_dateTime').value = nowStr;
  if (document.getElementById('inj_reportDateTime')) document.getElementById('inj_reportDateTime').value = nowStr;
  if (document.getElementById('inj_description')) document.getElementById('inj_description').value = '';

  // Matrix default
  const defRadio = document.getElementById('inj_mat_c_needle');
  if (defRadio) defRadio.checked = true;

  // Source of Contamination
  if (document.getElementById('inj_src_patient_name')) document.getElementById('inj_src_patient_name').value = '';
  if (document.getElementById('inj_src_file_no')) document.getElementById('inj_src_file_no').value = '';
  if (document.getElementById('inj_src_other_name')) document.getElementById('inj_src_other_name').value = '';
  if (document.getElementById('inj_src_other_file_no')) document.getElementById('inj_src_other_file_no').value = '';
  if (document.getElementById('inj_src_hbsag')) document.getElementById('inj_src_hbsag').value = '';
  if (document.getElementById('inj_src_hcv')) document.getElementById('inj_src_hcv').value = '';
  if (document.getElementById('inj_src_hiv')) document.getElementById('inj_src_hiv').value = '';
  if (document.getElementById('inj_src_others')) document.getElementById('inj_src_others').value = '';

  // Part II
  if (document.getElementById('inj_incharge_name')) document.getElementById('inj_incharge_name').value = '';
  if (document.getElementById('inj_incharge_position')) document.getElementById('inj_incharge_position').value = '';
  if (document.getElementById('inj_incharge_date')) document.getElementById('inj_incharge_date').value = '';
  if (document.getElementById('inj_incharge_time')) document.getElementById('inj_incharge_time').value = '';
  if (document.getElementById('inj_incharge_place')) document.getElementById('inj_incharge_place').value = '';
  if (document.getElementById('inj_incharge_sig')) document.getElementById('inj_incharge_sig').value = '';

  // Part III
  if (document.getElementById('inj_lab_req_no')) document.getElementById('inj_lab_req_no').value = '';
  if (document.getElementById('inj_action_assessment')) document.getElementById('inj_action_assessment').value = '';
  if (document.getElementById('inj_action_vaccination')) document.getElementById('inj_action_vaccination').value = '';
  if (document.getElementById('inj_action_pep')) document.getElementById('inj_action_pep').value = '';
  if (document.getElementById('inj_physicians_notes')) document.getElementById('inj_physicians_notes').value = '';
  if (document.getElementById('inj_lab_date')) document.getElementById('inj_lab_date').value = '';
  if (document.getElementById('inj_lab_time')) document.getElementById('inj_lab_time').value = '';
  if (document.getElementById('inj_lab_sig')) document.getElementById('inj_lab_sig').value = '';
  if (document.getElementById('inj_viral_hbsag')) document.getElementById('inj_viral_hbsag').value = '';
  if (document.getElementById('inj_viral_hcv')) document.getElementById('inj_viral_hcv').value = '';
  if (document.getElementById('inj_viral_hiv')) document.getElementById('inj_viral_hiv').value = '';

  if (typeof updateInjuryPrintState === 'function') updateInjuryPrintState();

  if (typeof showSuccessToast === 'function') {
    showSuccessToast(
      isAr ? 'تم فتح نموذج تسجيل حادثة جديدة لنفس الموظف' : 'New incident form ready for this staff member',
      isAr ? 'بلاغ جديد ➕' : 'New Incident ➕'
    );
  }
}
window.createNewIncidentForStaff = createNewIncidentForStaff;

function clearInjuryFormForManualEntry() {
  clearInjurySearch();
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  if (typeof showSuccessToast === 'function') {
    showSuccessToast(
      isAr ? 'تم تفريغ جميع الحقول بنجاح. يمكنك الآن التعبئة اليدوية.' : 'All fields cleared for manual entry!', 
      'Manual Fill Mode'
    );
  }
}
window.clearInjuryFormForManualEntry = clearInjuryFormForManualEntry;

function renderPeriodicIncidentLog(container) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const injuries = (typeof InjuryDataService !== 'undefined' && InjuryDataService._cache)
    ? InjuryDataService._cache
    : (JSON.parse(localStorage.getItem('avh_injuries')) || []);

  // Proactively fetch latest injuries from central server in background if cache is stale
  if (typeof InjuryDataService !== 'undefined' && !InjuryDataService._cache && typeof InjuryDataService.getAllInjuries === 'function') {
    InjuryDataService.getAllInjuries().then(list => {
      if (Array.isArray(list) && list.length !== injuries.length && container && document.getElementById('injury_periodic_log_tbody')) {
        renderPeriodicIncidentLog(container);
      }
    }).catch(() => {});
  }

  // Filter injuries by period, search query, and type
  const filteredInjuries = injuries.filter(inj => {
    const p1 = inj.part1 || {};
    const rawDate = inj.incidentDate || p1.dateTime || p1.incidentDate || '';
    
    let isoDate = '';
    if (rawDate) {
      const parts = String(rawDate).split(' ')[0].split(/[-/.]/);
      if (parts.length === 3) {
        if (parts[0].length === 4) isoDate = `${parts[0]}-${parts[1].padStart(2,'0')}-${parts[2].padStart(2,'0')}`;
        else if (parts[2].length === 4) isoDate = `${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}`;
      }
    }

    let matchPeriod = true;
    if (isoDate) {
      if (injuryLogPeriodFrom && isoDate < injuryLogPeriodFrom) matchPeriod = false;
      if (injuryLogPeriodTo && isoDate > injuryLogPeriodTo) matchPeriod = false;
    }

    let matchSearch = true;
    if (injuryLogSearchQuery.trim()) {
      const q = injuryLogSearchQuery.trim().toLowerCase();
      const name = (inj.employeeName || p1.name || '').toLowerCase();
      const fileNo = (p1.fileNo || '').toLowerCase();
      const serial = (inj.id || p1.serialNo || '').toLowerCase();
      const dept = (inj.department || p1.department || '').toLowerCase();
      matchSearch = name.includes(q) || fileNo.includes(q) || serial.includes(q) || dept.includes(q);
    }

    let matchType = true;
    if (injuryLogTypeFilter !== 'ALL') {
      const type = (inj.exposureType || p1.exposureType || '').toLowerCase();
      matchType = type.includes(injuryLogTypeFilter.toLowerCase());
    }

    return matchPeriod && matchSearch && matchType;
  });

  const totalCount = filteredInjuries.length;
  const needleCount = filteredInjuries.filter(i => (i.exposureType || i.part1?.exposureType || '').toLowerCase().includes('needle')).length;
  const sharpCount = filteredInjuries.filter(i => (i.exposureType || i.part1?.exposureType || '').toLowerCase().includes('sharp')).length;
  const pepCount = filteredInjuries.filter(i => i.pepInitiated !== false).length;

  container.innerHTML = `
    <!-- INJURY TAB SUB-MENU TOOLBAR -->
    <div class="sub-tabs-container no-print" style="margin-bottom: 20px; background: white; padding: 10px 16px; border-radius: 8px; border: 1px solid var(--border-color); box-shadow: var(--shadow-sm); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
      <div style="display: flex; gap: 10px; flex-wrap: wrap;">
        <button class="sub-tab-btn" onclick="switchInjurySubTab('form')" style="padding: 8px 16px; font-weight: bold; border-radius: 6px;">
          📋 ${isAr ? '1. نموذج الإصابة الفردي (SQE 02.01)' : '1. SQE 02.01 Individual Injury Report'}
        </button>
        <button class="sub-tab-btn active" onclick="switchInjurySubTab('periodic_log')" style="padding: 8px 16px; font-weight: bold; border-radius: 6px; background: #DC2626; color: white; border-color: #FCA5A5;">
          📊 ${isAr ? '2. سجل حوادث الإصابات الشامل حسب الفترة (Period Incidents Log)' : '2. All Incidents Log (By Period)'}
        </button>
      </div>
      <div style="font-size: 0.85rem; font-weight: bold; color: #DC2626;">
        🏥 ${isAr ? 'مستشفى الأوغستا فكتوريا - سجل بلاغات الإصابات المهنية' : 'Augusta Victoria Hospital | Periodic Injury Registry'}
      </div>
    </div>

    <!-- PERIOD SELECTION & SEARCH FILTER BAR -->
    <div class="card no-print" style="background: white; border-left: 5px solid #DC2626; padding: 18px 20px; margin-bottom: 20px;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
        <h4 style="margin: 0; color: #991B1B; font-weight: 800; font-size: 1.1rem; display: flex; align-items: center; gap: 8px;">
          🗓️ ${isAr ? 'تصفية بلاغات الإصابات حسب الفترة الزمنية (Select Period & Filters):' : 'Filter Incident Reports by Period & Criteria:'}
        </h4>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button type="button" class="btn btn-outline" style="font-size: 0.8rem; font-weight: bold;" onclick="setInjuryLogPeriod('ALL')">${isAr ? 'كل الفترات' : 'All Time'}</button>
          <button type="button" class="btn btn-outline" style="font-size: 0.8rem; font-weight: bold;" onclick="setInjuryLogPeriod('2026')">${isAr ? 'سنة 2026' : 'Year 2026'}</button>
          <button type="button" class="btn btn-outline" style="font-size: 0.8rem; font-weight: bold;" onclick="setInjuryLogPeriod('MONTH')">${isAr ? 'هذا الشهر' : 'This Month'}</button>
          <button type="button" class="btn btn-danger" style="font-size: 0.8rem; font-weight: bold; background: #EF4444; color: white; border: none;" onclick="clearAllInjuryReports()">🗑️ ${isAr ? 'مسح بيانات حوادث الاختبار' : 'Clear All Incidents'}</button>
          <button type="button" class="btn btn-outline" style="font-size: 0.8rem; font-weight: bold; background: #DC2626; color: white; border: none;" onclick="printSharpsLogTable()">🖨️ ${isAr ? 'طباعة سجل الفترة' : 'Print Period Log'}</button>
        </div>
      </div>

      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; align-items: end;">
        <div>
          <label style="font-size: 0.82rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">📅 ${isAr ? 'من تاريخ:' : 'From Date:'}</label>
          <input type="date" value="${injuryLogPeriodFrom}" onchange="injuryLogPeriodFrom=this.value; renderPeriodicIncidentLog(document.getElementById('mainAppArea'))" style="width: 100%; padding: 7px 10px; border-radius: 6px; border: 1.5px solid #CBD5E1; font-weight: 700; color: #1E293B;">
        </div>
        <div>
          <label style="font-size: 0.82rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">📅 ${isAr ? 'إلى تاريخ:' : 'To Date:'}</label>
          <input type="date" value="${injuryLogPeriodTo}" onchange="injuryLogPeriodTo=this.value; renderPeriodicIncidentLog(document.getElementById('mainAppArea'))" style="width: 100%; padding: 7px 10px; border-radius: 6px; border: 1.5px solid #CBD5E1; font-weight: 700; color: #1E293B;">
        </div>
        <div>
          <label style="font-size: 0.82rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">🔍 ${isAr ? 'البحث بالاسم / الرقم / القسم:' : 'Search Staff / Serial / Dept:'}</label>
          <input type="text" placeholder="${isAr ? 'اسم، رقم وظيفي، رقم بلاغ...' : 'Search by name, emp no, serial...'}" value="${injuryLogSearchQuery}" oninput="injuryLogSearchQuery=this.value; renderPeriodicIncidentLog(document.getElementById('mainAppArea'))" style="width: 100%; padding: 7px 10px; border-radius: 6px; border: 1.5px solid #CBD5E1; font-weight: 700; color: #1E293B;">
        </div>
        <div>
          <label style="font-size: 0.82rem; font-weight: 700; color: #475569; display: block; margin-bottom: 4px;">🩸 ${isAr ? 'نوع الإصابة (Exposure Type):' : 'Exposure Type:'}</label>
          <select onchange="injuryLogTypeFilter=this.value; renderPeriodicIncidentLog(document.getElementById('mainAppArea'))" style="width: 100%; padding: 7px 10px; border-radius: 6px; border: 1.5px solid #CBD5E1; font-weight: 700; color: #1E293B;">
            <option value="ALL" ${injuryLogTypeFilter === 'ALL' ? 'selected' : ''}>${isAr ? '-- جميع أنواع الإصابات --' : '-- All Exposure Types --'}</option>
            <option value="needle" ${injuryLogTypeFilter === 'needle' ? 'selected' : ''}>Needle Prick / وخز إبرة</option>
            <option value="sharp" ${injuryLogTypeFilter === 'sharp' ? 'selected' : ''}>Sharp Instrument / آلة حادة</option>
            <option value="fluid" ${injuryLogTypeFilter === 'fluid' ? 'selected' : ''}>Body Fluid Splash / رذاذ سوائل</option>
          </select>
        </div>
      </div>
    </div>

    <!-- PERIOD SUMMARY KPIS -->
    <div class="kpi-grid no-print" style="margin-bottom: 20px;">
      <div class="kpi-card red">
        <div>
          <div class="kpi-val" style="color: #DC2626;">${totalCount}</div>
          <div class="kpi-label">${isAr ? 'إجمالي الحوادث المسجلة بالفترة' : 'Total Incidents in Period'}</div>
        </div>
        <div style="font-size: 2.2rem; opacity: 0.8;">🚨</div>
      </div>
      <div class="kpi-card amber">
        <div>
          <div class="kpi-val" style="color: #D97706;">${needleCount}</div>
          <div class="kpi-label">${isAr ? 'حوادث وخز الإبر (Needle Pricks)' : 'Needle Prick Incidents'}</div>
        </div>
        <div style="font-size: 2.2rem; opacity: 0.8;">💉</div>
      </div>
      <div class="kpi-card">
        <div>
          <div class="kpi-val" style="color: #0284C7;">${sharpCount}</div>
          <div class="kpi-label">${isAr ? 'حوادث الآلات الحادة (Sharps)' : 'Sharp Instrument Incidents'}</div>
        </div>
        <div style="font-size: 2.2rem; opacity: 0.8;">🔪</div>
      </div>
      <div class="kpi-card green">
        <div>
          <div class="kpi-val" style="color: #059669;">${pepCount}</div>
          <div class="kpi-label">${isAr ? 'إجراءات PEP المبتدأة' : 'PEP Protocols Initiated'}</div>
        </div>
        <div style="font-size: 2.2rem; opacity: 0.8;">🛡️</div>
      </div>
    </div>

    <!-- PRINTABLE PERIODIC INCIDENT LOG TABLE -->
    <div style="background: white; padding: 24px; border-radius: 8px; border: 1px solid var(--border-color);" id="injuryPrintArea">
      <!-- OFFICIAL CENTERED HEADER -->
      <div style="margin-bottom: 16px; border-bottom: 2px solid #DC2626; padding-bottom: 12px; text-align: center;">
        <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 10px;">
          ${typeof getAVHLogoHTML === 'function' ? getAVHLogoHTML(95) : `<img src="assets/avh_logo.png" alt="Augusta Victoria Hospital" style="height: 95px; width: auto;" />`}
        </div>

        <h3 style="margin: 6px 0 2px 0; font-weight: 800; color: #991B1B; font-family: 'Times New Roman', Times, serif; font-size: 1.25rem;">
          Official Injury Incident Reports Log During Period
        </h3>
        <div style="font-size: 1.05rem; font-weight: 800; color: #1E293B; margin-top: 2px; font-family: 'Times New Roman', Times, serif;">
          سجل حوادث الإصابات المهنية والتعرض للدم وسوائل الجسم حسب الفترة
        </div>
        <div style="font-size: 0.9rem; font-weight: 700; color: #475569; margin-top: 6px;">
          Selected Period: <span style="color: #DC2626; font-weight: 800;">${injuryLogPeriodFrom || 'Start'}</span> &nbsp;To&nbsp; <span style="color: #DC2626; font-weight: 800;">${injuryLogPeriodTo || 'Present'}</span> &nbsp;|&nbsp; Total Records Filed: <strong style="color: #0284C7; font-size: 1rem;">${totalCount}</strong>
        </div>
      </div>

      <div class="table-responsive">
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-family: 'Times New Roman', Times, serif; font-size: 9.5pt;">
          <thead>
            <tr style="background: #FEF2F2; color: #991B1B; border: 1.5px solid #FCA5A5;">
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Serial / Ref No.</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Incident Date</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Employee Name</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Emp No / File</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Department</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Exposure & Status</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Source Contamination Lab</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">Injured Viral Profile (Part III)</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: left;">In-Charge (Part II)</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: center;">PEP</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: center;">Status</th>
              <th style="padding: 6px 8px; border: 1px solid #CBD5E1; text-align: center;" class="no-print">Action</th>
            </tr>
          </thead>
          <tbody>
            ${filteredInjuries.length === 0 ? `
              <tr>
                <td colspan="12" style="text-align: center; padding: 20px; color: #94A3B8; font-weight: bold;">
                  ${isAr ? 'لا توجد حوادث إصابة مسجلة خلال هذه الفترة الزمنية.' : 'No injury incident records found for the selected period.'}
                </td>
              </tr>
            ` : filteredInjuries.map(inj => {
              const p1 = inj.part1 || {};
              const p2 = inj.part2 || {};
              const p3 = inj.part3 || {};
              const serial = inj.id || p1.serialNo || inj.serialNo || 'INC-2026-001';
              const name = inj.employeeName || p1.name || 'Staff Member';
              const fileNo = p1.fileNo || inj.empNo || 'N/A';
              let dept = inj.department || p1.department || '';
              if (!dept || dept === 'Staff' || dept === 'N/A') {
                const matchEmp = employees.find(e => {
                  const eNo = e.empNo || e.id || e.demographic?.personNumber;
                  return (fileNo && fileNo !== 'N/A' && eNo && String(eNo) === String(fileNo)) || (name && e.name && e.name.toLowerCase() === name.toLowerCase());
                });
                if (matchEmp) {
                  dept = matchEmp.demographic?.orgName || matchEmp.organizationName || matchEmp.orgName || matchEmp.department || dept;
                }
              }
              if (!dept || dept === 'Staff') dept = 'Hospital Staff';
              const pos = inj.jobTitle || p1.position || 'N/A';
              const incDate = formatToDDMMYYYY(inj.incidentDate || p1.dateTime || '');
              const expType = inj.exposureType || p1.exposureType || 'Needle Prick';
              const expMatrix = p1.exposureMatrix || inj.exposureMatrix || `${inj.contaminationStatus || p1.contaminationStatus || 'Contaminated'} - ${expType}`;
              const isContam = expMatrix.toLowerCase().includes('contam');
              const isClean = expMatrix.toLowerCase().includes('clean');

              const srcLab = p1.sourceLab || inj.sourceLab || {};
              const viralProf = p3.injuredViralProfile || inj.injuredViralProfile || {};

              const pep = p3.pepAction || (inj.pepInitiated !== false ? '✅ Yes' : '❌ No');
              const status = p3.assessmentStatus || inj.status || 'In Progress';
              const vacAction = p3.vaccinationAction || '';

              return `
                <tr style="border-bottom: 1px solid #E2E8F0; vertical-align: top;">
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-family: monospace; font-weight: 800; color: #DC2626;">
                    <a href="javascript:void(0)" onclick="openInjuryReportBySerial('${serial}')" style="color: #DC2626; text-decoration: underline;" title="${isAr ? 'فتح وتعديل النموذج' : 'Open and Edit Report'}">${serial}</a>
                  </td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-weight: 700; white-space: nowrap;">${incDate}</td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-weight: 800; color: #0284C7;">${name}</td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-weight: 700;">${fileNo}</td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-size: 8.5pt;">${dept}</td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0;">
                    <span style="display: inline-block; padding: 2px 6px; border-radius: 4px; font-weight: 800; font-size: 0.8rem; background: ${isContam ? '#FEF2F2' : (isClean ? '#F0FDF4' : '#FEF3C7')}; color: ${isContam ? '#DC2626' : (isClean ? '#15803D' : '#B45309')}; border: 1px solid ${isContam ? '#FCA5A5' : (isClean ? '#86EFAC' : '#FCD34D')};">
                      ${isContam ? '⚠️ ' : (isClean ? '🧼 ' : '❓ ')}${expMatrix}
                    </span>
                  </td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-size: 8.5pt; line-height: 1.35;">
                    ${(p1.sourcePatientName || p1.sourceFileNo) ? `<div style="font-weight: 800; color: #1E293B; margin-bottom: 2px;">👤 ${p1.sourcePatientName || ''} ${p1.sourceFileNo ? '(' + p1.sourceFileNo + ')' : ''}</div>` : ''}
                    <div><b>HBsAg:</b> <span style="font-weight: 800; color: ${srcLab.hbsAg?.toLowerCase().includes('pos') ? '#DC2626' : (srcLab.hbsAg?.toLowerCase().includes('neg') ? '#16A34A' : '#64748B')};">${srcLab.hbsAg || '—'}</span></div>
                    <div><b>HCV:</b> <span style="font-weight: 800; color: ${srcLab.hcv?.toLowerCase().includes('pos') ? '#DC2626' : (srcLab.hcv?.toLowerCase().includes('neg') ? '#16A34A' : '#64748B')};">${srcLab.hcv || '—'}</span></div>
                    <div><b>HIV:</b> <span style="font-weight: 800; color: ${srcLab.hiv?.toLowerCase().includes('pos') ? '#DC2626' : (srcLab.hiv?.toLowerCase().includes('neg') ? '#16A34A' : '#64748B')};">${srcLab.hiv || '—'}</span></div>
                  </td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-size: 8.5pt; line-height: 1.35;">
                    <div><b>Anti-S:</b> <span style="font-weight: 800; color: #0284C7;">${viralProf.antiS || '—'}</span></div>
                    <div><b>HBsAg:</b> <span style="font-weight: 800; color: ${viralProf.hbsAg?.toLowerCase().includes('pos') ? '#DC2626' : (viralProf.hbsAg?.toLowerCase().includes('neg') ? '#16A34A' : '#64748B')};">${viralProf.hbsAg || '—'}</span></div>
                    <div><b>HCV:</b> <span style="font-weight: 800; color: ${viralProf.hcv?.toLowerCase().includes('pos') ? '#DC2626' : (viralProf.hcv?.toLowerCase().includes('neg') ? '#16A34A' : '#64748B')};">${viralProf.hcv || '—'}</span></div>
                    <div><b>HIV:</b> <span style="font-weight: 800; color: ${viralProf.hiv?.toLowerCase().includes('pos') ? '#DC2626' : (viralProf.hiv?.toLowerCase().includes('neg') ? '#16A34A' : '#64748B')};">${viralProf.hiv || '—'}</span></div>
                  </td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; font-size: 8.5pt; line-height: 1.35;">
                    ${p2.inChargeName ? `<div style="font-weight: 800; color: #1E293B;">${p2.inChargeName}</div>` : '<span style="color: #94A3B8;">—</span>'}
                    ${p2.position ? `<div style="color: #64748B; font-size: 8pt;">${p2.position}</div>` : ''}
                    ${p2.place ? `<div style="color: #0284C7; font-weight: 700; font-size: 8pt;">📍 ${p2.place}</div>` : ''}
                  </td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; text-align: center; font-weight: 800;">
                    <span style="display: inline-block; padding: 2px 6px; border-radius: 4px; font-weight: 800; font-size: 0.78rem; background: ${pep.toLowerCase().includes('started') || pep.toLowerCase().includes('completed') || pep === '✅ Yes' ? '#ECFDF5' : (pep.toLowerCase().includes('declined') ? '#FEF2F2' : '#F8FAFC')}; color: ${pep.toLowerCase().includes('started') || pep.toLowerCase().includes('completed') || pep === '✅ Yes' ? '#065F46' : (pep.toLowerCase().includes('declined') ? '#991B1B' : '#475569')}; border: 1px solid ${pep.toLowerCase().includes('started') || pep.toLowerCase().includes('completed') || pep === '✅ Yes' ? '#A7F3D0' : '#E2E8F0'};">
                      ${pep}
                    </span>
                  </td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; text-align: center;">
                    <span style="display: inline-block; padding: 2px 6px; border-radius: 4px; font-weight: 800; font-size: 0.78rem; background: ${status.toLowerCase().includes('completed') ? '#EFF6FF' : '#FEF2F2'}; color: ${status.toLowerCase().includes('completed') ? '#1D4ED8' : '#DC2626'}; border: 1px solid ${status.toLowerCase().includes('completed') ? '#BFDBFE' : '#FCA5A5'};">
                      ${status}
                    </span>
                    ${vacAction ? `<div style="font-size: 7.5pt; font-weight: 700; color: #64748B; margin-top: 2px;">Vac: ${vacAction}</div>` : ''}
                  </td>
                  <td style="padding: 6px 8px; border: 1px solid #E2E8F0; text-align: center; white-space: nowrap;" class="no-print">
                    <button type="button" class="btn btn-outline" style="padding: 3px 8px; font-size: 0.78rem; border-color: #DC2626; color: #DC2626; font-weight: bold; background: #FEF2F2; cursor: pointer; border-radius: 4px; margin-right: 4px;" onclick="openInjuryReportBySerial('${serial}')" title="${isAr ? 'فتح وتعديل تقرير الإصابة SQE 02.01' : 'Open / Edit SQE 02.01 Form'}">
                      ✏️ ${isAr ? 'عرض وتعديل' : 'View / Edit'}
                    </button>
                    <button type="button" class="btn btn-danger" style="padding: 3px 8px; font-size: 0.78rem; background: #EF4444; color: white; border: none; font-weight: bold; cursor: pointer; border-radius: 4px;" onclick="deleteInjuryReportBySerial('${serial}')" title="${isAr ? 'حذف هذا البلاغ' : 'Delete Injury Report'}">
                      🗑️ ${isAr ? 'حذف' : 'Delete'}
                    </button>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>

      <div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center; border-top: 1.5px solid #000000; padding-top: 8px; font-size: 0.8rem; font-family: 'Times New Roman', Times, serif; font-weight: bold;">
        <div>Form Registry: SQE 02.01 Periodic Incident Master Log</div>
        <div>Augusta Victoria Hospital Infectious Disease Unit</div>
        <div>Generated: ${new Date().toLocaleDateString()}</div>
      </div>
    </div>
  `;
}
window.renderPeriodicIncidentLog = renderPeriodicIncidentLog;

async function deleteInjuryReportBySerial(serialNo, skipConfirm = false) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  if (!serialNo) return false;

  if (!skipConfirm) {
    const confirmMsg = isAr 
      ? `⚠️ هل أنت متأكد من حذف بلاغ إصابة العمل (${serialNo})؟ يمكن لحساب المالك المعتمد فقط استعادته لاحقاً.` 
      : `⚠️ Are you sure you want to delete injury incident report (${serialNo})? Only the designated owner can restore it from Trash.`;
    if (!confirm(confirmMsg)) return false;
  }

  try {
    // 1. Authoritative central SQLite delete (strictly owner enforced)
    if (typeof InjuryDataService !== 'undefined' && typeof InjuryDataService.deleteInjury === 'function') {
      await InjuryDataService.deleteInjury(serialNo);
    } else {
      let injuries = JSON.parse(localStorage.getItem('avh_injuries')) || [];
      injuries = injuries.filter(i => (i.id !== serialNo && i.part1?.serialNo !== serialNo));
      localStorage.setItem('avh_injuries', JSON.stringify(injuries));
    }

    // 2. Remove/unlink from employee PEP Section 7
    let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
    let updatedEmployees = false;

    employees.forEach(emp => {
      if (emp.pep && Array.isArray(emp.pep.additionalPepRecords)) {
        const initLen = emp.pep.additionalPepRecords.length;
        emp.pep.additionalPepRecords = emp.pep.additionalPepRecords.filter(r => r.serialNo !== serialNo);
        if (emp.pep.additionalPepRecords.length !== initLen) updatedEmployees = true;
      }
    });

    if (updatedEmployees) {
      if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployees === 'function') {
        EmployeeDataService.saveEmployees(employees).catch(err => console.error("Error saving updated employees:", err));
      } else if (typeof saveEmployeesToLocalStorage === 'function') {
        saveEmployeesToLocalStorage(employees);
      }
    }

    if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('staffDataUpdated'));
      window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: employees.length } }));
    }

    // 3. Re-render periodic log and show toast
    const container = document.getElementById('mainAppArea');
    if (container && typeof renderPeriodicIncidentLog === 'function') {
      renderPeriodicIncidentLog(container);
    }

    if (typeof showSuccessToast === 'function') {
      showSuccessToast(
        isAr ? `تم نقل بلاغ الإصابة (${serialNo}) إلى سلة المحذوفات بنجاح 🗑️` : `Injury report (${serialNo}) moved to Trash successfully 🗑️`, 
        'Deleted / تم الحذف'
      );
    }
    return true;
  } catch (err) {
    console.error("Delete injury report error:", err);
    alert(isAr ? `❌ فشل الحذف: ${err.message}` : `❌ Deletion Failed: ${err.message}`);
    return false;
  }
}
window.deleteInjuryReportBySerial = deleteInjuryReportBySerial;

// Auto-purge dummy test incidents (INC-2026-874-01, INC-2026-415-01, etc.) from client local storage
(function purgeDummyTestIncidents() {
  try {
    const dummySerials = ['INC-2026-874-01', 'INC-2026-415-01'];
    let injuries = JSON.parse(localStorage.getItem('avh_injuries')) || [];
    const origInjLen = injuries.length;
    injuries = injuries.filter(i => {
      const sId = i.id || i.part1?.serialNo || '';
      const prot = i.protocol || i.part1?.description || '';
      if (dummySerials.includes(sId)) return false;
      if (prot.includes('Baseline Exposure Surveillance')) return false;
      return true;
    });
    if (injuries.length !== origInjLen) {
      localStorage.setItem('avh_injuries', JSON.stringify(injuries));
    }
    let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees().slice() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
    let updated = false;
    employees.forEach(emp => {
      if (emp.pep && Array.isArray(emp.pep.additionalPepRecords)) {
        const len = emp.pep.additionalPepRecords.length;
        emp.pep.additionalPepRecords = emp.pep.additionalPepRecords.filter(r => {
          if (dummySerials.includes(r.serialNo)) return false;
          if (r.protocol === 'Baseline Exposure Surveillance' || r.indication === 'No Active Incident Reported') return false;
          return true;
        });
        if (emp.pep.additionalPepRecords.length !== len) updated = true;
      }
    });
    if (updated) {
      if (typeof saveEmployeesToLocalStorage === 'function') {
        saveEmployeesToLocalStorage(employees);
      }
    }
  } catch(e) {}
})();

function switchInjurySubTab(tabKey) {
  currentInjurySubTab = tabKey;
  const container = document.getElementById('mainAppArea');
  if (container) {
    if (tabKey === 'periodic_log') {
      renderPeriodicIncidentLog(container);
    } else {
      renderInjuryReportForm(container);
    }
  }
}
window.switchInjurySubTab = switchInjurySubTab;

function setInjuryLogPeriod(preset) {
  const now = new Date();
  if (preset === 'ALL') {
    injuryLogPeriodFrom = '2020-01-01';
    injuryLogPeriodTo = '2030-12-31';
  } else if (preset === '2026') {
    injuryLogPeriodFrom = '2026-01-01';
    injuryLogPeriodTo = '2026-12-31';
  } else if (preset === 'MONTH') {
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    injuryLogPeriodFrom = `${y}-${m}-01`;
    injuryLogPeriodTo = new Date().toISOString().slice(0, 10);
  }
  const container = document.getElementById('mainAppArea');
  if (container) renderPeriodicIncidentLog(container);
}
window.setInjuryLogPeriod = setInjuryLogPeriod;

function updateInjuryPrintState() {
  const container = document.getElementById('injuryPrintArea');
  if (!container) return;

  // 1. Exposure Matrix Radios
  const matrixRadios = container.querySelectorAll('input[name="matrix_exposure_type"]');
  matrixRadios.forEach(r => {
    const pSpan = document.getElementById(r.id + '_print');
    if (pSpan) {
      pSpan.innerHTML = r.checked ? '<b style="font-size:12pt;color:black;">●</b>' : '<span style="font-size:11pt;color:#555;">○</span>';
    }
  });

  // 2. Gender Radios
  const gM = document.getElementById('inj_gender_m');
  const gF = document.getElementById('inj_gender_f');
  const pGM = document.getElementById('inj_gender_m_print');
  const pGF = document.getElementById('inj_gender_f_print');
  if (pGM && gM) pGM.innerHTML = gM.checked ? '<b style="font-size:12pt;color:black;">●</b>' : '<span style="font-size:11pt;color:#555;">○</span>';
  if (pGF && gF) pGF.innerHTML = gF.checked ? '<b style="font-size:12pt;color:black;">●</b>' : '<span style="font-size:11pt;color:#555;">○</span>';

  // 3. Select Dropdowns
  const selects = [
    'inj_src_hbsag', 'inj_src_hcv', 'inj_src_hiv', 'inj_src_others', 
    'inj_viral_hbsag', 'inj_viral_hcv', 'inj_viral_hiv',
    'inj_action_assessment', 'inj_action_vaccination', 'inj_action_pep'
  ];
  selects.forEach(id => {
    const sel = document.getElementById(id);
    const pSpan = document.getElementById(id + '_print');
    if (sel && pSpan) {
      const opt = (sel.selectedIndex >= 0) ? sel.options[sel.selectedIndex] : null;
      const txt = (opt && opt.value && !opt.value.startsWith('--')) ? opt.text : '';
      pSpan.textContent = txt;
    }
  });

  // 4. Mirror input values for native print engines
  container.querySelectorAll('input').forEach(inp => {
    if (inp.type !== 'radio' && inp.type !== 'checkbox') {
      inp.setAttribute('value', inp.value || '');
    }
  });

  // 5. Mirror textarea content
  container.querySelectorAll('textarea').forEach(ta => {
    ta.textContent = ta.value || '';
  });
}
window.updateInjuryPrintState = updateInjuryPrintState;

function printSharpsInjuryReport() {
  if (typeof updateInjuryPrintState === 'function') {
    updateInjuryPrintState();
  }
  const container = document.getElementById('injuryPrintArea') || document.getElementById('mainAppArea');
  if (window.AVHPrintController) {
    window.AVHPrintController.printContainer(container, { mode: 'portrait', printClass: 'printing-injury-report' });
  } else {
    window.print();
  }
}
window.printSharpsInjuryReport = printSharpsInjuryReport;

function printSharpsLogTable() {
  const container = document.getElementById('injuryPrintArea') || document.getElementById('mainAppArea');
  if (window.AVHPrintController) {
    window.AVHPrintController.printContainer(container, { mode: 'landscape', printClass: 'printing-injury-log' });
  } else {
    window.print();
  }
}
window.printSharpsLogTable = printSharpsLogTable;

// Global exports for Occupational Health Injury Incident Reporting (SQE 02.01)
window.renderInjuryReportForm = renderInjuryReportForm;
window.saveInjuryReport = saveInjuryReport;
window.formatToDDMMYYYY = formatToDDMMYYYY;
