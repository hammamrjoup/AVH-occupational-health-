/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - OCCUPATIONAL HEALTH & VACCINATION PORTAL
   Clinical Follow-up & Repeat Test Calendar Module (js/followupCalendar.js)
   Full Interactive Month & Agenda Views + 100% Dynamic Bilingual Support
   Supports: Complete, New Appointment (Reschedule), Cancelled Due to Reason
   ========================================================================== */

(function(window) {
  'use strict';

  // Module state
  let currentCalDate = new Date(); // Tracks the currently displayed month
  let currentCalView = 'month';    // 'month' or 'agenda'
  let currentCalFilter = 'all';    // 'all', 'vaccine', 'test', 'overdue', 'completed', 'cancelled'
  let currentCalDeptFilter = 'all';// 'all' or specific department
  let currentSearchQuery = '';
  let activeModalDateKey = null;   // Tracks currently open Day Detail modal date

  // --------------------------------------------------------------------------
  // 1. CLINICAL DATE & FOLLOW-UP EXTRACTION ENGINE
  // --------------------------------------------------------------------------
  function parseDateSafe(val) {
    if (!val) return null;
    if (val instanceof Date && !isNaN(val.getTime())) return val;
    if (typeof val === 'number') {
      const d = new Date(val);
      return isNaN(d.getTime()) ? null : d;
    }
    const str = String(val).trim();
    if (!str || str.toLowerCase() === 'null' || str.toLowerCase() === 'undefined') return null;

    // Format: DD/MM/YYYY or DD-MM-YYYY
    const dmyMatch = str.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})/);
    if (dmyMatch) {
      const day = parseInt(dmyMatch[1], 10);
      const month = parseInt(dmyMatch[2], 10) - 1;
      const year = parseInt(dmyMatch[3], 10);
      const d = new Date(year, month, day);
      return isNaN(d.getTime()) ? null : d;
    }

    // Standard ISO: YYYY-MM-DD
    const isoMatch = str.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})/);
    if (isoMatch) {
      const year = parseInt(isoMatch[1], 10);
      const month = parseInt(isoMatch[2], 10) - 1;
      const day = parseInt(isoMatch[3], 10);
      const d = new Date(year, month, day);
      return isNaN(d.getTime()) ? null : d;
    }

    const d = new Date(str);
    return isNaN(d.getTime()) ? null : d;
  }

  function addDays(date, days) {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  function formatDateISO(date) {
    if (!date) return '';
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  function formatDateDisplay(date, isAr) {
    if (!date) return '';
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }

  function getDaysDifference(targetDate, baseDate = new Date()) {
    const start = new Date(baseDate.getFullYear(), baseDate.getMonth(), baseDate.getDate());
    const end = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate());
    const diffTime = end.getTime() - start.getTime();
    return Math.round(diffTime / (1000 * 60 * 60 * 24));
  }

  /**
   * Extract all scheduled clinical follow-ups and repeat test appointments
   * across all staff records and injury incident reports.
   * Takes into account dispositions: Completed, Rescheduled, Cancelled.
   */
    // --------------------------------------------------------------------------
  // A.1.5 VACCINE STOCK INITIALIZATION & DATA PURGE (NO DUMMY DATA)
  // --------------------------------------------------------------------------
  function ensureStandardVaccineStockInitialized() {
    try {
      const existing = localStorage.getItem('avh_standalone_vaccine_expiries');
      let parsed = [];
      if (existing) {
        try { parsed = JSON.parse(existing); } catch (e) { parsed = []; }
      }
      if (!Array.isArray(parsed)) parsed = [];

      // Purge all dummy/sample batches so user can enter authentic hospital stock
      const dummyLots = ['TD-98421-B', 'FL-2026-904K', 'HBV-44781-C', 'MMR-88120-X', 'VAR-55201-E', 'LOT-GENERAL'];
      const dummyIds = [
        'stock_tdap_01', 'stock_flu_01', 'stock_hepb_01', 'stock_mmr_01', 'stock_varicella_01',
        'stock_tubersol_01', 'stock_polio_01', 'stock_pneumo_01', 'stock_nimenrix_01'
      ];

      const beforeLen = parsed.length;
      parsed = parsed.filter(p => {
        if (!p) return false;
        if (p.id && dummyIds.includes(p.id)) return false;
        const lot = (p.vaccineLot || '').trim().toUpperCase();
        if (lot && dummyLots.includes(lot)) return false;
        // If it was created with literal name "Custom" and no custom name
        if (p.vaccineName === 'Custom' && (!lot || lot === 'LOT-GENERAL')) return false;
        return true;
      });

      // User requested: "Vaccine Batch Expire Date i need delete all data entered because i will enter valid data"
      // If user flagged cleared, or on initial load with dummy batches, save clean empty list
      if (parsed.length !== beforeLen || !existing || localStorage.getItem('avh_vaccine_stock_cleared_by_user') === 'true') {
        localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(parsed));
        localStorage.setItem('avh_vaccine_stock_cleared_by_user', 'true');
      }

      return parsed;
    } catch (e) {
      console.warn('ensureStandardVaccineStockInitialized error:', e);
      return [];
    }
  }
  window.ensureStandardVaccineStockInitialized = ensureStandardVaccineStockInitialized;

  // --------------------------------------------------------------------------
  // CLEAR ALL VACCINE BATCHES (CLEAN SLATE FOR VALID DATA ENTRY)
  // --------------------------------------------------------------------------
  function clearAllVaccineExpiries() {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const msg = isAr 
      ? 'هل أنت متأكد من رغبتك في حذف وتفريغ كافة بيانات تشغيلات اللقاحات المسجلة للبدء من جديد بإدخال بيانات معتمدة وصالحة؟' 
      : 'Are you sure you want to delete all entered vaccine batch records so you can enter valid hospital data?';
    if (confirm(msg)) {
      localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify([]));
      localStorage.setItem('avh_vaccine_stock_cleared_by_user', 'true');
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') {
        renderFollowupCalendar(container);
      }
      if (typeof window.showSuccessToast === 'function') {
        window.showSuccessToast(
          isAr ? 'تم تفريغ وحذف كافة تشغيلات اللقاحات بنجاح 🗑️' : 'All vaccine batches deleted successfully. Ready for valid data entry 🗑️',
          isAr ? 'تم تفريغ السجلات' : 'Cleared'
        );
      } else {
        alert(isAr ? 'تم تفريغ وحذف كافة تشغيلات اللقاحات بنجاح 🗑️' : 'All vaccine batches deleted successfully 🗑️');
      }
    }
  }
  window.clearAllVaccineExpiries = clearAllVaccineExpiries;

  function cleanupLegacyStaffVaccineExpiries() {
    try {
      const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
      let touched = false;
      employees.forEach(emp => {
        if (Array.isArray(emp.customFollowups)) {
          const origLen = emp.customFollowups.length;
          emp.customFollowups = emp.customFollowups.filter(cf => {
            if (cf.category === 'vaccine_expiry' || cf.category === 'expiry' || cf.isExpiry || cf.expireDate) return false;
            const t = ((cf.title || '') + ' ' + (cf.titleEn || '') + ' ' + (cf.titleAr || '') + ' ' + (cf.notes || '')).toLowerCase();
            if (t.includes('10-year') || t.includes('vaccine expired') || t.includes('booster due') || t.includes('vaccine expire') || t.includes('ط§ظ†طھظ‡ط§ط،') || t.includes('طµظ„ط§ط­ظٹط©')) return false;
            return true;
          });
          if (emp.customFollowups.length !== origLen) touched = true;
        }
        if (emp.followupDispositions) {
          Object.keys(emp.followupDispositions).forEach(k => {
            if (k.startsWith('tdap_exp_') || k.startsWith('flu_exp_') || k.startsWith('ve_')) {
              delete emp.followupDispositions[k];
              touched = true;
            }
          });
        }
      });
      const rawStored = localStorage.getItem('avh_employees');
      if (rawStored) {
        try {
          const emps = JSON.parse(rawStored);
          if (Array.isArray(emps)) {
            let sTouched = false;
            emps.forEach(emp => {
              if (Array.isArray(emp.customFollowups)) {
                const oLen = emp.customFollowups.length;
                emp.customFollowups = emp.customFollowups.filter(cf => {
                  if (cf.category === 'vaccine_expiry' || cf.isExpiry || cf.expireDate) return false;
                  const t = (cf.title || cf.titleEn || '').toLowerCase();
                  if (t.includes('10-year') || t.includes('vaccine expired') || t.includes('booster due')) return false;
                  return true;
                });
                if (emp.customFollowups.length !== oLen) sTouched = true;
              }
              if (emp.followupDispositions) {
                Object.keys(emp.followupDispositions).forEach(k => {
                  if (k.startsWith('tdap_exp_') || k.startsWith('flu_exp_') || k.startsWith('ve_')) {
                    delete emp.followupDispositions[k];
                    sTouched = true;
                  }
                });
              }
            });
            if (sTouched) {
              localStorage.setItem('avh_employees', JSON.stringify(emps));
            }
          }
        } catch (e) {}
      }
    } catch (e) {
      console.warn('cleanupLegacyStaffVaccineExpiries error:', e);
    }
  }
  window.cleanupLegacyStaffVaccineExpiries = cleanupLegacyStaffVaccineExpiries;

  function extractAllClinicalFollowups() {
    cleanupLegacyStaffVaccineExpiries();
    const rawItems = [];
    const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
    const injuries = (typeof window.InjuryDataService !== 'undefined' && window.InjuryDataService._cache)
      ? window.InjuryDataService._cache
      : (JSON.parse(localStorage.getItem('avh_injuries') || '[]'));

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // ------------------------------------------------------------------------
    // A. EMPLOYEE VACCINATION & SEROLOGY REPEAT TESTS
    // ------------------------------------------------------------------------
    employees.forEach(emp => {
      const empNo = emp.empNo || emp.id || (emp.demographic && emp.demographic.personNumber) || '';
      const empName = emp.name || (emp.demographic && emp.demographic.fullName) || 'Unnamed Staff';
      const dept = emp.department || (emp.demographic && emp.demographic.department) || 'General';
      const job = emp.jobTitle || (emp.demographic && emp.demographic.jobTitle) || 'Staff';
      const v = emp.vaccines || {};
      const l = emp.labs || {};

      // 1. HEPATITIS B SERIES IN PROGRESS
      const hbD1 = parseDateSafe(v.hbvDose1Date || v.hbDose1Date || (v.hepatitisB && v.hepatitisB.dose1Date));
      const hbD2 = parseDateSafe(v.hbvDose2Date || v.hbDose2Date || (v.hepatitisB && v.hepatitisB.dose2Date));
      const hbD3 = parseDateSafe(v.hbvDose3Date || v.hbDose3Date || (v.hepatitisB && v.hepatitisB.dose3Date));
      const hbBooster = parseDateSafe(v.hbvBoosterDate || (v.hepatitisB && v.hepatitisB.boosterDate));

      // Dose 2 Due (1 month / 30 days after Dose 1)
      if (hbD1 && !hbD2) {
        const dueDate = addDays(hbD1, 30);
        rawItems.push({
          id: `hb_d2_${empNo}`,
          empNo,
          empName,
          dept,
          job,
          category: 'vaccine',
          subCategory: 'hepb',
          titleEn: 'Hepatitis B — Dose 2 Due',
          titleAr: 'تطعيم التهاب الكبد B — استحقاق الجرعة الثانية',
          descEn: 'Scheduled 1 month after Dose 1 to continue protective series.',
          descAr: 'موعد الجرعة الثانية (بعد شهر من الجرعة الأولى) لاستكمال السلسلة الوقائية.',
          dueDate,
          sourceDate: hbD1,
          emp
        });
      }

      // Dose 3 Due (5 months after Dose 2 / 6 months after Dose 1)
      if (hbD2 && !hbD3) {
        const dueDate = addDays(hbD2, 150);
        rawItems.push({
          id: `hb_d3_${empNo}`,
          empNo,
          empName,
          dept,
          job,
          category: 'vaccine',
          subCategory: 'hepb',
          titleEn: 'Hepatitis B — Dose 3 Due',
          titleAr: 'تطعيم التهاب الكبد B — استحقاق الجرعة الثالثة',
          descEn: 'Final series dose (5 months after Dose 2 / 6 months after Dose 1).',
          descAr: 'الجرعة الثالثة والأخيرة للسلسلة الأساسية (بعد 5 أشهر من الجرعة الثانية).',
          dueDate,
          sourceDate: hbD2,
          emp
        });
      }

      // 2. REPEAT ANTI-HBs TITER (Post-Vaccination Serology Confirmation)
      const lastCompletedHbDate = hbBooster || hbD3;
      const antiHBsResult = String(l.antiHBsResult || l.hbsAbResult || (l.antiHBs && l.antiHBs.result) || '').toLowerCase();
      const antiHBsDate = parseDateSafe(l.antiHBsDate || l.hbsAbDate || (l.antiHBs && l.antiHBs.date));

      if (lastCompletedHbDate) {
        const isAlreadyImmune = antiHBsResult.includes('immune') || antiHBsResult.includes('≥10') || parseFloat(antiHBsResult) >= 10;
        const testDoneAfterVaccine = antiHBsDate && antiHBsDate > lastCompletedHbDate;

        if (!testDoneAfterVaccine || !isAlreadyImmune) {
          const dueDate = addDays(lastCompletedHbDate, 45); // 1.5 months post-vaccine
          rawItems.push({
            id: `anti_hbs_titer_${empNo}`,
            empNo,
            empName,
            dept,
            job,
            category: 'test',
            subCategory: 'anti_hbs',
            titleEn: 'Repeat Anti-HBs Serology Titer (TST0040)',
            titleAr: 'إعادة فحص الأجسام المضادة للكبد B (Anti-HBs Titer)',
            descEn: 'Quantitative anti-HBs titer post-vaccination series to verify immunity ≥10 mIU/mL.',
            descAr: 'فحص مخبري كمي بعد التطعيم للتأكد من المناعة الوقائية (≥10 mIU/mL).',
            dueDate,
            sourceDate: lastCompletedHbDate,
            emp
          });
        }
      }

      // 3. VARICELLA (CHICKENPOX) DOSE 2 (4 weeks / 28 days after Dose 1)
      const varD1 = parseDateSafe(v.varicellaDose1Date || (v.varicella && v.varicella.dose1Date));
      const varD2 = parseDateSafe(v.varicellaDose2Date || (v.varicella && v.varicella.dose2Date));
      if (varD1 && !varD2) {
        const dueDate = addDays(varD1, 28);
        rawItems.push({
          id: `var_d2_${empNo}`,
          empNo,
          empName,
          dept,
          job,
          category: 'vaccine',
          subCategory: 'varicella',
          titleEn: 'Varicella (Chickenpox) — Dose 2 Due',
          titleAr: 'تطعيم الجدري المائي (Varicella) — الجرعة الثانية',
          descEn: 'Second dose due 4 weeks after Dose 1.',
          descAr: 'الجرعة الثانية مستحقة بعد 4 أسابيع من الجرعة الأولى.',
          dueDate,
          sourceDate: varD1,
          emp
        });
      }

      // 4. MMR DOSE 2 (4 weeks / 28 days after Dose 1)
      const mmrD1 = parseDateSafe(v.mmrDose1Date || (v.mmr && v.mmr.dose1Date));
      const mmrD2 = parseDateSafe(v.mmrDose2Date || (v.mmr && v.mmr.dose2Date));
      if (mmrD1 && !mmrD2) {
        const dueDate = addDays(mmrD1, 28);
        rawItems.push({
          id: `mmr_d2_${empNo}`,
          empNo,
          empName,
          dept,
          job,
          category: 'vaccine',
          subCategory: 'mmr',
          titleEn: 'MMR — Dose 2 Due',
          titleAr: 'تطعيم الحصبة والنكاف والحصبة الألمانية (MMR) — الجرعة الثانية',
          descEn: 'Second dose due 4 weeks after Dose 1.',
          descAr: 'الجرعة الثانية مستحقة بعد 4 أسابيع من الجرعة الأولى.',
          dueDate,
          sourceDate: mmrD1,
          emp
        });
      }

      // 5. TUBERCULIN (PPD / MANTOUX) 48-72 HOUR READING
      const ppdPlacedDate = parseDateSafe(l.ppdDate || l.ppdPlacedDate || (l.ppd && l.ppd.date));
      const ppdResult = l.ppdResult || (l.ppd && l.ppd.result);
      if (ppdPlacedDate && (!ppdResult || ppdResult.trim() === '')) {
        const daysSincePlacement = getDaysDifference(today, ppdPlacedDate);
        if (daysSincePlacement >= 0 && daysSincePlacement <= 14) {
          const dueDate = addDays(ppdPlacedDate, 2); // 48 hours
          rawItems.push({
            id: `ppd_reading_${empNo}`,
            empNo,
            empName,
            dept,
            job,
            category: 'test',
            subCategory: 'ppd',
            titleEn: 'PPD Tuberculin Skin Test Reading (48–72 Hours)',
            titleAr: 'قراءة فحص التدرن الجلدي (PPD Mantoux Reading)',
            descEn: 'Mandatory clinical reading of induration in mm within 48 to 72 hours of placement.',
            descAr: 'قراءة سريرية إلزامية لقطر التصلب (مم) خلال 48 إلى 72 ساعة من الحقن.',
            dueDate,
            sourceDate: ppdPlacedDate,
            emp
          });
        }
      }

      // 6. CUSTOM SCHEDULED CLINICAL APPOINTMENTS (STAFF CLINIC VISITS / TESTS)
      if (Array.isArray(emp.customFollowups)) {
        emp.customFollowups.forEach((cf, idx) => {
          // Exclude any vaccine expiry on staff members (vaccine expiry is strictly managed under General Vaccine Stock)
          if (cf.category === 'vaccine_expiry' || cf.category === 'expiry' || cf.isExpiry || cf.expireDate || cf.subCategory === 'expiry') return;
          const ct = ((cf.title || '') + ' ' + (cf.titleEn || '') + ' ' + (cf.titleAr || '') + ' ' + (cf.notes || '')).toLowerCase();
          if (ct.includes('10-year') || ct.includes('vaccine expired') || ct.includes('booster due') || ct.includes('vaccine expire') || ct.includes('ط§ظ†طھظ‡ط§ط،') || ct.includes('طµظ„ط§ط­ظٹط©')) return;
          const targetDateStr = cf.dueDate;
          if (targetDateStr) {
            const cfDate = parseDateSafe(targetDateStr);
            if (cfDate) {
              const titleEn = cf.titleEn || cf.title || 'Clinical Follow-up Appointment';
              const titleAr = cf.titleAr || cf.title || 'موعد متابعة سريرية مخصص';
              const descEn = cf.notes || 'Scheduled in-clinic follow-up.';
              const descAr = cf.notes || 'موعد متابعة مسجل في العيادة.';

              rawItems.push({
                id: cf.id || `custom_${empNo}_${idx}`,
                empNo,
                empName,
                dept,
                job,
                category: cf.category || 'test',
                subCategory: 'custom',
                titleEn,
                titleAr,
                descEn,
                descAr,
                dueDate: cfDate,
                sourceDate: parseDateSafe(cf.adminDate) || cfDate,
                isCustom: true,
                isExpiry: false,
                customItem: cf,
                emp
              });
            }
          }
        });
      }
    });

        // ------------------------------------------------------------------------
    // A.2 STANDALONE VACCINATION EXPIRATION RECORDS (NO STAFF NAME REQUIRED)
    // ------------------------------------------------------------------------
    ensureStandardVaccineStockInitialized();
    const standaloneExpiries = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    if (Array.isArray(standaloneExpiries)) {
      standaloneExpiries.forEach((ve, idx) => {
        const targetDateStr = ve.expireDate || ve.dueDate;
        if (targetDateStr) {
          const cfDate = parseDateSafe(targetDateStr);
          if (cfDate) {
            const vName = ve.vaccineName || 'Vaccine';
            const titleEn = ve.title || `${vName} — Expire Date & Booster Due`;
            const titleAr = ve.titleAr || `انتهاء صلاحية تطعيم ${vName} واستحقاق الجرعة المنشطة`;
            const remDate = ve.reminderDate || formatDateISO(addDays(cfDate, -(ve.reminderDays || 15)));
            const daysRemaining = getDaysDifference(cfDate, today);
            const is15DayAlert = (daysRemaining <= (ve.reminderDays || 15) && daysRemaining >= 0);

            const descEn = `Vaccine Expiry: ${ve.expireDate}${ve.vaccineLot ? ' • Lot: ' + ve.vaccineLot : ''}${ve.adminDate ? ' • Admin: ' + ve.adminDate : ''}. 15-Day Alert Reminder on ${remDate}.`;
            const descAr = `تاريخ انتهاء الصلاحية: ${ve.expireDate}${ve.vaccineLot ? ' • التشغيلة: ' + ve.vaccineLot : ''}${ve.adminDate ? ' • أُعطي بتاريخ: ' + ve.adminDate : ''}. تنبيه مسبق قبل 15 يوماً (${remDate}).`;

            rawItems.push({
              id: ve.id || `standalone_ve_${idx}`,
              empNo: 'GENERAL',
              empName: (window.i18n && window.i18n.isRTL()) ? 'مستودع اللقاحات / عام' : 'General Vaccine Stock',
              dept: (window.i18n && window.i18n.isRTL()) ? 'الصحة المهنية واللقاحات' : 'Occupational Health & Vaccines',
              job: (window.i18n && window.i18n.isRTL()) ? 'مخزون التطعيمات' : 'Vaccine Supply / Clinic',
              category: 'vaccine_expiry',
              subCategory: 'expiry',
              titleEn,
              titleAr,
              descEn,
              descAr,
              dueDate: cfDate,
              sourceDate: parseDateSafe(ve.adminDate) || cfDate,
              expireDate: ve.expireDate,
              reminderDate: remDate,
              reminderDays: ve.reminderDays || 15,
              reminderActive: ve.reminderActive !== false,
              is15DayAlert: is15DayAlert,
              vaccineName: ve.vaccineName || '',
              vaccineLot: ve.vaccineLot || '',
              isCustom: true,
              isExpiry: true,
              isStandalone: true,
              isCompleted: !!ve.completed,
              isCancelled: !!ve.cancelled,
              cancelledData: ve.cancelled ? { reason: ve.cancelledReason, notes: ve.cancelledNotes } : null,
              customItem: ve
            });
          }
        }
      });
    }

    // ------------------------------------------------------------------------
    // B. OCCUPATIONAL INJURY & SHARPS EXPOSURE PROTOCOL (PEP SQE 02.01)
    // ------------------------------------------------------------------------
    injuries.forEach(inj => {
      const p1 = inj.part1 || {};
      const empNo = p1.empNo || p1.fileNo || inj.empNo || '';
      const empName = p1.name || inj.empName || 'Injured Staff';
      const dept = p1.department || inj.department || 'Clinical';
      const serial = p1.serialNo || inj.id || 'INC-REPORT';
      const incidentDate = parseDateSafe(p1.dateTime || p1.incidentDate || inj.date);

      if (incidentDate) {
        // 6-Week Serology Check (HBsAg, HCV Ab, HIV Ab)
        const d6w = addDays(incidentDate, 42);
        rawItems.push({
          id: `pep_6w_${serial}`,
          empNo,
          empName,
          dept,
          job: p1.position || 'Staff',
          category: 'test',
          subCategory: 'pep',
          titleEn: `PEP 6-Week Serology Follow-up (${serial})`,
          titleAr: `متابعة تحاليل وخز الإبر بعد 6 أسابيع (${serial})`,
          descEn: 'Protocol testing: Repeat HBsAg, HCV Ab, and HIV rapid screen 6 weeks post-exposure.',
          descAr: 'بروتوكول السلامة المهنية: إعادة فحوصات الكبد B وC والإيدز بعد 6 أسابيع من الحادث.',
          dueDate: d6w,
          sourceDate: incidentDate,
          injurySerial: serial,
          injury: inj
        });

        // 3-Month Serology Check (HCV Ab, HIV Ab)
        const d3m = addDays(incidentDate, 90);
        rawItems.push({
          id: `pep_3m_${serial}`,
          empNo,
          empName,
          dept,
          job: p1.position || 'Staff',
          category: 'test',
          subCategory: 'pep',
          titleEn: `PEP 3-Month Serology Follow-up (${serial})`,
          titleAr: `متابعة تحاليل وخز الإبر بعد 3 أشهر (${serial})`,
          descEn: 'Protocol testing: HCV Ab and HIV 3-month seroconversion assessment.',
          descAr: 'فحص الأجسام المضادة لـ HCV وHIV بعد 3 أشهر من التعرض المهني.',
          dueDate: d3m,
          sourceDate: incidentDate,
          injurySerial: serial,
          injury: inj
        });

        // 6-Month Final Serology Check
        const d6m = addDays(incidentDate, 180);
        rawItems.push({
          id: `pep_6m_${serial}`,
          empNo,
          empName,
          dept,
          job: p1.position || 'Staff',
          category: 'test',
          subCategory: 'pep',
          titleEn: `PEP 6-Month Final Clearance (${serial})`,
          titleAr: `الفحص النهائي لخلو العدوى بعد 6 أشهر (${serial})`,
          descEn: 'Final clearance serology protocol testing (6 months post-exposure).',
          descAr: 'الفحص المخبري الختامي لإغلاق ملف حادثة الوخز والتأكد من خلو العدوى تماماً.',
          dueDate: d6m,
          sourceDate: incidentDate,
          injurySerial: serial,
          injury: inj
        });
      }
    });

    // ------------------------------------------------------------------------
    // C. APPLY DISPOSITIONS (Completed, Rescheduled, Cancelled Due to Reason)
    // ------------------------------------------------------------------------
    const followups = [];

    rawItems.forEach(item => {
      let isCompleted = false;
      let isCancelled = false;
      let isRescheduled = false;
      let completedData = null;
      let cancelledData = null;
      let reschedData = null;

      // Check if custom item has direct status
      if (item.customItem) {
        if (item.customItem.completed) {
          isCompleted = true;
          completedData = {
            date: item.customItem.completedDate || item.customItem.dueDate,
            notes: item.customItem.completedNotes || item.customItem.notes,
            result: item.customItem.completedResult || ''
          };
        } else if (item.customItem.status === 'cancelled') {
          isCancelled = true;
          cancelledData = {
            reason: item.customItem.cancelledDue || 'Cancelled per clinic order',
            notes: item.customItem.cancelledNotes || item.customItem.notes,
            date: item.customItem.cancelledAt
          };
        }
      }

      // Check employee followupDispositions store
      const emp = item.emp;
      if (emp && emp.followupDispositions && emp.followupDispositions[item.id]) {
        const disp = emp.followupDispositions[item.id];
        if (disp.status === 'completed') {
          isCompleted = true;
          completedData = disp;
        } else if (disp.status === 'cancelled') {
          isCancelled = true;
          cancelledData = disp;
        } else if (disp.status === 'rescheduled') {
          isRescheduled = true;
          reschedData = disp;
          const newD = parseDateSafe(disp.newDueDate);
          if (newD) {
            item.originalDueDate = item.dueDate;
            item.dueDate = newD;
          }
        }
      }

      // Check injury followupDispositions store
      const inj = item.injury;
      if (inj && inj.followupDispositions && inj.followupDispositions[item.id]) {
        const disp = inj.followupDispositions[item.id];
        if (disp.status === 'completed') {
          isCompleted = true;
          completedData = disp;
        } else if (disp.status === 'cancelled') {
          isCancelled = true;
          cancelledData = disp;
        } else if (disp.status === 'rescheduled') {
          isRescheduled = true;
          reschedData = disp;
          const newD = parseDateSafe(disp.newDueDate);
          if (newD) {
            item.originalDueDate = item.dueDate;
            item.dueDate = newD;
          }
        }
      }

      item.dueDateStr = formatDateISO(item.dueDate);
      item.isCompleted = isCompleted;
      item.completedData = completedData;
      item.isCancelled = isCancelled;
      item.cancelledData = cancelledData;
      item.isRescheduled = isRescheduled;
      item.reschedData = reschedData;

      // Status calculation
      if (isCompleted) {
        item.status = 'completed';
        item.diffDays = 0;
      } else if (isCancelled) {
        item.status = 'cancelled';
        item.diffDays = 0;
      } else {
        const diff = getDaysDifference(item.dueDate, today);
        if (diff < 0) {
          item.status = 'overdue';
          item.diffDays = Math.abs(diff);
        } else if (diff === 0) {
          item.status = 'today';
          item.diffDays = 0;
        } else {
          item.status = 'upcoming';
          item.diffDays = diff;
        }
      }

      followups.push(item);
    });

    // Sort: overdue first, then today, then upcoming nearest, then completed/cancelled
    followups.sort((a, b) => {
      const order = { overdue: 1, today: 2, upcoming: 3, completed: 4, cancelled: 5 };
      const statusDiff = (order[a.status] || 99) - (order[b.status] || 99);
      if (statusDiff !== 0) return statusDiff;
      return a.dueDate.getTime() - b.dueDate.getTime();
    });

    return followups;
  }

  // --------------------------------------------------------------------------
  // 2. MAIN RENDERER FUNCTION
  // --------------------------------------------------------------------------
  function renderFollowupCalendar(container) {
    if (!container) return;
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const allFollowups = extractAllClinicalFollowups();

    // Active follow-ups only (excluding completed & cancelled) for main calendar & counts
    const activeFollowups = allFollowups.filter(f => !f.isCompleted && !f.isCancelled);

    // Calculate metrics
    const overdueCount = activeFollowups.filter(f => f.status === 'overdue').length;
    const todayCount = activeFollowups.filter(f => f.status === 'today').length;
    const weekCount = activeFollowups.filter(f => f.status === 'upcoming' && f.diffDays <= 7).length;
    const monthCount = activeFollowups.filter(f => {
      const d = f.dueDate;
      return d.getMonth() === currentCalDate.getMonth() && d.getFullYear() === currentCalDate.getFullYear();
    }).length;
    const completedCount = allFollowups.filter(f => f.isCompleted).length;
    const cancelledCount = allFollowups.filter(f => f.isCancelled).length;

    // Standalone General Vaccine Stock Metrics & 15-Day Alert Count
    const expiryStockItems = allFollowups.filter(f => f.category === 'vaccine_expiry' || f.isExpiry || !!f.expireDate);
    const activeExpiryStock = expiryStockItems.filter(f => !f.isCompleted && !f.isCancelled);
    const expiryStockCount = activeExpiryStock.length;
    const alert15Count = activeExpiryStock.filter(f => f.is15DayAlert).length;

    // Filter list based on selected tab/type
    let filtered = [];
    if (currentCalFilter === 'completed') {
      filtered = allFollowups.filter(f => f.isCompleted);
    } else if (currentCalFilter === 'cancelled') {
      filtered = allFollowups.filter(f => f.isCancelled);
    } else {
      filtered = activeFollowups;
      if (currentCalFilter === 'vaccine') {
        filtered = filtered.filter(f => f.category === 'vaccine');
      } else if (currentCalFilter === 'expiry') {
        filtered = filtered.filter(f => f.category === 'vaccine_expiry' || f.subCategory === 'expiry' || f.isExpiry || !!f.expireDate);
      } else if (currentCalFilter === 'test') {
        filtered = filtered.filter(f => f.category === 'test');
      } else if (currentCalFilter === 'overdue') {
        filtered = filtered.filter(f => f.status === 'overdue');
      }
    }

    // Strict separation: Clinical Appointments (agenda view) MUST NEVER show vaccine stock expirations
    if (currentCalView === 'agenda' && currentCalFilter !== 'expiry') {
      filtered = filtered.filter(f => !f.isExpiry && f.category !== 'vaccine_expiry' && !f.expireDate && f.subCategory !== 'expiry');
    }

    if (currentCalDeptFilter !== 'all') {
      filtered = filtered.filter(f => f.dept === currentCalDeptFilter);
    }

    if (currentSearchQuery && currentSearchQuery.trim() !== '') {
      const q = currentSearchQuery.toLowerCase().trim();
      filtered = filtered.filter(f => 
        (f.empName && f.empName.toLowerCase().includes(q)) ||
        (f.empNo && f.empNo.toLowerCase().includes(q)) ||
        (f.titleEn && f.titleEn.toLowerCase().includes(q)) ||
        (f.titleAr && f.titleAr.includes(q)) ||
        (f.dept && f.dept.toLowerCase().includes(q)) ||
        (f.cancelledData && f.cancelledData.reason && f.cancelledData.reason.toLowerCase().includes(q))
      );
    }

    // Extract unique departments for filter dropdown
    const depts = Array.from(new Set(allFollowups.map(f => f.dept).filter(Boolean))).sort();

    const monthNamesEn = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthNamesAr = ['يناير (1)', 'فبراير (2)', 'مارس (3)', 'أبريل (4)', 'مايو (5)', 'يونيو (6)', 'يوليو (7)', 'أغسطس (8)', 'سبتمبر (9)', 'أكتوبر (10)', 'نوفمبر (11)', 'ديسمبر (12)'];
    const curMonthName = isAr ? monthNamesAr[currentCalDate.getMonth()] : monthNamesEn[currentCalDate.getMonth()];
    const curYear = currentCalDate.getFullYear();

    container.innerHTML = `
      <div class="calendar-module-container" style="padding: 10px 4px 40px 4px;">
        <!-- TOP BRAND BANNER -->
        <div class="card" style="background: linear-gradient(135deg, #0D5C75 0%, #00838F 100%); color: white; padding: 22px 28px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.12); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
          <div>
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 6px;">
              <span style="font-size: 2rem;">📅</span>
              <h2 style="margin: 0; font-size: 1.55rem; font-weight: 800; letter-spacing: -0.02em;">
                ${isAr ? 'تقويم المتابعات السريرية والفحوصات المعادة' : 'Clinical Follow-up & Repeat Test Calendar'}
              </h2>
            </div>
            <p style="margin: 0; opacity: 0.9; font-size: 0.92rem;">
              ${isAr 
                ? 'إدارة مواعيد استكمال التطعيمات، إعادة تحاليل Anti-HBs، قراءات PPD، وحوادث PEP، مع إمكانية الإتمام المباشر، حجز موعد جديد، أو إلغاء الموعد بسبب موثق.' 
                : 'Manage vaccine doses, repeat titers, PPD readings & PEP protocols. Complete actions, schedule new appointments, or record cancellations.'}
            </p>
          </div>

          <!-- Hospital Badge (Clean & Elegant Header, No Button Clutter) -->
          <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <div style="background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); border-radius: 8px; padding: 8px 16px; display: flex; align-items: center; gap: 10px; backdrop-filter: blur(4px);">
              <span style="font-size: 1.3rem;">🏥</span>
              <div>
                <div style="font-size: 0.74rem; opacity: 0.85; text-transform: uppercase; font-weight: 700; letter-spacing: 0.03em;">
                  ${isAr ? 'عيادة السلامة والصحة المهنية' : 'Occupational Health Clinic'}
                </div>
                <div style="font-size: 0.95rem; font-weight: 800;">
                  ${isAr ? 'مستشفى المُطلع - القدس' : 'Augusta Victoria Hospital'}
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- LIVE SUMMARY KPI STATS (CLICK ANY CARD TO VIEW STAFF LIST FOR THE MONTH) -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 22px;">
          <!-- Card 1: Overdue -->
          <div class="card stat-card-cal" title="${isAr ? 'اضغط لعرض قائمة الكوادر المتأخرة لهذا الشهر' : 'Click to view overdue staff list for this month'}" style="background: white; border: 1.5px solid ${currentCalFilter === 'overdue' ? '#DC2626' : '#FCA5A5'}; border-radius: 10px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);" onclick="openCategoryStaffRosterModal('overdue')">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 0.8rem; font-weight: 700; color: #DC2626; text-transform: uppercase;">
                  ⚠️ ${isAr ? 'متأخرة (Overdue)' : 'Overdue'}
                </div>
                <div style="font-size: 1.85rem; font-weight: 800; color: #991B1B; margin-top: 4px;">
                  ${overdueCount}
                </div>
              </div>
              <span style="font-size: 1.8rem;">🔴</span>
            </div>
            <div style="font-size: 0.76rem; color: #7F1D1D; margin-top: 4px; display: flex; justify-content: space-between;">
              <span>${isAr ? 'تتطلب إجراءً عاجلاً' : 'Action required'}</span>
              <span style="text-decoration: underline; font-weight: 700;">${isAr ? 'عرض الكوادر ↗' : 'View Staff ↗'}</span>
            </div>
          </div>

          <!-- Card 2: Due Today -->
          <div class="card stat-card-cal" title="${isAr ? 'اضغط لعرض قائمة الكوادر المستحقة اليوم' : 'Click to view staff due today in clinic'}" style="background: white; border: 1.5px solid #93C5FD; border-radius: 10px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);" onclick="openCategoryStaffRosterModal('today')">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 0.8rem; font-weight: 700; color: #0284C7; text-transform: uppercase;">
                  🎯 ${isAr ? 'مستحقة اليوم' : 'Due Today'}
                </div>
                <div style="font-size: 1.85rem; font-weight: 800; color: #0369A1; margin-top: 4px;">
                  ${todayCount}
                </div>
              </div>
              <span style="font-size: 1.8rem;">🔵</span>
            </div>
            <div style="font-size: 0.76rem; color: #075985; margin-top: 4px; display: flex; justify-content: space-between;">
              <span>${isAr ? 'مواعيد العيادة لليوم' : 'In clinic today'}</span>
              <span style="text-decoration: underline; font-weight: 700;">${isAr ? 'عرض الكوادر ↗' : 'View Staff ↗'}</span>
            </div>
          </div>

          <!-- Card 3: Due This Week -->
          <div class="card stat-card-cal" title="${isAr ? 'اضغط لعرض قائمة الكوادر المستحقة خلال 7 أيام' : 'Click to view staff due in next 7 days'}" style="background: white; border: 1.5px solid #FDE68A; border-radius: 10px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);" onclick="openCategoryStaffRosterModal('week')">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 0.8rem; font-weight: 700; color: #D97706; text-transform: uppercase;">
                  🗓️ ${isAr ? 'خلال 7 أيام' : 'Next 7 Days'}
                </div>
                <div style="font-size: 1.85rem; font-weight: 800; color: #B45309; margin-top: 4px;">
                  ${weekCount}
                </div>
              </div>
              <span style="font-size: 1.8rem;">🟡</span>
            </div>
            <div style="font-size: 0.76rem; color: #92400E; margin-top: 4px; display: flex; justify-content: space-between;">
              <span>${isAr ? 'جاهزة للتواصل' : 'Upcoming'}</span>
              <span style="text-decoration: underline; font-weight: 700;">${isAr ? 'عرض الكوادر ↗' : 'View Staff ↗'}</span>
            </div>
          </div>

          <!-- Card 4: Month Active Total -->
          <div class="card stat-card-cal" title="${isAr ? `اضغط لعرض كافة استحقاقات الكوادر لشهر ${curMonthName}` : `Click to view all staff due in ${curMonthName}`}" style="background: white; border: 1.5px solid #A7F3D0; border-radius: 10px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);" onclick="openCategoryStaffRosterModal('month')">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 0.8rem; font-weight: 700; color: #059669; text-transform: uppercase;">
                  📅 ${isAr ? `إجمالي ${curMonthName}` : `${curMonthName}`}
                </div>
                <div style="font-size: 1.85rem; font-weight: 800; color: #065F46; margin-top: 4px;">
                  ${monthCount}
                </div>
              </div>
              <span style="font-size: 1.8rem;">🟢</span>
            </div>
            <div style="font-size: 0.76rem; color: #064E3B; margin-top: 4px; display: flex; justify-content: space-between;">
              <span>${isAr ? 'استحقاقات الشهر' : 'Total in month'}</span>
              <span style="text-decoration: underline; font-weight: 700;">${isAr ? 'عرض الكوادر ↗' : 'View Staff ↗'}</span>
            </div>
          </div>

          <!-- Card 5: Completed History -->
          <div class="card stat-card-cal" title="${isAr ? 'اضغط لعرض قائمة المواعيد المكتملة لهذا الشهر' : 'Click to view completed staff follow-ups for this month'}" style="background: white; border: 1.5px solid ${currentCalFilter === 'completed' ? '#16A34A' : '#CBD5E1'}; border-radius: 10px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);" onclick="openCategoryStaffRosterModal('completed')">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 0.8rem; font-weight: 700; color: #16A34A; text-transform: uppercase;">
                  ✅ ${isAr ? 'مكتملة (Done)' : 'Completed'}
                </div>
                <div style="font-size: 1.85rem; font-weight: 800; color: #15803D; margin-top: 4px;">
                  ${completedCount}
                </div>
              </div>
              <span style="font-size: 1.8rem;">✔️</span>
            </div>
            <div style="font-size: 0.76rem; color: #14532D; margin-top: 4px; display: flex; justify-content: space-between;">
              <span>${isAr ? 'تم إنجازها بنجاح' : 'Recorded & logged'}</span>
              <span style="text-decoration: underline; font-weight: 700;">${isAr ? 'عرض السجل ↗' : 'View Records ↗'}</span>
            </div>
          </div>

          <!-- Card 6: Cancelled History -->
          <div class="card stat-card-cal" title="${isAr ? 'اضغط لعرض قائمة المواعيد الملغاة لهذا الشهر مع الأسباب' : 'Click to view cancelled follow-ups with reasons for this month'}" style="background: white; border: 1.5px solid ${currentCalFilter === 'cancelled' ? '#64748B' : '#E2E8F0'}; border-radius: 10px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);" onclick="openCategoryStaffRosterModal('cancelled')">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 0.8rem; font-weight: 700; color: #64748B; text-transform: uppercase;">
                  ❌ ${isAr ? 'ملغاة بسبب...' : 'Cancelled Due'}
                </div>
                <div style="font-size: 1.85rem; font-weight: 800; color: #475569; margin-top: 4px;">
                  ${cancelledCount}
                </div>
              </div>
              <span style="font-size: 1.8rem;">🚫</span>
            </div>
            <div style="font-size: 0.76rem; color: #475569; margin-top: 4px; display: flex; justify-content: space-between;">
              <span>${isAr ? 'مع بيان السبب السريري' : 'With recorded reason'}</span>
              <span style="text-decoration: underline; font-weight: 700;">${isAr ? 'عرض السجل ↗' : 'View Records ↗'}</span>
            </div>
          </div>

          <!-- Card 7: Dedicated Vaccine Expiry Stock KPI Card -->
          <div class="card stat-card-cal" title="${isAr ? 'اضغط لعرض تواريخ انتهاء تشغيلات اللقاحات ومخزون المستودع' : 'Click to view Vaccine Batch Expire Date'}" style="background: white; border: 1.5px solid ${currentCalView === 'expiry' ? '#D97706' : (alert15Count > 0 ? '#F59E0B' : '#FDE68A')}; border-radius: 10px; padding: 14px 16px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);" onclick="setCalendarView('expiry')">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 0.8rem; font-weight: 700; color: #B45309; text-transform: uppercase; display: flex; align-items: center; gap: 4px;">
                  ⏳ ${isAr ? 'تاريخ انتهاء تشغيلة اللقاح' : 'Vaccine Batch Expire Date'}
                  ${alert15Count > 0 ? `<span style="font-size: 0.68rem; background: #DC2626; color: white; padding: 1px 6px; border-radius: 10px; font-weight: 800;">${alert15Count} ⚠️</span>` : ''}
                </div>
                <div style="font-size: 1.85rem; font-weight: 800; color: #92400E; margin-top: 4px;">
                  ${expiryStockCount}
                </div>
              </div>
              <span style="font-size: 1.8rem;">📦</span>
            </div>
            <div style="font-size: 0.76rem; color: #78350F; margin-top: 4px; display: flex; justify-content: space-between;">
              <span>${alert15Count > 0 ? (isAr ? `${alert15Count} تشغيلة قاربت على الانتهاء` : `${alert15Count} nearing expiry`) : (isAr ? 'مستودع تشغيلات اللقاحات العام' : 'General Vaccine Batch Stock')}</span>
              <span style="text-decoration: underline; font-weight: 700;">${isAr ? 'عرض القائمة ↗' : 'View List ↗'}</span>
            </div>
          </div>
        </div>

        <!-- CONTROL & FILTER TOOLBAR -->
        <div class="card" style="background: white; border: 1px solid #E2E8F0; border-radius: 10px; padding: 14px 18px; margin-bottom: 20px;">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
            <!-- Left: View Switcher (Month Grid vs Clinical Appointments vs Vaccine Batch Expire Date) -->
            <div style="display: inline-flex; background: #F1F5F9; padding: 4px; border-radius: 8px; border: 1px solid #CBD5E1;">
              <button type="button" class="btn" style="padding: 6px 14px; font-size: 0.85rem; font-weight: 700; border: none; border-radius: 6px; ${currentCalView === 'month' ? 'background: #0D5C75; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="setCalendarView('month')">
                📅 ${isAr ? 'تقويم شهري' : 'Month Grid'}
              </button>
              <button type="button" class="btn" style="padding: 6px 14px; font-size: 0.85rem; font-weight: 700; border: none; border-radius: 6px; ${currentCalView === 'agenda' ? 'background: #0D5C75; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="setCalendarView('agenda')">
                📋 ${isAr ? 'جدول المواعيد السريرية' : 'Clinical Appointments'}
              </button>
              <button type="button" class="btn" style="padding: 6px 14px; font-size: 0.85rem; font-weight: 700; border: none; border-radius: 6px; ${currentCalView === 'expiry' ? 'background: #D97706; color: white; box-shadow: 0 2px 4px rgba(217,119,6,0.3);' : 'background: transparent; color: #B45309;'}" onclick="setCalendarView('expiry')">
                ⏳ ${isAr ? 'تاريخ انتهاء تشغيلة اللقاح' : 'Vaccine Batch Expire Date'}
              </button>
            </div>

            <!-- Month Navigator (Only in Month View) -->
            ${currentCalView === 'month' ? `
              <div style="display: flex; align-items: center; gap: 10px;">
                <button type="button" class="btn btn-outline" style="padding: 6px 12px; font-weight: 800; border-color: #CBD5E1;" onclick="navigateCalendarMonth(-1)">
                  ◀ ${isAr ? 'الشهر السابق' : 'Prev'}
                </button>
                <div style="font-size: 1.1rem; font-weight: 800; color: #0F172A; min-width: 170px; text-align: center;">
                  ${curMonthName} ${curYear}
                </div>
                <button type="button" class="btn btn-outline" style="padding: 6px 12px; font-weight: 800; border-color: #CBD5E1;" onclick="navigateCalendarMonth(1)">
                  ${isAr ? 'الشهر التالي' : 'Next'} ▶
                </button>
                <button type="button" class="btn btn-outline" style="padding: 6px 10px; font-size: 0.8rem; font-weight: 700; border-color: #0284C7; color: #0284C7; background: #F0F9FF;" onclick="jumpToCurrentMonth()">
                  📍 ${isAr ? 'اليوم' : 'Today'}
                </button>
              </div>
            ` : ''}

            <!-- Right: Action Buttons (Moved to Toolbar) + Type Filter & Search -->
            <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
              <!-- View-Specific Action Buttons -->
              ${currentCalView === 'expiry' ? `
                <button type="button" class="btn" style="background: #D97706; color: white; border: none; font-weight: 700; padding: 6px 12px; border-radius: 6px; font-size: 0.84rem; box-shadow: 0 2px 4px rgba(217,119,6,0.3); display: inline-flex; align-items: center; gap: 5px;" onclick="openScheduleCustomModal(false, 'vaccine_expiry')">
                  <span>➕</span> <span>${isAr ? 'إضافة تشغيلة لقاح' : 'Add Vaccine Batch'}</span>
                </button>
                <button type="button" class="btn btn-outline" style="background: white; color: #78350F; border: 1.5px solid #F59E0B; font-weight: 700; padding: 6px 12px; border-radius: 6px; font-size: 0.84rem; display: inline-flex; align-items: center; gap: 5px;" onclick="printVaccineExpiryList()">
                  <span>🖨️</span> <span>${isAr ? 'طباعة الكشف' : 'Print Expiry List'}</span>
                </button>
                <button type="button" class="btn btn-outline" style="background: #16A34A; color: white; border-color: #16A34A; font-weight: 700; padding: 6px 12px; border-radius: 6px; font-size: 0.84rem; display: inline-flex; align-items: center; gap: 5px;" onclick="exportVaccineExpiryToExcel()">
                  <span>📊</span> <span>${isAr ? 'تصدير إكسل' : 'Export to Excel'}</span>
                </button>
                <button type="button" class="btn btn-outline" style="background: #FEF2F2; color: #DC2626; border: 1.5px solid #FCA5A5; font-weight: 700; padding: 6px 12px; border-radius: 6px; font-size: 0.84rem; display: inline-flex; align-items: center; gap: 5px;" onclick="clearAllVaccineExpiries()" title="${isAr ? 'حذف وتفريغ كافة التشغيلات للبدء من جديد' : 'Delete all batch records to enter valid data'}">
                  <span>🗑️</span> <span>${isAr ? 'حذف كافة البيانات' : 'Delete All Batches'}</span>
                </button>
              ` : `
                <button type="button" class="btn" style="background: #0D5C75; color: white; border: none; font-weight: 700; padding: 6px 12px; border-radius: 6px; font-size: 0.84rem; box-shadow: 0 2px 4px rgba(13,92,117,0.25); display: inline-flex; align-items: center; gap: 5px;" onclick="openScheduleCustomModal()">
                  <span>➕</span> <span>${isAr ? 'حجز موعد سريري' : 'Schedule Follow-up'}</span>
                </button>
                <button type="button" class="btn btn-outline" style="background: white; color: #0D5C75; border: 1.5px solid #0D5C75; font-weight: 700; padding: 6px 12px; border-radius: 6px; font-size: 0.84rem; display: inline-flex; align-items: center; gap: 5px;" onclick="printCalendarSchedule()">
                  <span>🖨️</span> <span>${isAr ? 'طباعة الكشف' : 'Print Schedule'}</span>
                </button>
                <button type="button" class="btn btn-outline" style="background: #16A34A; color: white; border-color: #16A34A; font-weight: 700; padding: 6px 12px; border-radius: 6px; font-size: 0.84rem; display: inline-flex; align-items: center; gap: 5px;" onclick="exportFollowupsToExcel()">
                  <span>📊</span> <span>${isAr ? 'تصدير إكسل' : 'Export to Excel'}</span>
                </button>
              `}

              <!-- Divider -->
              <span style="display: inline-block; width: 1px; height: 22px; background: #CBD5E1; margin: 0 2px;"></span>

              <!-- Type Filter -->
              ${currentCalView !== 'expiry' ? `
                <div style="display: flex; align-items: center; gap: 4px;">
                  <select id="cal_type_filter" style="padding: 6px 10px; font-size: 0.84rem; border: 1.5px solid #CBD5E1; border-radius: 6px; background: white; font-weight: 600;" onchange="setCalendarFilter(this.value)">
                    <option value="all" ${currentCalFilter === 'all' ? 'selected' : ''}>${isAr ? '🌟 النشطة (الكل)' : 'Active Follow-ups (All)'}</option>
                    <option value="vaccine" ${currentCalFilter === 'vaccine' ? 'selected' : ''}>💉 ${isAr ? 'تطعيمات فقط' : 'Vaccinations Only'}</option>
                    <option value="test" ${currentCalFilter === 'test' ? 'selected' : ''}>🧪 ${isAr ? 'فحوصات معادة' : 'Lab Tests Only'}</option>
                    <option value="overdue" ${currentCalFilter === 'overdue' ? 'selected' : ''}>⚠️ ${isAr ? 'المتأخرات فقط' : 'Overdue Only'}</option>
                    <option value="completed" ${currentCalFilter === 'completed' ? 'selected' : ''}>✅ ${isAr ? 'سجل المكتملة' : 'Completed History'}</option>
                    <option value="cancelled" ${currentCalFilter === 'cancelled' ? 'selected' : ''}>❌ ${isAr ? 'سجل الملغاة بسبب' : 'Cancelled Due History'}</option>
                  </select>
                </div>
              ` : ''}

              <!-- Quick Search Input -->
              <input type="text" id="cal_search_input" value="${currentSearchQuery || ''}" placeholder="${isAr ? 'بحث بالاسم، الرقم، القسم، الفحص...' : 'Search Name, Emp No, Department, Action...'}" style="padding: 6px 12px; font-size: 0.84rem; border: 1.5px solid #CBD5E1; border-radius: 6px; width: ${currentCalView === 'month' ? '170px' : '200px'};" oninput="handleCalendarSearchInput(this.value)" />
            </div>
          </div>
        </div>

        <!-- MAIN CALENDAR VIEW AREA -->
        <div id="calendarMainViewArea">
          ${currentCalView === 'month' 
            ? renderMonthGridHTML(activeFollowups, isAr) 
            : (currentCalView === 'expiry' 
                ? renderVaccineExpiryListHTML(isAr) 
                : renderAgendaListHTML(filtered, isAr))}
        </div>

        <!-- MODAL CONTAINER FOR DAY ROSTER, ACTIONS & CUSTOM SCHEDULING -->
        <div id="calendarModalContainer"></div>
      </div>
    `;
  }
  window.renderFollowupCalendar = renderFollowupCalendar;

  // --------------------------------------------------------------------------
  // 3. MONTH GRID VIEW GENERATOR
  // --------------------------------------------------------------------------
  function renderMonthGridHTML(activeFollowups, isAr) {
    const year = currentCalDate.getFullYear();
    const month = currentCalDate.getMonth();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const dayNamesEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayNamesAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const dayHeaders = isAr ? dayNamesAr : dayNamesEn;

    const firstDayIndex = new Date(year, month, 1).getDay();
    const totalDaysInMonth = new Date(year, month + 1, 0).getDate();
    const totalDaysInPrevMonth = new Date(year, month, 0).getDate();

    const followupsByDate = {};
    activeFollowups.forEach(f => {
      const key = f.dueDateStr;
      if (!followupsByDate[key]) followupsByDate[key] = [];
      followupsByDate[key].push(f);
    });

    let html = `
      <div class="card" style="background: white; border: 1px solid #CBD5E1; border-radius: 12px; padding: 16px; overflow-x: auto; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        <div style="display: grid; grid-template-columns: repeat(7, minmax(130px, 1fr)); gap: 8px; margin-bottom: 8px; text-align: center;">
          ${dayHeaders.map(name => `
            <div style="padding: 10px 4px; background: #F8FAFC; border-radius: 6px; font-weight: 800; font-size: 0.85rem; color: #334155; border: 1px solid #E2E8F0;">
              ${name}
            </div>
          `).join('')}
        </div>

        <div style="display: grid; grid-template-columns: repeat(7, minmax(130px, 1fr)); gap: 8px;">
    `;

    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const prevDayNum = totalDaysInPrevMonth - i;
      html += `
        <div style="min-height: 105px; background: #F8FAFC; border: 1px dashed #E2E8F0; border-radius: 8px; padding: 8px; opacity: 0.45;">
          <div style="font-size: 0.85rem; font-weight: 700; color: #94A3B8;">${prevDayNum}</div>
        </div>
      `;
    }

    for (let day = 1; day <= totalDaysInMonth; day++) {
      const cellDate = new Date(year, month, day);
      const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayItems = followupsByDate[dateKey] || [];
      const isToday = (today.getFullYear() === year && today.getMonth() === month && today.getDate() === day);
      const isPast = (cellDate < today);

      const vacCount = dayItems.filter(i => i.category === 'vaccine').length;
      const testCount = dayItems.filter(i => i.category === 'test').length;
      const hasOverdue = isPast && dayItems.length > 0;

      html += `
        <div class="calendar-day-cell" style="min-height: 110px; background: ${isToday ? '#EFF6FF' : '#FFFFFF'}; border: ${isToday ? '2px solid #0284C7' : (hasOverdue ? '1.5px solid #FCA5A5' : '1px solid #E2E8F0')}; border-radius: 8px; padding: 8px; position: relative; transition: all 0.15s ease; cursor: ${dayItems.length > 0 ? 'pointer' : 'default'};" ${dayItems.length > 0 ? `onclick="openDayDetailModal('${dateKey}')"` : ''} title="${dayItems.length > 0 ? (isAr ? `انقر لعرض وإجراء متابعة ${dayItems.length} موظف` : `Click to view & take action for ${dayItems.length} staff`) : ''}">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <span style="font-size: 0.95rem; font-weight: 800; color: ${isToday ? '#0284C7' : (hasOverdue ? '#DC2626' : '#1E293B')};">
              ${day} ${isToday ? (isAr ? '📍 (اليوم)' : '📍 Today') : ''}
            </span>
            ${dayItems.length > 0 ? `
              <span style="background: ${hasOverdue ? '#DC2626' : '#0D5C75'}; color: white; border-radius: 9999px; padding: 2px 7px; font-size: 0.72rem; font-weight: 800;">
                ${dayItems.length}
              </span>
            ` : ''}
          </div>

          <div style="display: flex; flex-direction: column; gap: 4px;">
            ${vacCount > 0 ? `
              <div style="background: #E0F2FE; color: #0369A1; border: 1px solid #BAE6FD; border-radius: 4px; padding: 3px 6px; font-size: 0.74rem; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                💉 ${vacCount} ${isAr ? 'تطعيم' : 'Vaccine'}${vacCount > 1 ? 's' : ''}
              </div>
            ` : ''}

            ${testCount > 0 ? `
              <div style="background: #FEF3C7; color: #92400E; border: 1px solid #FDE68A; border-radius: 4px; padding: 3px 6px; font-size: 0.74rem; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                🧪 ${testCount} ${isAr ? 'فحص معار' : 'Lab Test'}${testCount > 1 ? 's' : ''}
              </div>
            ` : ''}

            ${hasOverdue ? `
              <div style="background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; border-radius: 4px; padding: 2px 5px; font-size: 0.72rem; font-weight: 800; text-align: center;">
                ⚠️ ${isAr ? 'متأخر' : 'Overdue'}
              </div>
            ` : ''}
          </div>
        </div>
      `;
    }

    const totalRenderedCells = firstDayIndex + totalDaysInMonth;
    const remainingCells = (7 - (totalRenderedCells % 7)) % 7;
    for (let i = 1; i <= remainingCells; i++) {
      html += `
        <div style="min-height: 105px; background: #F8FAFC; border: 1px dashed #E2E8F0; border-radius: 8px; padding: 8px; opacity: 0.45;">
          <div style="font-size: 0.85rem; font-weight: 700; color: #94A3B8;">${i}</div>
        </div>
      `;
    }

    html += `
        </div>
      </div>
    `;

    return html;
  }

  // --------------------------------------------------------------------------
  // 4. AGENDA LIST VIEW GENERATOR
  // --------------------------------------------------------------------------
  function renderAgendaListHTML(followups, isAr) {
    // Safety guard: Clinical appointments list must only show clinical appointments, NEVER vaccine stock or employee expiry
    followups = (followups || []).filter(f => {
      if (f.isExpiry || f.category === 'vaccine_expiry' || f.category === 'expiry' || f.expireDate || f.subCategory === 'expiry') return false;
      const ft = ((f.titleEn || '') + ' ' + (f.titleAr || '') + ' ' + (f.descEn || '') + ' ' + (f.descAr || '')).toLowerCase();
      if (ft.includes('vaccine expire') || ft.includes('10-year') || ft.includes('booster due') || ft.includes('ط§ظ†طھظ‡ط§ط، طھط·ط¹ظٹظ…') || ft.includes('طµظ„ط§ط­ظٹط© ط§ظ„ظ„ظ‚ط§ط­')) return false;
      return true;
    });

    if (!followups || followups.length === 0) {
      return `
        <div class="card" style="background: white; border: 1px solid #E2E8F0; border-radius: 12px; padding: 40px; text-align: center; color: #64748B;">
          <span style="font-size: 3rem;">🎉</span>
          <h3 style="color: #0F172A; margin: 12px 0 6px 0;">
            ${isAr ? 'لا توجد مواعيد مطابقة لخيارات البحث أو التصفية' : 'No Follow-up Appointments Found'}
          </h3>
          <p style="margin: 0; font-size: 0.9rem;">
            ${isAr ? 'جميع الكوادر في حالة متابعة مكتملة، أو جرب تغيير معايير التصفية أعلاه.' : 'All clinical records are up-to-date or adjust the search filter.'}
          </p>
        </div>
      `;
    }

    // If viewing Completed History
    if (currentCalFilter === 'completed') {
      return `
        <div class="card" style="background: white; border: 1.5px solid #86EFAC; border-radius: 12px; padding: 18px; box-shadow: 0 4px 6px -1px rgba(22, 163, 74, 0.08);">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #DCFCE7; padding-bottom: 8px;">
            <h3 style="margin: 0; color: #15803D; font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
              ✅ ${isAr ? `سجل المتابعات والفحوصات المكتملة (${followups.length})` : `Completed Clinical Follow-ups History (${followups.length})`}
            </h3>
            <span style="font-size: 0.85rem; font-weight: 700; color: #166534; background: #DCFCE7; padding: 3px 10px; border-radius: 9999px;">
              ${isAr ? 'تم الإنجاز والتوثيق' : 'Completed & Documented'}
            </span>
          </div>
          ${renderFollowupTable(followups, isAr, false)}
        </div>
      `;
    }

    // If viewing Cancelled History
    if (currentCalFilter === 'cancelled') {
      return `
        <div class="card" style="background: white; border: 1.5px solid #CBD5E1; border-radius: 12px; padding: 18px; box-shadow: 0 4px 6px -1px rgba(100, 116, 139, 0.08);">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #E2E8F0; padding-bottom: 8px;">
            <h3 style="margin: 0; color: #475569; font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
              ❌ ${isAr ? `سجل المواعيد الملغاة مع أسباب الإلغاء (${followups.length})` : `Cancelled Follow-ups History with Reasons (${followups.length})`}
            </h3>
            <span style="font-size: 0.85rem; font-weight: 700; color: #475569; background: #F1F5F9; padding: 3px 10px; border-radius: 9999px;">
              ${isAr ? 'ملغاة مع بيان السبب' : 'Cancelled with Clinical Reason'}
            </span>
          </div>
          ${renderFollowupTable(followups, isAr, false)}
        </div>
      `;
    }

    // Active views: Group by status
    const overdues = followups.filter(f => f.status === 'overdue');
    const todayItems = followups.filter(f => f.status === 'today');
    const upcomingItems = followups.filter(f => f.status === 'upcoming');

    return `
      <div style="display: flex; flex-direction: column; gap: 20px;">
        ${overdues.length > 0 ? `
          <div class="card" style="background: white; border: 1.5px solid #FCA5A5; border-radius: 12px; padding: 18px; box-shadow: 0 4px 6px -1px rgba(220, 38, 38, 0.08);">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #FEE2E2; padding-bottom: 8px;">
              <h3 style="margin: 0; color: #DC2626; font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                ⚠️ ${isAr ? `مواعيد متأخرة (${overdues.length}) — تتطلب إجراءً سريرياً عاجلاً` : `Overdue Follow-ups (${overdues.length}) — Action Required`}
              </h3>
              <span style="font-size: 0.85rem; font-weight: 700; color: #991B1B; background: #FEE2E2; padding: 3px 10px; border-radius: 9999px;">
                ${isAr ? 'تجاوزت تاريخ الاستحقاق' : 'Past Due Date'}
              </span>
            </div>
            ${renderFollowupTable(overdues, isAr, true)}
          </div>
        ` : ''}

        ${todayItems.length > 0 ? `
          <div class="card" style="background: white; border: 1.5px solid #93C5FD; border-radius: 12px; padding: 18px; box-shadow: 0 4px 6px -1px rgba(2, 132, 199, 0.08);">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #E0F2FE; padding-bottom: 8px;">
              <h3 style="margin: 0; color: #0284C7; font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                🎯 ${isAr ? `مستحقة اليوم في العيادة (${todayItems.length})` : `Due Today in Clinic (${todayItems.length})`}
              </h3>
              <span style="font-size: 0.85rem; font-weight: 700; color: #0369A1; background: #E0F2FE; padding: 3px 10px; border-radius: 9999px;">
                ${isAr ? 'اليوم' : 'Today'}
              </span>
            </div>
            ${renderFollowupTable(todayItems, isAr, false)}
          </div>
        ` : ''}

        ${upcomingItems.length > 0 ? `
          <div class="card" style="background: white; border: 1px solid #CBD5E1; border-radius: 12px; padding: 18px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #E2E8F0; padding-bottom: 8px;">
              <h3 style="margin: 0; color: #0F172A; font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                🗓️ ${isAr ? `المواعيد القادمة (${upcomingItems.length})` : `Upcoming Follow-ups (${upcomingItems.length})`}
              </h3>
              <span style="font-size: 0.85rem; font-weight: 700; color: #475569; background: #F1F5F9; padding: 3px 10px; border-radius: 9999px;">
                ${isAr ? 'مرتبة زمنياً' : 'Chronological'}
              </span>
            </div>
            ${renderFollowupTable(upcomingItems, isAr, false)}
          </div>
        ` : ''}
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // 5. FOLLOW-UP TABLE WITH COMPLETE, NEW APPOINTMENT, & CANCELLED DUE BUTTONS
  // --------------------------------------------------------------------------
  function renderFollowupTable(items, isAr, isOverdueSection) {
    return `
      <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; font-size: 0.88rem; text-align: ${isAr ? 'right' : 'left'};">
          <thead>
            <tr style="background: #F8FAFC; border-bottom: 2px solid #E2E8F0; color: #475569; font-weight: 800;">
              <th style="padding: 10px 12px;">${isAr ? 'تاريخ الاستحقاق' : 'Due Date'}</th>
              <th style="padding: 10px 12px;">${isAr ? 'الموظف / الكادر' : 'Staff Member'}</th>
              <th style="padding: 10px 12px;">${isAr ? 'القسم / المسمى الوظيفي' : 'Department & Role'}</th>
              <th style="padding: 10px 12px;">${isAr ? 'نوع المتابعة' : 'Category'}</th>
              <th style="padding: 10px 12px;">${isAr ? 'الإجراء السريري المطلوب' : 'Action Required'}</th>
              <th style="padding: 10px 12px; text-align: center; min-width: 280px;">${isAr ? 'الإجراءات (Actions)' : 'Actions'}</th>
            </tr>
          </thead>
          <tbody>
            ${items.map(f => {
              const dateStr = formatDateDisplay(f.dueDate, isAr);
              const isExpiry = (f.category === 'vaccine_expiry' || f.isExpiry || !!f.expireDate);
              const reminderBadgeHTML = (isExpiry && f.reminderDate) 
                ? `<div style="margin-top: 4px; font-size: 0.76rem; color: #92400E; background: #FEF3C7; border: 1px solid #F59E0B; padding: 2px 7px; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px; font-weight: 700;">
                     <span>🔔</span> ${isAr ? `تنبيه مسبق قبل 15 يوماً: ${f.reminderDate}` : `15-Day Reminder Alert: ${f.reminderDate}`}
                   </div>` 
                : '';
              const badgeStyle = isExpiry
                ? 'background: #FEF3C7; color: #B45309; border: 1.5px solid #F59E0B;'
                : (f.category === 'vaccine'
                  ? 'background: #E0F2FE; color: #0369A1; border: 1px solid #BAE6FD;'
                  : (f.subCategory === 'pep' ? 'background: #FEF2F2; color: #991B1B; border: 1px solid #FCA5A5;' : 'background: #FEF3C7; color: #92400E; border: 1px solid #FDE68A;'));
              const categoryLabel = isExpiry
                ? (isAr ? '⏳ انتهاء تطعيم' : '⏳ Vaccine Expiry')
                : (f.category === 'vaccine'
                  ? (isAr ? '💉 تطعيم' : '💉 Vaccine')
                  : (f.subCategory === 'pep' ? (isAr ? '⚠️ وخز إبر PEP' : '⚠️ Sharps PEP') : (isAr ? '🧪 فحص معار' : '🧪 Repeat Test')));

              const title = isAr ? f.titleAr : f.titleEn;
              const desc = isAr ? f.descAr : f.descEn;

              return `
                <tr style="border-bottom: 1px solid #F1F5F9; transition: background 0.15s ease;" onmouseover="this.style.background='#F8FAFC'" onmouseout="this.style.background='white'">
                  <td style="padding: 12px; font-weight: 800; white-space: nowrap;">
                    <span style="color: ${f.isCompleted ? '#16A34A' : (f.isCancelled ? '#64748B' : (f.status === 'overdue' ? '#DC2626' : (f.status === 'today' ? '#0284C7' : '#0F172A')))};">
                      ${dateStr}
                    </span>
                    ${f.isRescheduled ? `<br><small style="color: #D97706; font-weight: 700;">🔄 ${isAr ? 'مؤجل / موعد جديد' : 'Rescheduled'}</small>` : ''}
                    ${(!f.isCompleted && !f.isCancelled && f.status === 'overdue') ? `<br><small style="color: #991B1B; font-weight: 700;">(${f.diffDays} ${isAr ? 'يوم تأخير' : 'days overdue'})</small>` : ''}
                    ${(!f.isCompleted && !f.isCancelled && f.status === 'today') ? `<br><small style="color: #0369A1; font-weight: 700;">(${isAr ? 'اليوم' : 'Today'})</small>` : ''}
                  </td>

                  <td style="padding: 12px;">
                    <div style="font-weight: 800; color: #0F172A;">${f.empName}</div>
                    <div style="font-size: 0.78rem; color: #64748B; font-family: monospace;">No: ${f.empNo}</div>
                  </td>

                  <td style="padding: 12px;">
                    <div style="font-weight: 700; color: #334155;">${f.dept}</div>
                    <div style="font-size: 0.78rem; color: #64748B;">${f.job}</div>
                  </td>

                  <td style="padding: 12px; white-space: nowrap;">
                    <span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 800; ${badgeStyle}">
                      ${categoryLabel}
                    </span>
                  </td>

                  <td style="padding: 12px;">
                    <div style="font-weight: 800; color: #0F172A;">${title}</div>
                    <div style="font-size: 0.78rem; color: #475569; margin-top: 2px;">${desc}</div>
                    ${f.expireDate ? `
                      <div style="margin-top: 4px; font-size: 0.76rem; color: #B45309; background: #FFFBEB; border: 1px solid #FDE68A; padding: 2px 7px; border-radius: 4px; display: inline-flex; align-items: center; gap: 4px; font-weight: 700;">
                        ⏳ ${isAr ? 'تاريخ انتهاء الصلاحية:' : 'Vaccine Expire Date:'} ${f.expireDate}${f.vaccineLot ? ' (' + (isAr ? 'تشغيلة: ' : 'Lot: ') + f.vaccineLot + ')' : ''}
                      </div>
                    ` : ''}
                    ${reminderBadgeHTML}
                    ${f.isCompleted ? `
                      <div style="margin-top: 4px; font-size: 0.76rem; color: #15803D; background: #DCFCE7; padding: 2px 6px; border-radius: 4px; display: inline-block;">
                        ✅ ${isAr ? 'أُنجز بتاريخ:' : 'Done on:'} ${formatDateDisplay(parseDateSafe(f.completedData?.date), isAr)} ${f.completedData?.result ? `(${f.completedData.result})` : ''}
                      </div>
                    ` : ''}
                    ${f.isCancelled ? `
                      <div style="margin-top: 4px; font-size: 0.76rem; color: #991B1B; background: #FEE2E2; padding: 2px 6px; border-radius: 4px; display: inline-block;">
                        ❌ ${isAr ? 'أُلغي بسبب:' : 'Cancelled due:'} ${f.cancelledData?.reason || 'Clinical Reason'}
                      </div>
                    ` : ''}
                  </td>

                  <td style="padding: 12px; text-align: center;">
                    ${f.isCompleted ? `
                      <div style="display: flex; gap: 6px; justify-content: center; align-items: center;">
                        <span style="display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: 800; background: #DCFCE7; color: #15803D; border: 1px solid #86EFAC;">
                          ✅ ${isAr ? 'مكتمل' : 'Completed'}
                        </span>
                        ${f.isStandalone ? `
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 700; border-color: #DC2626; color: #DC2626; background: #FEF2F2;" onclick="deleteStandaloneVaccineExpiry('${f.id}')" title="${isAr ? 'حذف هذا السجل' : 'Delete Record'}">
                            🗑️ ${isAr ? 'حذف' : 'Delete'}
                          </button>
                        ` : `
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 700; border-color: #0284C7; color: #0284C7; background: white;" onclick="openStaffFormsFromCalendar('${f.empNo}')" title="${isAr ? 'فتح ملف وسجل الموظف' : 'Open Staff File'}">
                            💉 ${isAr ? 'الملف' : 'Open File'}
                          </button>
                        `}
                      </div>
                    ` : (f.isCancelled ? `
                      <div style="display: flex; gap: 6px; justify-content: center; align-items: center;">
                        <span style="display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: 800; background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5;">
                          ❌ ${isAr ? 'ملغي' : 'Cancelled'}
                        </span>
                        ${f.isStandalone ? `
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 700; border-color: #DC2626; color: #DC2626; background: #FEF2F2;" onclick="deleteStandaloneVaccineExpiry('${f.id}')" title="${isAr ? 'حذف هذا السجل' : 'Delete Record'}">
                            🗑️ ${isAr ? 'حذف' : 'Delete'}
                          </button>
                        ` : `
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 700; border-color: #0284C7; color: #0284C7; background: white;" onclick="openStaffFormsFromCalendar('${f.empNo}')">
                            💉 ${isAr ? 'الملف' : 'Open File'}
                          </button>
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 700; border-color: #D97706; color: #B45309; background: #FFFBEB;" onclick="openRescheduleFollowupModal('${f.id}')" title="${isAr ? 'إعادة تفعيل وجدولة موعد جديد' : 'Re-activate / New Appt'}">
                            🔄 ${isAr ? 'إعادة جدولة' : 'Re-activate'}
                          </button>
                        `}
                      </div>
                    ` : `
                      <!-- ACTIVE FOLLOW-UP ACTIONS: OPEN FILE / DELETE | COMPLETE | NEW APPOINTMENT | CANCELLED DUE -->
                      <div style="display: flex; gap: 5px; justify-content: center; align-items: center; flex-wrap: wrap;">
                        <!-- 1. Open File OR Delete for Standalone Vaccine Stock -->
                        ${f.isStandalone ? `
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #DC2626; color: #DC2626; background: #FEF2F2;" onclick="deleteStandaloneVaccineExpiry('${f.id}')" title="${isAr ? 'حذف هذا السجل من مخزون اللقاحات' : 'Delete from General Vaccine Stock'}">
                            🗑️ ${isAr ? 'حذف' : 'Delete'}
                          </button>
                        ` : f.subCategory === 'pep' ? `
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #DC2626; color: #DC2626; background: white;" onclick="openInjuryReportFromCalendar('${f.injurySerial}')" title="${isAr ? 'فتح بلاغ الإصابة' : 'Open PEP Report'}">
                            ⚠️ ${isAr ? 'البلاغ' : 'Open PEP'}
                          </button>
                        ` : `
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #0284C7; color: #0284C7; background: white;" onclick="openStaffFormsFromCalendar('${f.empNo}')" title="${isAr ? 'فتح ملف وسجل الموظف' : 'Open Staff File'}">
                            💉 ${isAr ? 'الملف' : 'Open File'}
                          </button>
                        `}

                        <!-- 2. Complete Action -->
                        <button type="button" class="btn btn-success" style="padding: 4px 9px; font-size: 0.78rem; font-weight: 800; background: #16A34A; border-color: #16A34A; color: white;" onclick="openCompleteFollowupModal('${f.id}')" title="${isAr ? 'إتمام الإجراء / تسجيل النتيجة' : 'Complete / Record Result'}">
                          ✅ ${isAr ? 'إتمام' : 'Complete'}
                        </button>

                        <!-- 3. New Appointment (Reschedule) -->
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #D97706; color: #B45309; background: #FFFBEB;" onclick="openRescheduleFollowupModal('${f.id}')" title="${isAr ? 'حجز موعد جديد / إعادة جدولة' : 'Schedule New Appointment'}">
                          📅 ${isAr ? 'موعد جديد' : 'New Appt'}
                        </button>

                        <!-- 4. Cancelled Due... -->
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #DC2626; color: #DC2626; background: #FEF2F2;" onclick="openCancelFollowupModal('${f.id}')" title="${isAr ? 'إلغاء الموعد مع بيان السبب' : 'Cancel Due to Reason'}">
                          ❌ ${isAr ? 'إلغاء بسبب...' : 'Cancelled Due...'}
                        </button>
                      </div>
                    `)}
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // 6. ACTION MODALS: COMPLETE, NEW APPOINTMENT, CANCELLED DUE
  // --------------------------------------------------------------------------

  // Find item by ID
  function findFollowupItemById(id) {
    const all = extractAllClinicalFollowups();
    return all.find(f => f.id === id) || null;
  }

  /**
   * MODAL 1: COMPLETE FOLLOW-UP
   */
  function openCompleteFollowupModal(followupId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const item = findFollowupItemById(followupId);
    if (!item) return;

    let modalBox = document.getElementById('calendarModalContainer');
    if (!modalBox) {
      modalBox = document.createElement('div');
      modalBox.id = 'calendarModalContainer';
      document.body.appendChild(modalBox);
    }

    const todayISO = formatDateISO(new Date());

    modalBox.innerHTML = `
      <div class="modal-backdrop-cal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); z-index: 10000; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px);">
        <div class="modal-card-cal" style="background: white; border-radius: 14px; width: 92%; max-width: 580px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25);">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #15803D 0%, #16A34A 100%); color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 1.4rem;">✅</span>
              <div>
                <h3 style="margin: 0; font-size: 1.15rem; font-weight: 800;">
                  ${isAr ? 'إتمام الإجراء والمتابعة السريرية' : 'Complete Clinical Follow-up'}
                </h3>
                <div style="font-size: 0.8rem; opacity: 0.95; margin-top: 2px;">
                  ${item.empName} (No: ${item.empNo}) — ${item.dept}
                </div>
              </div>
            </div>
            <button type="button" style="background: transparent; border: none; color: white; font-size: 1.4rem; cursor: pointer;" onclick="closeActionModal()">✕</button>
          </div>

          <!-- Body -->
          <div style="padding: 20px; display: flex; flex-direction: column; gap: 14px;">
            <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px 14px;">
              <div style="font-size: 0.82rem; font-weight: 700; color: #64748B;">${isAr ? 'الإجراء المستحق:' : 'Action Required:'}</div>
              <div style="font-size: 0.95rem; font-weight: 800; color: #0F172A; margin-top: 2px;">${isAr ? item.titleAr : item.titleEn}</div>
              <div style="font-size: 0.8rem; color: #475569;">${isAr ? item.descAr : item.descEn}</div>
            </div>

            <!-- Date Completed -->
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'تاريخ إتمام الإجراء / الفحص:' : 'Date Performed / Completed:'} *
              </label>
              <input type="date" id="act_comp_date" value="${todayISO}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
            </div>

            <!-- Dynamic Form based on Category -->
            ${item.category === 'vaccine' ? `
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                  <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                    ${isAr ? 'رقم التشغيلة (Batch/Lot) - اختياري:' : 'Batch / Lot No (Optional):'}
                  </label>
                  <input type="text" id="act_comp_lot" placeholder="e.g. B2026-HB" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
                </div>
                <div>
                  <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                    ${isAr ? 'موضع الحقن (Route/Site):' : 'Injection Site:'}
                  </label>
                  <select id="act_comp_site" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">
                    <option value="Left Deltoid IM">${isAr ? 'عضلة الكتف الأيسر (Left Deltoid IM)' : 'Left Deltoid IM'}</option>
                    <option value="Right Deltoid IM">${isAr ? 'عضلة الكتف الأيمن (Right Deltoid IM)' : 'Right Deltoid IM'}</option>
                    <option value="Oral">${isAr ? 'فموي (Oral)' : 'Oral'}</option>
                    <option value="Subcutaneous">${isAr ? 'تحت الجلد (Subcutaneous)' : 'Subcutaneous'}</option>
                  </select>
                </div>
              </div>
            ` : `
              <!-- Laboratory Result Input -->
              <div>
                <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                  ${isAr ? 'النتيجة المخبرية / التقرير الطبي:' : 'Lab Result / Clinical Outcome:'} *
                </label>
                ${item.subCategory === 'anti_hbs' ? `
                  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <select id="act_comp_result" style="padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">
                      <option value="Immune (anti-HBs ≥10 mIU/mL)">Immune (anti-HBs ≥10 mIU/mL)</option>
                      <option value="Vaccine non-responder">Vaccine non-responder (<10 mIU/mL)</option>
                      <option value="Immunity status unknown">Immunity status unknown</option>
                    </select>
                    <input type="text" id="act_comp_numeric" placeholder="${isAr ? 'القيمة الرقمية (mIU/mL) مثل 27.11' : 'Numeric titer (e.g. 27.11 mIU/mL)'}" style="padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
                  </div>
                ` : (item.subCategory === 'ppd' ? `
                  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <select id="act_comp_result" style="padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">
                      <option value="Negative (0 mm)">Negative (0 mm)</option>
                      <option value="Negative (<10 mm)">Negative (<10 mm)</option>
                      <option value="Positive (≥10 mm)">Positive (≥10 mm)</option>
                    </select>
                    <input type="text" id="act_comp_numeric" placeholder="${isAr ? 'قطر التصلب (مم) مثل 0mm' : 'Induration mm (e.g. 0 mm)'}" style="padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
                  </div>
                ` : `
                  <select id="act_comp_result" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">
                    <option value="Negative (سلبي)">Negative (سلبي) - Non-Reactive</option>
                    <option value="Positive (إيجابي)">Positive (إيجابي) - Reactive</option>
                    <option value="Completed / Verified">${isAr ? 'تم الإجراء والفحص بنجاح' : 'Completed / Normal'}</option>
                  </select>
                `)}
              </div>
            `}

            <!-- Clinical Notes -->
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'ملاحظات وتوثيق سريري:' : 'Clinical Notes / Documentation:'}
              </label>
              <textarea id="act_comp_notes" rows="2" placeholder="${isAr ? 'أي ملاحظات إضافية، اسم الممرض/الطبيب...' : 'Enter any clinical remarks, nurse/physician notes...'}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;"></textarea>
            </div>

            <!-- Auto-update master record checkbox -->
            <label style="display: flex; align-items: center; gap: 8px; font-size: 0.85rem; color: #0F172A; font-weight: 700; cursor: pointer; background: #F0FDF4; padding: 10px 12px; border-radius: 6px; border: 1px solid #BBF7D0;">
              <input type="checkbox" id="act_comp_update_master" checked style="width: 17px; height: 17px; cursor: pointer;" />
              <span>${isAr ? 'تحديث وتثبيت هذه النتيجة تلقائياً في ملف وسجل الموظف المركزي' : 'Auto-update and persist this result directly in the staff occupational health record'}</span>
            </label>
          </div>

          <!-- Footer -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 20px; display: flex; justify-content: flex-end; gap: 10px;">
            <button type="button" class="btn btn-outline" onclick="closeActionModal()">
              ${isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button type="button" class="btn btn-success" style="background: #16A34A; border-color: #16A34A;" onclick="submitCompleteFollowup('${followupId}')">
              ✅ ${isAr ? 'حفظ وإتمام الإجراء' : 'Save & Mark Completed'}
            </button>
          </div>
        </div>
      </div>
    `;
  }
  window.openCompleteFollowupModal = openCompleteFollowupModal;

  /**
   * MODAL 2: NEW APPOINTMENT (RESCHEDULE)
   */
  function openRescheduleFollowupModal(followupId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const item = findFollowupItemById(followupId);
    if (!item) return;

    let modalBox = document.getElementById('calendarModalContainer');
    if (!modalBox) {
      modalBox = document.createElement('div');
      modalBox.id = 'calendarModalContainer';
      document.body.appendChild(modalBox);
    }

    // Default suggested new date: +7 days from now
    const suggestedNewDate = formatDateISO(addDays(new Date(), 7));
    const curDueDisplay = formatDateDisplay(item.dueDate, isAr);

    modalBox.innerHTML = `
      <div class="modal-backdrop-cal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); z-index: 10000; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px);">
        <div class="modal-card-cal" style="background: white; border-radius: 14px; width: 92%; max-width: 580px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25);">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #B45309 0%, #D97706 100%); color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 1.4rem;">📅</span>
              <div>
                <h3 style="margin: 0; font-size: 1.15rem; font-weight: 800;">
                  ${isAr ? 'حجز موعد جديد / إعادة جدولة المتابعة' : 'Schedule New Appointment / Reschedule'}
                </h3>
                <div style="font-size: 0.8rem; opacity: 0.95; margin-top: 2px;">
                  ${item.empName} (No: ${item.empNo}) — ${item.dept}
                </div>
              </div>
            </div>
            <button type="button" style="background: transparent; border: none; color: white; font-size: 1.4rem; cursor: pointer;" onclick="closeActionModal()">✕</button>
          </div>

          <!-- Body -->
          <div style="padding: 20px; display: flex; flex-direction: column; gap: 14px;">
            <div style="background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 8px; padding: 10px 14px;">
              <div style="font-size: 0.82rem; font-weight: 700; color: #92400E;">${isAr ? 'الإجراء المراد إعادة جدولته:' : 'Follow-up to Reschedule:'}</div>
              <div style="font-size: 0.95rem; font-weight: 800; color: #78350F; margin-top: 2px;">${isAr ? item.titleAr : item.titleEn}</div>
              <div style="font-size: 0.8rem; color: #92400E; margin-top: 2px;">
                ${isAr ? 'الموعد الأصلي الحالي:' : 'Current Due Date:'} <strong>${curDueDisplay}</strong>
              </div>
            </div>

            <!-- New Due Date -->
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'تاريخ الموعد الجديد:' : 'New Appointment Due Date:'} *
              </label>
              <input type="date" id="act_resched_date" value="${suggestedNewDate}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
            </div>

            <!-- Reason for Rescheduling -->
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'سبب تأجيل الموعد / حجز موعد جديد:' : 'Reason for Rescheduling / New Date:'} *
              </label>
              <select id="act_resched_reason" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">
                <option value="Staff on annual / official leave">${isAr ? '🏖️ الموظف في إجازة سنوية / رسمية' : 'Staff on annual / official leave'}</option>
                <option value="Staff on sick leave">${isAr ? '🤒 الموظف في إجازة مرضية' : 'Staff on sick leave'}</option>
                <option value="Temporary acute clinical contraindication">${isAr ? '🏥 تأجيل طبي مؤقت / استشارة طبيب' : 'Temporary acute clinical contraindication'}</option>
                <option value="Staff requested later appointment">${isAr ? '📞 تم تأجيل الموعد بناءً على طلب الموظف' : 'Staff requested later appointment'}</option>
                <option value="Postponed per OH Clinic schedule">${isAr ? '🗓️ تأجيل تنظيمي بطلب عيادة صحة العاملين' : 'Postponed per OH Clinic schedule'}</option>
                <option value="Awaiting prior test / Lab delay">${isAr ? '⏳ بانتظار نتائج فحص سابق / تأخر المخبر' : 'Awaiting prior test / Lab delay'}</option>
                <option value="Other reason">${isAr ? '✏️ سبب آخر (يُرجى التوضيح أدناه)' : 'Other reason (Specify in notes)'}</option>
              </select>
            </div>

            <!-- Notes -->
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'ملاحظات وتفاصيل التنسيق:' : 'Coordination Notes & Remarks:'}
              </label>
              <textarea id="act_resched_notes" rows="2" placeholder="${isAr ? 'أي تفاصيل عن التواصل مع الموظف أو سبب التأجيل...' : 'Details of staff contact, coordination, or reasons...'}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;"></textarea>
            </div>
          </div>

          <!-- Footer -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 20px; display: flex; justify-content: flex-end; gap: 10px;">
            <button type="button" class="btn btn-outline" onclick="closeActionModal()">
              ${isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button type="button" class="btn btn-primary" style="background: #D97706; border-color: #D97706;" onclick="submitRescheduleFollowup('${followupId}')">
              📅 ${isAr ? 'تأكيد الموعد الجديد' : 'Confirm New Appointment'}
            </button>
          </div>
        </div>
      </div>
    `;
  }
  window.openRescheduleFollowupModal = openRescheduleFollowupModal;

  /**
   * MODAL 3: CANCELLED DUE TO REASON
   */
  function openCancelFollowupModal(followupId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const item = findFollowupItemById(followupId);
    if (!item) return;

    let modalBox = document.getElementById('calendarModalContainer');
    if (!modalBox) {
      modalBox = document.createElement('div');
      modalBox.id = 'calendarModalContainer';
      document.body.appendChild(modalBox);
    }

    const curDueDisplay = formatDateDisplay(item.dueDate, isAr);

    modalBox.innerHTML = `
      <div class="modal-backdrop-cal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); z-index: 10000; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px);">
        <div class="modal-card-cal" style="background: white; border-radius: 14px; width: 92%; max-width: 580px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25);">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #991B1B 0%, #DC2626 100%); color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 1.4rem;">❌</span>
              <div>
                <h3 style="margin: 0; font-size: 1.15rem; font-weight: 800;">
                  ${isAr ? 'إلغاء الموعد مع بيان السبب السريري (Cancelled Due...)' : 'Cancel Follow-up Due to Clinical Reason'}
                </h3>
                <div style="font-size: 0.8rem; opacity: 0.95; margin-top: 2px;">
                  ${item.empName} (No: ${item.empNo}) — ${item.dept}
                </div>
              </div>
            </div>
            <button type="button" style="background: transparent; border: none; color: white; font-size: 1.4rem; cursor: pointer;" onclick="closeActionModal()">✕</button>
          </div>

          <!-- Body -->
          <div style="padding: 20px; display: flex; flex-direction: column; gap: 14px;">
            <div style="background: #FEF2F2; border: 1px solid #FCA5A5; border-radius: 8px; padding: 10px 14px;">
              <div style="font-size: 0.82rem; font-weight: 700; color: #991B1B;">${isAr ? 'المتابعة المراد إلغاؤها:' : 'Follow-up to Cancel:'}</div>
              <div style="font-size: 0.95rem; font-weight: 800; color: #7F1D1D; margin-top: 2px;">${isAr ? item.titleAr : item.titleEn}</div>
              <div style="font-size: 0.8rem; color: #991B1B; margin-top: 2px;">
                ${isAr ? 'تاريخ الاستحقاق:' : 'Due Date:'} <strong>${curDueDisplay}</strong>
              </div>
            </div>

            <!-- Cancellation Reason Dropdown -->
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'سبب الإلغاء (Cancelled Due To):' : 'Cancellation Reason (Cancelled Due):'} *
              </label>
              <select id="act_cancel_reason" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #FCA5A5; border-radius: 6px; font-weight: 700; color: #991B1B; background: #FFF5F5;">
                <option value="Staff on leave / Vacation">${isAr ? '🏖️ الموظف في إجازة رسمية / خارج البلاد (Staff on leave / Vacation)' : 'Staff on leave / Vacation'}</option>
                <option value="Medical contraindication / Clinical exemption">${isAr ? '🏥 مانع طبي معتمد / استثناء طبي (Medical contraindication)' : 'Medical contraindication / Clinical exemption'}</option>
                <option value="Worker declined / Refused">${isAr ? '✋ رفض الموظف أخذ الإجراء (Worker declined / Refused)' : 'Worker declined / Refused'}</option>
                <option value="Resigned / End of service">${isAr ? '🚪 استقالة الموظف أو إنهاء الخدمة (Resigned / Left Hospital)' : 'Resigned / End of service'}</option>
                <option value="Done externally with documented proof">${isAr ? '🔬 أُجري في مركز خارجي مع إثبات (Done externally)' : 'Done externally with documented proof'}</option>
                <option value="Vaccination not indicated under MOH guidelines">${isAr ? '🩺 غير مطلوب سريرياً وفق إرشادات الوزارة (Not indicated under MOH)' : 'Vaccination not indicated under MOH guidelines'}</option>
                <option value="Other clinical reason">${isAr ? '✏️ سبب آخر (يُرجى التوضيح أدناه)' : 'Other clinical reason (Specify in notes)'}</option>
              </select>
            </div>

            <!-- Notes -->
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'تفاصيل المبرر السريري والملاحظات:' : 'Clinical Justification & Notes:'}
              </label>
              <textarea id="act_cancel_notes" rows="2" placeholder="${isAr ? 'اكتب تفاصيل قرار الإلغاء، اسم الطبيب، أو رقم كتاب الإجازة...' : 'Document clinical rationale, physician name, leave approval...'}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;"></textarea>
            </div>

            <div style="background: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 6px; padding: 10px 12px; font-size: 0.8rem; color: #64748B;">
              ℹ️ ${isAr ? 'سيتم نقل هذا الموعد من قائمة المواعيد النشطة وتوثيق سبب الإلغاء في سجل وتاريخ الموظف السريري.' : 'This appointment will be marked as Cancelled and recorded with its reason in the staff clinical audit trail.'}
            </div>
          </div>

          <!-- Footer -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 20px; display: flex; justify-content: flex-end; gap: 10px;">
            <button type="button" class="btn btn-outline" onclick="closeActionModal()">
              ${isAr ? 'تراجع' : 'Back'}
            </button>
            <button type="button" class="btn btn-outline" style="background: #DC2626; color: white; border-color: #DC2626; font-weight: bold;" onclick="submitCancelFollowup('${followupId}')">
              ❌ ${isAr ? 'تأكيد الإلغاء' : 'Confirm Cancellation'}
            </button>
          </div>
        </div>
      </div>
    `;
  }
  window.openCancelFollowupModal = openCancelFollowupModal;

  function closeActionModal() {
    // If a day detail modal was open before, restore it; otherwise clear modal
    if (activeModalDateKey) {
      openDayDetailModal(activeModalDateKey);
    } else {
      closeCalendarModal();
    }
  }
  window.closeActionModal = closeActionModal;

  // --------------------------------------------------------------------------
  // 7. SUBMIT HANDLERS (SAVE TO EMPLOYEES & INJURIES)
  // --------------------------------------------------------------------------

  // A. SUBMIT COMPLETE
  async function submitCompleteFollowup(followupId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const item = findFollowupItemById(followupId);
    if (!item) return;

    const compDate = document.getElementById('act_comp_date')?.value || formatDateISO(new Date());
    const lotNo = document.getElementById('act_comp_lot')?.value || '';
    const site = document.getElementById('act_comp_site')?.value || '';
    const result = document.getElementById('act_comp_result')?.value || '';
    const numeric = document.getElementById('act_comp_numeric')?.value || '';
    const notes = document.getElementById('act_comp_notes')?.value || '';
    const autoUpdateMaster = document.getElementById('act_comp_update_master')?.checked !== false;

    // Handle Standalone General Vaccine Stock
    if (item.isStandalone) {
      const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
      const target = list.find((v, idx) => (v.id === followupId || v.id === item.id || `standalone_ve_${idx}` === followupId));
      if (target) {
        target.completed = true;
        target.completedDate = compDate;
        target.completedNotes = notes.trim();
        localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(list));
      }
      closeActionModal();
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') renderFollowupCalendar(container);
      if (typeof window.showSuccessToast === 'function') {
        window.showSuccessToast(
          isAr ? 'تم إتمام وتوثيق السجل في مخزون اللقاحات بنجاح 🟢' : 'Vaccine stock record marked as completed 🟢',
          isAr ? 'تم الإتمام 🟢' : 'Completed 🟢'
        );
      }
      return;
    }

        // Handle Standalone General Vaccine Stock Renewal / New Expire Date
    if (item.isStandalone) {
      const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
      const target = list.find((v, idx) => (v.id === followupId || v.id === item.id || `standalone_ve_${idx}` === followupId));
      if (target) {
        target.expireDate = newDate;
        target.dueDate = newDate;
        target.reminderDate = formatDateISO(addDays(parseDateSafe(newDate), -(target.reminderDays || 15)));
        target.notes = (target.notes ? target.notes + ' | ' : '') + `Renewed to ${newDate}: ${reason} (${notes})`;
        localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(list));
      }
      closeActionModal();
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') renderFollowupCalendar(container);
      if (typeof window.showSuccessToast === 'function') {
        window.showSuccessToast(
          isAr ? `تم تحديث تاريخ صلاحية اللقاح إلى (${newDate}) بنجاح 🟢` : `Vaccine expiration updated to (${newDate}) 🟢`,
          isAr ? 'تجديد الصلاحية 🟢' : 'Renewed 🟢'
        );
      }
      return;
    }

    const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
    const emp = employees.find(e => (e.empNo === item.empNo || e.id === item.empNo));

    if (emp) {
      if (!emp.followupDispositions) emp.followupDispositions = {};
      emp.followupDispositions[followupId] = {
        status: 'completed',
        date: compDate,
        lot: lotNo,
        site: site,
        result: numeric ? `${result} (${numeric})` : result,
        notes: notes.trim(),
        completedAt: new Date().toISOString()
      };

      // Also update custom appointment if custom
      if (item.customItem && Array.isArray(emp.customFollowups)) {
        const cf = emp.customFollowups.find(c => (c.id === followupId || c.id === item.customItem.id));
        if (cf) {
          cf.completed = true;
          cf.completedDate = compDate;
          cf.completedNotes = notes.trim();
          cf.completedResult = result;
        }
      }

      // Auto-update master clinical record if checked
      if (autoUpdateMaster) {
        if (!emp.vaccines) emp.vaccines = {};
        if (!emp.labs) emp.labs = {};

        if (item.subCategory === 'hepb') {
          if (item.id.includes('hb_d2')) emp.vaccines.hbvDose2Date = compDate;
          if (item.id.includes('hb_d3')) emp.vaccines.hbvDose3Date = compDate;
        } else if (item.subCategory === 'anti_hbs') {
          emp.labs.antiHBsDate = compDate;
          emp.labs.antiHBsResult = result || 'Immune (≥10 mIU/mL)';
          if (numeric) emp.labs.antiHBsTiter = numeric;
        } else if (item.subCategory === 'varicella') {
          emp.vaccines.varicellaDose2Date = compDate;
        } else if (item.subCategory === 'mmr') {
          emp.vaccines.mmrDose2Date = compDate;
        } else if (item.subCategory === 'ppd') {
          emp.labs.ppdReadDate = compDate;
          emp.labs.ppdResult = result || 'Negative (0 mm)';
        }
      }

      if (typeof window.EmployeeDataService !== 'undefined' && typeof window.EmployeeDataService.saveEmployee === 'function') {
        await window.EmployeeDataService.saveEmployee(emp, 'update');
      } else if (typeof window.saveEmployeesToLocalStorage === 'function') {
        window.saveEmployeesToLocalStorage(employees);
      }
    }

    // PEP Injury update if PEP item
    if (item.injurySerial && item.injury) {
      const inj = item.injury;
      if (!inj.followupDispositions) inj.followupDispositions = {};
      inj.followupDispositions[followupId] = {
        status: 'completed',
        date: compDate,
        result: result,
        notes: notes.trim(),
        completedAt: new Date().toISOString()
      };
      if (typeof window.InjuryDataService !== 'undefined' && typeof window.InjuryDataService.saveInjury === 'function') {
        await window.InjuryDataService.saveInjury(inj);
      }
    }

    closeActionModal();

    if (typeof window.showSuccessToast === 'function') {
      window.showSuccessToast(
        isAr ? `تم إتمام وتوثيق الإجراء بنجاح للموظف (${item.empName}) 🟢` : `Follow-up completed and recorded for (${item.empName}) 🟢`,
        isAr ? 'تم الإتمام 🟢' : 'Completed 🟢'
      );
    }

    // Refresh view
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.submitCompleteFollowup = submitCompleteFollowup;

  // B. SUBMIT RESCHEDULE (NEW APPOINTMENT)
  async function submitRescheduleFollowup(followupId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const item = findFollowupItemById(followupId);
    if (!item) return;

    const newDate = document.getElementById('act_resched_date')?.value;
    const reason = document.getElementById('act_resched_reason')?.value || 'Rescheduled per clinic schedule';
    const notes = document.getElementById('act_resched_notes')?.value || '';

    if (!newDate) {
      alert(isAr ? 'يرجى اختيار تاريخ الموعد الجديد.' : 'Please select a new appointment date.');
      return;
    }

        // Handle Standalone General Vaccine Stock Renewal / New Expire Date
    if (item.isStandalone) {
      const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
      const target = list.find((v, idx) => (v.id === followupId || v.id === item.id || `standalone_ve_${idx}` === followupId));
      if (target) {
        target.expireDate = newDate;
        target.dueDate = newDate;
        target.reminderDate = formatDateISO(addDays(parseDateSafe(newDate), -(target.reminderDays || 15)));
        target.notes = (target.notes ? target.notes + ' | ' : '') + `Renewed to ${newDate}: ${reason} (${notes})`;
        localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(list));
      }
      closeActionModal();
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') renderFollowupCalendar(container);
      if (typeof window.showSuccessToast === 'function') {
        window.showSuccessToast(
          isAr ? `تم تحديث تاريخ صلاحية اللقاح إلى (${newDate}) بنجاح 🟢` : `Vaccine expiration updated to (${newDate}) 🟢`,
          isAr ? 'تجديد الصلاحية 🟢' : 'Renewed 🟢'
        );
      }
      return;
    }

    const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
    const emp = employees.find(e => (e.empNo === item.empNo || e.id === item.empNo));

    if (emp) {
      if (!emp.followupDispositions) emp.followupDispositions = {};
      emp.followupDispositions[followupId] = {
        status: 'rescheduled',
        newDueDate: newDate,
        originalDueDate: formatDateISO(item.dueDate),
        reason: reason,
        notes: notes.trim(),
        rescheduledAt: new Date().toISOString()
      };

      // Also update custom appointment if custom
      if (item.customItem && Array.isArray(emp.customFollowups)) {
        const cf = emp.customFollowups.find(c => (c.id === followupId || c.id === item.customItem.id));
        if (cf) {
          cf.dueDate = newDate;
          cf.notes = (cf.notes ? cf.notes + ' | ' : '') + `Rescheduled: ${reason} (${notes})`;
        }
      }

      if (typeof window.EmployeeDataService !== 'undefined' && typeof window.EmployeeDataService.saveEmployee === 'function') {
        await window.EmployeeDataService.saveEmployee(emp, 'update');
      } else if (typeof window.saveEmployeesToLocalStorage === 'function') {
        window.saveEmployeesToLocalStorage(employees);
      }
    }

    // PEP Injury update if PEP item
    if (item.injurySerial && item.injury) {
      const inj = item.injury;
      if (!inj.followupDispositions) inj.followupDispositions = {};
      inj.followupDispositions[followupId] = {
        status: 'rescheduled',
        newDueDate: newDate,
        originalDueDate: formatDateISO(item.dueDate),
        reason: reason,
        notes: notes.trim(),
        rescheduledAt: new Date().toISOString()
      };
      if (typeof window.InjuryDataService !== 'undefined' && typeof window.InjuryDataService.saveInjury === 'function') {
        await window.InjuryDataService.saveInjury(inj);
      }
    }

    closeActionModal();

    if (typeof window.showSuccessToast === 'function') {
      window.showSuccessToast(
        isAr ? `تمت إعادة جدولة الموعد إلى (${formatDateDisplay(parseDateSafe(newDate), isAr)}) بنجاح 🟢` : `Appointment rescheduled to (${formatDateDisplay(parseDateSafe(newDate), false)}) 🟢`,
        isAr ? 'موعد جديد 🟢' : 'New Appointment 🟢'
      );
    }

    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.submitRescheduleFollowup = submitRescheduleFollowup;

  // C. SUBMIT CANCEL (CANCELLED DUE TO REASON)
  async function submitCancelFollowup(followupId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const item = findFollowupItemById(followupId);
    if (!item) return;

    const reason = document.getElementById('act_cancel_reason')?.value || 'Staff on leave / Vacation';
    const notes = document.getElementById('act_cancel_notes')?.value || '';

    // Handle Standalone General Vaccine Stock
    if (item.isStandalone) {
      const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
      const target = list.find((v, idx) => (v.id === followupId || v.id === item.id || `standalone_ve_${idx}` === followupId));
      if (target) {
        target.cancelled = true;
        target.cancelledDate = formatDateISO(new Date());
        target.cancelledReason = reason;
        target.cancelledNotes = notes.trim();
        localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(list));
      }
      closeActionModal();
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') renderFollowupCalendar(container);
      if (typeof window.showSuccessToast === 'function') {
        window.showSuccessToast(
          isAr ? 'تم إلغاء السجل في مخزون اللقاحات ❌' : 'Vaccine stock record cancelled ❌',
          isAr ? 'تم الإلغاء ❌' : 'Cancelled ❌'
        );
      }
      return;
    }

        // Handle Standalone General Vaccine Stock Renewal / New Expire Date
    if (item.isStandalone) {
      const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
      const target = list.find((v, idx) => (v.id === followupId || v.id === item.id || `standalone_ve_${idx}` === followupId));
      if (target) {
        target.expireDate = newDate;
        target.dueDate = newDate;
        target.reminderDate = formatDateISO(addDays(parseDateSafe(newDate), -(target.reminderDays || 15)));
        target.notes = (target.notes ? target.notes + ' | ' : '') + `Renewed to ${newDate}: ${reason} (${notes})`;
        localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(list));
      }
      closeActionModal();
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') renderFollowupCalendar(container);
      if (typeof window.showSuccessToast === 'function') {
        window.showSuccessToast(
          isAr ? `تم تحديث تاريخ صلاحية اللقاح إلى (${newDate}) بنجاح 🟢` : `Vaccine expiration updated to (${newDate}) 🟢`,
          isAr ? 'تجديد الصلاحية 🟢' : 'Renewed 🟢'
        );
      }
      return;
    }

    const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
    const emp = employees.find(e => (e.empNo === item.empNo || e.id === item.empNo));

    if (emp) {
      if (!emp.followupDispositions) emp.followupDispositions = {};
      emp.followupDispositions[followupId] = {
        status: 'cancelled',
        reason: reason,
        notes: notes.trim(),
        cancelledAt: new Date().toISOString()
      };

      // Also update custom appointment if custom
      if (item.customItem && Array.isArray(emp.customFollowups)) {
        const cf = emp.customFollowups.find(c => (c.id === followupId || c.id === item.customItem.id));
        if (cf) {
          cf.status = 'cancelled';
          cf.cancelledDue = reason;
          cf.cancelledNotes = notes.trim();
          cf.completed = true; // no longer pending
        }
      }

      if (typeof window.EmployeeDataService !== 'undefined' && typeof window.EmployeeDataService.saveEmployee === 'function') {
        await window.EmployeeDataService.saveEmployee(emp, 'update');
      } else if (typeof window.saveEmployeesToLocalStorage === 'function') {
        window.saveEmployeesToLocalStorage(employees);
      }
    }

    // PEP Injury update if PEP item
    if (item.injurySerial && item.injury) {
      const inj = item.injury;
      if (!inj.followupDispositions) inj.followupDispositions = {};
      inj.followupDispositions[followupId] = {
        status: 'cancelled',
        reason: reason,
        notes: notes.trim(),
        cancelledAt: new Date().toISOString()
      };
      if (typeof window.InjuryDataService !== 'undefined' && typeof window.InjuryDataService.saveInjury === 'function') {
        await window.InjuryDataService.saveInjury(inj);
      }
    }

    closeActionModal();

    if (typeof window.showSuccessToast === 'function') {
      window.showSuccessToast(
        isAr ? `تم إلغاء الموعد وتوثيق السبب: (${reason}) ⚠️` : `Follow-up cancelled due to: (${reason}) ⚠️`,
        isAr ? 'تم الإلغاء ⚠️' : 'Cancelled ⚠️'
      );
    }

    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.submitCancelFollowup = submitCancelFollowup;

  // D. DELETE STANDALONE VACCINE STOCK ITEM
  function deleteStandaloneVaccineExpiry(id) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const msg = isAr 
      ? 'هل أنت متأكد من حذف هذا السجل من مخزون اللقاحات (General Vaccine Stock)؟' 
      : 'Are you sure you want to delete this record from General Vaccine Stock?';
    if (confirm(msg)) {
      const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
      const filtered = list.filter((v, idx) => (v.id !== id && `standalone_ve_${idx}` !== id));
      localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(filtered));
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') {
        renderFollowupCalendar(container);
      }
      if (typeof window.showSuccessToast === 'function') {
        window.showSuccessToast(
          isAr ? 'تم حذف الصنف من مخزون اللقاحات بنجاح 🗑️' : 'Successfully deleted from vaccine stock 🗑️',
          isAr ? 'تم الحذف 🗑️' : 'Deleted 🗑️'
        );
      }
    }
  }
  window.deleteStandaloneVaccineExpiry = deleteStandaloneVaccineExpiry;

  // --------------------------------------------------------------------------
  // EDIT / UPDATE VACCINE BATCH MODAL & LOGIC
  // --------------------------------------------------------------------------
  function openEditVaccineExpiryModal(batchId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    const batch = list.find((b, idx) => b.id === batchId || `standalone_ve_${idx}` === batchId);
    if (!batch) {
      alert(isAr ? 'لم يتم العثور على سجل التشغيلة المطلوب تعديلها.' : 'Vaccine batch record not found.');
      return;
    }

    let modalBox = document.getElementById('calendarModalContainer');
    if (!modalBox) {
      modalBox = document.createElement('div');
      modalBox.id = 'calendarModalContainer';
      document.body.appendChild(modalBox);
    }

    const escapeAttr = (s) => (typeof window.escapeHtmlAttr === 'function' ? window.escapeHtmlAttr(s) : (s ? String(s).replace(/"/g, '&quot;') : ''));

    const curName = batch.vaccineName || '';
    const curLot = batch.vaccineLot || '';
    const curAdminDate = batch.adminDate || '';
    const curExpireDate = batch.expireDate || batch.dueDate || '';
    const reminderActive = (batch.reminderActive !== false);
    const reminderDays = batch.reminderDays || 15;
    const reminderDateVal = batch.reminderDate || '';
    const notesVal = batch.notes || '';
    const isCompleted = !!(batch.completed || batch.isCompleted);
    const isCancelled = !!(batch.cancelled || batch.isCancelled);
    let statusVal = 'active';
    if (isCompleted) statusVal = 'completed';
    else if (isCancelled) statusVal = 'cancelled';

    const standardPresets = [
      { id: 'Tubersol (Tuberculin)', label: isAr ? 'تيوبرسول فحص السل (Tubersol Tuberculin)' : 'Tubersol (Tuberculin)', years: 1 },
      { id: 'Imovax Polio', label: isAr ? 'إيموفاكس شلل الأطفال (Imovax Polio)' : 'Imovax Polio', years: 10 },
      { id: 'Pneumococcal Vaccine', label: isAr ? 'لقاح المكورات الرئوية (Pneumococcal Vaccine)' : 'Pneumococcal Vaccine', years: 5 },
      { id: 'Varillex (Varicella,Chickenpox)', label: isAr ? 'فاريلكس جدري الماء (Varillex Varicella,Chickenpox)' : 'Varillex (Varicella,Chickenpox)', years: 10 },
      { id: 'Nimenrix Meningococcal Vaccine', label: isAr ? 'نيمينريكس السحايا (Nimenrix Meningococcal Vaccine)' : 'Nimenrix Meningococcal Vaccine', years: 5 },
      { id: 'Tetanus / Diphtheria / Pertussis (Tdap)', label: isAr ? 'الكزاز والدفتيريا والسعال الديكي (Tdap)' : 'Tetanus / Diphtheria / Pertussis (Tdap)', years: 10 },
      { id: 'Seasonal Influenza (Flu Quadrivalent 2026/2027)', label: isAr ? 'الإنفلونزا الموسمية الرباعي (Flu)' : 'Seasonal Influenza (Flu)', years: 1 },
      { id: 'Hepatitis B Recombinant (Engerix-B 20mcg)', label: isAr ? 'التهاب الكبد الوبائي ب (Engerix-B)' : 'Hepatitis B Recombinant (Engerix-B)', years: 5 },
      { id: 'MMR (Measles, Mumps, Rubella) II', label: isAr ? 'الحصبة والنكاف والحصبة الألمانية (MMR II)' : 'MMR (Measles, Mumps, Rubella) II', years: 10 },
      { id: 'Varicella (Chickenpox) Live Attenuated', label: isAr ? 'جدري الماء (Varicella Live Attenuated)' : 'Varicella (Chickenpox) Live Attenuated', years: 10 },
      { id: 'COVID-19 Vaccine / Booster', label: isAr ? 'كوفيد-19 معزز (COVID-19 Booster)' : 'COVID-19 Vaccine / Booster', years: 1 },
      { id: 'Meningococcal Vaccine (ACWY)', label: isAr ? 'لقاح السحايا الرباعي (MenACWY)' : 'Meningococcal Vaccine (ACWY)', years: 5 }
    ];

    modalBox.innerHTML = `
      <div class="modal-backdrop-cal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); z-index: 10000; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px);">
        <div class="modal-card-cal" style="background: white; border-radius: 14px; width: 92%; max-width: 620px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25);">
          
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #0284C7 0%, #0D5C75 100%); color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 1.4rem;">✏️</span>
              <div>
                <h3 style="margin: 0; font-size: 1.15rem; font-weight: 800;">
                  ${isAr ? 'تحديث وتعديل بيانات تشغيلة اللقاح' : 'Edit / Update Vaccine Batch'}
                </h3>
                <div style="font-size: 0.8rem; opacity: 0.9; margin-top: 2px;">
                  ${isAr ? `تعديل التشغيلة: ${curLot || batch.id}` : `Batch ID / Lot: ${curLot || batch.id}`}
                </div>
              </div>
            </div>
            <button type="button" style="background: transparent; border: none; color: white; font-size: 1.4rem; cursor: pointer;" onclick="closeCalendarModal()">✕</button>
          </div>

          <!-- Body -->
          <div style="padding: 20px; display: flex; flex-direction: column; gap: 14px; max-height: 80vh; overflow-y: auto;">
            
            <!-- Quick Preset Dropdown & Actual Display Name -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
              <div>
                <label style="display: block; font-size: 0.82rem; font-weight: 700; color: #1E293B; margin-bottom: 4px;">
                  ${isAr ? 'اختيار من اللقاحات القياسية:' : 'Select Standard Vaccine:'}
                </label>
                <select id="edit_ve_preset_select" onchange="handleEditVaccinePresetSelect(this.value)" style="width: 100%; padding: 8px 10px; font-size: 0.85rem; border: 1.5px solid #CBD5E1; border-radius: 6px; background: white;">
                  <option value="">${isAr ? '-- اختر للتعبئة التلقائية --' : '-- Choose to autofill --'}</option>
                  ${standardPresets.map(p => `
                    <option value="${p.id}" data-years="${p.years}">💉 ${p.label}</option>
                  `).join('')}
                  <option value="__CUSTOM__">💉 ${isAr ? 'لقاح آخر (مخصص)...' : 'Other / Custom Vaccine...'}</option>
                </select>
              </div>

              <div>
                <label style="display: block; font-size: 0.82rem; font-weight: 700; color: #0369A1; margin-bottom: 4px;">
                  ${isAr ? 'اسم اللقاح الفعلي (Vaccine Name):' : 'Display Vaccine Name:'} *
                </label>
                <input type="text" id="edit_ve_name" value="${escapeAttr(curName)}" placeholder="${isAr ? 'اكتب اسم اللقاح هنا...' : 'e.g. Tubersol (Tuberculin)'}" style="width: 100%; padding: 8px 10px; font-size: 0.88rem; border: 2px solid #0284C7; border-radius: 6px; font-weight: 800; color: #0C4A6E; background: #F0F9FF;" />
              </div>
            </div>

            <!-- Lot No & In-Stock Date -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
              <div>
                <label style="display: block; font-size: 0.82rem; font-weight: 700; color: #1E293B; margin-bottom: 4px;">
                  ${isAr ? 'رقم التشغيلة / الدفعة (Lot / Batch No):' : 'Lot / Batch No:'} *
                </label>
                <input type="text" id="edit_ve_lot" value="${escapeAttr(curLot)}" placeholder="e.g. LOT-GENERAL / TD-98421-B" style="width: 100%; padding: 8px 10px; font-size: 0.85rem; border: 1.5px solid #CBD5E1; border-radius: 6px; font-weight: bold;" />
              </div>

              <div>
                <label style="display: block; font-size: 0.82rem; font-weight: 700; color: #1E293B; margin-bottom: 4px;">
                  ${isAr ? 'تاريخ التوريد / الدخول للمخزون (In-Stock Date):' : 'In-Stock / Admin Date:'}
                </label>
                <input type="date" id="edit_ve_admin_date" value="${curAdminDate}" onchange="recalcEditExpiryFromAdminDate()" style="width: 100%; padding: 8px 10px; font-size: 0.85rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
              </div>
            </div>

            <!-- Expire Date & Status -->
            <div style="background: #FFFBEB; border: 1.5px solid #FCD34D; border-radius: 8px; padding: 12px;">
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 8px;">
                <div>
                  <label style="display: block; font-size: 0.82rem; font-weight: 700; color: #92400E; margin-bottom: 4px;">
                    ${isAr ? 'تاريخ انتهاء الصلاحية (Expire Date):' : 'Vaccine Batch Expire Date:'} *
                  </label>
                  <input type="date" id="edit_ve_expire_date" value="${curExpireDate}" onchange="updateEditReminderCalculatedDate()" style="width: 100%; padding: 8px 10px; font-size: 0.88rem; border: 2px solid #D97706; border-radius: 6px; font-weight: 800; color: #B45309; background: white;" />
                </div>

                <div>
                  <label style="display: block; font-size: 0.82rem; font-weight: 700; color: #92400E; margin-bottom: 4px;">
                    ${isAr ? 'حالة التشغيلة:' : 'Batch Status:'}
                  </label>
                  <select id="edit_ve_status" style="width: 100%; padding: 8px 10px; font-size: 0.85rem; border: 1.5px solid #CBD5E1; border-radius: 6px; background: white; font-weight: 700;">
                    <option value="active" ${statusVal === 'active' ? 'selected' : ''}>🟢 ${isAr ? 'متوفر وفي المخزون (In Stock)' : 'Active / In Stock'}</option>
                    <option value="completed" ${statusVal === 'completed' ? 'selected' : ''}>✅ ${isAr ? 'مستهلك بالكامل (Completed)' : 'Completed / Consumed'}</option>
                    <option value="cancelled" ${statusVal === 'cancelled' ? 'selected' : ''}>❌ ${isAr ? 'ملغي / تالف (Cancelled)' : 'Cancelled / Discarded'}</option>
                  </select>
                </div>
              </div>

              <!-- Quick Presets -->
              <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                <span style="font-size: 0.74rem; font-weight: 700; color: #92400E;">${isAr ? 'تمديد سريع:' : 'Quick Presets:'}</span>
                <button type="button" class="btn" onclick="applyEditVaccineExpiryPreset(1)" style="padding: 2px 8px; font-size: 0.74rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+1 Year</button>
                <button type="button" class="btn" onclick="applyEditVaccineExpiryPreset(2)" style="padding: 2px 8px; font-size: 0.74rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+2 Years</button>
                <button type="button" class="btn" onclick="applyEditVaccineExpiryPreset(3)" style="padding: 2px 8px; font-size: 0.74rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+3 Years</button>
                <button type="button" class="btn" onclick="applyEditVaccineExpiryPreset(5)" style="padding: 2px 8px; font-size: 0.74rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+5 Years</button>
                <button type="button" class="btn" onclick="applyEditVaccineExpiryPreset(10)" style="padding: 2px 8px; font-size: 0.74rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+10 Years</button>
              </div>
            </div>

            <!-- 15-Day Alert Reminder Component -->
            <div style="background: #FEF3C7; border: 1.5px solid #F59E0B; border-radius: 8px; padding: 12px;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                <label style="font-size: 0.85rem; font-weight: 800; color: #92400E; display: flex; align-items: center; gap: 7px; cursor: pointer;">
                  <input type="checkbox" id="edit_ve_reminder_active" ${reminderActive ? 'checked' : ''} style="width: 17px; height: 17px; accent-color: #D97706; cursor: pointer;" onchange="document.getElementById('edit_ve_reminder_box').style.display = this.checked ? 'grid' : 'none';" />
                  <span>🔔 ${isAr ? 'تفعيل التنبيه المسبق قبل انتهاء الصلاحية' : 'Enable Early Expiry Alert'}</span>
                </label>
                <span style="font-size: 0.74rem; background: #D97706; color: white; padding: 2px 8px; border-radius: 4px; font-weight: 800;">
                  ${isAr ? 'تنبيه استباقي' : 'Early Alert'}
                </span>
              </div>

              <div id="edit_ve_reminder_box" style="display: ${reminderActive ? 'grid' : 'none'}; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 6px;">
                <div>
                  <label style="display: block; font-size: 0.78rem; font-weight: 700; color: #78350F; margin-bottom: 3px;">
                    ${isAr ? 'تاريخ انطلاق التنبيه (Alert Date):' : 'Alert Trigger Date:'}
                  </label>
                  <input type="date" id="edit_ve_reminder_date" value="${reminderDateVal}" readonly style="width: 100%; padding: 6px 10px; font-size: 0.85rem; border: 1.5px solid #F59E0B; border-radius: 6px; background: white; font-weight: bold; color: #B45309;" />
                </div>
                <div>
                  <label style="display: block; font-size: 0.78rem; font-weight: 700; color: #78350F; margin-bottom: 3px;">
                    ${isAr ? 'فترة التنبيه المسبق (Window):' : 'Reminder Interval:'}
                  </label>
                  <select id="edit_ve_reminder_days" onchange="updateEditReminderCalculatedDate()" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; border: 1.5px solid #F59E0B; border-radius: 6px; background: white; font-weight: bold; color: #0F172A;">
                    <option value="15" ${reminderDays === 15 ? 'selected' : ''}>${isAr ? 'قبل 15 يوماً (المعتمد القياسي)' : '15 Days Before Expire Date (Standard)'}</option>
                    <option value="30" ${reminderDays === 30 ? 'selected' : ''}>${isAr ? 'قبل 30 يوماً (شهر كامل)' : '30 Days Before Expire Date'}</option>
                    <option value="7" ${reminderDays === 7 ? 'selected' : ''}>${isAr ? 'قبل 7 أيام (أسبوع)' : '7 Days Before Expire Date'}</option>
                  </select>
                </div>
              </div>
            </div>

            <!-- Storage Unit & Notes -->
            <div>
              <label style="display: block; font-size: 0.82rem; font-weight: 700; color: #1E293B; margin-bottom: 4px;">
                ${isAr ? 'وحدة التخزين وملاحظات الرصيد / التشغيلة:' : 'Storage Unit & Notes:'}
              </label>
              <textarea id="edit_ve_notes" rows="2" placeholder="${isAr ? 'مثال: ثلاجة العيادة المركزية (2°C–8°C) • 50 جرعة متوفرة...' : 'e.g. Central Clinic Refrigerator #1 (2°C–8°C) • 50 doses in stock...'}" style="width: 100%; padding: 8px 10px; font-size: 0.85rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">${escapeAttr(notesVal)}</textarea>
            </div>

          </div>

          <!-- Footer -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; gap: 10px;">
            <button type="button" class="btn btn-outline" onclick="closeCalendarModal()">
              ${isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button type="button" class="btn btn-success" style="background: #0284C7; border-color: #0284C7; font-weight: 800; padding: 8px 18px;" onclick="saveEditVaccineExpiry('${batch.id}')">
              💾 ${isAr ? 'تحديث وحفظ التعديلات' : 'Update & Save Changes'}
            </button>
          </div>

        </div>
      </div>
    `;

    updateEditReminderCalculatedDate();
  }
  window.openEditVaccineExpiryModal = openEditVaccineExpiryModal;

  function handleEditVaccinePresetSelect(val) {
    const nameInput = document.getElementById('edit_ve_name');
    const select = document.getElementById('edit_ve_preset_select');
    if (!nameInput || !select) return;
    if (val === '__CUSTOM__') {
      nameInput.focus();
      return;
    }
    if (val) {
      nameInput.value = val;
      const opt = select.options[select.selectedIndex];
      const years = parseInt(opt ? opt.getAttribute('data-years') : 0, 10);
      if (years > 0) {
        applyEditVaccineExpiryPreset(years);
      }
    }
  }
  window.handleEditVaccinePresetSelect = handleEditVaccinePresetSelect;

  function applyEditVaccineExpiryPreset(years) {
    const adminInput = document.getElementById('edit_ve_admin_date');
    const expireInput = document.getElementById('edit_ve_expire_date');
    if (!expireInput) return;
    let baseDate = new Date();
    if (adminInput && adminInput.value) {
      const parsed = new Date(adminInput.value);
      if (!isNaN(parsed.getTime())) baseDate = parsed;
    }
    const expDate = new Date(baseDate);
    expDate.setFullYear(expDate.getFullYear() + years);
    expireInput.value = formatDateISO(expDate);
    updateEditReminderCalculatedDate();
  }
  window.applyEditVaccineExpiryPreset = applyEditVaccineExpiryPreset;

  function recalcEditExpiryFromAdminDate() {
    const select = document.getElementById('edit_ve_preset_select');
    if (select && select.selectedIndex > 0) {
      const opt = select.options[select.selectedIndex];
      const years = parseInt(opt ? opt.getAttribute('data-years') : 0, 10);
      if (years > 0) {
        applyEditVaccineExpiryPreset(years);
        return;
      }
    }
    updateEditReminderCalculatedDate();
  }
  window.recalcEditExpiryFromAdminDate = recalcEditExpiryFromAdminDate;

  function updateEditReminderCalculatedDate() {
    const expireInput = document.getElementById('edit_ve_expire_date');
    const reminderDateInput = document.getElementById('edit_ve_reminder_date');
    const reminderDaysSelect = document.getElementById('edit_ve_reminder_days');
    if (!expireInput || !reminderDateInput) return;
    const days = parseInt(reminderDaysSelect?.value || '15', 10);
    if (expireInput.value) {
      const expDate = parseDateSafe(expireInput.value);
      if (expDate) {
        reminderDateInput.value = formatDateISO(addDays(expDate, -days));
      }
    }
  }
  window.updateEditReminderCalculatedDate = updateEditReminderCalculatedDate;

  function saveEditVaccineExpiry(batchId) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    const idx = list.findIndex((b, i) => b.id === batchId || `standalone_ve_${i}` === batchId);
    if (idx === -1) {
      alert(isAr ? 'لم يتم العثور على سجل التشغيلة لحفظ التعديلات.' : 'Vaccine batch record not found to save.');
      return;
    }

    const vName = (document.getElementById('edit_ve_name')?.value || '').trim();
    const lot = (document.getElementById('edit_ve_lot')?.value || '').trim();
    const adminDate = document.getElementById('edit_ve_admin_date')?.value || '';
    const expireDate = document.getElementById('edit_ve_expire_date')?.value || '';
    const status = document.getElementById('edit_ve_status')?.value || 'active';
    const reminderActive = document.getElementById('edit_ve_reminder_active') ? document.getElementById('edit_ve_reminder_active').checked : true;
    const reminderDays = parseInt(document.getElementById('edit_ve_reminder_days')?.value || '15', 10);
    const reminderDate = document.getElementById('edit_ve_reminder_date')?.value || (expireDate ? formatDateISO(addDays(parseDateSafe(expireDate), -reminderDays)) : '');
    const notes = (document.getElementById('edit_ve_notes')?.value || '').trim();

    if (!vName) {
      alert(isAr ? 'يرجى إدخال اسم اللقاح.' : 'Please enter the vaccine name.');
      document.getElementById('edit_ve_name')?.focus();
      return;
    }
    if (!expireDate) {
      alert(isAr ? 'يرجى تحديد تاريخ انتهاء الصلاحية.' : 'Please select a vaccine expire date.');
      document.getElementById('edit_ve_expire_date')?.focus();
      return;
    }

    const target = list[idx];
    target.vaccineName = vName;
    target.vaccineLot = lot;
    target.adminDate = adminDate;
    target.expireDate = expireDate;
    target.dueDate = expireDate;
    target.title = isAr ? `انتهاء صلاحية تطعيم ${vName} واستحقاق الجرعة المنشطة` : `${vName} — Expire Date & Booster Due`;
    target.titleAr = `تطعيم ${vName} — مستودع اللقاحات`;
    target.reminderActive = reminderActive;
    target.reminderDays = reminderDays;
    target.reminderDate = reminderDate;
    target.notes = notes;
    target.completed = (status === 'completed');
    target.isCompleted = (status === 'completed');
    target.cancelled = (status === 'cancelled');
    target.isCancelled = (status === 'cancelled');
    target.updatedAt = new Date().toISOString();

    localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(list));

    closeCalendarModal();

    const container = document.getElementById('mainAppArea');
    if (container && typeof renderFollowupCalendar === 'function') {
      renderFollowupCalendar(container);
    }

    if (typeof window.showSuccessToast === 'function') {
      window.showSuccessToast(
        isAr ? `تم تحديث بيانات تشغيلة (${vName}) بنجاح ✅` : `Successfully updated vaccine batch (${vName}) ✅`,
        isAr ? 'تم التحديث بنجاح' : 'Batch Updated'
      );
    } else {
      alert(isAr ? `تم تحديث بيانات تشغيلة (${vName}) بنجاح ✅` : `Successfully updated vaccine batch (${vName}) ✅`);
    }
  }
  window.saveEditVaccineExpiry = saveEditVaccineExpiry;


  // --------------------------------------------------------------------------
  // 8. DAY DETAIL & CUSTOM SCHEDULING MODALS
  // --------------------------------------------------------------------------
  function openDayDetailModal(dateKey) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    activeModalDateKey = dateKey;
    const all = extractAllClinicalFollowups();
    const dayItems = all.filter(f => f.dueDateStr === dateKey && !f.isCompleted && !f.isCancelled);
    if (!dayItems || dayItems.length === 0) return;

    let modalBox = document.getElementById('calendarModalContainer');
    if (!modalBox) {
      modalBox = document.createElement('div');
      modalBox.id = 'calendarModalContainer';
      document.body.appendChild(modalBox);
    }

    const targetDate = parseDateSafe(dateKey);
    const dateFormatted = formatDateDisplay(targetDate, isAr);

    modalBox.innerHTML = `
      <div class="modal-backdrop-cal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); z-index: 9999; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px);">
        <div class="modal-card-cal" style="background: white; border-radius: 14px; width: 94%; max-width: 950px; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25);">
          <!-- Modal Header -->
          <div style="background: linear-gradient(135deg, #0D5C75 0%, #00838F 100%); color: white; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="font-size: 1.6rem;">🗓️</span>
              <div>
                <h3 style="margin: 0; font-size: 1.25rem; font-weight: 800;">
                  ${isAr ? `مواعيد المتابعة ليوم: ${dateFormatted}` : `Scheduled Follow-ups for: ${dateFormatted}`}
                </h3>
                <div style="font-size: 0.85rem; opacity: 0.9; margin-top: 2px;">
                  ${isAr ? `إجمالي الاستحقاقات السريرية: ${dayItems.length}` : `Total clinical actions due: ${dayItems.length}`}
                </div>
              </div>
            </div>
            <button type="button" style="background: transparent; border: none; color: white; font-size: 1.5rem; cursor: pointer; line-height: 1;" onclick="closeCalendarModal()">
              ✕
            </button>
          </div>

          <!-- Modal Body List -->
          <div style="padding: 20px; overflow-y: auto; flex: 1;">
            ${renderFollowupTable(dayItems, isAr, false)}
          </div>

          <!-- Modal Footer -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 24px; display: flex; justify-content: flex-end; gap: 10px;">
            <button type="button" class="btn btn-primary" onclick="closeCalendarModal()">
              ${isAr ? 'إغلاق' : 'Close'}
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // --------------------------------------------------------------------------
  // 5.5 DEDICATED VACCINATION EXPIRE DATE & STOCK INVENTORY LIST VIEW
  // --------------------------------------------------------------------------
  function renderVaccineExpiryListHTML(isAr) {
    ensureStandardVaccineStockInitialized();
    const stockList = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const activeBatches = stockList.filter(b => !b.completed && !b.cancelled);
    const consumedBatches = stockList.filter(b => b.completed);
    const cancelledBatches = stockList.filter(b => b.cancelled);

    let alert15Batches = 0;
    let expiredBatches = 0;
    let validBatches = 0;

    activeBatches.forEach(b => {
      const exp = parseDateSafe(b.expireDate || b.dueDate);
      if (exp) {
        const diff = getDaysDifference(exp, today);
        if (diff < 0) {
          expiredBatches++;
        } else if (diff <= (b.reminderDays || 15)) {
          alert15Batches++;
        } else {
          validBatches++;
        }
      }
    });

    return `
      <div class="card" style="background: white; border: 1.5px solid #F59E0B; border-radius: 12px; padding: 22px; box-shadow: 0 4px 12px rgba(217,119,6,0.08); margin-bottom: 25px;">
        <!-- Top Hero Title for Vaccine Expiration -->
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px; border-bottom: 2px solid #FEF3C7; padding-bottom: 16px; margin-bottom: 20px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 52px; height: 52px; border-radius: 12px; background: linear-gradient(135deg, #D97706 0%, #B45309 100%); color: white; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; box-shadow: 0 4px 8px rgba(180,83,9,0.3);">
              ⏳
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                <h3 style="margin: 0; font-size: 1.35rem; font-weight: 800; color: #78350F;">
                  ${isAr ? 'تاريخ انتهاء تشغيلة اللقاح' : 'Vaccine Batch Expire Date'}
                </h3>
                <span style="font-size: 0.76rem; background: #FEF3C7; color: #92400E; border: 1px solid #F59E0B; padding: 2px 8px; border-radius: 9999px; font-weight: 800;">
                  ${isAr ? 'مستودع عام (بدون أسماء موظفين)' : 'General Vaccine Stock (No Staff Names)'}
                </span>
              </div>
              <p style="margin: 3px 0 0 0; font-size: 0.88rem; color: #92400E;">
                ${isAr 
                  ? 'جدول تفصيلي لتتبع تواريخ انتهاء صلاحية تشغيلات اللقاحات في المستودع العام، وأرقام التشغيلات (Lot No)، مع نظام الإنذار المبكر قبل 15 يوماً.' 
                  : 'Comprehensive tracking of hospital vaccine shelf-life, batch lot numbers, and automated 15-day advance expiration alerts.'}
              </p>
            </div>
          </div>

          <!-- Stock Summary Badge (Clean, No Duplicate Buttons) -->
          <div style="background: #FFFBEB; border: 1.5px solid #F59E0B; border-radius: 8px; padding: 8px 16px; display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 1.4rem;">📦</span>
            <div>
              <div style="font-size: 0.72rem; color: #92400E; font-weight: 700; text-transform: uppercase;">
                ${isAr ? 'مستودع المستشفى' : 'Hospital Inventory'}
              </div>
              <div style="font-size: 0.95rem; font-weight: 800; color: #78350F;">
                ${stockList.length} ${isAr ? 'تشغيلة مسجلة' : 'Recorded Batches'}
              </div>
            </div>
          </div>
        </div>

        <!-- 5 KPI Summary Cards for Vaccine Expiry (Click Any Card To View Filtered List) -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; margin-bottom: 22px;">
          <!-- 1: Total Active -->
          <div class="card stat-card-cal" onclick="openVaccineStockCategoryListModal('active')" title="${isAr ? 'اضغط لعرض قائمة كافة التشغيلات النشطة' : 'Click to view active stock batches list'}" style="background: #FFFBEB; border: 1.5px solid #FDE68A; border-radius: 8px; padding: 12px 14px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);">
            <div style="font-size: 0.76rem; font-weight: 800; color: #92400E; text-transform: uppercase;">
              📦 ${isAr ? 'إجمالي التشغيلات الفعالة' : 'Active Stock Batches'}
            </div>
            <div style="font-size: 1.6rem; font-weight: 800; color: #78350F; margin-top: 2px;">
              ${activeBatches.length}
            </div>
            <div style="font-size: 0.72rem; color: #B45309; display: flex; justify-content: space-between; align-items: center; margin-top: 4px; border-top: 1px dashed #FDE68A; padding-top: 4px;">
              <span>${isAr ? 'جاهزة للاستخدام' : 'Available in storage'}</span>
              <span style="font-weight: 800; text-decoration: underline;">${isAr ? 'عرض القائمة ↗' : 'View List ↗'}</span>
            </div>
          </div>

          <!-- 2: Valid (> 15 Days) -->
          <div class="card stat-card-cal" onclick="openVaccineStockCategoryListModal('valid')" title="${isAr ? 'اضغط لعرض قائمة التشغيلات سارية الصلاحية' : 'Click to view valid batches list'}" style="background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 8px; padding: 12px 14px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);">
            <div style="font-size: 0.76rem; font-weight: 800; color: #166534; text-transform: uppercase;">
              🟢 ${isAr ? 'سارية الصلاحية (> 15 يوم)' : 'Valid (> 15 Days)'}
            </div>
            <div style="font-size: 1.6rem; font-weight: 800; color: #15803D; margin-top: 2px;">
              ${validBatches}
            </div>
            <div style="font-size: 0.72rem; color: #166534; display: flex; justify-content: space-between; align-items: center; margin-top: 4px; border-top: 1px dashed #86EFAC; padding-top: 4px;">
              <span>${isAr ? 'مأمونية عالية' : 'Full safety margin'}</span>
              <span style="font-weight: 800; text-decoration: underline;">${isAr ? 'عرض القائمة ↗' : 'View List ↗'}</span>
            </div>
          </div>

          <!-- 3: 15-Day Alert (Nearing Expiry) -->
          <div class="card stat-card-cal" onclick="openVaccineStockCategoryListModal('alert15')" title="${isAr ? 'اضغط لعرض قائمة التشغيلات التي أوشكت على الانتهاء' : 'Click to view 15-day alert batches list'}" style="background: #FEF3C7; border: 1.5px solid #F59E0B; border-radius: 8px; padding: 12px 14px; position: relative; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);">
            ${alert15Batches > 0 ? `<span style="position: absolute; top: 8px; ${isAr ? 'left: 8px;' : 'right: 8px;'}; background: #DC2626; color: white; font-size: 0.65rem; font-weight: 800; padding: 1px 6px; border-radius: 8px;">ALERT</span>` : ''}
            <div style="font-size: 0.76rem; font-weight: 800; color: #92400E; text-transform: uppercase;">
              ⚠️ ${isAr ? 'إنذار 15 يوماً (أوشكت)' : '15-Day Expiry Alert'}
            </div>
            <div style="font-size: 1.6rem; font-weight: 800; color: #D97706; margin-top: 2px;">
              ${alert15Batches}
            </div>
            <div style="font-size: 0.72rem; color: #92400E; font-weight: 700; display: flex; justify-content: space-between; align-items: center; margin-top: 4px; border-top: 1px dashed #F59E0B; padding-top: 4px;">
              <span>${isAr ? 'تتطلب طلباً عاجلاً' : 'Requires procurement'}</span>
              <span style="font-weight: 800; text-decoration: underline;">${isAr ? 'عرض القائمة ↗' : 'View List ↗'}</span>
            </div>
          </div>

          <!-- 4: Expired -->
          <div class="card stat-card-cal" onclick="openVaccineStockCategoryListModal('expired')" title="${isAr ? 'اضغط لعرض قائمة التشغيلات منتهية الصلاحية' : 'Click to view expired batches list'}" style="background: #FEF2F2; border: 1.5px solid #FCA5A5; border-radius: 8px; padding: 12px 14px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);">
            <div style="font-size: 0.76rem; font-weight: 800; color: #991B1B; text-transform: uppercase;">
              🔴 ${isAr ? 'منتهية الصلاحية' : 'Expired Batches'}
            </div>
            <div style="font-size: 1.6rem; font-weight: 800; color: #DC2626; margin-top: 2px;">
              ${expiredBatches}
            </div>
            <div style="font-size: 0.72rem; color: #991B1B; display: flex; justify-content: space-between; align-items: center; margin-top: 4px; border-top: 1px dashed #FCA5A5; padding-top: 4px;">
              <span>${isAr ? 'يجب حجرها أو إتلافها' : 'Must be quarantined'}</span>
              <span style="font-weight: 800; text-decoration: underline;">${isAr ? 'عرض القائمة ↗' : 'View List ↗'}</span>
            </div>
          </div>

          <!-- 5: Consumed History -->
          <div class="card stat-card-cal" onclick="openVaccineStockCategoryListModal('consumed')" title="${isAr ? 'اضغط لعرض أرشيف التشغيلات المستهلكة' : 'Click to view consumed batches archive'}" style="background: #F8FAFC; border: 1.5px solid #CBD5E1; border-radius: 8px; padding: 12px 14px; cursor: pointer; transition: all 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.04);">
            <div style="font-size: 0.76rem; font-weight: 800; color: #475569; text-transform: uppercase;">
              ✔️ ${isAr ? 'مستهلكة بالكامل (أرشيف)' : 'Consumed / Administered'}
            </div>
            <div style="font-size: 1.6rem; font-weight: 800; color: #334155; margin-top: 2px;">
              ${consumedBatches.length}
            </div>
            <div style="font-size: 0.72rem; color: #64748B; display: flex; justify-content: space-between; align-items: center; margin-top: 4px; border-top: 1px dashed #CBD5E1; padding-top: 4px;">
              <span>${isAr ? 'سجل الأرشيف' : 'Archive records logged'}</span>
              <span style="font-weight: 800; text-decoration: underline;">${isAr ? 'عرض القائمة ↗' : 'View List ↗'}</span>
            </div>
          </div>
        </div>

        <!-- Filter & Search Toolbar -->
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px 14px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <label style="font-size: 0.82rem; font-weight: 700; color: #475569;">
              ${isAr ? 'عرض حسب الحالة:' : 'Show Filter:'}
            </label>
            <select id="vaccine_expiry_view_filter" onchange="filterVaccineExpiryTable()" style="padding: 5px 10px; font-size: 0.85rem; border: 1.5px solid #CBD5E1; border-radius: 6px; background: white; font-weight: 600;">
              <option value="all">${isAr ? '📦 كافة التشغيلات النشطة' : 'All Active Batches'}</option>
              <option value="alert15">⚠️ ${isAr ? 'تنبيه الـ 15 يوماً فقط (Expiring Soon)' : '15-Day Alert Batches Only'}</option>
              <option value="valid">🟢 ${isAr ? 'سارية الصلاحية (> 15 يوم)' : 'Valid Batches Only'}</option>
              <option value="expired">🔴 ${isAr ? 'منتهية الصلاحية فقط' : 'Expired Batches Only'}</option>
              <option value="consumed">✔️ ${isAr ? 'سجل التشغيلات المستهلكة' : 'Consumed Batches (History)'}</option>
              <option value="all_including_history">📋 ${isAr ? 'كافة السجلات بما فيها الأرشيف' : 'All (Active & Consumed)'}</option>
            </select>
          </div>

          <div style="display: flex; align-items: center; gap: 8px;">
            <input type="text" id="vaccine_expiry_search_input" oninput="filterVaccineExpiryTable()" placeholder="${isAr ? 'بحث باسم اللقاح، رقم التشغيلة، مكان التخزين...' : 'Search vaccine, lot number, notes...'}" style="padding: 5px 10px; font-size: 0.85rem; border: 1.5px solid #CBD5E1; border-radius: 6px; width: 260px;" />
            <button type="button" class="btn btn-outline" style="background: #FEF2F2; color: #DC2626; border: 1.5px solid #FCA5A5; font-weight: 700; padding: 5px 10px; border-radius: 6px; font-size: 0.82rem; display: inline-flex; align-items: center; gap: 5px;" onclick="clearAllVaccineExpiries()" title="${isAr ? 'حذف وتفريغ كافة التشغيلات' : 'Delete all batch records to enter valid data'}">
              <span>🗑️</span> <span>${isAr ? 'حذف كافة البيانات' : 'Delete All'}</span>
            </button>
          </div>
        </div>

        <!-- Table Container -->
        <div id="vaccineExpiryTableContainer">
          ${renderVaccineExpiryTable(stockList, isAr, false)}
        </div>
      </div>
    `;
  }
  window.renderVaccineExpiryListHTML = renderVaccineExpiryListHTML;

  function renderVaccineExpiryTable(items, isAr, isHistory) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (!Array.isArray(items) || items.length === 0) {
      return `
        <div style="text-align: center; padding: 40px 20px; background: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 8px;">
          <div style="font-size: 2.2rem; margin-bottom: 8px;">📦</div>
          <div style="font-size: 1.1rem; font-weight: 800; color: #475569;">
            ${isAr ? 'لا توجد دفعات لقاحات مطابقة للبحث' : 'No vaccine batches found'}
          </div>
          <div style="font-size: 0.85rem; color: #64748B; margin-top: 4px;">
            ${isAr ? 'يمكنك إضافة دفعة لقاح جديدة من خلال الزر أعلاه.' : 'You can register a new vaccine stock batch using the button above.'}
          </div>
          <button type="button" class="btn" style="margin-top: 14px; background: #D97706; color: white; border: none; font-weight: 700; padding: 6px 14px; border-radius: 6px;" onclick="openScheduleCustomModal(false, 'vaccine_expiry')">
            ➕ ${isAr ? 'إضافة دفعة تطعيم جديدة' : 'Add New Vaccine Batch'}
          </button>
        </div>
      `;
    }

    return `
      <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; font-size: 0.88rem; text-align: ${isAr ? 'right' : 'left'};">
          <thead>
            <tr style="background: #FFFBEB; border-bottom: 2px solid #FCD34D; color: #92400E; font-weight: 800;">
              <th style="padding: 10px 8px; width: 35px; text-align: center;">#</th>
              <th style="padding: 10px 10px; min-width: 170px;">${isAr ? 'اسم اللقاح والنوع' : 'Vaccine Name & Type'}</th>
              <th style="padding: 10px 8px; min-width: 110px;">${isAr ? 'رقم التشغيلة' : 'Lot / Batch No'}</th>
              <th style="padding: 10px 8px; min-width: 95px;">${isAr ? 'تاريخ التوريد' : 'In-Stock Date'}</th>
              <th style="padding: 10px 10px; min-width: 145px;">${isAr ? 'تاريخ انتهاء الصلاحية' : 'Vaccine Batch Expire Date'}</th>
              <th style="padding: 10px 10px; min-width: 140px;">${isAr ? 'تنبيه 15 يوماً' : '15-Day Early Alert'}</th>
              <th style="padding: 10px 10px; min-width: 160px;">${isAr ? 'مكان التخزين والملاحظات' : 'Storage Unit & Notes'}</th>
              <th style="padding: 10px 8px; min-width: 85px; text-align: center;">${isAr ? 'الحالة' : 'Status'}</th>
              <th style="padding: 10px 10px; text-align: center; min-width: 160px;">${isAr ? 'الإجراءات' : 'Actions'}</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((v, idx) => {
              const expDate = parseDateSafe(v.expireDate || v.dueDate);
              const expDateFormatted = formatDateDisplay(expDate, isAr);
              const adminDateFormatted = formatDateDisplay(parseDateSafe(v.adminDate), isAr) || '—';
              const diffDays = expDate ? getDaysDifference(expDate, today) : 0;
              const isExpired = (diffDays < 0);
              const is15DayAlert = (diffDays <= (v.reminderDays || 15) && diffDays >= 0);
              const isCompleted = !!v.completed;
              const isCancelled = !!v.cancelled;

              let expiryBadgeHTML = '';
              let rowBg = 'white';
              if (isCompleted) {
                expiryBadgeHTML = `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 0.78rem; font-weight: 800; background: #DCFCE7; color: #15803D; border: 1px solid #86EFAC;">✔️ ${isAr ? 'مستهلكة بالكامل' : 'Consumed'}</span>`;
              } else if (isCancelled) {
                expiryBadgeHTML = `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 0.78rem; font-weight: 800; background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5;">❌ ${isAr ? 'ملغاة / تالفة' : 'Cancelled'}</span>`;
              } else if (isExpired) {
                rowBg = '#FEF2F2';
                expiryBadgeHTML = `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 0.78rem; font-weight: 800; background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5;">🔴 ${isAr ? 'منتهية الصلاحية' : 'Expired'} (${Math.abs(diffDays)} ${isAr ? 'يوم مضى' : 'days ago'})</span>`;
              } else if (is15DayAlert) {
                rowBg = '#FFFBEB';
                expiryBadgeHTML = `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 0.78rem; font-weight: 800; background: #FEF3C7; color: #B45309; border: 1.5px solid #F59E0B;">⚠️ ${isAr ? 'تنبيه أوشكت' : 'Expiring Soon'} (${diffDays} ${isAr ? 'يوم متبقي' : 'days left'})</span>`;
              } else {
                expiryBadgeHTML = `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 0.78rem; font-weight: 800; background: #F0FDF4; color: #166534; border: 1px solid #86EFAC;">🟢 ${isAr ? 'سارية' : 'Valid'} (${diffDays} ${isAr ? 'يوم' : 'days left'})</span>`;
              }

              const reminderAlertDate = v.reminderDate || (expDate ? formatDateISO(addDays(expDate, -(v.reminderDays || 15))) : '—');
              const reminderPill = isCompleted 
                ? `<span style="font-size: 0.74rem; color: #64748B;">—</span>`
                : (is15DayAlert 
                    ? `<div style="font-size: 0.76rem; background: #D97706; color: white; padding: 2px 8px; border-radius: 4px; font-weight: 800; display: inline-flex; align-items: center; gap: 4px;"><span>🔔</span> ${isAr ? 'تنبيه نشط الآن' : 'Alert ACTIVE'}</div>`
                    : `<div style="font-size: 0.76rem; background: #F1F5F9; color: #475569; padding: 2px 7px; border-radius: 4px; font-weight: 700; display: inline-flex; align-items: center; gap: 4px;"><span>⏱️</span> ${isAr ? 'تنبيه مجدول' : 'Scheduled'}</div>`);

              return `
                <tr style="border-bottom: 1px solid #F1F5F9; background: ${rowBg}; transition: background 0.15s ease;" onmouseover="this.style.background='#F8FAFC'" onmouseout="this.style.background='${rowBg}'">
                  <td style="padding: 12px 10px; text-align: center; font-weight: 800; color: #94A3B8;">
                    ${idx + 1}
                  </td>

                  <td style="padding: 12px;">
                    <div style="font-weight: 800; font-size: 0.92rem; color: #0F172A;">
                      💉 ${v.vaccineName || v.title}
                    </div>
                    <div style="font-size: 0.76rem; color: #64748B; margin-top: 2px;">
                      ${isAr ? 'مستودع اللقاحات • رعاية سريرية عامة' : 'Hospital Central Stock • General Clinical Coverage'}
                    </div>
                  </td>

                  <td style="padding: 12px;">
                    <span style="font-family: monospace; font-weight: 800; font-size: 0.85rem; background: #F1F5F9; border: 1.5px solid #CBD5E1; padding: 3px 8px; border-radius: 4px; color: #0F172A; display: inline-block;">
                      ${v.vaccineLot || 'LOT-GENERAL'}
                    </span>
                  </td>

                  <td style="padding: 12px; font-weight: 700; color: #334155;">
                    ${adminDateFormatted}
                  </td>

                  <td style="padding: 12px;">
                    <div style="font-weight: 800; font-size: 0.95rem; color: ${isExpired ? '#DC2626' : (is15DayAlert ? '#D97706' : '#15803D')};">
                      ⏳ ${expDateFormatted}
                    </div>
                    <div style="margin-top: 3px;">
                      ${expiryBadgeHTML}
                    </div>
                  </td>

                  <td style="padding: 12px;">
                    <div style="font-weight: 700; color: #92400E; font-size: 0.85rem;">
                      🔔 ${reminderAlertDate}
                    </div>
                    <div style="margin-top: 3px;">
                      ${reminderPill}
                    </div>
                  </td>

                  <td style="padding: 12px;">
                    <div style="font-size: 0.82rem; color: #334155; line-height: 1.35;">
                      ${v.notes || (isAr ? 'ثلاجة العيادة المركزية (2°C–8°C)' : 'Central Clinic Refrigerator (2°C–8°C)')}
                    </div>
                  </td>

                  <td style="padding: 12px; text-align: center;">
                    ${isCompleted 
                      ? `<span style="font-size: 0.78rem; font-weight: 800; color: #15803D;">✅ ${isAr ? 'مستهلك' : 'Done'}</span>`
                      : (isCancelled
                          ? `<span style="font-size: 0.78rem; font-weight: 800; color: #991B1B;">❌ ${isAr ? 'ملغي' : 'Cancelled'}</span>`
                          : (isExpired
                              ? `<span style="font-size: 0.78rem; font-weight: 800; color: #DC2626;">🔴 ${isAr ? 'منتهي' : 'Expired'}</span>`
                              : `<span style="font-size: 0.78rem; font-weight: 800; color: #059669;">🟢 ${isAr ? 'متوفر' : 'In Stock'}</span>`))}
                  </td>

                  <td style="padding: 12px; text-align: center;">
                    <div style="display: flex; gap: 5px; justify-content: center; align-items: center; flex-wrap: wrap;">
                      ${isCompleted ? `
                        <!-- Update / Edit -->
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #0284C7; color: #0284C7; background: #F0F9FF;" onclick="openEditVaccineExpiryModal('${v.id}')" title="${isAr ? 'تعديل وتحديث بيانات التشغيلة' : 'Edit / Update Batch Details'}">
                          ✏️ ${isAr ? 'تعديل' : 'Update'}
                        </button>
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 700; border-color: #DC2626; color: #DC2626; background: #FEF2F2;" onclick="deleteStandaloneVaccineExpiry('${v.id}')" title="${isAr ? 'حذف هذا السجل' : 'Delete Record'}">
                          🗑️ ${isAr ? 'حذف' : 'Delete'}
                        </button>
                      ` : (isCancelled ? `
                        <!-- Update / Edit -->
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #0284C7; color: #0284C7; background: #F0F9FF;" onclick="openEditVaccineExpiryModal('${v.id}')" title="${isAr ? 'تعديل وتحديث بيانات التشغيلة' : 'Edit / Update Batch Details'}">
                          ✏️ ${isAr ? 'تعديل' : 'Update'}
                        </button>
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 700; border-color: #DC2626; color: #DC2626; background: #FEF2F2;" onclick="deleteStandaloneVaccineExpiry('${v.id}')" title="${isAr ? 'حذف هذا السجل' : 'Delete Record'}">
                          🗑️ ${isAr ? 'حذف' : 'Delete'}
                        </button>
                      ` : `
                        <!-- 1. Mark Consumed / Administered -->
                        <button type="button" class="btn btn-success" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; background: #16A34A; border-color: #16A34A; color: white;" onclick="openCompleteFollowupModal('${v.id}')" title="${isAr ? 'تسجيل استهلاك الدفعة بالكامل' : 'Mark Batch Consumed / Completed'}">
                          ✅ ${isAr ? 'إتمام' : 'Complete'}
                        </button>

                        <!-- 2. Update / Edit Batch Details -->
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #0284C7; color: #0284C7; background: #F0F9FF;" onclick="openEditVaccineExpiryModal('${v.id}')" title="${isAr ? 'تعديل وتحديث بيانات تشغيلة اللقاح' : 'Edit / Update Vaccine Batch'}">
                          ✏️ ${isAr ? 'تعديل' : 'Update'}
                        </button>

                        <!-- 3. Renew / Reschedule Expire Date -->
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #D97706; color: #B45309; background: #FFFBEB;" onclick="openRescheduleFollowupModal('${v.id}')" title="${isAr ? 'تجديد تاريخ انتهاء الصلاحية' : 'Renew / Extend Expire Date'}">
                          🔄 ${isAr ? 'تجديد' : 'Renew'}
                        </button>

                        <!-- 4. Delete from Vaccine Stock -->
                        <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.78rem; font-weight: 800; border-color: #DC2626; color: #DC2626; background: #FEF2F2;" onclick="deleteStandaloneVaccineExpiry('${v.id}')" title="${isAr ? 'حذف هذا السجل من المخزون' : 'Delete Batch Record'}">
                          🗑️ ${isAr ? 'حذف' : 'Delete'}
                        </button>
                      `)}
                    </div>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    `;
  }
  window.renderVaccineExpiryTable = renderVaccineExpiryTable;

  function filterVaccineExpiryTable(explicitFilterVal) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const filterSelect = document.getElementById('vaccine_expiry_view_filter');
    const searchInput = document.getElementById('vaccine_expiry_search_input');
    const container = document.getElementById('vaccineExpiryTableContainer');
    if (!container) return;

    if (explicitFilterVal && filterSelect) {
      filterSelect.value = explicitFilterVal;
    }

    const filterVal = filterSelect ? filterSelect.value : 'all';
    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const allStock = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let filtered = allStock;

    if (filterVal === 'all') {
      filtered = filtered.filter(b => !b.completed && !b.cancelled);
    } else if (filterVal === 'alert15') {
      filtered = filtered.filter(b => {
        if (b.completed || b.cancelled) return false;
        const exp = parseDateSafe(b.expireDate || b.dueDate);
        if (!exp) return false;
        const diff = getDaysDifference(exp, today);
        return (diff <= (b.reminderDays || 15) && diff >= 0);
      });
    } else if (filterVal === 'valid') {
      filtered = filtered.filter(b => {
        if (b.completed || b.cancelled) return false;
        const exp = parseDateSafe(b.expireDate || b.dueDate);
        if (!exp) return false;
        const diff = getDaysDifference(exp, today);
        return diff > (b.reminderDays || 15);
      });
    } else if (filterVal === 'expired') {
      filtered = filtered.filter(b => {
        if (b.completed || b.cancelled) return false;
        const exp = parseDateSafe(b.expireDate || b.dueDate);
        if (!exp) return false;
        return getDaysDifference(exp, today) < 0;
      });
    } else if (filterVal === 'consumed') {
      filtered = filtered.filter(b => !!b.completed);
    }

    if (query) {
      filtered = filtered.filter(b => 
        (b.vaccineName && b.vaccineName.toLowerCase().includes(query)) ||
        (b.title && b.title.toLowerCase().includes(query)) ||
        (b.titleAr && b.titleAr.includes(query)) ||
        (b.vaccineLot && b.vaccineLot.toLowerCase().includes(query)) ||
        (b.notes && b.notes.toLowerCase().includes(query)) ||
        (b.expireDate && b.expireDate.includes(query))
      );
    }

    container.innerHTML = renderVaccineExpiryTable(filtered, isAr, filterVal === 'consumed');
  }
  window.filterVaccineExpiryTable = filterVaccineExpiryTable;

  // --------------------------------------------------------------------------
  // 5.6 INTERACTIVE VACCINE BATCH EXPIRY CATEGORY LIST MODAL (ON CARD CLICK)
  // --------------------------------------------------------------------------
  function openVaccineStockCategoryListModal(categoryKey) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const allStock = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Sync on-page table filter
    const selectVal = (categoryKey === 'active') ? 'all' : categoryKey;
    const filterSelect = document.getElementById('vaccine_expiry_view_filter');
    if (filterSelect) {
      filterSelect.value = selectVal;
      filterVaccineExpiryTable();
    }

    let filtered = allStock;
    let meta = {
      titleEn: 'Active Stock Batches',
      titleAr: 'ظƒط§ظپط© طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ„ظ‚ط§ط­ط§طھ ط§ظ„ظ†ط´ط·ط© ط¨ط§ظ„ظ…ط³طھظˆط¯ط¹',
      subtitleEn: 'Hospital vaccine inventory available and ready for clinical use',
      subtitleAr: 'ظ…ط®ط²ظˆظ† طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ„ظ‚ط§ط­ط§طھ ط§ظ„ظ…طھظˆظپط±ط© ط¨ط§ظ„ظ…ط³طھظˆط¯ط¹ ظˆط§ظ„ط¬ط§ظ‡ط²ط© ظ„ظ„ط§ط³طھط®ط¯ط§ظ… ط§ظ„ط³ط±ظٹط±ظٹ',
      icon: 'ًں“¦',
      color: '#D97706',
      badgeBg: '#FEF3C7',
      badgeColor: '#92400E'
    };

    if (categoryKey === 'active') {
      filtered = filtered.filter(b => !b.completed && !b.cancelled);
    } else if (categoryKey === 'valid') {
      filtered = filtered.filter(b => {
        if (b.completed || b.cancelled) return false;
        const exp = parseDateSafe(b.expireDate || b.dueDate);
        if (!exp) return false;
        return getDaysDifference(exp, today) > (b.reminderDays || 15);
      });
      meta = {
        titleEn: 'Valid Vaccine Batches (> 15 Days)',
        titleAr: 'طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ„ظ‚ط§ط­ط§طھ ط³ط§ط±ظٹط© ط§ظ„طµظ„ط§ط­ظٹط© (> 15 ظٹظˆظ…ط§ظ‹)',
        subtitleEn: 'Batches with safe operational shelf-life remaining',
        subtitleAr: 'طھط´ط؛ظٹظ„ط§طھ ط°ط§طھ ظ…ط£ظ…ظˆظ†ظٹط© ط¹ط§ظ„ظٹط© ظˆطµظ„ط§ط­ظٹط© طھط´ط؛ظٹظ„ظٹط© ط¢ظ…ظ†ط©',
        icon: 'ًںں¢',
        color: '#16A34A',
        badgeBg: '#DCFCE7',
        badgeColor: '#166534'
      };
    } else if (categoryKey === 'alert15') {
      filtered = filtered.filter(b => {
        if (b.completed || b.cancelled) return false;
        const exp = parseDateSafe(b.expireDate || b.dueDate);
        if (!exp) return false;
        const diff = getDaysDifference(exp, today);
        return (diff <= (b.reminderDays || 15) && diff >= 0);
      });
      meta = {
        titleEn: '15-Day Expiry Alert Batches (Nearing Expiry)',
        titleAr: 'ط¥ظ†ط°ط§ط± 15 ظٹظˆظ…ط§ظ‹ â€” طھط´ط؛ظٹظ„ط§طھ ظ‚ط§ط±ط¨طھ طµظ„ط§ط­ظٹطھظ‡ط§ ط¹ظ„ظ‰ ط§ظ„ط§ظ†طھظ‡ط§ط،',
        subtitleEn: 'Requires urgent procurement, expedited administration, or stock rotation',
        subtitleAr: 'طھطھط·ظ„ط¨ ط·ظ„ط¨ط§ظ‹ ط¹ط§ط¬ظ„ط§ظ‹ ظ„ظ„طھظˆط±ظٹط¯طŒ ط£ظˆ طھط³ط±ظٹط¹ ط¥ط¹ط·ط§ط¦ظ‡ط§ ظˆطھط¯ظˆظٹط± ط§ظ„ظ…ط®ط²ظˆظ†',
        icon: 'âڑ ï¸ڈ',
        color: '#D97706',
        badgeBg: '#FEF3C7',
        badgeColor: '#92400E'
      };
    } else if (categoryKey === 'expired') {
      filtered = filtered.filter(b => {
        if (b.completed || b.cancelled) return false;
        const exp = parseDateSafe(b.expireDate || b.dueDate);
        if (!exp) return false;
        return getDaysDifference(exp, today) < 0;
      });
      meta = {
        titleEn: 'Expired Vaccine Batches',
        titleAr: 'طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ„ظ‚ط§ط­ط§طھ ظ…ظ†طھظ‡ظٹط© ط§ظ„طµظ„ط§ط­ظٹط©',
        subtitleEn: 'Mandatory quarantine and immediate safe medical disposal protocol',
        subtitleAr: 'ظٹط¬ط¨ ط¹ط²ظ„ظ‡ط§ ظپظˆط±ط§ظ‹ ظˆطھط·ط¨ظٹظ‚ ط¨ط±ظˆطھظˆظƒظˆظ„ ط§ظ„ط¥طھظ„ط§ظپ ط§ظ„ط·ط¨ظٹ ط§ظ„ط¢ظ…ظ† ط§ظ„ظ…ط¹طھظ…ط¯',
        icon: 'ًں”´',
        color: '#DC2626',
        badgeBg: '#FEE2E2',
        badgeColor: '#991B1B'
      };
    } else if (categoryKey === 'consumed') {
      filtered = filtered.filter(b => !!b.completed);
      meta = {
        titleEn: 'Consumed / Administered Vaccine Batches',
        titleAr: 'ط³ط¬ظ„ ظˆط£ط±ط´ظٹظپ طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ„ظ‚ط§ط­ط§طھ ط§ظ„ظ…ط³طھظ‡ظ„ظƒط© ظˆط§ظ„ظ…ط¹ط·ط§ط© ط¨ط§ظ„ظƒط§ظ…ظ„',
        subtitleEn: 'Historical archive of exhausted or fully administered vaccine lots',
        subtitleAr: 'ط³ط¬ظ„ ط£ط±ط´ظٹظپظٹ ظ…ظˆط«ظ‚ ظ„ظ„طھط´ط؛ظٹظ„ط§طھ ط§ظ„طھظٹ طھظ… ط§ط³طھظ‡ظ„ط§ظƒظ‡ط§ ط£ظˆ ط¥ط¹ط·ط§ط¤ظ‡ط§ ط¨ط§ظ„ظƒط§ظ…ظ„',
        icon: 'âœ”ï¸ڈ',
        color: '#475569',
        badgeBg: '#F1F5F9',
        badgeColor: '#334155'
      };
    }

    let modalContainer = document.getElementById('calendarModalContainer');
    if (!modalContainer) {
      modalContainer = document.createElement('div');
      modalContainer.id = 'calendarModalContainer';
      document.body.appendChild(modalContainer);
    }

    const title = isAr ? meta.titleAr : meta.titleEn;
    const subtitle = isAr ? meta.subtitleAr : meta.subtitleEn;

    modalContainer.innerHTML = `
      <div style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.72); z-index: 99999; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;" onclick="if(event.target === this) closeCalendarModal()">
        <div style="background: white; border-radius: 14px; width: 95%; max-width: 1120px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35); max-height: 90vh; display: flex; flex-direction: column;" onclick="event.stopPropagation()">
          <!-- MODAL HEADER -->
          <div style="background: linear-gradient(135deg, ${meta.color} 0%, #0F172A 100%); color: white; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid rgba(255,255,255,0.15);">
            <div style="display: flex; align-items: center; gap: 12px;">
              <span style="font-size: 1.8rem;">${meta.icon}</span>
              <div>
                <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                  <h3 style="margin: 0; font-size: 1.25rem; font-weight: 800; letter-spacing: -0.01em;">
                    ${title}
                  </h3>
                  <span style="font-size: 0.76rem; background: ${meta.badgeBg}; color: ${meta.badgeColor}; padding: 2px 10px; border-radius: 9999px; font-weight: 800;">
                    ${filtered.length} ${isAr ? 'طھط´ط؛ظٹظ„ط© ظ…ط³ط¬ظ„ط©' : 'Recorded Batches'}
                  </span>
                </div>
                <div style="font-size: 0.82rem; opacity: 0.9; margin-top: 3px;">
                  ${subtitle}
                </div>
              </div>
            </div>
            <button type="button" onclick="closeCalendarModal()" style="background: transparent; border: none; color: white; font-size: 1.6rem; cursor: pointer; line-height: 1; padding: 4px 8px;" title="${isAr ? 'ط¥ط؛ظ„ط§ظ‚' : 'Close'}">&times;</button>
          </div>

          <!-- MODAL BODY -->
          <div style="padding: 20px 24px; overflow-y: auto; flex: 1;">
            ${filtered.length === 0 ? `
              <div style="text-align: center; padding: 40px 20px; color: #64748B;">
                <span style="font-size: 2.8rem;">ًںژ‰</span>
                <h4 style="margin: 12px 0 6px 0; color: #0F172A; font-size: 1.1rem; font-weight: 800;">
                  ${isAr ? 'ظ„ط§ طھظˆط¬ط¯ طھط´ط؛ظٹظ„ط§طھ ظ…ط³ط¬ظ„ط© ظپظٹ ظ‡ط°ط§ ط§ظ„طھطµظ†ظٹظپ' : 'No Batches Found in This Category'}
                </h4>
                <p style="margin: 0; font-size: 0.88rem;">
                  ${isAr ? 'ظ…ط³طھظˆط¯ط¹ ط§ظ„ظ„ظ‚ط§ط­ط§طھ ظ„ط§ ظٹط­طھظˆظٹ ط­ط§ظ„ظٹط§ظ‹ ط¹ظ„ظ‰ طھط´ط؛ظٹظ„ط§طھ طھظ†ط¯ط±ط¬ طھط­طھ ظ‡ط°ظ‡ ط§ظ„ظپط¦ط©.' : 'The hospital vaccine repository currently has no records matching this criteria.'}
                </p>
              </div>
            ` : `
              ${renderVaccineExpiryTable(filtered, isAr, categoryKey === 'consumed')}
            `}
          </div>

          <!-- MODAL FOOTER -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 14px 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div style="display: flex; gap: 8px;">
              <button type="button" class="btn" style="background: #D97706; color: white; border: none; font-weight: 700; padding: 7px 14px; border-radius: 6px; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 6px;" onclick="closeCalendarModal(); openScheduleCustomModal(false, 'vaccine_expiry');">
                <span>â‍•</span> <span>${isAr ? 'ط¥ط¶ط§ظپط© طھط´ط؛ظٹظ„ط© ظ„ظ‚ط§ط­' : 'Add Vaccine Batch'}</span>
              </button>
              <button type="button" class="btn btn-outline" style="background: white; color: #0D5C75; border: 1.5px solid #0D5C75; font-weight: 700; padding: 7px 14px; border-radius: 6px; font-size: 0.85rem; display: inline-flex; align-items: center; gap: 6px;" onclick="printVaccineStockCategory('${categoryKey}')">
                <span>ًں–¨ï¸ڈ</span> <span>${isAr ? 'ط·ط¨ط§ط¹ط© ظ‡ط°ط§ ط§ظ„ظƒط´ظپ' : 'Print This List'}</span>
              </button>
            </div>
            <button type="button" class="btn btn-outline" onclick="closeCalendarModal()" style="padding: 7px 18px; font-weight: 700; border-color: #CBD5E1; color: #475569;">
              ${isAr ? 'ط¥ط؛ظ„ط§ظ‚' : 'Close'}
            </button>
          </div>
        </div>
      </div>
    `;
  }
  window.openVaccineStockCategoryListModal = openVaccineStockCategoryListModal;

  function printVaccineStockCategory(categoryKey) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const allStock = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let filtered = allStock;
    let catTitle = isAr ? 'ظƒط´ظپ طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ„ظ‚ط§ط­ط§طھ' : 'Vaccine Batches Report';
    if (categoryKey === 'active') {
      filtered = filtered.filter(b => !b.completed && !b.cancelled);
      catTitle = isAr ? 'ظƒط´ظپ ط§ظ„طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ†ط´ط·ط© ط¨ظ…ط³طھظˆط¯ط¹ ط§ظ„ظ„ظ‚ط§ط­ط§طھ' : 'Active Vaccine Batches Report';
    } else if (categoryKey === 'valid') {
      filtered = filtered.filter(b => !b.completed && !b.cancelled && getDaysDifference(parseDateSafe(b.expireDate || b.dueDate), today) > (b.reminderDays || 15));
      catTitle = isAr ? 'ظƒط´ظپ ط§ظ„طھط´ط؛ظٹظ„ط§طھ ط³ط§ط±ظٹط© ط§ظ„طµظ„ط§ط­ظٹط©' : 'Valid Vaccine Batches Report';
    } else if (categoryKey === 'alert15') {
      filtered = filtered.filter(b => {
        if (b.completed || b.cancelled) return false;
        const diff = getDaysDifference(parseDateSafe(b.expireDate || b.dueDate), today);
        return diff <= (b.reminderDays || 15) && diff >= 0;
      });
      catTitle = isAr ? 'ظƒط´ظپ ط¥ظ†ط°ط§ط± 15 ظٹظˆظ…ط§ظ‹ ظ„ظ‚ط±ط¨ ط§ظ†طھظ‡ط§ط، ط§ظ„طµظ„ط§ط­ظٹط©' : '15-Day Vaccine Expiry Alert Report';
    } else if (categoryKey === 'expired') {
      filtered = filtered.filter(b => !b.completed && !b.cancelled && getDaysDifference(parseDateSafe(b.expireDate || b.dueDate), today) < 0);
      catTitle = isAr ? 'ظƒط´ظپ ط§ظ„طھط´ط؛ظٹظ„ط§طھ ظ…ظ†طھظ‡ظٹط© ط§ظ„طµظ„ط§ط­ظٹط© (ط¹ط²ظ„ ظˆط¥طھظ„ط§ظپ ط·ط¨ظٹ)' : 'Expired Vaccine Batches Report';
    } else if (categoryKey === 'consumed') {
      filtered = filtered.filter(b => !!b.completed);
      catTitle = isAr ? 'ط£ط±ط´ظٹظپ ط§ظ„طھط´ط؛ظٹظ„ط§طھ ط§ظ„ظ…ط³طھظ‡ظ„ظƒط© ظˆط§ظ„ظ…ط¹ط·ط§ط© ط¨ط§ظ„ظƒط§ظ…ظ„' : 'Consumed Vaccine Batches Archive';
    }

    const printWin = window.open('', '_blank', 'width=1000,height=750');
    if (!printWin) {
      window.print();
      return;
    }

    const rowsHTML = filtered.map((v, idx) => {
      const expDate = parseDateSafe(v.expireDate || v.dueDate);
      const diff = expDate ? getDaysDifference(expDate, today) : 0;
      const statusText = v.completed ? (isAr ? 'ظ…ط³طھظ‡ظ„ظƒط©' : 'Consumed') : (diff < 0 ? (isAr ? 'ظ…ظ†طھظ‡ظٹط©' : 'Expired') : (diff <= (v.reminderDays || 15) ? (isAr ? 'طھظ†ط¨ظٹظ‡ 15 ظٹظˆظ…' : 'Alert â‰¤15d') : (isAr ? 'ط³ط§ط±ظٹط©' : 'Valid')));
      return `
        <tr>
          <td style="text-align: center;">${idx + 1}</td>
          <td><strong>${v.vaccineName || v.title}</strong></td>
          <td style="font-family: monospace;">${v.vaccineLot || 'â€”'}</td>
          <td>${formatDateDisplay(parseDateSafe(v.adminDate), isAr) || 'â€”'}</td>
          <td style="font-weight: bold;">${formatDateDisplay(expDate, isAr)}</td>
          <td>${diff < 0 ? Math.abs(diff) + 'd overdue' : diff + 'd remaining'}</td>
          <td>${v.reminderDate || 'â€”'}</td>
          <td>${v.notes || 'â€”'}</td>
          <td style="text-align: center;">${statusText}</td>
        </tr>
      `;
    }).join('');

    printWin.document.write(`
      <!DOCTYPE html>
      <html dir="${isAr ? 'rtl' : 'ltr'}">
      <head>
        <meta charset="UTF-8">
        <title>${catTitle} - AVH</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 24px; color: #0F172A; }
          .header { border-bottom: 2.5px solid #D97706; padding-bottom: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
          table { width: 100%; border-collapse: collapse; font-size: 11pt; }
          th { background: #FEF3C7; color: #78350F; border: 1px solid #CBD5E1; padding: 8px; text-align: ${isAr ? 'right' : 'left'}; }
          td { border: 1px solid #CBD5E1; padding: 8px; text-align: ${isAr ? 'right' : 'left'}; }
          @media print { button { display: none; } }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h2 style="margin: 0; color: #78350F;">${isAr ? 'ظ…ط³طھط´ظپظ‰ ط§ظ„ظ…ط·ظ„ط¹ â€” ط§ظ„ظ‚ط¯ط³ (Augusta Victoria Hospital)' : 'Augusta Victoria Hospital â€” Jerusalem'}</h2>
            <h3 style="margin: 4px 0 0 0; color: #0F172A;">${catTitle}</h3>
          </div>
          <div style="text-align: ${isAr ? 'left' : 'right'}; font-size: 9pt; color: #64748B;">
            ${isAr ? 'طھط§ط±ظٹط® ط§ظ„ط·ط¨ط§ط¹ط©:' : 'Printed on:'} ${new Date().toLocaleDateString()}<br>
            ${isAr ? 'ط¥ط¬ظ…ط§ظ„ظٹ ط§ظ„طھط´ط؛ظٹظ„ط§طھ:' : 'Total Batches:'} ${filtered.length}
          </div>
        </div>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>${isAr ? 'ط§ط³ظ… ط§ظ„ظ„ظ‚ط§ط­' : 'Vaccine Name'}</th>
              <th>${isAr ? 'ط±ظ‚ظ… ط§ظ„طھط´ط؛ظٹظ„ط©' : 'Lot No'}</th>
              <th>${isAr ? 'طھط§ط±ظٹط® ط§ظ„طھظˆط±ظٹط¯' : 'In-Stock'}</th>
              <th>${isAr ? 'طھط§ط±ظٹط® ط§ظ†طھظ‡ط§ط، ط§ظ„طµظ„ط§ط­ظٹط©' : 'Vaccine Batch Expire Date'}</th>
              <th>${isAr ? 'ط§ظ„ط£ظٹط§ظ… ط§ظ„ظ…طھط¨ظ‚ظٹط©' : 'Days'}</th>
              <th>${isAr ? 'طھط§ط±ظٹط® ط§ظ„طھظ†ط¨ظٹظ‡ (15 ظٹظˆظ…)' : 'Alert Date'}</th>
              <th>${isAr ? 'ظ…ظƒط§ظ† ط§ظ„طھط®ط²ظٹظ† ظˆط§ظ„ظ…ظ„ط§ط­ط¸ط§طھ' : 'Notes'}</th>
              <th style="text-align: center;">${isAr ? 'ط§ظ„ط­ط§ظ„ط©' : 'Status'}</th>
            </tr>
          </thead>
          <tbody>${rowsHTML}</tbody>
        </table>
        <script>
          window.onload = function() { window.print(); };
        </script>
      </body>
      </html>
    `);
    printWin.document.close();
  }
  window.printVaccineStockCategory = printVaccineStockCategory;

  function printVaccineExpiryList() {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const stockList = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const printWin = window.open('', '_blank', 'width=1000,height=750');
    if (!printWin) {
      window.print();
      return;
    }

    const printDate = new Date().toLocaleDateString(isAr ? 'ar-EG' : 'en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const printTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const html = `<!DOCTYPE html>
<html dir="${isAr ? 'rtl' : 'ltr'}" lang="${isAr ? 'ar' : 'en'}">
<head>
  <meta charset="UTF-8">
  <title>${isAr ? 'كشف تواريخ انتهاء صلاحية اللقاحات - مستشفى المطلع' : 'Hospital Vaccine Expiration Inventory - AVH'}</title>
  <style>
    @page { size: A4 landscape; margin: 12mm; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; margin: 0; padding: 20px; color: #0F172A; }
    .header-box { display: flex; justify-content: space-between; align-items: center; border-bottom: 2.5px solid #D97706; padding-bottom: 12px; margin-bottom: 16px; }
    .title-area h1 { margin: 0; font-size: 1.35rem; color: #92400E; }
    .title-area p { margin: 4px 0 0 0; font-size: 0.85rem; color: #475569; }
    .meta-area { text-align: ${isAr ? 'left' : 'right'}; font-size: 0.8rem; color: #64748B; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 0.82rem; }
    th { background: #D97706; color: white; padding: 8px 10px; text-align: ${isAr ? 'right' : 'left'}; font-weight: 700; border: 1px solid #D97706; }
    td { padding: 7px 10px; border: 1px solid #E2E8F0; vertical-align: middle; }
    tr:nth-child(even) td { background: #FFFBEB; }
    .badge { display: inline-block; padding: 2px 7px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; }
    .badge-alert { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
    .badge-valid { background: #DCFCE7; color: #15803D; border: 1px solid #86EFAC; }
    .badge-expired { background: #450A0A; color: white; }
    .footer-box { margin-top: 25px; display: flex; justify-content: space-between; align-items: flex-end; padding-top: 15px; border-top: 1px dashed #CBD5E1; font-size: 0.8rem; color: #64748B; }
    .sig-box { border-top: 1px solid #0F172A; width: 220px; text-align: center; padding-top: 6px; font-weight: bold; }
    @media print {
      .no-print { display: none !important; }
      body { padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="margin-bottom: 15px; display: flex; justify-content: flex-end; gap: 10px;">
    <button onclick="window.print()" style="padding: 8px 16px; background: #D97706; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
      🖨️ ${isAr ? 'طباعة كشف الصلاحية الآن' : 'Print Expiry Report Now'}
    </button>
    <button onclick="window.close()" style="padding: 8px 16px; background: #E2E8F0; color: #334155; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
      ✖ ${isAr ? 'إغلاق النافذة' : 'Close'}
    </button>
  </div>

  <div class="header-box">
    <div class="title-area">
      <h1>⏳ ${isAr ? 'مستشفى المُطلع - مستودع اللقاحات العام' : 'Augusta Victoria Hospital — General Vaccine Stock'}</h1>
      <p><strong>${isAr ? 'كشف تواريخ انتهاء الصلاحية والتشغيلات ونظام الإنذار المبكر (15 يوماً)' : 'Vaccine Shelf-Life, Batch Lot Inventory & 15-Day Early Alert System'}</strong></p>
    </div>
    <div class="meta-area">
      <div><strong>${isAr ? 'تاريخ التقرير:' : 'Date:'}</strong> ${printDate} ${printTime}</div>
      <div><strong>${isAr ? 'إجمالي التشغيلات:' : 'Total Batches:'}</strong> ${stockList.length}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width: 35px;">#</th>
        <th>${isAr ? 'اسم اللقاح' : 'Vaccine Name'}</th>
        <th style="width: 130px;">${isAr ? 'رقم التشغيلة (Lot No)' : 'Batch / Lot No'}</th>
        <th style="width: 100px;">${isAr ? 'تاريخ التوريد/الإعطاء' : 'Admin/Received'}</th>
        <th style="width: 110px;">${isAr ? 'تاريخ انتهاء الصلاحية' : 'Vaccine Expire Date'}</th>
        <th style="width: 90px;">${isAr ? 'الأيام المتبقية' : 'Days Left'}</th>
        <th style="width: 120px;">${isAr ? 'تاريخ التنبيه المسبق' : '15-Day Alert Date'}</th>
        <th style="width: 100px;">${isAr ? 'حالة الصلاحية' : 'Status'}</th>
        <th>${isAr ? 'ملاحظات المستودع والتخزين' : 'Storage / Clinic Notes'}</th>
      </tr>
    </thead>
    <tbody>
      ${stockList.length === 0 ? `
        <tr><td colspan="9" style="text-align: center; padding: 25px; color: #64748B;">${isAr ? 'لا توجد دفعات لقاحات مسجلة في المستودع.' : 'No vaccine stock records found in storage.'}</td></tr>
      ` : stockList.map((b, idx) => {
        const expDate = parseDateSafe(b.expireDate || b.dueDate);
        const diffDays = expDate ? getDaysDifference(expDate, today) : 0;
        let statusBadge = '';
        if (b.completed) statusBadge = `<span class="badge" style="background: #E2E8F0; color: #475569;">${isAr ? 'مستهلكة' : 'CONSUMED'}</span>`;
        else if (b.cancelled) statusBadge = `<span class="badge" style="background: #F1F5F9; color: #64748B;">${isAr ? 'ملغاة' : 'CANCELLED'}</span>`;
        else if (diffDays < 0) statusBadge = `<span class="badge badge-expired">${isAr ? 'منتهية الصلاحية' : 'EXPIRED'}</span>`;
        else if (diffDays <= (b.reminderDays || 15)) statusBadge = `<span class="badge badge-alert">⚠️ ${isAr ? 'إنذار 15 يوم' : '15-DAY ALERT'}</span>`;
        else statusBadge = `<span class="badge badge-valid">✅ ${isAr ? 'صالحة' : 'VALID'}</span>`;

        return `
          <tr>
            <td style="text-align: center;">${idx + 1}</td>
            <td><strong>${b.vaccineName || b.title || ''}</strong></td>
            <td><code style="background: #F1F5F9; padding: 2px 6px; border-radius: 4px; font-weight: bold;">${b.vaccineLot || '-'}</code></td>
            <td>${b.adminDate || '-'}</td>
            <td><strong style="color: ${diffDays < 0 ? '#DC2626' : (diffDays <= 15 ? '#D97706' : '#15803D')};">${b.expireDate || '-'}</strong></td>
            <td style="text-align: center; font-weight: bold;">${diffDays < 0 ? `${Math.abs(diffDays)} ${isAr ? 'يوم مضى' : 'days ago'}` : `${diffDays} ${isAr ? 'يوم' : 'days'}`}</td>
            <td>${b.reminderDate || '-'}</td>
            <td>${statusBadge}</td>
            <td><span style="font-size: 0.78rem;">${b.notes || '-'}</span></td>
          </tr>
        `;
      }).join('')}
    </tbody>
  </table>

  <div class="footer-box">
    <div>
      <div>${isAr ? 'مستودع الصيدلية واللقاحات العامة - قسم الصحة المهنية' : 'Hospital Pharmacy & General Vaccine Supply — Occupational Health'}</div>
      <div>${isAr ? 'كشف معتمد لتتبع صلاحيات التشغيلات واستبدال المخزون' : 'Certified inventory report for stock replenishment & expiration tracking'}</div>
    </div>
    <div class="sig-box">
      ${isAr ? 'توقيع الصيدلي / مسؤول المستودع' : 'Pharmacist / Supply Officer Signature'}
    </div>
  </div>

  <script>
    window.onload = function() {
      setTimeout(function() { window.print(); }, 400);
    };
  <\/script>
</body>
</html>`;

    printWin.document.open();
    printWin.document.write(html);
    printWin.document.close();
  }
  window.printVaccineExpiryList = printVaccineExpiryList;

  function exportVaccineExpiryToExcel() {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const stockList = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
    if (!Array.isArray(stockList) || stockList.length === 0) {
      alert(isAr ? 'ظ„ط§ طھظˆط¬ط¯ ط¨ظٹط§ظ†ط§طھ ظ„ظ‚ط§ط­ط§طھ ظ„ظ„طھطµط¯ظٹط±.' : 'No vaccine stock records to export.');
      return;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let csvContent = '\uFEFF'; // UTF-8 BOM
    csvContent += 'Index,Vaccine Name,Lot Number,Administered Date,Vaccine Batch Expire Date,Days Remaining,15-Day Alert Trigger Date,Storage Notes,Status\n';

    stockList.forEach((b, idx) => {
      const expDate = parseDateSafe(b.expireDate || b.dueDate);
      const diffDays = expDate ? getDaysDifference(expDate, today) : '';
      let statusStr = 'IN STOCK';
      if (b.completed) statusStr = 'CONSUMED';
      else if (b.cancelled) statusStr = 'CANCELLED';
      else if (diffDays < 0) statusStr = 'EXPIRED';
      else if (diffDays <= (b.reminderDays || 15)) statusStr = '15-DAY ALERT';

      const row = [
        idx + 1,
        `"${(b.vaccineName || b.title || '').replace(/"/g, '""')}"`,
        `"${(b.vaccineLot || '').replace(/"/g, '""')}"`,
        b.adminDate || '',
        b.expireDate || '',
        diffDays,
        b.reminderDate || '',
        `"${(b.notes || '').replace(/"/g, '""')}"`,
        statusStr
      ];
      csvContent += row.join(',') + '\n';
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `AVH_Vaccine_Expiration_List_${formatDateISO(new Date())}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  window.exportVaccineExpiryToExcel = exportVaccineExpiryToExcel;

    window.openDayDetailModal = openDayDetailModal;

  // --------------------------------------------------------------------------
  // 7.5 CATEGORY STAFF ROSTER MODAL (OPENED BY CLICKING ANY KPI STAT CARD)
  // --------------------------------------------------------------------------
  function openCategoryStaffRosterModal(catKey) {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const allFollowups = extractAllClinicalFollowups();
    const activeFollowups = allFollowups.filter(f => !f.isCompleted && !f.isCancelled);
    const calMonth = currentCalDate.getMonth();
    const calYear = currentCalDate.getFullYear();

    const monthNamesEn = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthNamesAr = ['يناير (1)', 'فبراير (2)', 'مارس (3)', 'أبريل (4)', 'مايو (5)', 'يونيو (6)', 'يوليو (7)', 'أغسطس (8)', 'سبتمبر (9)', 'أكتوبر (10)', 'نوفمبر (11)', 'ديسمبر (12)'];
    const curMonthName = isAr ? monthNamesAr[calMonth] : monthNamesEn[calMonth];

    let items = [];
    let modalTitle = '';
    let modalSubtitle = '';
    let badgeColor = '';
    let icon = '';

    if (catKey === 'overdue') {
      icon = '⚠️';
      modalTitle = isAr ? `قائمة الكوادر المتأخرة عن المواعيد (${curMonthName} ${calYear})` : `Overdue Staff Follow-up Roster (${curMonthName} ${calYear})`;
      modalSubtitle = isAr ? 'فحوصات وتطعيمات تجاوزت موعدها المحدد وتتطلب تدخلاً عاجلاً' : 'Clinical actions that have passed their due date requiring urgent clinic follow-up';
      badgeColor = '#DC2626';
      items = activeFollowups.filter(f => f.status === 'overdue');
    } else if (catKey === 'today') {
      icon = '🎯';
      modalTitle = isAr ? `قائمة الكوادر المستحقة اليوم في العيادة` : `Staff Due Today in Clinic`;
      modalSubtitle = isAr ? 'مواعيد وتطعيمات وفحوصات مجدولة ليومنا هذا' : 'Follow-up appointments and repeat tests scheduled for today';
      badgeColor = '#0284C7';
      items = activeFollowups.filter(f => f.status === 'today');
    } else if (catKey === 'week') {
      icon = '🗓️';
      modalTitle = isAr ? `قائمة الكوادر المستحقة خلال 7 أيام القادمة` : `Upcoming Staff Follow-ups (Next 7 Days)`;
      modalSubtitle = isAr ? 'المواعيد القادمة الجاهزة للتواصل والتنسيق مع الأقسام' : 'Appointments scheduled in the upcoming week ready for coordination';
      badgeColor = '#D97706';
      items = activeFollowups.filter(f => f.status === 'upcoming' && f.diffDays <= 7);
    } else if (catKey === 'month') {
      icon = '📅';
      modalTitle = isAr ? `كافة استحقاقات الكوادر لشهر ${curMonthName} ${calYear}` : `All Scheduled Staff Follow-ups for ${curMonthName} ${calYear}`;
      modalSubtitle = isAr ? `إجمالي التطعيمات والفحوصات المجدولة لكافة الأقسام خلال هذا الشهر` : `Total vaccinations and diagnostic tests scheduled during this month`;
      badgeColor = '#059669';
      items = activeFollowups.filter(f => {
        const d = f.dueDate;
        return d.getMonth() === calMonth && d.getFullYear() === calYear;
      });
    } else if (catKey === 'completed') {
      icon = '✅';
      modalTitle = isAr ? `سجل المواعيد والفحوصات المكتملة (${curMonthName} ${calYear})` : `Completed Follow-ups History (${curMonthName} ${calYear})`;
      modalSubtitle = isAr ? 'الإجراءات والفحوصات التي تم إنجازها وتوثيق نتائجها رسمياً' : 'Completed clinical follow-ups with recorded results and batch numbers';
      badgeColor = '#16A34A';
      items = allFollowups.filter(f => f.isCompleted && (
        (f.dueDate.getMonth() === calMonth && f.dueDate.getFullYear() === calYear) ||
        (f.completedData?.date && parseDateSafe(f.completedData.date)?.getMonth() === calMonth && parseDateSafe(f.completedData.date)?.getFullYear() === calYear)
      ));
      if (items.length === 0) items = allFollowups.filter(f => f.isCompleted);
    } else if (catKey === 'cancelled') {
      icon = '❌';
      modalTitle = isAr ? `سجل المواعيد الملغاة مع بيان السبب السريري (${curMonthName} ${calYear})` : `Cancelled Follow-ups History (${curMonthName} ${calYear})`;
      modalSubtitle = isAr ? 'المواعيد التي تم إلغاؤها موثقة مع الأسباب الطبية والوظيفية' : 'Follow-up appointments cancelled with documented clinical justifications';
      badgeColor = '#475569';
      items = allFollowups.filter(f => f.isCancelled && (
        (f.dueDate.getMonth() === calMonth && f.dueDate.getFullYear() === calYear) ||
        (f.cancelledData?.cancelledAt && parseDateSafe(f.cancelledData.cancelledAt)?.getMonth() === calMonth && parseDateSafe(f.cancelledData.cancelledAt)?.getFullYear() === calYear)
      ));
      if (items.length === 0) items = allFollowups.filter(f => f.isCancelled);
    }

    let modalBox = document.getElementById('calendarModalContainer');
    if (!modalBox) {
      modalBox = document.createElement('div');
      modalBox.id = 'calendarModalContainer';
      document.body.appendChild(modalBox);
    }

    modalBox.innerHTML = `
      <div class="modal-backdrop-cal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); z-index: 9999; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px);">
        <div class="modal-card-cal" style="background: white; border-radius: 14px; width: 94%; max-width: 1050px; max-height: 90vh; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25);">
          <!-- Modal Header -->
          <div style="background: linear-gradient(135deg, #0D5C75 0%, #00838F 100%); color: white; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <span style="font-size: 1.8rem; background: rgba(255,255,255,0.15); border-radius: 50%; width: 48px; height: 48px; display: flex; align-items: center; justify-content: center;">${icon}</span>
              <div>
                <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                  <h3 style="margin: 0; font-size: 1.25rem; font-weight: 800;">
                    ${modalTitle}
                  </h3>
                  <span style="background: ${badgeColor}; color: white; padding: 2px 10px; border-radius: 12px; font-size: 0.82rem; font-weight: 800;">
                    ${items.length} ${isAr ? 'كادر' : 'Staff'}
                  </span>
                </div>
                <div style="font-size: 0.85rem; opacity: 0.92; margin-top: 3px;">
                  ${modalSubtitle}
                </div>
              </div>
            </div>
            <button type="button" style="background: transparent; border: none; color: white; font-size: 1.5rem; cursor: pointer; line-height: 1;" onclick="closeCalendarModal()">
              ✕
            </button>
          </div>

          <!-- Modal Body List -->
          <div style="padding: 20px; overflow-y: auto; flex: 1;">
            ${items.length > 0 ? renderFollowupTable(items, isAr, catKey === 'overdue') : `
              <div style="padding: 45px 20px; text-align: center; color: #64748B;">
                <span style="font-size: 3rem;">🎉</span>
                <h4 style="margin: 12px 0 6px 0; font-size: 1.15rem; color: #0F172A; font-weight: 800;">
                  ${isAr ? 'لا توجد استحقاقات أو مواعيد في هذا التصنيف لهذا الشهر' : 'No Follow-up Records Found in this Category for this Month'}
                </h4>
                <p style="margin: 0; font-size: 0.88rem; color: #64748B;">
                  ${isAr ? 'كافة كوادر المستشفى في حالة متابعة محدثة، أو لا توجد مواعيد مسجلة تحت هذا التصنيف حالياً.' : 'All clinical staff records are up to date or no appointments are currently registered.'}
                </p>
              </div>
            `}
          </div>

          <!-- Modal Footer -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div style="font-size: 0.82rem; font-weight: 700; color: #64748B;">
              ${isAr ? `إجمالي الكوادر المعروضة: ${items.length}` : `Total displayed records: ${items.length}`}
            </div>
            <div style="display: flex; gap: 10px;">
              <button type="button" class="btn btn-outline" style="background: white; border-color: #0284C7; color: #0284C7; font-weight: 700;" onclick="switchToFilteredAgendaFromModal('${catKey}')">
                📋 ${isAr ? 'عرض في جدول الصفحة (Agenda)' : 'View in Page Table'}
              </button>
              <button type="button" class="btn btn-primary" style="background: #0D5C75; border-color: #0D5C75;" onclick="closeCalendarModal()">
                ${isAr ? 'إغلاق النافذة' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  window.openCategoryStaffRosterModal = openCategoryStaffRosterModal;

  function switchToFilteredAgendaFromModal(catKey) {
    closeCalendarModal();
    if (catKey === 'overdue') {
      currentCalFilter = 'overdue';
    } else if (catKey === 'completed') {
      currentCalFilter = 'completed';
    } else if (catKey === 'cancelled') {
      currentCalFilter = 'cancelled';
    } else {
      currentCalFilter = 'all';
    }
    currentCalView = 'agenda';
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.switchToFilteredAgendaFromModal = switchToFilteredAgendaFromModal;

  function closeCalendarModal() {
    activeModalDateKey = null;
    const modalBox = document.getElementById('calendarModalContainer');
    if (modalBox) modalBox.innerHTML = '';
  }
  window.closeCalendarModal = closeCalendarModal;

  let currentModalStaffMode = 'existing';

  function toggleCustomModalStaffMode(mode) {
    currentModalStaffMode = mode;
    const tabExisting = document.getElementById('tab_existing_staff');
    const tabNew = document.getElementById('tab_new_staff');
    const secExisting = document.getElementById('sec_existing_staff');
    const secNew = document.getElementById('sec_new_staff');

    if (mode === 'new') {
      if (tabExisting) {
        tabExisting.style.background = 'transparent';
        tabExisting.style.color = '#475569';
        tabExisting.style.boxShadow = 'none';
      }
      if (tabNew) {
        tabNew.style.background = '#0D5C75';
        tabNew.style.color = 'white';
        tabNew.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
      }
      if (secExisting) secExisting.style.display = 'none';
      if (secNew) secNew.style.display = 'block';
      setTimeout(() => document.getElementById('cf_new_name')?.focus(), 50);
    } else {
      if (tabExisting) {
        tabExisting.style.background = '#0D5C75';
        tabExisting.style.color = 'white';
        tabExisting.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';
      }
      if (tabNew) {
        tabNew.style.background = 'transparent';
        tabNew.style.color = '#475569';
        tabNew.style.boxShadow = 'none';
      }
      if (secExisting) secExisting.style.display = 'block';
      if (secNew) secNew.style.display = 'none';
    }
  }
  window.toggleCustomModalStaffMode = toggleCustomModalStaffMode;

  function jumpToFullStaffRegistration() {
    closeCalendarModal();
    if (typeof window.switchNav === 'function') {
      window.switchNav('staff-entry');
      setTimeout(() => {
        if (typeof window.resetFormForNewStaff === 'function') {
          window.resetFormForNewStaff(true);
        }
      }, 150);
    }
  }
  window.jumpToFullStaffRegistration = jumpToFullStaffRegistration;

  function openScheduleCustomModal(startWithNewStaff = false, defaultCategory = null) {
    if (typeof startWithNewStaff === 'string' && !defaultCategory) {
      defaultCategory = startWithNewStaff;
      startWithNewStaff = false;
    }
    currentModalStaffMode = startWithNewStaff ? 'new' : 'existing';
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
    let modalBox = document.getElementById('calendarModalContainer');
    if (!modalBox) {
      modalBox = document.createElement('div');
      modalBox.id = 'calendarModalContainer';
      document.body.appendChild(modalBox);
    }

    const todayISO = formatDateISO(new Date());
    const isExpiryDefault = (defaultCategory === 'vaccine_expiry');
    const defaultTitle = isExpiryDefault 
      ? (isAr ? 'تطعيم الكزاز (Tdap) — انتهاء الصلاحية واستحقاق الجرعة المنشطة' : 'Tetanus / Tdap — Vaccine Batch Expire Date / Booster Due')
      : '';

    modalBox.innerHTML = `
      <div class="modal-backdrop-cal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); z-index: 9999; display: flex; justify-content: center; align-items: center; backdrop-filter: blur(4px);">
        <div class="modal-card-cal" style="background: white; border-radius: 14px; width: 92%; max-width: 640px; overflow: hidden; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.25);">
          <!-- Header -->
          <div style="background: ${isExpiryDefault ? 'linear-gradient(135deg, #B45309 0%, #D97706 100%)' : '#0D5C75'}; color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 1.4rem;">${isExpiryDefault ? '⏳' : '➕'}</span>
              <div>
                <h3 style="margin: 0; font-size: 1.15rem; font-weight: 800;">
                  ${isExpiryDefault 
                    ? (isAr ? 'تسجيل تاريخ انتهاء صلاحية التطعيم والجرعة المنشطة' : 'Add Vaccine Batch Expire Date & Booster Schedule')
                    : (isAr ? 'حجز موعد متابعة سريري / إدخال كادر جديد' : 'Schedule Clinical Follow-up & Staff Appointment')}
                </h3>
                <div style="font-size: 0.8rem; opacity: 0.9; margin-top: 2px;">
                  ${isExpiryDefault
                    ? (isAr ? 'توثيق مدة صلاحية اللقاحات وحساب موعد انتهاء المناعة الوقائية' : 'Document vaccine coverage periods & calculate immunity expiration')
                    : (isAr ? 'جدولة التطعيمات، الفحوصات المعادة، وتسجيل الكوادر الجديدة' : 'Vaccination follow-up, repeat titers & new staff intake')}
                </div>
              </div>
            </div>
            <button type="button" style="background: transparent; border: none; color: white; font-size: 1.4rem; cursor: pointer;" onclick="closeCalendarModal()">✕</button>
          </div>

          <!-- Body Form -->
          <div style="padding: 20px; display: flex; flex-direction: column; gap: 14px; max-height: 80vh; overflow-y: auto;">
            <!-- Wrap staff selector to allow hiding completely for vaccine expiry -->
            <div id="sec_staff_selector_wrap" style="${isExpiryDefault ? 'display: none;' : 'display: block;'}">
            <!-- Segmented Toggle between Existing Staff & Introduce New Staff -->
            <div style="display: flex; gap: 8px; background: #F1F5F9; padding: 4px; border-radius: 8px; border: 1px solid #CBD5E1;">
              <button type="button" id="tab_existing_staff" class="btn" style="flex: 1; padding: 7px 12px; font-size: 0.85rem; font-weight: 700; border: none; border-radius: 6px; ${!startWithNewStaff ? 'background: #0D5C75; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="toggleCustomModalStaffMode('existing')">
                👤 ${isAr ? 'موظف مسجل في النظام' : 'Select Existing Staff'}
              </button>
              <button type="button" id="tab_new_staff" class="btn" style="flex: 1; padding: 7px 12px; font-size: 0.85rem; font-weight: 700; border: none; border-radius: 6px; ${startWithNewStaff ? 'background: #0D5C75; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="toggleCustomModalStaffMode('new')">
                ➕ ${isAr ? 'إدخال وتسجيل كادر جديد' : 'Introduce New Staff'}
              </button>
            </div>

            <!-- Panel 1: Select Existing Staff -->
            <div id="sec_existing_staff" style="${startWithNewStaff ? 'display: none;' : 'display: block;'}">
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'اختر الموظف / الكادر المسجل:' : 'Select Staff Member:'} *
              </label>
              <select id="cf_staff_select" onchange="if(this.value==='__INTRODUCE_NEW__') toggleCustomModalStaffMode('new')" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">
                <option value="">${isAr ? '-- اختر الموظف --' : '-- Select Staff --'}</option>
                <option value="__INTRODUCE_NEW__" style="color: #15803D; font-weight: 800; background: #ECFDF5;">
                  ➕ ${isAr ? 'إدخال وتسجيل كادر جديد...' : '➕ [ Introduce New Staff Member... ]'}
                </option>
                <optgroup label="${isAr ? 'الكوادر المسجلة في النظام' : 'Registered Staff'}">
                  ${employees.map(e => `<option value="${e.empNo || e.id}">${e.name || e.demographic?.fullName} (${e.empNo || e.id}) - ${e.department || ''}</option>`).join('')}
                </optgroup>
              </select>
            </div>

            <!-- Panel 2: Introduce New Staff Form -->
            <div id="sec_new_staff" style="${startWithNewStaff ? 'display: block;' : 'display: none;'} background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 8px; padding: 14px;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <span style="font-weight: 800; font-size: 0.9rem; color: #166534;">
                  ➕ ${isAr ? 'بيانات الكادر الجديد الأساسية:' : 'New Staff Basic Profile:'}
                </span>
                <button type="button" class="btn btn-outline" style="padding: 2px 8px; font-size: 0.74rem; background: white; border-color: #0284C7; color: #0284C7; font-weight: 700;" onclick="jumpToFullStaffRegistration()">
                  👥 ${isAr ? 'بوابة التسجيل الشاملة' : 'Full Registration Portal'} ↗
                </button>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #166534; margin-bottom: 4px;">
                    ${isAr ? 'الاسم الكامل للموظف:' : 'Full Employee Name:'} *
                  </label>
                  <input type="text" id="cf_new_name" placeholder="${isAr ? 'مثال: أسامة نايف حسن العرامين' : 'e.g. Osama Nayef Hassan Al-Arameen'}" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 1.5px solid #86EFAC; border-radius: 6px; background: white;" />
                </div>

                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #166534; margin-bottom: 4px;">
                    ${isAr ? 'الرقم الوظيفي / رقم الهوية:' : 'Employee No or ID No:'} *
                  </label>
                  <input type="text" id="cf_new_emp_no" placeholder="${isAr ? 'مثال: 108039 أو 902148591' : 'e.g. 108039 or National ID'}" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 1.5px solid #86EFAC; border-radius: 6px; background: white;" />
                </div>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #166534; margin-bottom: 4px;">
                    ${isAr ? 'القسم / الوحدة:' : 'Department / Unit:'} *
                  </label>
                  <input type="text" id="cf_new_dept" list="cf_dept_datalist" placeholder="${isAr ? 'اختر أو اكتب القسم...' : 'Select or type department...'}" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 1.5px solid #86EFAC; border-radius: 6px; background: white;" />
                  <datalist id="cf_dept_datalist">
                    <option value="Intensive Care Unit (ICU)">
                    <option value="Emergency Department (ER)">
                    <option value="Medical Oncology (Doctors)">
                    <option value="Surgical Department">
                    <option value="Pediatric Oncology">
                    <option value="Dialysis Unit">
                    <option value="Long Term Skilled Nursing">
                    <option value="Laboratory">
                    <option value="Pharmacy">
                    <option value="Radiation Oncology">
                    <option value="Radiology & Imaging">
                    <option value="Operating Theater (OR)">
                    <option value="Outpatient Clinics">
                    <option value="Administration">
                    <option value="Support Services & Maintenance">
                    <option value="Infection Control">
                  </datalist>
                </div>

                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #166534; margin-bottom: 4px;">
                    ${isAr ? 'المسمى الوظيفي:' : 'Job Title / Role:'} *
                  </label>
                  <input type="text" id="cf_new_job" list="cf_job_datalist" placeholder="${isAr ? 'اختر أو اكتب المسمى...' : 'Select or type job title...'}" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 1.5px solid #86EFAC; border-radius: 6px; background: white;" />
                  <datalist id="cf_job_datalist">
                    <option value="Staff Nurse">
                    <option value="Practical Nurse">
                    <option value="Medical House Officer">
                    <option value="Resident Doctor">
                    <option value="Specialist Physician">
                    <option value="Medical Laboratory Technologist">
                    <option value="Clinical Pharmacist">
                    <option value="Radiologic Technologist">
                    <option value="Physiotherapist">
                    <option value="Administrative Staff">
                    <option value="Orderly / Transporter">
                    <option value="Support & Housekeeping Staff">
                  </datalist>
                </div>
              </div>

              <div style="font-size: 0.74rem; color: #15803D; margin-top: 8px;">
                ✓ ${isAr ? 'سيتم إنشاء سجل وظيفي رسمي جديد فوراً في قاعدة بيانات المستشفى وتفعيل متابعته.' : 'A new official employee record will be registered immediately and tracked in clinic database.'}
              </div>
            </div>
            </div> <!-- /sec_staff_selector_wrap -->

            <!-- Appointment Details -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div>
                <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                  ${isAr ? 'نوع الموعد / المتابعة:' : 'Appointment / Follow-up Type:'} *
                </label>
                <select id="cf_category" onchange="toggleVaccineExpiryFields(this.value)" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;">
                  <option value="test" ${defaultCategory === 'test' ? 'selected' : ''}>🧪 ${isAr ? 'فحص مخبري / سريري' : 'Lab / Diagnostic Test'}</option>
                  <option value="vaccine" ${defaultCategory === 'vaccine' ? 'selected' : ''}>💉 ${isAr ? 'جرعة تطعيم' : 'Vaccination Dose'}</option>
                  <option value="vaccine_expiry" ${isExpiryDefault ? 'selected' : ''}>⏳ ${isAr ? 'تاريخ انتهاء صلاحية التطعيم (Vaccine Batch Expire Date)' : 'Vaccine Batch Expire Date / Booster Due'}</option>
                </select>
              </div>

              <div>
                <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;" id="cf_due_date_label">
                  ${isAr ? (isExpiryDefault ? 'تاريخ استحقاق التجديد / الموعد:' : 'تاريخ الاستحقاق:') : (isExpiryDefault ? 'Due Date / Renewal Date:' : 'Due Date:')} *
                </label>
                <input type="date" id="cf_due_date" value="${isExpiryDefault ? formatDateISO(addDays(new Date(), 3652)) : todayISO}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
              </div>
            </div>

            <!-- DEDICATED VACCINATION EXPIRE DATE & BATCH DETAILS PANEL -->
            <div id="sec_vaccine_expiry_details" style="${isExpiryDefault ? 'display: block;' : 'display: none;'} background: #FFFBEB; border: 1.5px solid #FCD34D; border-radius: 8px; padding: 14px;">
              <div style="font-weight: 800; font-size: 0.9rem; color: #B45309; margin-bottom: 10px; display: flex; align-items: center; gap: 6px;">
                <span>⏳</span> ${isAr ? 'بيانات انتهاء صلاحية اللقاح والجرعة المنشطة:' : 'Vaccination Expiry & Booster Details:'}
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #92400E; margin-bottom: 4px;">
                    ${isAr ? 'اسم التطعيم / اللقاح:' : 'Vaccine Name:'} *
                  </label>
                  <select id="cf_vaccine_select" onchange="handleVaccinePresetChange(this.value)" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 1.5px solid #FCD34D; border-radius: 6px; background: white;">
                    <option value="">${isAr ? '-- \u0627\u062E\u062A\u0631 \u0627\u0644\u0644\u0642\u0627\u062D --' : '-- Select Vaccine --'}</option>
                    <option value="Tdap" data-years="10" ${isExpiryDefault ? 'selected' : ''}>💉 ${isAr ? '\u062A\u0637\u0639\u064A\u0645 \u0627\u0644\u0643\u0632\u0627\u0632 \u0648\u0627\u0644\u062f\u0641\u062A\u064A\u0631\u064A\u0627 \u0648\u0627\u0644\u0633\u0639\u0627\u0644 \u0627\u0644\u062f\u064A\u0643\u064A (Td / Tdap) \u2014 10 \u0633\u0646\u0648\u0627\u062A' : 'Tetanus / Diphtheria / Pertussis (Td / Tdap) — 10 Years'}</option>
                    <option value="Flu" data-years="1">💉 ${isAr ? '\u0627\u0644\u0625\u0646\u0641\u0644\u0648\u0646\u0632\u0627 \u0627\u0644\u0645\u0648\u0633\u0645\u064A\u0629 (Flu) \u2014 \u0633\u0646\u0629 \u0648\u0627\u062D\u062f\u0629 (\u0633\u0646\u0648\u064A)' : 'Seasonal Influenza (Flu) — 1 Year (Annual)'}</option>
                    <option value="Tubersol (Tuberculin)" data-years="1">💉 ${isAr ? '\u062A\u064A\u0648\u0628\u0631\u0633\u0648\u0644 \u0641\u062D\u0635 \u0627\u0644\u0633\u0644 (Tubersol Tuberculin) \u2014 \u0633\u0646\u0629 \u0648\u0627\u062D\u062f\u0629' : 'Tubersol (Tuberculin) — 1 Year (Annual)'}</option>
                    <option value="Imovax Polio" data-years="10">💉 ${isAr ? '\u0625\u064A\u0645\u0648\u0641\u0627\u0643\u0633 \u0634\u0644\u0644 \u0627\u0644\u0623\u0637\u0641\u0627\u0644 (Imovax Polio) \u2014 10 \u0633\u0646\u0648\u0627\u062A' : 'Imovax Polio — 10 Years'}</option>
                    <option value="Pneumococcal Vaccine" data-years="5">💉 ${isAr ? '\u0644\u0642\u0627\u062D \u0627\u0644\u0645\u0643\u0648\u0631\u0627\u062A \u0627\u0644\u0631\u0626\u0648\u064A\u0629 (Pneumococcal Vaccine) \u2014 5 \u0633\u0646\u0648\u0627\u062A' : 'Pneumococcal Vaccine — 5 Years'}</option>
                    <option value="Varillex (Varicella,Chickenpox)" data-years="10">💉 ${isAr ? '\u0641\u0627\u0631\u064A\u0644\u0643\u0633 \u062C\u062f\u0631\u064A \u0627\u0644\u0645\u0627\u0621 (Varillex Varicella,Chickenpox) \u2014 10 \u0633\u0646\u0648\u0627\u062A' : 'Varillex (Varicella,Chickenpox) — 10 Years'}</option>
                    <option value="Varicella" data-years="10">💉 ${isAr ? '\u062C\u062f\u0631\u064A \u0627\u0644\u0645\u0627\u0621 (Varicella / Chickenpox) \u2014 10 \u0633\u0646\u0648\u0627\u062A' : 'Varicella (Chickenpox) — 10 Years'}</option>
                    <option value="Nimenrix Meningococcal Vaccine" data-years="5">💉 ${isAr ? '\u0646\u064A\u0645\u064A\u0646\u0631\u064A\u0643\u0633 \u0627\u0644\u0633\u062D\u0627\u064A\u0627 (Nimenrix Meningococcal Vaccine) \u2014 5 \u0633\u0646\u0648\u0627\u062A' : 'Nimenrix Meningococcal Vaccine — 5 Years'}</option>
                    <option value="Meningococcal" data-years="5">💉 ${isAr ? '\u0644\u0642\u0627\u062D \u0627\u0644\u0633\u062D\u0627\u064A\u0627 \u0627\u0644\u0631\u0628\u0627\u0639\u064A (MenACWY) \u2014 5 \u0633\u0646\u0648\u0627\u062A' : 'Meningococcal Vaccine (ACWY) — 5 Years'}</option>
                    <option value="COVID-19" data-years="1">💉 ${isAr ? '\u062A\u0637\u0639\u064A\u0645 \u0643\u0648\u0641\u064A\u062f-19 / \u0645\u0639\u0632\u0632 \u2014 \u0633\u0646\u0629 \u0648\u0627\u062D\u062f\u0629' : 'COVID-19 Vaccine / Booster — 1 Year'}</option>
                    <option value="Hepatitis B Booster" data-years="5">💉 ${isAr ? '\u0645\u0646\u0634\u0637 \u0627\u0644\u062A\u0647\u0627\u0628 \u0627\u0644\u0643\u0628\u062f \u0627\u0644\u0648\u0628\u0627\u0626\u064A \u0628 \u2014 5 \u0633\u0646\u0648\u0627\u062A' : 'Hepatitis B Booster / Challenge Dose — 5 Years'}</option>
                    <option value="MMR" data-years="10">💉 ${isAr ? '\u0627\u0644\u062D\u0635\u0628\u0629 \u0648\u0627\u0644\u0646\u0643\u0627\u0641 \u0648\u0627\u0644\u062D\u0635\u0628\u0629 \u0627\u0644\u0623\u0644\u0645\u0627\u0646\u064A\u0629 (MMR) \u2014 10 \u0633\u0646\u0648\u0627\u062A' : 'MMR (Measles, Mumps, Rubella) — 10 Years'}</option>
                    <option value="Custom" data-years="0">💉 ${isAr ? '\u0644\u0642\u0627\u062D \u0622\u062e\u0631 (\u0645\u062e\u0635\u0635)...' : 'Other / Custom Vaccine...'}</option>
                  </select>
                </div>

                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #92400E; margin-bottom: 4px;">
                    ${isAr ? 'تاريخ إعطاء اللقاح (Administered Date):' : 'Date Administered:'}
                  </label>
                  <input type="date" id="cf_admin_date" value="${todayISO}" onchange="recalcVaccineExpiryFromAdminDate()" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 1.5px solid #FCD34D; border-radius: 6px; background: white;" />
                </div>
              </div>

              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #92400E; margin-bottom: 4px;">
                    ${isAr ? 'تاريخ انتهاء صلاحية التطعيم (Expire Date):' : 'Vaccine Batch Expire Date:'} *
                  </label>
                  <input type="date" id="cf_expire_date" value="${isExpiryDefault ? formatDateISO(addDays(new Date(), 3652)) : todayISO}" onchange="document.getElementById('cf_due_date').value = this.value; if(typeof updateCalculatedReminderDate === 'function') updateCalculatedReminderDate();" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 2px solid #D97706; border-radius: 6px; background: white; font-weight: bold; color: #B45309;" />
                </div>

                <div>
                  <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #92400E; margin-bottom: 4px;">
                    ${isAr ? 'رقم التشغيلة / الدفعة (Lot / Batch):' : 'Vaccine Lot / Batch No:'}
                  </label>
                  <input type="text" id="cf_vaccine_lot" placeholder="e.g. AB12345 / EXP-2027" style="width: 100%; padding: 7px 10px; font-size: 0.85rem; border: 1.5px solid #FCD34D; border-radius: 6px; background: white;" />
                </div>
              </div>

              <!-- Quick Expiry Presets -->
              <div style="display: flex; gap: 6px; align-items: center; flex-wrap: wrap;">
                <span style="font-size: 0.76rem; font-weight: 700; color: #92400E;">${isAr ? 'فترات الصلاحية السريعة:' : 'Expiry Presets:'}</span>
                <button type="button" class="btn" onclick="applyVaccineExpiryPreset(1)" style="padding: 2px 8px; font-size: 0.75rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+1 Year (Flu/Tubersol/Covid)</button>
                <button type="button" class="btn" onclick="applyVaccineExpiryPreset(3)" style="padding: 2px 8px; font-size: 0.75rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+3 Years</button>
                <button type="button" class="btn" onclick="applyVaccineExpiryPreset(5)" style="padding: 2px 8px; font-size: 0.75rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+5 Years (Hep B/Pneumo/Nimenrix)</button>
                <button type="button" class="btn" onclick="applyVaccineExpiryPreset(10)" style="padding: 2px 8px; font-size: 0.75rem; background: white; border: 1px solid #D97706; color: #B45309; border-radius: 4px; font-weight: 700;">+10 Years (Tdap/Polio/Varillex)</button>
              </div>

              <!-- 15-DAY REMINDER COMPONENT -->
              <div style="background: #FEF3C7; border: 1.5px solid #F59E0B; border-radius: 8px; padding: 12px; margin-top: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                  <label style="font-size: 0.86rem; font-weight: 800; color: #92400E; display: flex; align-items: center; gap: 7px; cursor: pointer;">
                    <input type="checkbox" id="cf_reminder_active" checked style="width: 17px; height: 17px; accent-color: #D97706; cursor: pointer;" onchange="toggleReminderFields(this.checked)" />
                    <span>🔔 ${isAr ? 'تفعيل التنبيه المسبق قبل 15 يوماً من انتهاء الصلاحية' : 'Reminder 15 days before expire date'}</span>
                  </label>
                  <span style="font-size: 0.74rem; background: #D97706; color: white; padding: 2px 8px; border-radius: 4px; font-weight: 800;">
                    ${isAr ? 'تنبيه استباقي 15 يوماً' : '15-Day Alert'}
                  </span>
                </div>

                <div id="cf_reminder_details_box" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 8px;">
                  <div>
                    <label style="display: block; font-size: 0.78rem; font-weight: 700; color: #78350F; margin-bottom: 3px;">
                      ${isAr ? 'تاريخ انطلاق التنبيه في النظام (Alert Date):' : 'Alert Trigger Date (15 Days Prior):'}
                    </label>
                    <input type="date" id="cf_reminder_date" value="${isExpiryDefault ? formatDateISO(addDays(addDays(new Date(), 3652), -15)) : formatDateISO(addDays(new Date(), -15))}" readonly style="width: 100%; padding: 6px 10px; font-size: 0.85rem; border: 1.5px solid #F59E0B; border-radius: 6px; background: white; font-weight: bold; color: #B45309;" />
                  </div>
                  <div>
                    <label style="display: block; font-size: 0.78rem; font-weight: 700; color: #78350F; margin-bottom: 3px;">
                      ${isAr ? 'فترة التنبيه المسبق (Reminder Window):' : 'Reminder Interval:'}
                    </label>
                    <select id="cf_reminder_days" onchange="updateCalculatedReminderDate(this.value)" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; border: 1.5px solid #F59E0B; border-radius: 6px; background: white; font-weight: bold; color: #0F172A;">
                      <option value="15" selected>${isAr ? 'قبل 15 يوماً (المعتمد القياسي)' : '15 Days Before Expire Date (Standard)'}</option>
                      <option value="30">${isAr ? 'قبل 30 يوماً (شهر كامل)' : '30 Days Before Expire Date'}</option>
                      <option value="7">${isAr ? 'قبل 7 أيام (أسبوع)' : '7 Days Before Expire Date'}</option>
                    </select>
                  </div>
                </div>

                <div style="font-size: 0.75rem; color: #92400E; margin-top: 6px; display: flex; align-items: center; gap: 5px;">
                  <span>ℹ️</span>
                  <span id="cf_reminder_notice">
                    ${isAr ? 'سيقوم النظام بإشعار العيادة وتحديد اللقاح بلون تنبيه برتقالي قبل 15 يوماً من انتهاء الصلاحية لتجديد الجرعة.' : 'System will trigger amber alert notifications in calendar and schedule list 15 days before expiration.'}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'عنوان الموعد / الفحص المطلوب:' : 'Follow-up Title / Reason:'} *
              </label>
              <input type="text" id="cf_title" value="${defaultTitle}" placeholder="${isAr ? 'مثال: إعادة فحص الأجسام المضادة للكبد، قراءة مانتو، انتهاء صلاحية تطعيم الكزاز...' : 'e.g., Repeat Serology, Mantoux Reading, Booster Due, Vaccine Expiration...'}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;" />
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 700; color: #1E293B; margin-bottom: 5px;">
                ${isAr ? 'ملاحظات سريرية أو تعليمات:' : 'Clinical Notes / Instructions:'}
              </label>
              <textarea id="cf_notes" rows="3" placeholder="${isAr ? 'أي ملاحظات إضافية أو نتائج سابقة...' : 'Additional notes or previous titers...'}" style="width: 100%; padding: 8px 12px; font-size: 0.88rem; border: 1.5px solid #CBD5E1; border-radius: 6px;"></textarea>
            </div>
          </div>

          <!-- Footer -->
          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 20px; display: flex; justify-content: space-between; align-items: center; gap: 10px;">
            <button type="button" class="btn btn-outline" onclick="closeCalendarModal()">
              ${isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button type="button" class="btn btn-success" style="background: ${isExpiryDefault ? '#D97706; border-color: #D97706;' : '#16A34A; border-color: #16A34A;'}" onclick="saveCustomFollowup()">
              💾 ${isExpiryDefault ? (isAr ? 'حفظ تاريخ انتهاء الصلاحية' : 'Save Expiration Schedule') : (isAr ? 'حفظ الموعد وجدولته' : 'Save & Schedule')}
            </button>
          </div>
        </div>
      </div>
    `;
  }
  window.openScheduleCustomModal = openScheduleCustomModal;

  function toggleVaccineExpiryFields(catVal) {
    const panel = document.getElementById('sec_vaccine_expiry_details');
    const staffWrap = document.getElementById('sec_staff_selector_wrap');
    const dateLabel = document.getElementById('cf_due_date_label');
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    if (catVal === 'vaccine_expiry') {
      if (panel) panel.style.display = 'block';
      if (staffWrap) staffWrap.style.display = 'none'; // No need for staff name
      if (dateLabel) {
        dateLabel.innerHTML = `${isAr ? 'تاريخ الاستحقاق / انتهاء الصلاحية:' : 'Due Date / Expire Date:'} *`;
      }
    } else if (catVal === 'vaccine') {
      if (panel) panel.style.display = 'block';
      if (staffWrap) staffWrap.style.display = 'block';
      if (dateLabel) {
        dateLabel.innerHTML = `${isAr ? 'تاريخ الاستحقاق / انتهاء الصلاحية:' : 'Due Date / Expire Date:'} *`;
      }
    } else {
      if (panel) panel.style.display = 'none';
      if (staffWrap) staffWrap.style.display = 'block';
      if (dateLabel) {
        dateLabel.innerHTML = `${isAr ? 'تاريخ الاستحقاق:' : 'Due Date:'} *`;
      }
    }
  }
  window.toggleVaccineExpiryFields = toggleVaccineExpiryFields;

  function updateCalculatedReminderDate(daysVal) {
    const expireInput = document.getElementById('cf_expire_date');
    const reminderInput = document.getElementById('cf_reminder_date');
    const days = parseInt(daysVal || (document.getElementById('cf_reminder_days')?.value) || 15, 10);
    if (expireInput && expireInput.value && reminderInput) {
      const expDate = parseDateSafe(expireInput.value);
      if (expDate) {
        const remDate = addDays(expDate, -days);
        reminderInput.value = formatDateISO(remDate);
      }
    }
  }
  window.updateCalculatedReminderDate = updateCalculatedReminderDate;

  function toggleReminderFields(isActive) {
    const box = document.getElementById('cf_reminder_details_box');
    const notice = document.getElementById('cf_reminder_notice');
    if (box) box.style.opacity = isActive ? '1' : '0.4';
    if (notice) notice.style.opacity = isActive ? '1' : '0.4';
  }
  window.toggleReminderFields = toggleReminderFields;

  function handleVaccinePresetChange(vaccineVal) {
    const customWrap = document.getElementById('cf_custom_vaccine_wrap');
    if (customWrap) {
      customWrap.style.display = (vaccineVal === 'Custom') ? 'block' : 'none';
      if (vaccineVal === 'Custom') {
        const customInput = document.getElementById('cf_custom_vaccine_name');
        if (customInput) customInput.focus();
      }
    }
    const select = document.getElementById('cf_vaccine_select');
    const titleInput = document.getElementById('cf_title');
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    if (!select) return;
    const opt = select.options[select.selectedIndex];
    const years = parseInt(opt ? opt.getAttribute('data-years') : 0, 10);
    
    if (vaccineVal && vaccineVal !== 'Custom') {
      if (titleInput && (!titleInput.value || titleInput.value.includes('Vaccination') || titleInput.value.includes('تطعيم') || titleInput.value.includes('Booster') || titleInput.value.includes('الكزاز'))) {
        titleInput.value = isAr 
          ? `تطعيم ${vaccineVal} — استحقاق الجرعة المنشطة / انتهاء الصلاحية` 
          : `${vaccineVal} — Vaccine Batch Expire Date / Booster Due`;
      }
      if (years > 0) {
        applyVaccineExpiryPreset(years);
      }
    }
  }
  window.handleVaccinePresetChange = handleVaccinePresetChange;

  function applyVaccineExpiryPreset(years) {
    const adminInput = document.getElementById('cf_admin_date');
    const expireInput = document.getElementById('cf_expire_date');
    const dueInput = document.getElementById('cf_due_date');
    if (!expireInput) return;
    
    let baseDate = new Date();
    if (adminInput && adminInput.value) {
      const parsed = new Date(adminInput.value);
      if (!isNaN(parsed.getTime())) baseDate = parsed;
    }
    
    const expireDate = new Date(baseDate);
    expireDate.setFullYear(expireDate.getFullYear() + years);
    const isoStr = formatDateISO(expireDate);
    expireInput.value = isoStr;
    if (dueInput) dueInput.value = isoStr;
    if (typeof updateCalculatedReminderDate === 'function') updateCalculatedReminderDate();
  }
  window.applyVaccineExpiryPreset = applyVaccineExpiryPreset;

  function recalcVaccineExpiryFromAdminDate() {
    const select = document.getElementById('cf_vaccine_select');
    if (!select) return;
    const opt = select.options[select.selectedIndex];
    const years = parseInt(opt ? opt.getAttribute('data-years') : 0, 10);
    if (years > 0) {
      applyVaccineExpiryPreset(years);
    }
  }
  window.recalcVaccineExpiryFromAdminDate = recalcVaccineExpiryFromAdminDate;

  async function saveCustomFollowup() {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const category = document.getElementById('cf_category')?.value || 'test';
    const dueDate = document.getElementById('cf_due_date')?.value;
    const title = document.getElementById('cf_title')?.value;
    const notes = document.getElementById('cf_notes')?.value;

    const vaccineSelect = document.getElementById('cf_vaccine_select');
    let vaccineName = vaccineSelect ? vaccineSelect.value : '';
    const customVacInput = document.getElementById('cf_custom_vaccine_name');
    if (vaccineName === 'Custom' && customVacInput && customVacInput.value.trim()) {
      vaccineName = customVacInput.value.trim();
    }
    const adminDate = document.getElementById('cf_admin_date')?.value || '';
    const expireDate = document.getElementById('cf_expire_date')?.value || dueDate;
    const vaccineLot = document.getElementById('cf_vaccine_lot')?.value || '';
    const reminderActive = document.getElementById('cf_reminder_active') ? document.getElementById('cf_reminder_active').checked : true;
    const reminderDays = parseInt(document.getElementById('cf_reminder_days')?.value || '15', 10);
    const reminderDate = document.getElementById('cf_reminder_date')?.value || (expireDate ? formatDateISO(addDays(parseDateSafe(expireDate), -reminderDays)) : '');

    // If it is a vaccine expiry, NO NEED FOR STAFF NAME
    if (category === 'vaccine_expiry') {
      if (!expireDate) {
        alert(isAr ? 'يرجى تحديد تاريخ انتهاء صلاحية التطعيم.' : 'Please select a vaccine expire date.');
        return;
      }
      const finalTitle = (title && title.trim()) ? title.trim() : (isAr ? `انتهاء صلاحية تطعيم ${vaccineName || 'اللقاح'}` : `${vaccineName || 'Vaccine'} Expire Date & Booster`);

      const standaloneRecord = {
        id: `ve_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        title: finalTitle,
        category: 'vaccine_expiry',
        dueDate: expireDate,
        expireDate: expireDate,
        adminDate: adminDate,
        vaccineName: vaccineName || 'Vaccine',
        vaccineLot: vaccineLot,
        reminderActive: reminderActive,
        reminderDays: reminderDays,
        reminderDate: reminderDate,
        notes: notes ? notes.trim() : '',
        completed: false,
        createdAt: new Date().toISOString()
      };

      const list = JSON.parse(localStorage.getItem('avh_standalone_vaccine_expiries') || '[]');
      list.push(standaloneRecord);
      localStorage.setItem('avh_standalone_vaccine_expiries', JSON.stringify(list));

      closeCalendarModal();
      const container = document.getElementById('mainAppArea');
      if (container && typeof renderFollowupCalendar === 'function') {
        renderFollowupCalendar(container);
      }
      alert(isAr 
        ? `✅ تم تسجيل تاريخ انتهاء تطعيم (${standaloneRecord.vaccineName}) بنجاح!\n🔔 تم تفعيل التنبيه المسبق قبل 15 يوماً من الانتهاء (${reminderDate}).` 
        : `✅ Successfully saved vaccine expire date (${standaloneRecord.vaccineName})!\n🔔 15-day early reminder scheduled for (${reminderDate}).`
      );
      return;
    }

    if (!dueDate) {
      alert(isAr ? 'يرجى تحديد تاريخ الموعد.' : 'Please select a due date.');
      return;
    }
    if (!title || !title.trim()) {
      alert(isAr ? 'يرجى كتابة عنوان أو سبب الموعد.' : 'Please enter a title or reason for follow-up.');
      return;
    }

    let emp = null;
    let isBrandNewStaff = false;

    if (currentModalStaffMode === 'new') {
      const newName = document.getElementById('cf_new_name')?.value?.trim();
      const newEmpNo = document.getElementById('cf_new_emp_no')?.value?.trim();
      const newDept = document.getElementById('cf_new_dept')?.value?.trim() || 'General';
      const newJob = document.getElementById('cf_new_job')?.value?.trim() || 'Healthcare Staff';

      if (!newName) {
        alert(isAr ? 'يرجى إدخال اسم الكادر الجديد.' : 'Please enter the new staff member\'s full name.');
        document.getElementById('cf_new_name')?.focus();
        return;
      }
      if (!newEmpNo) {
        alert(isAr ? 'يرجى إدخال الرقم الوظيفي أو رقم الهوية.' : 'Please enter the employment number or ID.');
        document.getElementById('cf_new_emp_no')?.focus();
        return;
      }

      const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
      let existing = employees.find(e => (e.empNo === newEmpNo || e.id === newEmpNo));

      if (existing) {
        emp = existing;
        if (!emp.name) emp.name = newName;
        if (!emp.department) emp.department = newDept;
        if (!emp.jobTitle) emp.jobTitle = newJob;
      } else {
        isBrandNewStaff = true;
        emp = {
          id: newEmpNo,
          empNo: newEmpNo,
          idNo: newEmpNo,
          name: newName,
          gender: 'Unspecified',
          department: newDept,
          jobTitle: newJob,
          staffGroup: 'Clinical',
          employmentStatus: 'Active Staff',
          workStatus: 'Active Staff',
          isArchived: false,
          archived: false,
          immunityStatus: 'Follow-up Scheduled',
          demographic: {
            fullName: newName,
            personNumber: newEmpNo,
            nationalId: newEmpNo,
            department: newDept,
            jobTitle: newJob,
            employmentStatus: 'Active Staff'
          },
          vaccines: {},
          labs: {},
          customFollowups: [],
          createdAt: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          updated_by: typeof getCurrentSystemUserName === 'function' ? getCurrentSystemUserName() : 'Follow-up Calendar'
        };
      }
    } else {
      const empNo = document.getElementById('cf_staff_select')?.value;
      if (!empNo || empNo === '__INTRODUCE_NEW__') {
        alert(isAr ? 'يرجى اختيار الموظف أولاً أو التبديل لإدخال كادر جديد.' : 'Please select a staff member or switch to Introduce New Staff.');
        return;
      }

      const employees = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
      emp = employees.find(e => (e.empNo === empNo || e.id === empNo));
      if (!emp) {
        alert(isAr ? 'لم يتم العثور على سجل الموظف.' : 'Staff record not found.');
        return;
      }
    }

    if (!Array.isArray(emp.customFollowups)) {
      emp.customFollowups = [];
    }

    const newAppointment = {
      id: `cf_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      title: title.trim(),
      category: isExpiry ? 'vaccine_expiry' : category,
      dueDate: resolvedDueDate,
      vaccineName,
      adminDate,
      expireDate,
      vaccineLot,
      isExpiry,
      notes: notes ? notes.trim() : '',
      completed: false,
      createdAt: new Date().toISOString()
    };

    emp.customFollowups.push(newAppointment);

    // Sync into employee profile vaccines record
    if (emp && isExpiry && expireDate) {
      if (!emp.vaccines) emp.vaccines = {};
      if (!Array.isArray(emp.vaccineExpiries)) emp.vaccineExpiries = [];
      emp.vaccineExpiries.push({
        vaccineName: vaccineName || title.trim(),
        adminDate,
        expireDate,
        lotNumber: vaccineLot,
        recordedAt: new Date().toISOString()
      });

      if (vaccineName === 'Tdap' || vaccineName === 'Tetanus' || title.toLowerCase().includes('tdap') || title.toLowerCase().includes('tetanus')) {
        emp.vaccines.tdapExpireDate = expireDate;
        if (adminDate) emp.vaccines.tdapDate = adminDate;
      } else if (vaccineName === 'Flu' || vaccineName === 'Influenza' || title.toLowerCase().includes('flu')) {
        emp.vaccines.fluExpireDate = expireDate;
        if (adminDate) emp.vaccines.fluDate = adminDate;
      } else if (vaccineName.includes('COVID') || title.toLowerCase().includes('covid')) {
        emp.vaccines.covidExpireDate = expireDate;
        if (adminDate) emp.vaccines.covidDate = adminDate;
      }
    }

    if (typeof window.EmployeeDataService !== 'undefined' && typeof window.EmployeeDataService.saveEmployee === 'function') {
      await window.EmployeeDataService.saveEmployee(emp, isBrandNewStaff ? 'create' : 'update');
    } else if (typeof window.saveEmployeesToLocalStorage === 'function') {
      const allEmps = typeof window.getUniqueEmployees === 'function' ? window.getUniqueEmployees() : [];
      const idx = allEmps.findIndex(e => e.empNo === emp.empNo || e.id === emp.empNo);
      if (idx !== -1) {
        allEmps[idx] = emp;
      } else {
        allEmps.push(emp);
      }
      window.saveEmployeesToLocalStorage(allEmps);
    }

    // Trigger events to update all open views
    if (typeof window.dispatchEvent === 'function') {
      window.dispatchEvent(new CustomEvent('staffDataUpdated', { detail: { employee: emp } }));
      window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { employee: emp } }));
    }

    closeCalendarModal();

    if (typeof window.showSuccessToast === 'function') {
      const successMsg = isBrandNewStaff
        ? (isAr ? `تم تسجيل الكادر الجديد (${emp.name}) وجدولة الموعد بنجاح 🟢` : `New staff member (${emp.name}) registered & follow-up scheduled 🟢`)
        : (isAr ? `تمت جدولة موعد المتابعة بنجاح في التقويم للموظف (${emp.name}) 🟢` : `Follow-up appointment scheduled for (${emp.name}) 🟢`);
      
      window.showSuccessToast(
        successMsg,
        isBrandNewStaff ? (isAr ? 'تم التسجيل والجدولة 🟢' : 'Staff Registered 🟢') : (isAr ? 'تمت الجدولة 🟢' : 'Scheduled 🟢')
      );
    }

    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.saveCustomFollowup = saveCustomFollowup;

  // --------------------------------------------------------------------------
  // 9. NAVIGATION SHORTCUTS & EVENT HANDLERS
  // --------------------------------------------------------------------------
  function openStaffFormsFromCalendar(empNo) {
    if (!empNo) return;
    closeCalendarModal();
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(empNo);
    }
    if (typeof window.switchNav === 'function') {
      window.switchNav('vaccination-forms');
    }
  }
  window.openStaffFormsFromCalendar = openStaffFormsFromCalendar;

  function openInjuryReportFromCalendar(serialNo) {
    if (!serialNo) return;
    closeCalendarModal();
    if (typeof window.openInjuryReportBySerial === 'function') {
      window.openInjuryReportBySerial(serialNo);
    } else if (typeof window.switchNav === 'function') {
      window.switchNav('injury-report');
    }
  }
  window.openInjuryReportFromCalendar = openInjuryReportFromCalendar;

  function setCalendarView(view) {
    currentCalView = view;
    if (view === 'expiry') {
      currentCalFilter = 'expiry';
    } else if (view === 'agenda' && currentCalFilter === 'expiry') {
      currentCalFilter = 'all';
    }
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.setCalendarView = setCalendarView;

  function setCalendarFilter(filter) {
    currentCalFilter = filter;
    if (filter === 'expiry') {
      currentCalView = 'expiry';
    } else if (currentCalView === 'expiry') {
      currentCalView = 'agenda';
    }
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.setCalendarFilter = setCalendarFilter;

  function setCalendarDeptFilter(dept) {
    currentCalDeptFilter = dept;
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.setCalendarDeptFilter = setCalendarDeptFilter;

  function handleCalendarSearchInput(query) {
    currentSearchQuery = query;
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.handleCalendarSearchInput = handleCalendarSearchInput;

  function navigateCalendarMonth(direction) {
    currentCalDate.setMonth(currentCalDate.getMonth() + direction);
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.navigateCalendarMonth = navigateCalendarMonth;

  function jumpToCurrentMonth() {
    currentCalDate = new Date();
    const container = document.getElementById('mainAppArea');
    if (container) renderFollowupCalendar(container);
  }
  window.jumpToCurrentMonth = jumpToCurrentMonth;

  function printCalendarSchedule() {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    if (currentCalView === 'expiry') {
      printVaccineExpiryList();
      return;
    }
    const all = extractAllClinicalFollowups();
    // Exclude vaccine expiry items from clinical schedule print
    const items = all.filter(f => !f.isExpiry && f.category !== 'vaccine_expiry' && !f.expireDate);

    // Apply active filter if not 'all'
    let printItems = items;
    if (currentCalFilter === 'overdue') printItems = items.filter(f => f.status === 'overdue');
    else if (currentCalFilter === 'today') printItems = items.filter(f => f.status === 'today');
    else if (currentCalFilter === 'upcoming') printItems = items.filter(f => f.status === 'upcoming');
    else if (currentCalFilter === 'completed') printItems = items.filter(f => f.status === 'completed');
    else if (currentCalFilter === 'cancelled') printItems = items.filter(f => f.status === 'cancelled');
    else if (currentCalFilter === 'vaccine') printItems = items.filter(f => f.category === 'vaccine');
    else if (currentCalFilter === 'test') printItems = items.filter(f => f.category === 'test');
    else {
      // Default: Active items (overdue, today, upcoming)
      printItems = items.filter(f => !f.isCompleted && !f.isCancelled);
    }

    const printWin = window.open('', '_blank', 'width=1000,height=750');
    if (!printWin) {
      window.print();
      return;
    }

    const printDate = new Date().toLocaleDateString(isAr ? 'ar-EG' : 'en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const printTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const html = `<!DOCTYPE html>
<html dir="${isAr ? 'rtl' : 'ltr'}" lang="${isAr ? 'ar' : 'en'}">
<head>
  <meta charset="UTF-8">
  <title>${isAr ? 'كشف المتابعات والمواعيد السريرية - مستشفى المطلع' : 'Clinical Follow-up & Appointment Schedule - AVH'}</title>
  <style>
    @page { size: A4 landscape; margin: 12mm; }
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; margin: 0; padding: 20px; color: #0F172A; }
    .header-box { display: flex; justify-content: space-between; align-items: center; border-bottom: 2.5px solid #0D5C75; padding-bottom: 12px; margin-bottom: 16px; }
    .title-area h1 { margin: 0; font-size: 1.35rem; color: #0D5C75; }
    .title-area p { margin: 4px 0 0 0; font-size: 0.85rem; color: #475569; }
    .meta-area { text-align: ${isAr ? 'left' : 'right'}; font-size: 0.8rem; color: #64748B; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 0.82rem; }
    th { background: #0D5C75; color: white; padding: 8px 10px; text-align: ${isAr ? 'right' : 'left'}; font-weight: 700; border: 1px solid #0D5C75; }
    td { padding: 7px 10px; border: 1px solid #E2E8F0; vertical-align: top; }
    tr:nth-child(even) td { background: #F8FAFC; }
    .badge-status { display: inline-block; padding: 2px 7px; border-radius: 4px; font-size: 0.72rem; font-weight: 700; text-transform: uppercase; }
    .status-overdue { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
    .status-today { background: #FEF3C7; color: #92400E; border: 1px solid #F59E0B; }
    .status-upcoming { background: #E0F2FE; color: #0369A1; border: 1px solid #7DD3FC; }
    .status-completed { background: #DCFCE7; color: #15803D; border: 1px solid #86EFAC; }
    .status-cancelled { background: #F1F5F9; color: #475569; border: 1px solid #CBD5E1; }
    .footer-box { margin-top: 25px; display: flex; justify-content: space-between; align-items: flex-end; padding-top: 15px; border-top: 1px dashed #CBD5E1; font-size: 0.8rem; color: #64748B; }
    .sig-box { border-top: 1px solid #0F172A; width: 220px; text-align: center; padding-top: 6px; font-weight: bold; }
    @media print {
      .no-print { display: none !important; }
      body { padding: 0; }
    }
  </style>
</head>
<body>
  <div class="no-print" style="margin-bottom: 15px; display: flex; justify-content: flex-end; gap: 10px;">
    <button onclick="window.print()" style="padding: 8px 16px; background: #0D5C75; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
      🖨️ ${isAr ? 'طباعة الكشف الآن' : 'Print Report Now'}
    </button>
    <button onclick="window.close()" style="padding: 8px 16px; background: #E2E8F0; color: #334155; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
      ✖ ${isAr ? 'إغلاق النافذة' : 'Close'}
    </button>
  </div>

  <div class="header-box">
    <div class="title-area">
      <h1>🏥 ${isAr ? 'مستشفى المُطلع - القدس' : 'Augusta Victoria Hospital — Jerusalem'}</h1>
      <p><strong>${isAr ? 'عيادة السلامة والصحة المهنية' : 'Occupational Health Clinic'}</strong> • ${isAr ? 'كشف المتابعات والمواعيد السريرية للكوادر' : 'Staff Clinical Follow-up & Appointment Schedule'}</p>
    </div>
    <div class="meta-area">
      <div><strong>${isAr ? 'تاريخ الاستخراج:' : 'Date:'}</strong> ${printDate} ${printTime}</div>
      <div><strong>${isAr ? 'التصنيف:' : 'Filter:'}</strong> ${currentCalFilter.toUpperCase()}</div>
      <div><strong>${isAr ? 'إجمالي الحالات:' : 'Total Records:'}</strong> ${printItems.length}</div>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th style="width: 35px;">#</th>
        <th style="width: 85px;">${isAr ? 'تاريخ الاستحقاق' : 'Due Date'}</th>
        <th style="width: 75px;">${isAr ? 'الحالة' : 'Status'}</th>
        <th>${isAr ? 'اسم الموظف' : 'Staff Name'}</th>
        <th style="width: 75px;">${isAr ? 'الرقم الوظيفي' : 'Emp No'}</th>
        <th>${isAr ? 'القسم / الوظيفة' : 'Department & Job'}</th>
        <th>${isAr ? 'نوع الموعد / الإجراء المطلوب' : 'Appointment / Action Required'}</th>
        <th>${isAr ? 'الإجراء المتخذ / ملاحظات' : 'Notes / Disposition'}</th>
      </tr>
    </thead>
    <tbody>
      ${printItems.length === 0 ? `
        <tr><td colspan="8" style="text-align: center; padding: 25px; color: #64748B;">${isAr ? 'لا توجد مواعيد مسجلة ضمن هذا التصنيف.' : 'No follow-up appointments found for this filter.'}</td></tr>
      ` : printItems.map((item, idx) => {
        const statusClass = `status-${item.status || 'upcoming'}`;
        let disp = '';
        if (item.isCompleted) disp = `${isAr ? 'مكتمل' : 'Done'}: ${item.completedData?.date || ''} ${item.completedData?.result ? '(' + item.completedData.result + ')' : ''}`;
        else if (item.isCancelled) disp = `${isAr ? 'ملغى' : 'Cancelled'}: ${item.cancelledData?.reason || ''}`;
        else if (item.isRescheduled) disp = `${isAr ? 'معاد جدولته' : 'Rescheduled'}: ${item.reschedData?.reason || ''}`;
        else disp = item.descEn || item.descAr || '-';

        return `
          <tr>
            <td style="text-align: center;">${idx + 1}</td>
            <td><strong>${formatDateDisplay(item.dueDate, isAr)}</strong></td>
            <td><span class="badge-status ${statusClass}">${(item.status || 'ACTIVE').toUpperCase()}</span></td>
            <td><strong>${item.empName || ''}</strong></td>
            <td>${item.empNo || ''}</td>
            <td>${item.dept || ''}<br><span style="color: #64748B; font-size: 0.75rem;">${item.job || ''}</span></td>
            <td><strong>${isAr ? (item.titleAr || item.titleEn) : (item.titleEn || item.titleAr)}</strong></td>
            <td><span style="font-size: 0.78rem;">${disp}</span></td>
          </tr>
        `;
      }).join('')}
    </tbody>
  </table>

  <div class="footer-box">
    <div>
      <div>${isAr ? 'سجل طبي سري خاص بعيادة الصحة والسلامة المهنية' : 'Confidential Medical Record — Occupational Health Clinic'}</div>
      <div>${isAr ? 'تم الاستخراج إلكترونياً من بوابة المتابعة السريرية' : 'Generated electronically via AVH Occupational Health System'}</div>
    </div>
    <div class="sig-box">
      ${isAr ? 'توقيع وختم مسؤول الصحة المهنية' : 'Occupational Health Officer Stamp & Signature'}
    </div>
  </div>

  <script>
    window.onload = function() {
      setTimeout(function() { window.print(); }, 400);
    };
  <\/script>
</body>
</html>`;

    printWin.document.open();
    printWin.document.write(html);
    printWin.document.close();
  }
  window.printCalendarSchedule = printCalendarSchedule;

  function exportFollowupsToExcel() {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    if (currentCalView === 'expiry') {
      exportVaccineExpiryToExcel();
      return;
    }
    const allItems = extractAllClinicalFollowups();
    // Exclude vaccine expiry items from clinical appointments export
    const items = allItems.filter(f => !f.isExpiry && f.category !== 'vaccine_expiry' && !f.expireDate);
    if (!items || items.length === 0) {
      alert(isAr ? 'لا توجد بيانات مواعيد للتصدير.' : 'No follow-up records to export.');
      return;
    }

    let csvContent = '\uFEFF'; // UTF-8 BOM
    csvContent += 'Index,Due Date,Status,Staff Name,Emp No,Department,Job Title,Category,Action Due,Clinical Description,Disposition Info\n';

    items.forEach((item, idx) => {
      let dispInfo = '';
      if (item.isCompleted) {
        dispInfo = `Completed: ${item.completedData?.date || ''} (${item.completedData?.result || ''})`;
      } else if (item.isCancelled) {
        dispInfo = `Cancelled Due: ${item.cancelledData?.reason || ''}`;
      } else if (item.isRescheduled) {
        dispInfo = `Rescheduled: ${item.reschedData?.reason || ''}`;
      }

      const statusStr = (item.status || (item.isCompleted ? 'completed' : (item.isCancelled ? 'cancelled' : 'active'))).toUpperCase();
      const dueDisplay = (item.dueDate instanceof Date && !isNaN(item.dueDate.getTime()))
        ? formatDateDisplay(item.dueDate, false)
        : (item.dueDateStr || '');

      const row = [
        idx + 1,
        dueDisplay,
        statusStr,
        `"${(item.empName || '').replace(/"/g, '""')}"`,
        `"${(item.empNo || '').replace(/"/g, '""')}"`,
        `"${(item.dept || '').replace(/"/g, '""')}"`,
        `"${(item.job || '').replace(/"/g, '""')}"`,
        `"${(item.category || '').replace(/"/g, '""')}"`,
        `"${(item.titleEn || item.titleAr || '').replace(/"/g, '""')}"`,
        `"${(item.descEn || item.descAr || '').replace(/"/g, '""')}"`,
        `"${dispInfo.replace(/"/g, '""')}"`
      ];
      csvContent += row.join(',') + '\n';
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `AVH_Clinical_Appointments_${formatDateISO(new Date())}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
  window.exportFollowupsToExcel = exportFollowupsToExcel;
  window.extractAllClinicalFollowups = extractAllClinicalFollowups;

  function getClinicalAppointmentSummary() {
    const all = extractAllClinicalFollowups();
    const active = all.filter(f => !f.isCompleted && !f.isCancelled);
    const overdue = active.filter(f => f.status === 'overdue');
    const today = active.filter(f => f.status === 'today');
    const upcoming = active.filter(f => f.status === 'upcoming');
    return {
      all,
      active,
      overdue,
      today,
      upcoming,
      overdueCount: overdue.length,
      todayCount: today.length,
      upcomingCount: upcoming.length,
      hasUrgent: overdue.length > 0 || today.length > 0
    };
  }
  window.getClinicalAppointmentSummary = getClinicalAppointmentSummary;

  function playClinicalAlarmChime() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;
      
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, now); // D5
      gain1.gain.setValueAtTime(0.12, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.4);

      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(880, now + 0.12); // A5
      gain2.gain.setValueAtTime(0.15, now + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.12);
      osc2.stop(now + 0.6);
    } catch(e) {}
  }
  window.playClinicalAlarmChime = playClinicalAlarmChime;

  // --------------------------------------------------------------------------
  // 10. REAL-TIME DATA REFRESH LISTENERS
  // --------------------------------------------------------------------------
  if (typeof window !== 'undefined') {
    const refreshCalOnUpdate = () => {
      if (typeof window.activeNavTab !== 'undefined' && window.activeNavTab === 'followup-calendar') {
        const container = document.getElementById('mainAppArea');
        if (container) renderFollowupCalendar(container);
      }
    };
    window.addEventListener('staffDataUpdated', refreshCalOnUpdate);
    window.addEventListener('avh_data_updated', refreshCalOnUpdate);
    window.addEventListener('avh_injuries_updated', refreshCalOnUpdate);
  }

})(window);
