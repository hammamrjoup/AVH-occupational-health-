/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - MASTER DROPDOWN OPTIONS MANAGER & AUTHORITY
   Provides centralized management for all system drop-down lists.
   Stored in localStorage: 'avh_master_dropdown_options'
   ========================================================================== */

const INITIAL_MASTER_DROPDOWNS = {
  master_microorganisms: {
    title: '🦠 Master Microorganisms & Pathogens List (Unified System-Wide List)',
    description: 'Unified master pathogens and organisms select list used across all dashboard modules (BSI, UTI, VAE, SSI, MDRO Logs, AMS)',
    options: [
      'Acinetobacter baumannii (CRAB / MDR)',
      'Aerococcus spp.',
      'Bacillus spp. (not B. anthracis)',
      'Burkholderia cepacia complex',
      'Candida albicans',
      'Candida auris',
      'Candida non-albicans (glabrata/parapsilosis/tropicalis/krusei)',
      'Citrobacter freundii / koseri',
      'Clostridioides difficile (C. diff)',
      'Coagulase-Negative Staphylococci (CoNS / S. epidermidis)',
      'Corynebacterium spp. (Diphtheroids / C. jeikeium)',
      'Cutibacterium / Propionibacterium acnes',
      'Enterobacter cloacae complex',
      'Enterococcus faecalis (VSE / VRE)',
      'Enterococcus faecium (VRE)',
      'Escherichia coli (E. coli)',
      'Escherichia coli ESBL',
      'Klebsiella pneumoniae',
      'Klebsiella pneumoniae ESBL',
      'Klebsiella pneumoniae (CRE / KPC)',
      'Klebsiella oxytoca',
      'Micrococcus / Kocuria spp.',
      'Morganella morganii',
      'Proteus mirabilis / Proteus spp.',
      'Pseudomonas aeruginosa (MDR / CR-PA)',
      'Rhodococcus spp.',
      'Rothia spp. (mucilaginosa/dentocariosa)',
      'Salmonella spp. (Salmonella Species)',
      'Serratia marcescens',
      'Staphylococcus aureus (MRSA)',
      'Staphylococcus aureus (MSSA)',
      'Stenotrophomonas maltophilia',
      'Streptococcus pneumoniae',
      'Viridans Group Streptococcus (VGS)',
      'Negative / No Growth',
      'Other Microorganism / Pathogen (Specify)'
    ]
  },
  specimen_sources: {
    title: '🧪 Specimen Sources & Culture Types',
    description: 'Diagnostic specimen types in IPC surveillance forms',
    options: [
      'Urine Culture',
      'Blood Culture (Central Line)',
      'Blood Culture (Peripheral Line)',
      'Sputum Culture (CX / ETA)',
      'Endotracheal Aspirate (ETA)',
      'Bronchoalveolar Lavage (BAL)',
      'Wound / Pus Swab Culture',
      'Stool Culture / C. diff Toxin',
      'Cerebrospinal Fluid (CSF)'
    ]
  },
  hospital_departments: {
    title: '🏥 Hospital Departments & Nursing Units',
    description: 'Department drop-down lists used in staff records, infection logs, and isolation maps',
    options: [
      'Hematology & BMT Care Center',
      'Pediatric Oncology & Hematology',
      'Inpatient Oncology Unit (Third Floor)',
      'Outpatient Chemotherapy Clinic & Day Care',
      'Intensive Care Unit (ICU)',
      'Radiation Oncology Unit & Linac',
      'Nephrology & Hemodialysis Unit',
      'Surgical Ward & Operating Theaters (OR)',
      'Infection Prevention & Control Unit (IPC)',
      'Occupational Health & Safety (OHS)',
      'Biomedical Engineering & Facilities',
      'Pharmacy & Antimicrobial Stewardship',
      'General Administration & HR'
    ]
  },
  vaccine_types: {
    title: '💉 Staff Vaccination Types & Immunizations',
    description: 'Vaccine types selectable in staff vaccination records and certificates',
    options: [
      'Hepatitis B (Engerix-B / 3-Dose)',
      'Annual Influenza (Quadrivalent)',
      'MMR (Measles, Mumps, Rubella)',
      'Varicella (Chickenpox / 2-Dose)',
      'Varillex (Varicella,Chickenpox)',
      'Tdap (Tetanus, Diphtheria, Pertussis)',
      'Meningococcal (MenACWY)',
      'Nimenrix Meningococcal Vaccine',
      'COVID-19 Bivalent Booster',
      'Tubersol (Tuberculin)',
      'Imovax Polio',
      'Pneumococcal Vaccine'
    ]
  },
  injury_exposure_types: {
    title: '🩹 Occupational Injury & Exposure Categories',
    description: 'Injury and bloodborne pathogen exposure types in SQE 02.01 reports',
    options: [
      'Percutaneous Needlestick Injury',
      'Sharp Object / Scalpel Cut',
      'Blood Splash to Mucous Membrane (Eyes/Mouth)',
      'Body Fluid Splash to Non-Intact Skin',
      'Chemical / Disinfectant Exposure',
      'Physical Strain / Ergonomic Musculoskeletal',
      'Slip, Trip, or Fall'
    ]
  },
  ams_antibiotics: {
    title: '💊 Master Antibiotic Description & Antimicrobials List',
    description: 'Unified master list of prescribed antibiotics and antimicrobial descriptions across IPC surveillance worksheets (VAE, BSI, UTI) and AMS stewardship',
    options: [
      'Cefepime IP',
      'Vancomycin PO',
      'Cefuroxime (Zinnat) Tab',
      'Zovirax I.V',
      'cefotaxime (Claforan)',
      'Daptomycin',
      'Meropenem IP',
      'Cefepime',
      'clindamycin (oral)',
      'ZOVIRAX TAB',
      'Mebendazole',
      'Clarithromycin P.O',
      'Ceftazidime (Fortum)  IP',
      'Acyclovir PO',
      'Acyclovir IV',
      'Amikacin',
      'Amoxi/clav IV',
      'Amoxi/Clav P.O',
      'Amoxicillin PO',
      'Amphotericin B',
      'Ampicillin',
      'Azithromycin I.V',
      'Azithromycin p.o',
      'Bactroban nasal Ointment',
      'Caspofungin',
      'Cefazolin',
      'Ceftriaxone',
      'Cefuroxime IV',
      'Chloramphenicol',
      'Ciprofloxacin IV',
      'Ciprofloxacin P.O',
      'Clindamycin I.V',
      'Colistin',
      'Ciprofloxacin (Ciloxan) ophthalmic',
      'Dactarin oral gel',
      'Doxycycline',
      'Dex-otic drops',
      'Ertapenem',
      'Erythromycin',
      'Fluconazole P.O',
      'Ceftazidime (Fortum)',
      'Foscarnet (phosphonomethanoic acid)',
      'Fucidin Cream',
      'Fucidin Ointment',
      'Fucidin H Cream',
      'Gentamycin',
      'Ganciclovir',
      'Hydroagisten Cream',
      'Imipenem',
      'Clarithromycin',
      'Levofloxacin',
      'Liposomal amphotericin',
      'Linezolid',
      'Lacromycin eye drops',
      'Meropenem',
      'Metronidazole IV',
      'Metronidazole P.O',
      'Neomycin P.O',
      'Nitrofurantoin',
      'Nystatin Mouth Wash',
      'Oseltamivir (Tamiflu)',
      'Trimethoprim - sulfamethoxazole (Resprim) IV',
      'Trimethoprim - sulfamethoxazole (Resprim) P.O',
      'Rifampicin',
      'Teicoplanin (Targocid)',
      'Piperacillin Sodium/Tazobactam Sodium (Tazocin)',
      'Tigecyclin',
      'Fluconazole (Triflucan) I.V',
      'Vancomycin IV',
      'Voriconazole IV',
      'ValGancyclovir',
      'Acyclovir topical ( Cream )',
      'Acyclovir Genital Cream',
      'Lamivudine (Zeffix)',
      'Cefalexin po',
      'Moxifloxacim',
      'piperacillin',
      'Cloxacillin',
      'Ceftazidime/Avibactam',
      'Vancomycin IP',
      'Gentamicin IP',
      'Voriconazole P.O',
      'Ritonavir+Nirmatrelvir (Paxlovid)'
    ]
  }
};

let _cachedMasterCategories = null;
const _cachedOptionsCache = new Map();

class MasterDropdownManager {
  static getCategories(forceReload = false) {
    if (!forceReload && _cachedMasterCategories) {
      return _cachedMasterCategories;
    }
    const stored = localStorage.getItem('avh_master_dropdown_options');
    if (!stored) {
      localStorage.setItem('avh_master_dropdown_options', JSON.stringify(INITIAL_MASTER_DROPDOWNS));
      _cachedMasterCategories = INITIAL_MASTER_DROPDOWNS;
      return INITIAL_MASTER_DROPDOWNS;
    }
    try {
      const parsed = JSON.parse(stored);
      if (!parsed.master_microorganisms) {
        parsed.master_microorganisms = INITIAL_MASTER_DROPDOWNS.master_microorganisms;
        this.saveCategories(parsed);
      }
      if (!parsed.ams_antibiotics || !Array.isArray(parsed.ams_antibiotics.options) || parsed.ams_antibiotics.options.length < 20) {
        parsed.ams_antibiotics = INITIAL_MASTER_DROPDOWNS.ams_antibiotics;
        this.saveCategories(parsed);
      }
      _cachedMasterCategories = parsed;
      return parsed;
    } catch(e) {
      _cachedMasterCategories = INITIAL_MASTER_DROPDOWNS;
      return INITIAL_MASTER_DROPDOWNS;
    }
  }

  static getOptions(catKey) {
    if (_cachedOptionsCache.has(catKey)) {
      return _cachedOptionsCache.get(catKey);
    }
    const cats = this.getCategories();
    let rawOpts = [];
    if (['blood_culture_organisms', 'surveillance_organisms', 'mdro_pathogens', 'master_microorganisms'].includes(catKey)) {
      rawOpts = cats.master_microorganisms ? cats.master_microorganisms.options : INITIAL_MASTER_DROPDOWNS.master_microorganisms.options;
    } else if (['ams_antibiotics', 'antimicrobial_agents', 'antibiotic_description'].includes(catKey)) {
      rawOpts = cats.ams_antibiotics ? cats.ams_antibiotics.options : INITIAL_MASTER_DROPDOWNS.ams_antibiotics.options;
    } else if (cats[catKey] && Array.isArray(cats[catKey].options)) {
      rawOpts = cats[catKey].options;
    } else {
      rawOpts = INITIAL_MASTER_DROPDOWNS[catKey] ? INITIAL_MASTER_DROPDOWNS[catKey].options : [];
    }

    const uniqueMap = new Map();
    (rawOpts || []).forEach(opt => {
      if (opt && typeof opt === 'string') {
        const trimmed = opt.trim();
        if (trimmed && !uniqueMap.has(trimmed.toLowerCase())) {
          uniqueMap.set(trimmed.toLowerCase(), trimmed);
        }
      }
    });

    const sorted = Array.from(uniqueMap.values()).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
    _cachedOptionsCache.set(catKey, sorted);
    return sorted;
  }

  static saveCategories(cats) {
    _cachedMasterCategories = cats;
    _cachedOptionsCache.clear();
    localStorage.setItem('avh_master_dropdown_options', JSON.stringify(cats));
  }

  static addOption(catKey, newOptionText) {
    const cleanText = newOptionText.trim();
    if (!cleanText) return false;
    const targetKey = ['blood_culture_organisms', 'surveillance_organisms', 'mdro_pathogens', 'master_microorganisms'].includes(catKey) ? 'master_microorganisms' : catKey;
    const cats = this.getCategories();
    if (!cats[targetKey]) return false;
    if (!cats[targetKey].options.includes(cleanText)) {
      cats[targetKey].options.push(cleanText);
      this.saveCategories(cats);
    }
    return true;
  }

  static editOption(catKey, index, updatedText) {
    const cleanText = updatedText.trim();
    if (!cleanText) return false;
    const targetKey = ['blood_culture_organisms', 'surveillance_organisms', 'mdro_pathogens', 'master_microorganisms'].includes(catKey) ? 'master_microorganisms' : catKey;
    const cats = this.getCategories();
    if (!cats[targetKey] || index < 0 || index >= cats[targetKey].options.length) return false;
    cats[targetKey].options[index] = cleanText;
    this.saveCategories(cats);
    return true;
  }

  static removeOption(catKey, index) {
    const targetKey = ['blood_culture_organisms', 'surveillance_organisms', 'mdro_pathogens', 'master_microorganisms'].includes(catKey) ? 'master_microorganisms' : catKey;
    const cats = this.getCategories();
    if (!cats[targetKey] || index < 0 || index >= cats[targetKey].options.length) return false;
    cats[targetKey].options.splice(index, 1);
    this.saveCategories(cats);
    return true;
  }

  static moveOption(catKey, index, direction) {
    const targetKey = ['blood_culture_organisms', 'surveillance_organisms', 'mdro_pathogens', 'master_microorganisms'].includes(catKey) ? 'master_microorganisms' : catKey;
    const cats = this.getCategories();
    if (!cats[targetKey]) return false;
    const opts = cats[targetKey].options;
    const newIdx = index + direction;
    if (newIdx < 0 || newIdx >= opts.length) return false;
    const temp = opts[index];
    opts[index] = opts[newIdx];
    opts[newIdx] = temp;
    this.saveCategories(cats);
    return true;
  }

  static resetCategoryToDefault(catKey) {
    const targetKey = ['blood_culture_organisms', 'surveillance_organisms', 'mdro_pathogens', 'master_microorganisms'].includes(catKey) ? 'master_microorganisms' : catKey;
    const cats = this.getCategories();
    if (INITIAL_MASTER_DROPDOWNS[targetKey]) {
      cats[targetKey] = JSON.parse(JSON.stringify(INITIAL_MASTER_DROPDOWNS[targetKey]));
      this.saveCategories(cats);
    }
  }

  static renderSelectOptionsHTML(catKey, selectedValue = '') {
    const options = this.getOptions(catKey);
    let html = options.map(opt => `
      <option value="${opt.replace(/"/g, '&quot;')}" ${opt === selectedValue ? 'selected' : ''}>${opt}</option>
    `).join('');
    if (selectedValue && !options.includes(selectedValue)) {
      html += `<option value="${selectedValue.replace(/"/g, '&quot;')}" selected>${selectedValue}</option>`;
    }
    return html;
  }
}

let _cachedAntimicrobialOptionsHTML = null;

function invalidateAntimicrobialCache() {
  _cachedAntimicrobialOptionsHTML = null;
}
window.invalidateAntimicrobialCache = invalidateAntimicrobialCache;

function getAntimicrobialOptionsHTML(selectedValue = '') {
  if (!_cachedAntimicrobialOptionsHTML) {
    const options = MasterDropdownManager.getOptions('ams_antibiotics');
    _cachedAntimicrobialOptionsHTML = options.map(opt => `<option value="${opt.replace(/"/g, '&quot;')}">${opt}</option>`).join('');
  }
  let html = '<option value="">-- Select --</option>' + _cachedAntimicrobialOptionsHTML;
  if (selectedValue) {
    const valEsc = selectedValue.replace(/"/g, '&quot;');
    if (html.includes(`value="${valEsc}"`)) {
      html = html.replace(`value="${valEsc}"`, `value="${valEsc}" selected`);
    } else {
      html += `<option value="${valEsc}" selected>${selectedValue}</option>`;
    }
  }
  return html;
}
window.getAntimicrobialOptionsHTML = getAntimicrobialOptionsHTML;

function populateAntimicrobialSelect(selectEl) {
  if (!selectEl || selectEl.dataset.populated === 'true') return;
  const currentVal = selectEl.value;
  selectEl.innerHTML = getAntimicrobialOptionsHTML(currentVal);
  selectEl.dataset.populated = 'true';
}
window.populateAntimicrobialSelect = populateAntimicrobialSelect;

function ensureAntimicrobialDatalist() {
  let list = document.getElementById('antimicrobial_master_datalist');
  if (!list) {
    list = document.createElement('datalist');
    list.id = 'antimicrobial_master_datalist';
    document.body.appendChild(list);
  }
  const options = MasterDropdownManager.getOptions('ams_antibiotics');
  list.innerHTML = options.map(opt => `<option value="${opt.replace(/"/g, '&quot;')}">${opt}</option>`).join('');
}
window.ensureAntimicrobialDatalist = ensureAntimicrobialDatalist;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', ensureAntimicrobialDatalist);
} else {
  ensureAntimicrobialDatalist();
}

window.MasterDropdownManager = MasterDropdownManager;
