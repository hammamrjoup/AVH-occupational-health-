
// Uses canonical toSafeLabString and getFirstDefinedLabValue from js/data.js with safe fallbacks
if (typeof toSafeLabString === 'undefined') {
  window.toSafeLabString = function(v) { return (v !== null && v !== undefined) ? String(v) : ''; };
}
if (typeof getFirstDefinedLabValue === 'undefined') {
  window.getFirstDefinedLabValue = function(...args) {
    for (let a of args) {
      if (a !== null && a !== undefined && a !== '') return a;
    }
    return '';
  };
}

/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - OFFICIAL CLINICAL DOCUMENTS & CERTIFICATES
   1. Official Vaccination & Immunity Certificate ("To Whom It May Concern")
   2. Medical Test Fee Exemption Form for Employees (Form HR-02) / نموذج إعفاء من رسوم الفحوصات
   ========================================================================== */

let activeCertDocumentType = 'vaccination'; // 'vaccination', 'special', 'covid', 'khcc', or 'ppd'
let activeEmpPersonNo = '';

function selectCertEmployee(empNo) {
  if (!empNo) {
    activeEmpPersonNo = '';
    activeEmpIndex = -1;
    certSearchQuery = '';
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(null);
    }
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea) renderVaccinationCertificate(mainArea);
    return;
  }
  const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || (typeof INITIAL_EMPLOYEES !== 'undefined' ? INITIAL_EMPLOYEES : [])));
  const queryStr = String(empNo).trim().toLowerCase();
  const idx = employees.findIndex(e => {
    const demo = e.demographic || {};
    const eEmp = String(e.empNo || e.id || demo.personNumber || '').trim().toLowerCase();
    const eId = String(e.idNo || demo.nationalId || '').trim().toLowerCase();
    const eName = String(e.name || demo.fullName || '').trim().toLowerCase();
    return (eEmp && eEmp === queryStr) || (eId && eId === queryStr) || (eName && eName === queryStr);
  });
  if (idx !== -1) {
    activeEmpIndex = idx;
    const e = employees[idx];
    activeEmpPersonNo = String(e.empNo || e.personNumber || e.id || e.demographic?.personNumber || e.idNo || '');
    certSearchQuery = e.name || (e.demographic ? e.demographic.fullName : '');
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(e);
    }
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea) renderVaccinationCertificate(mainArea);
  }
}
window.selectCertEmployee = selectCertEmployee;

function escapeHtmlAttr(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
window.escapeHtmlAttr = escapeHtmlAttr;

let certSearchQuery = '';

function showCertSearchResults(query) {
  const resultsBox = document.getElementById('cert_search_results');
  if (!resultsBox) return;
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const q = (query || '').trim().toLowerCase();

  let matches = [];
  if (!q) {
    matches = employees.slice(0, 10);
  } else {
    matches = employees.filter(e => {
      const demo = e.demographic || {};
      const idNo = (e.idNo || demo.nationalId || '').toString().toLowerCase();
      const empNo = (e.empNo || e.id || demo.personNumber || '').toString().toLowerCase();
      const name = (e.name || demo.fullName || '').toString().toLowerCase();
      const arName = (demo.arabicFullName || '').toString().toLowerCase();
      const dept = (demo.orgName || e.organizationName || demo.organizationName || e.orgName || e.department || demo.deptTreating || '').toString().toLowerCase();
      const job = (e.jobTitle || demo.positionName || '').toString().toLowerCase();
      return idNo.includes(q) || empNo.includes(q) || name.includes(q) || arName.includes(q) || dept.includes(q) || job.includes(q);
    }).slice(0, 15);
  }

  if (matches.length === 0) {
    resultsBox.innerHTML = `
      <div style="padding: 14px 16px; color: #64748B; font-size: 0.9rem; text-align: center;">
        ${isAr ? '\u274C \u0644\u0627 \u062a\u0648\u062c\u062f \u0646\u062a\u0627\u0626\u062c \u0645\u0637\u0627\u0628\u0642\u0629 \u0644\u0628\u062d\u062b\u0643' : '\u274C No matching staff members found'}
      </div>
    `;
    resultsBox.style.display = 'block';
    return;
  }

  resultsBox.innerHTML = `
    <div style="padding: 7px 12px; background: #F1F5F9; border-bottom: 1px solid #CBD5E1; font-size: 0.78rem; font-weight: bold; color: var(--primary-blue, #0F766E); display: flex; justify-content: space-between;">
      <span>\u26A1 ${isAr ? '\u0627\u0646\u0642\u0631 \u0639\u0644\u0649 \u0623\u064a \u0645\u0648\u0638\u0641 \u0644\u0627\u062e\u062a\u064a\u0627\u0631\u0647 \u0645\u0628\u0627\u0634\u0631\u0629:' : 'Click any staff member to select:'}</span>
      <span style="color: #64748B;">${matches.length} ${isAr ? '\u0646\u062a\u0627\u0626\u062c' : 'results'}</span>
    </div>
  ` + matches.map(e => {
    const origIdx = employees.indexOf(e);
    const demo = e.demographic || {};
    const nameStr = e.name || demo.fullName || 'Staff Member';
    const empStr = e.empNo || e.id || demo.personNumber || '';
    const idStr = e.idNo || demo.nationalId || '';
    const isSel = (empStr && activeEmpPersonNo && String(empStr) === String(activeEmpPersonNo)) ||
                  (idStr && activeEmpPersonNo && String(idStr) === String(activeEmpPersonNo));

    return `
      <div style="padding: 10px 14px; border-bottom: 1px solid #E2E8F0; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: ${isSel ? '#F0FDFA' : '#FFFFFF'}; transition: background 0.15s;" 
           onmouseover="this.style.background='#F0F9FF'" 
           onmouseout="this.style.background='${isSel ? '#F0FDFA' : '#FFFFFF'}'"
           onclick="selectCertStaffFromSearch(${origIdx})">
        <div style="font-weight: 700; font-size: 0.95rem; color: #0F172A;">
          ${typeof escapeHtmlAttr === 'function' ? escapeHtmlAttr(nameStr) : nameStr}
        </div>
        <span style="background: ${isSel ? '#0D9488' : '#E0F2FE'}; color: ${isSel ? '#FFFFFF' : '#0369A1'}; padding: 4px 12px; border-radius: 6px; font-size: 0.8rem; font-weight: bold; white-space: nowrap;">
          ${isSel ? (isAr ? '\u2713 \u0627\u0644\u0645\u062e\u062a\u0627\u0631' : '\u2713 Current') : (isAr ? '\u0627\u062e\u062a\u064a\u0627\u0631' : 'Select')}
        </span>
      </div>
    `;
  }).join('');

  resultsBox.style.display = 'block';
}
window.showCertSearchResults = showCertSearchResults;

function handleCertHeaderSearch(query) {
  certSearchQuery = query || '';
  showCertSearchResults(query);
}
window.handleCertHeaderSearch = handleCertHeaderSearch;

function handleCertSearchChange(query) {
  const q = (query || '').trim();
  if (!q) return;
  selectCertEmployee(q);
}
window.handleCertSearchChange = handleCertSearchChange;

function selectCertStaffFromSearch(idx) {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  if (idx >= 0 && employees[idx]) {
    activeEmpIndex = idx;
    const e = employees[idx];
    activeEmpPersonNo = String(e.empNo || e.id || e.demographic?.personNumber || e.idNo || '');
    certSearchQuery = e.name || (e.demographic ? e.demographic.fullName : '');
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(e);
    }
  }
  const resultsBox = document.getElementById('cert_search_results');
  if (resultsBox) resultsBox.style.display = 'none';
  const container = document.getElementById('mainAppArea');
  if (container) renderVaccinationCertificate(container);
}
window.selectCertStaffFromSearch = selectCertStaffFromSearch;

function handleCertSearchKeyDown(event) {
  if (event.key === 'Escape') {
    const resultsBox = document.getElementById('cert_search_results');
    if (resultsBox) resultsBox.style.display = 'none';
  } else if (event.key === 'Enter') {
    event.preventDefault();
    const resultsBox = document.getElementById('cert_search_results');
    const firstOption = resultsBox ? resultsBox.querySelector('[onclick^="selectCertStaffFromSearch"]') : null;
    if (firstOption && resultsBox.style.display !== 'none') {
      firstOption.click();
    } else {
      const q = (event.target.value || '').trim();
      if (q) {
        selectCertEmployee(q);
      }
    }
  }
}
window.handleCertSearchKeyDown = handleCertSearchKeyDown;

function clearCertSearch() {
  certSearchQuery = '';
  activeEmpIndex = -1;
  activeEmpPersonNo = '';
  if (typeof window.setGlobalSelectedStaff === 'function') {
    window.setGlobalSelectedStaff(null);
  }
  const input = document.getElementById('cert_header_search_input');
  if (input) {
    input.value = '';
    input.focus();
  }
  const resultsBox = document.getElementById('cert_search_results');
  if (resultsBox) resultsBox.style.display = 'none';
  const container = document.getElementById('mainAppArea');
  if (container) renderVaccinationCertificate(container);
}
window.clearCertSearch = clearCertSearch;

if (typeof document !== 'undefined') {
  document.addEventListener('click', function(e) {
    const box = document.getElementById('cert_search_results');
    const input = document.getElementById('cert_header_search_input');
    if (box && input && !box.contains(e.target) && e.target !== input) {
      box.style.display = 'none';
    }
  });
}

function switchCertDocType(type) {
  activeCertDocumentType = type;
  const mainArea = document.getElementById('mainAppArea');
  if (mainArea) renderVaccinationCertificate(mainArea);
}
window.switchCertDocType = switchCertDocType;

function generateFeeExemptionForEmp(empNoOrIdx) {
  const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || (typeof INITIAL_EMPLOYEES !== 'undefined' ? INITIAL_EMPLOYEES : [])));
  if (typeof empNoOrIdx === 'string' || typeof empNoOrIdx === 'number') {
    const idx = employees.findIndex(e => String(e.empNo || e.personNumber || e.id) === String(empNoOrIdx) || String(e.idNo || e.nationalId) === String(empNoOrIdx));
    if (idx !== -1) {
      activeEmpIndex = idx;
      activeEmpPersonNo = String(employees[idx].empNo || employees[idx].personNumber || employees[idx].id || '');
    } else if (typeof empNoOrIdx === 'number' && employees[empNoOrIdx]) {
      activeEmpIndex = empNoOrIdx;
      activeEmpPersonNo = String(employees[empNoOrIdx].empNo || employees[empNoOrIdx].personNumber || employees[empNoOrIdx].id || '');
    }
  }
  activeCertDocumentType = 'khcc';
  if (typeof switchNav === 'function') {
    switchNav('vaccination-certificate');
  } else {
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea) renderVaccinationCertificate(mainArea);
  }
}
window.generateFeeExemptionForEmp = generateFeeExemptionForEmp;

function renderVaccinationCertificate(container) {
  const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || (typeof INITIAL_EMPLOYEES !== 'undefined' ? INITIAL_EMPLOYEES : [])));
  if (!employees || employees.length === 0) {
    container.innerHTML = `<div class="card"><p style="color:red; padding: 20px; font-weight: bold;">⚠️ No staff records available in system. Please import or enter staff data first.</p></div>`;
    return;
  }

  let selEmp = typeof window.getGlobalSelectedStaff === 'function' ? window.getGlobalSelectedStaff() : null;
  if (selEmp) {
    const sEmpNo = String(selEmp.empNo || selEmp.id || selEmp.demographic?.personNumber || selEmp.idNo || '').trim();
    if (sEmpNo) {
      activeEmpPersonNo = sEmpNo;
      const sIdx = employees.findIndex(e => String(e.empNo || e.id || e.demographic?.personNumber || e.idNo || '').trim() === sEmpNo);
      if (sIdx !== -1) activeEmpIndex = sIdx;
    }
  }

  const isAr = (window.i18n && typeof window.i18n.isRTL === 'function') ? window.i18n.isRTL() : false;
  let emp = null;
  if (typeof activeEmpPersonNo !== 'undefined' && activeEmpPersonNo) {
    emp = employees.find(e => String(e.empNo || e.personNumber || e.id || e.idNo) === String(activeEmpPersonNo));
  }
  const isBlankState = !emp;
  const blankEmp = {
    name: '',
    idNo: '',
    empNo: '',
    id: '',
    department: '',
    jobTitle: '',
    dob: '',
    gender: '',
    demographic: { fullName: '', arabicFullName: '', nationalId: '', personNumber: '', deptTreating: '', positionName: '', assignmentEffectiveDate: '' },
    healthStatus: {},
    labResults: {},
    vaccines: {},
    specialVaccines: {},
    covidFlu: {},
    pep: {}
  };
  if (!emp) {
    emp = blankEmp;
  }
  
  console.log("CERTIFICATE EMPLOYEE", emp);
  const demo = emp ? (emp.demographic || {}) : {};
  const lab = emp ? (emp.labResults || emp.lab || {}) : {};
  const vac = emp ? (emp.vaccines || {}) : {};
  const sp = emp ? (emp.specialVaccines || {}) : {};
  const cf = emp ? (emp.covidFlu || {}) : {};

  const formatDate = (val) => {
    if (!val) return '';
    return typeof standardizeDateStr === 'function' ? standardizeDateStr(val, false) : val;
  };

  const fullName = emp ? (emp.name || demo.fullName || '') : '';
  const arName = emp ? (demo.arabicFullName || emp.arabicName || '') : '';
  const idNo = emp ? (emp.idNo || demo.nationalId || emp.empNo || demo.personNumber || '') : '';
  const empNo = emp ? (emp.empNo || demo.personNumber || emp.id || '') : '';
  const dept = emp ? (demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || demo.deptTreating || '') : '';
  const positionName = emp ? (emp.jobTitle || demo.positionName || '') : '';
  const currentDateStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const currentDateFormatted = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });

  const assignEffectiveDate = formatDate(demo.assignmentEffectiveDate || (emp ? (emp.assignmentEffectiveDate || emp.assignDate) : '') || demo.assignmentDate || demo.startDate || '');

  // Render Top Toolbar with Employee Selector & 4 Certificate Type Buttons
  let topToolbarHTML = `
    <!-- LIVE SEARCH BAR & RECORD CONTROLS (QUICK SEARCH OR SELECT FROM LIST) -->
    <div class="card no-print" style="border-left: 4px solid var(--accent-teal); margin-bottom: 20px; padding: 18px 22px; background: #FAFDFD;">
      <div style="display: flex; gap: 14px; align-items: flex-end; flex-wrap: wrap;">
        <div style="flex: 2; min-width: 280px; position: relative;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            🔍 ${isAr ? 'البحث السريع عن موظف (الاسم / الهوية / الرقم الوظيفي):' : 'Quick Search Staff (Name, ID, or Emp No):'}
          </label>
          <div class="search-flex-group" style="display: flex; gap: 8px;">
            <input type="text" id="cert_header_search_input"
              placeholder="${isAr ? 'اكتب اسم الموظف أو الهوية أو الرقم الوظيفي...' : 'Type Name, ID, or Emp No...'}"
              value="${escapeHtmlAttr(certSearchQuery || (!isBlankState && emp.name ? (emp.name + (emp.idNo ? ' (ID: ' + emp.idNo + ')' : '')) : ''))}"
              onfocus="showCertSearchResults(this.value)"
              oninput="handleCertHeaderSearch(this.value)"
              onkeydown="handleCertSearchKeyDown(event)"
              autocomplete="off"
              style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.95rem; font-weight: 600; background: white;">
            <button type="button" class="btn btn-outline" style="padding: 8px 14px; font-weight: bold; background: white; white-space: nowrap; border-color: #94A3B8; color: #475569;" onclick="clearCertSearch()">
              🧹 ${isAr ? 'تفريغ الشاشة' : 'Clear Form'}
            </button>
          </div>
          <!-- FLOATING LIVE SEARCH RESULTS DROPDOWN -->
          <div id="cert_search_results" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1.5px solid var(--accent-teal); border-radius: 6px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); z-index: 100; max-height: 280px; overflow-y: auto;"></div>
        </div>

        <div style="flex: 1.5; min-width: 240px;">
          <label style="font-weight: 800; font-size: 0.9rem; display: block; margin-bottom: 6px; color: var(--primary-blue);">
            👤 ${isAr ? 'أو اختر موظفاً من القائمة مباشرة:' : 'Or Select Employee from List:'}
          </label>
          <select id="cert_quick_select" style="width: 100%; padding: 10px 14px; border: 2px solid var(--accent-teal); border-radius: 6px; font-size: 0.92rem; font-weight: 600; background: white;" onchange="selectCertEmployee(this.value)">
            ${typeof buildStaffQuickSelectOptionsHtml === 'function' ? buildStaffQuickSelectOptionsHtml(employees, isAr, emp && (emp.empNo || emp.id)) : ''}
          </select>
        </div>
      </div>
    </div>

    <!-- DOCUMENT TYPE & PRINT CONTROLS TOOLBAR -->
    <div style="margin-bottom: 18px; display: flex; justify-content: space-between; align-items: center; background: #F8FAFC; padding: 12px 18px; border-radius: 8px; border: 1px solid #E2E8F0; flex-wrap: wrap; gap: 14px;" class="no-print">
        <div style="display: flex; gap: 6px; background: #E2E8F0; padding: 4px; border-radius: 8px; flex-wrap: wrap;">
          <button type="button" class="btn" style="padding: 7px 14px; font-size: 0.86rem; font-weight: 700; border-radius: 6px; border: none; cursor: pointer; ${activeCertDocumentType === 'vaccination' ? 'background: #0284C7; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="switchCertDocType('vaccination')">
            📜 Vaccination Certificate
          </button>
          <button type="button" class="btn" style="padding: 7px 14px; font-size: 0.86rem; font-weight: 700; border-radius: 6px; border: none; cursor: pointer; ${activeCertDocumentType === 'special' ? 'background: #0284C7; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="switchCertDocType('special')">
            💉 Special Vaccine Certificate
          </button>
          <button type="button" class="btn" style="padding: 7px 14px; font-size: 0.86rem; font-weight: 700; border-radius: 6px; border: none; cursor: pointer; ${activeCertDocumentType === 'covid' ? 'background: #0284C7; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="switchCertDocType('covid')">
            💉 COVID Vaccine Certificate
          </button>
          <button type="button" class="btn" style="padding: 7px 14px; font-size: 0.86rem; font-weight: 700; border-radius: 6px; border: none; cursor: pointer; ${activeCertDocumentType === 'khcc' ? 'background: #0284C7; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="switchCertDocType('khcc')">
            🏛️ KHCC Certificate Letter
          </button>
          <button type="button" class="btn" style="padding: 7px 14px; font-size: 0.86rem; font-weight: 700; border-radius: 6px; border: none; cursor: pointer; ${activeCertDocumentType === 'ppd' ? 'background: #0284C7; color: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1);' : 'background: transparent; color: #475569;'}" onclick="switchCertDocType('ppd')">
            🩺 PPD Test Certificate
          </button>
        </div>
      </div>

      <div style="display: flex; align-items: center; gap: 8px;">
        <label style="font-weight: 700; color: #475569; font-size: 0.86rem;" class="no-print">Paper Size:</label>
        <select id="cert_paper_size_select" onchange="if(typeof setCertPaperSize==='function') setCertPaperSize(this.value)" style="padding: 8px 12px; font-size: 0.88rem; font-weight: 700; border-radius: 6px; border: 1px solid #CBD5E1; background: white; color: #1E293B;">
          <option value="a4" selected>📄 A4 Portrait</option>
          <option value="letter">📄 Letter Portrait</option>
        </select>
        <button type="button" class="btn btn-success" style="background: #10B981; border: none; font-weight: 700; padding: 9px 20px; display: flex; align-items: center; gap: 6px; font-size: 0.92rem; box-shadow: 0 2px 6px rgba(16, 185, 129, 0.3);" onclick="printCertificate()">
          🖨️ Print / Download (PDF)
        </button>
      </div>
    </div>
  `;

  if (activeCertDocumentType === 'special') {
    const meningococcalDate = formatDate(sp.meningococcal || sp.meningococcalDate || '');
    const hepA1Date = formatDate(sp.hepA1 || sp.hepA1Date || '');
    const hepA2Date = formatDate(sp.hepA2 || sp.hepA2Date || '');
    const typhoidDate = formatDate(sp.typhoid || sp.typhoidDate || '');
    const pneumovaxDate = formatDate(sp.pneumovax || sp.pneumococcal || sp.pnemovax || sp.pneumovaxDate || '');

    const renderValSpan = (val, defaultWidth = '140px') => {
      const textVal = (val !== null && val !== undefined && val !== '') ? val : '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
      return `<span style="font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; min-width: ${defaultWidth}; display: inline-block; text-align: center; color: #000000; padding: 0 4px;">${textVal}</span>`;
    };

    container.innerHTML = topToolbarHTML + `
      <!-- FORMAL SPECIAL VACCINE CERTIFICATE PREVIEW -->
      <div id="printPage" class="print-page">
        <div id="certificatePrintArea" class="certificate-print-area formal-cert-wrapper print-a4" style="background: white; width: 100%; max-width: 820px; margin: 0 auto; padding: 25px 35px; border: 1px solid #CBD5E1; box-shadow: none; font-family: 'Times New Roman', Times, serif; color: #000000; box-sizing: border-box;">
        
        <!-- HEADER -->
        <div style="margin-bottom: 20px; text-align: center;">
          <div style="display: inline-block; text-align: center;">
            <img src="assets/branded_header_75.png" alt="Augusta Victoria Hospital Branded Header" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none;" />
          </div>
          <div style="border-bottom: 1.5px solid #000000; margin: 12px 0 8px 0; width: 100%;"></div>
          <div style="text-align: right; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; color: #000000; padding-right: 4px;">
            ${currentDateStr}
          </div>
        </div>

        <!-- TITLE -->
        <div style="text-align: center; margin-top: 10px; margin-bottom: 25px;">
          <h2 style="font-family: 'Times New Roman', Times, serif; font-size: 16pt; font-weight: bold; text-decoration: underline; text-underline-offset: 4px; margin: 0; color: #000000;">Special Vaccination Certificate</h2>
        </div>

        <!-- SALUTATION & EMPLOYEE IDENTIFIER -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 11.5pt; line-height: 1.8; margin-bottom: 25px; text-align: left; color: #000000;">
          According to policy of vaccination, Special Vaccines was given for &nbsp;
          <span style="font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; padding: 0 8px; display: inline-block;">${fullName || '--------------------'}</span>
          &nbsp;&nbsp;&nbsp;&nbsp;
          <span style="white-space: nowrap;">ID No: <span style="font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; padding: 0 8px; display: inline-block;">${idNo || '----------'}</span></span>
        </div>

        <!-- NUMBERED VACCINATION LIST -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 11pt; line-height: 2.2; margin-bottom: 30px; color: #000000;">
          
          <!-- ITEM 1 -->
          <div style="display: flex; align-items: baseline; gap: 14px; margin-bottom: 8px;">
            <div style="width: 24px; font-weight: normal; font-size: 11pt;">1</div>
            <div style="flex: 1;">
              Meningococcal Vaccine – Serogroups A &amp; C was given on &nbsp;&nbsp;&nbsp;&nbsp; ${renderValSpan(meningococcalDate, '140px')}
            </div>
          </div>

          <!-- ITEM 2 -->
          <div style="display: flex; align-items: baseline; gap: 14px; margin-bottom: 8px;">
            <div style="width: 24px; font-weight: normal; font-size: 11pt;">2</div>
            <div style="flex: 1;">
              Hepatitis A Vaccine Dose 1 was given on &nbsp;&nbsp;&nbsp;&nbsp; ${renderValSpan(hepA1Date, '140px')}
            </div>
          </div>

          <!-- ITEM 3 -->
          <div style="display: flex; align-items: baseline; gap: 14px; margin-bottom: 8px;">
            <div style="width: 24px; font-weight: normal; font-size: 11pt;">3</div>
            <div style="flex: 1;">
              Hepatitis A Vaccine Dose 2 was given on &nbsp;&nbsp;&nbsp;&nbsp; ${renderValSpan(hepA2Date, '140px')}
            </div>
          </div>

          <!-- ITEM 4 -->
          <div style="display: flex; align-items: baseline; gap: 14px; margin-bottom: 8px;">
            <div style="width: 24px; font-weight: normal; font-size: 11pt;">4</div>
            <div style="flex: 1;">
              Typhoid Vaccine was given on &nbsp;&nbsp;&nbsp;&nbsp; ${renderValSpan(typhoidDate, '140px')}
            </div>
          </div>

          <!-- ITEM 5 -->
          <div style="display: flex; align-items: baseline; gap: 14px; margin-bottom: 8px;">
            <div style="width: 24px; font-weight: normal; font-size: 11pt;">5</div>
            <div style="flex: 1;">
              Pneumococcal Vaccine was given on &nbsp;&nbsp;&nbsp;&nbsp; ${renderValSpan(pneumovaxDate, '140px')}
            </div>
          </div>

        </div>

        <!-- CLOSING REMARK -->
        <div style="text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 12pt; margin-top: 25px; margin-bottom: 25px; color: #000000;">
          <div>This certificate has been given upon request.</div>
          <div style="margin-top: 6px;">Sincerely,</div>
        </div>

        <!-- SIGNATURE BLOCK -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; font-family: 'Times New Roman', Times, serif; font-size: 11pt; padding: 0 10px; margin-bottom: 25px; color: #000000;">
          <div style="text-align: center; width: 45%;">
            <div style="font-weight: bold; font-size: 12pt;">Infectious Disease Unit</div>
            <div style="margin-top: 6px; font-weight: bold; font-size: 12pt;">${currentDateFormatted}</div>
          </div>
          <div style="text-align: center; width: 50%;">
            <div style="font-weight: bold; font-size: 12pt;">Dr. Ali Sabateen</div>
            <div style="font-size: 11pt; margin-top: 2px;">Infectious disease specialist</div>
            <div style="font-size: 11pt; font-weight: bold;">Head of Infectious Disease Unit</div>
          </div>
        </div>

        <!-- OFFICIAL FORMAL FOOTER BAR -->
        <div style="margin-top: 20px; width: 100%;">
          <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none; -webkit-filter: none;" />
        </div>

      </div>
      </div>

      <!-- BOTTOM ACTIONS BAR (NO PRINT) -->
      <div style="max-width: 820px; margin: 20px auto 10px auto; display: flex; justify-content: center; gap: 16px;" class="no-print">
        <button type="button" class="btn btn-success" style="background: #10B981; border: none; font-weight: 700; padding: 12px 28px; font-size: 1rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);" onclick="saveAndPrintCertificate()">
          💾 Save & Print Special Vaccine Certificate (PDF)
        </button>
      </div>
    `;
    return;
  }

  if (activeCertDocumentType === 'covid') {
    const records = typeof getCanonicalVaccineRecords === 'function' ? getCanonicalVaccineRecords(emp) : [];
    let certRows = [];
    if (records && records.length > 0) {
      certRows = records.map(r => ({
        label: typeof getVaccineLabel === 'function' ? getVaccineLabel(r) : (r.vacName || 'Vaccine'),
        mfr: r.mfr || '',
        date: formatDate(r.date) || '',
        lot: r.lot || ''
      }));
    } else {
      certRows = [
        { label: "COVID -19 first dose", mfr: "", date: "", lot: "" },
        { label: "COVID -19 second dose", mfr: "", date: "", lot: "" },
        { label: "COVID -19 third dose", mfr: "", date: "", lot: "" },
        { label: "COVID -19 booster dose", mfr: "", date: "", lot: "" },
        { label: "flu vaccine year (2025/2026)", mfr: "", date: "", lot: "" }
      ];
    }

    container.innerHTML = topToolbarHTML + `
      <!-- FORMAL COVID-19 VACCINE CERTIFICATE PREVIEW -->
      <div id="printPage" class="print-page">
        <div id="certificatePrintArea" class="certificate-print-area formal-cert-wrapper print-a4" style="background: white; width: 100%; max-width: 820px; margin: 0 auto; padding: 25px 35px; border: 1px solid #CBD5E1; box-shadow: none; font-family: 'Times New Roman', Times, serif; color: #000000; box-sizing: border-box;">
        
        <!-- HEADER -->
        <div style="margin-bottom: 20px; text-align: center;">
          <div style="display: inline-block; text-align: center;">
            <img src="assets/branded_header_75.png" alt="Augusta Victoria Hospital Branded Header" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none;" />
          </div>
          <div style="border-bottom: 1.5px solid #000000; margin: 12px 0 8px 0; width: 100%;"></div>
          <div style="text-align: right; font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; color: #000000; padding-right: 4px;">
            ${currentDateStr}
          </div>
        </div>

        <!-- TITLE -->
        <div style="text-align: center; margin-top: 10px; margin-bottom: 25px;">
          <h2 style="font-family: 'Times New Roman', Times, serif; font-size: 16pt; font-weight: bold; text-decoration: underline; text-underline-offset: 4px; margin: 0; color: #000000;">COVID-19 & Seasonal Flu Vaccination Certificate</h2>
        </div>

        <!-- SALUTATION PARAGRAPH -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 11.5pt; line-height: 1.8; margin-bottom: 25px; text-align: left; color: #000000;">
          This is to certify that &nbsp;
          <span style="font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-decoration: underline; padding: 0 8px;">${fullName}</span>
          &nbsp;&nbsp; (ID No: <span style="font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; text-decoration: underline; padding: 0 6px;">${idNo}</span>), Department: <strong>${dept}</strong>, Position: <strong>${positionName}</strong>, has received the following COVID-19 & Seasonal Flu vaccinations at Augusta Victoria Hospital:
        </div>

        <!-- COVID VACCINATION TABLE -->
        <table style="width: 100%; table-layout: fixed; border-collapse: collapse; margin-bottom: 30px; font-family: 'Times New Roman', Times, serif; font-size: 11pt; border: 1.5px solid #000000;">
          <thead>
            <tr style="background: #F1F5F9; border-bottom: 1.5px solid #000000;">
              <th style="padding: 10px 12px; border-right: 1px solid #000000; text-align: left; width: 35%;">Dose / Vaccine Name</th>
              <th style="padding: 10px 12px; border-right: 1px solid #000000; text-align: center; width: 25%;">Manufacturer / Brand</th>
              <th style="padding: 10px 12px; border-right: 1px solid #000000; text-align: center; width: 22%;">Date Administered</th>
              <th style="padding: 10px 12px; text-align: center; width: 18%;">Batch / Lot No.</th>
            </tr>
          </thead>
          <tbody>
            ${certRows.map(row => `
              <tr style="border-bottom: 1px solid #000000;">
                <td style="padding: 10px 12px; border-right: 1px solid #000000; font-weight: bold;">${row.label}</td>
                <td style="padding: 10px 12px; border-right: 1px solid #000000; text-align: center;">${row.mfr}</td>
                <td style="padding: 10px 12px; border-right: 1px solid #000000; text-align: center; font-weight: bold; text-decoration: underline;">${row.date}</td>
                <td style="padding: 10px 12px; text-align: center; font-weight: bold; text-decoration: underline;">${row.lot}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <!-- CLOSING REMARK -->
        <div style="text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 12pt; margin-top: 30px; margin-bottom: 30px; color: #000000;">
          <div>This official certificate has been issued upon request for official vaccination verification.</div>
          <div style="margin-top: 6px;">Sincerely,</div>
        </div>

        <!-- SIGNATURE BLOCK -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; font-family: 'Times New Roman', Times, serif; font-size: 11pt; padding: 0 10px; margin-bottom: 30px; color: #000000;">
          <div style="text-align: center; width: 45%;">
            <div style="font-weight: bold; font-size: 12pt;">Infectious Disease Unit</div>
            <div style="margin-top: 6px; font-weight: bold; font-size: 12pt;">${currentDateFormatted}</div>
          </div>
          <div style="text-align: center; width: 50%;">
            <div style="font-weight: bold; font-size: 12pt;">Dr. Ali Sabateen</div>
            <div style="font-size: 11pt; margin-top: 2px;">Infectious disease specialist</div>
            <div style="font-size: 11pt; font-weight: bold;">Head of Infectious Disease Unit</div>
          </div>
        </div>

        <!-- FOOTER BAR -->
        <div style="margin-top: 20px; width: 100%;">
          <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none; -webkit-filter: none;" />
        </div>

      </div>
      </div>

      <!-- BOTTOM ACTIONS BAR -->
      <div style="max-width: 820px; margin: 20px auto 10px auto; display: flex; justify-content: center; gap: 16px;" class="no-print">
        <button type="button" class="btn btn-success" style="background: #10B981; border: none; font-weight: 700; padding: 12px 28px; font-size: 1rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);" onclick="saveAndPrintCertificate()">
          💾 Save & Print COVID Vaccine Certificate (PDF)
        </button>
      </div>
    `;
    return;
  }

  if (activeCertDocumentType === 'khcc') {
    const mmr1Date = formatDate(vac.mmrDose1 || (vac.MMR ? vac.MMR.d1 : '') || '');
    const mmrDateVal = mmr1Date ? mmr1Date : '';

    const rawVarIgGVal = emp ? (lab.varicellaIgG || lab.varicellaIgGResult || vac.varicellaIgG || emp.varicellaIgG || emp['Varicella Zoster, IgG'] || emp['Varicella Zoster IgG'] || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || vac.chickenpoxStatus || emp.chickenpoxStatus || emp['Chicken pox infected or Vaccinated'] || emp['Chickenpox Infected or Vaccinated'] || '') : '';
    const rawVarIgGDateVal = emp ? (lab.varicellaIgGDate || lab.varicellaDate || vac.chickenpoxDate || vac.varicellaIgGDate || emp.varicellaDate || emp.varicellaIgGDate || emp['Varicella Zoster, IgG date'] || emp['Varicella Zoster, IgG Date'] || emp['Varicella Zoster IgG Date'] || emp['Varicella Zoster IgG date'] || (lab.Varicella_IgG ? lab.Varicella_IgG.date : '') || '') : '';
    const varicellaStatusText = rawVarIgGVal || '';
    const varicellaDateVal = formatDate(rawVarIgGDateVal, true);

    const hbsabTiter = emp.hepbTiter || lab.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || '';
    const hbsabStatusText = hbsabTiter ? (hbsabTiter !== '0' ? `Immune (${hbsabTiter} IU/L)` : hbsabTiter) : '';
    const hbsabDate = formatDate(lab.hbsabDate || (lab.HBsAb ? lab.HBsAb.date : '') || emp.hbsabDate || '');

    const ppd1Date = formatDate(lab.ppdStep1Date || (lab.PPD ? lab.PPD.date : '') || '');
    const ppd1ReadDate = formatDate(lab.ppdStep1ReadDate || '') || (ppd1Date ? (typeof addDaysToDateStr === 'function' ? addDaysToDateStr(ppd1Date, 3) : ppd1Date) : '');
    const ppdResultVal = lab.ppdStep1Result || lab.ppdResult || '';
    let rawInd1 = toSafeLabString(getFirstDefinedLabValue(lab.ppdStep1Induration, (lab.PPD ? lab.PPD.test1 : ''))).replace(/mm/gi, '').trim();
    const ppdIndVal = rawInd1 !== '' ? (rawInd1 + 'mm') : '';

    const mumpsIgGResult = emp ? (lab.mumpsIgGTiter || (lab.Mumps_IgG ? lab.Mumps_IgG.result : '') || emp.mumpsIgGTiter || emp['Mumps IgG Titer'] || emp['Mumps IgG'] || '') : '';
    const mumpsIgGDate = formatDate(lab.mumpsIgGTiterDate || (lab.Mumps_IgG ? lab.Mumps_IgG.date : '') || emp.mumpsIgGTiterDate || emp['Mumps IgG Titer date'] || emp['Mumps IgG Date'] || '', true);

    const measlesIgGResult = emp ? (lab.measlesIgGTiter || (lab.Measles_IgG ? lab.Measles_IgG.result : '') || emp.measlesIgGTiter || emp['Measles IgG Titer'] || emp['Measles IgG'] || '') : '';
    const measlesIgGDate = formatDate(lab.measlesIgGTiterDate || (lab.Measles_IgG ? lab.Measles_IgG.date : '') || emp.measlesIgGTiterDate || emp['Measles IgG Titer date'] || emp['Measles IgG Date'] || '', true);

    const rubellaIgGResult = emp ? (lab.rubellaIgGTiter || (lab.Rubella_IgG ? lab.Rubella_IgG.result : '') || emp.rubellaIgGTiter || emp['Rubella IgG Titer'] || emp['Rubella IgG'] || '') : '';
    const rubellaIgGDate = formatDate(lab.rubellaIgGTiterDate || (lab.Rubella_IgG ? lab.Rubella_IgG.date : '') || emp.rubellaIgGTiterDate || emp['Rubella IgG Titer date'] || emp['Rubella IgG Date'] || '', true);

    const covidDate = formatDate(cf.covidDose1Date || cf.covid1Date || '');
    const fluDate = formatDate(cf.flu2425 || cf.flu2324 || cf.fluDate || (vac['Flu vaccine'] ? vac['Flu vaccine'].d5 : '') || '');

    container.innerHTML = topToolbarHTML + `
      <!-- KHCC FORMAL MEDICAL CLEARANCE LETTER PREVIEW -->
      <div id="printPage" class="print-page">
        <div id="certificatePrintArea" class="certificate-print-area formal-cert-wrapper print-a4" style="background: white; width: 100%; max-width: 820px; margin: 0 auto; padding: 14px 22px; border: 1px solid #CBD5E1; box-shadow: none; font-family: 'Times New Roman', Times, serif; color: #000000; box-sizing: border-box;">
        
        <!-- HEADER -->
        <div style="margin-bottom: 8px;">
          <div style="width: 100%;">
            <img src="assets/branded_header_75.png" alt="Augusta Victoria Hospital Branded Header" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none;" />
          </div>
          <div style="text-align: right; font-family: 'Times New Roman', Times, serif; font-size: 11pt; font-weight: bold; color: #000000; padding-right: 4px; margin-top: 4px;">
            ${currentDateStr}
          </div>
        </div>

        <!-- TITLE & SUBTITLE -->
        <div style="text-align: center; margin-top: 4px; margin-bottom: 10px;">
          <h2 style="font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; margin: 0; color: #000000;">Medical & Vaccination Clearance Certificate</h2>
          <div style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; margin-top: 3px; color: #000000;">
            King Hussein Cancer Center (KHCC) - Trainee & Visiting Staff Clearance Letter
          </div>
        </div>

        <!-- ADDRESSEE -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; margin-bottom: 8px; color: #000000;">
          To: King Hussein Cancer Center (KHCC)<br />
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Infection Control & Occupational Health Department
        </div>

        <!-- SALUTATION PARAGRAPH -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 10pt; line-height: 1.45; margin-bottom: 10px; text-align: left; color: #000000;">
          This is to certify that &nbsp;
          <span style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; padding: 0 6px;">${fullName}</span>
          &nbsp;&nbsp; (ID No: <span style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; padding: 0 4px;">${idNo}</span> ), Position: <strong>${positionName},</strong> Department: <strong>${dept},</strong> has fulfilled all mandatory occupational health requirements and immunization protocols as per Augusta Victoria Hospital policy:
        </div>

        <!-- SECTION 1: VACCINATION TABLE -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-decoration: underline; margin-bottom: 3px; text-align: left; color: #000000;">
          Vaccination
        </div>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-family: 'Times New Roman', Times, serif; font-size: 9.5pt; border: 1.5px solid #000000;">
          <thead>
            <tr style="background: #FFFFFF; border-bottom: 1.5px solid #000000;">
              <th style="padding: 3px 5px; border-right: 1px solid #000000; text-align: left; width: 28%; font-weight: bold; color: #000000;">Vaccine</th>
              <th style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; width: 18%; font-weight: bold; color: #000000;">Dose 1 date</th>
              <th style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; width: 18%; font-weight: bold; color: #000000;">Dose 2 date</th>
              <th style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; width: 18%; font-weight: bold; color: #000000;">Dose 3 date</th>
              <th style="padding: 3px 5px; text-align: center; width: 18%; font-weight: bold; color: #000000;">Dose 4 date</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">IPV</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.ipvDate || (vac.IPV ? vac.IPV.d1 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.IPV ? vac.IPV.d2 : '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.IPV ? vac.IPV.d3 : '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(vac.IPV ? vac.IPV.d4 : '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">OPV</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.opvDose1 || (vac.OPV ? vac.OPV.d1 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.opvDose2 || (vac.OPV ? vac.OPV.d2 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.opvDose3 || (vac.OPV ? vac.OPV.d3 : '') || '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(vac.opvDose4 || (vac.OPV ? vac.OPV.d4 : '') || '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">DPT/dT</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.dptDose1 || (vac['DPT/dT'] ? vac['DPT/dT'].d1 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.dptDose2 || (vac['DPT/dT'] ? vac['DPT/dT'].d2 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.dptDose3 || (vac['DPT/dT'] ? vac['DPT/dT'].d3 : '') || '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(vac.dptDose4 || (vac['DPT/dT'] ? vac['DPT/dT'].d4 : '') || '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Tdap</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.tdapDate || emp.tdapDate || (vac.Tdap ? vac.Tdap.d5 || vac.Tdap.d1 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.Tdap ? vac.Tdap.d2 : '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.Tdap ? vac.Tdap.d3 : '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(vac.Tdap ? vac.Tdap.d4 : '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">MMR</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${mmrDateVal}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.mmrDose2 || (vac.MMR ? vac.MMR.d2 || vac.MMR.d5 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.MMR ? vac.MMR.d3 : '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(vac.MMR ? vac.MMR.d4 : '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Hepatitis B</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(lab.engrixDose1 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d5 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(lab.engrixDose2 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d6 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(lab.engrixDose3 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d7 : '') || '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(lab.engrixBooster || (vac['Hepatitis B'] ? vac['Hepatitis B'].d4 : '') || '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Varicella</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.chickenpoxDose1 || vac.varicella1Date || emp.varicella1Date || (vac['Varicella Zoster (Chicken pox)'] ? vac['Varicella Zoster (Chicken pox)'].d1 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac.chickenpoxDose2 || (vac['Varicella Zoster (Chicken pox)'] ? vac['Varicella Zoster (Chicken pox)'].d2 : '') || '')}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${formatDate(vac['Varicella Zoster (Chicken pox)'] ? vac['Varicella Zoster (Chicken pox)'].d3 : '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(vac['Varicella Zoster (Chicken pox)'] ? vac['Varicella Zoster (Chicken pox)'].d4 : '')}</td>
            </tr>
            <tr>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Other</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${emp?.otherVaccines || ''}</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;"></td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;"></td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;"></td>
            </tr>
          </tbody>
        </table>

        <!-- SECTION 2: LABORATORY RESULT TABLE -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; font-weight: bold; text-decoration: underline; margin-bottom: 3px; text-align: left; color: #000000;">
          Laboratory Result
        </div>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px; font-family: 'Times New Roman', Times, serif; font-size: 9.5pt; border: 1.5px solid #000000;">
          <thead>
            <tr style="background: #FFFFFF; border-bottom: 1.5px solid #000000;">
              <th style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; width: 35%; font-weight: bold; color: #000000;">Test</th>
              <th style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; width: 40%; font-weight: bold; color: #000000;">Result</th>
              <th style="padding: 3px 5px; text-align: center; width: 25%; font-weight: bold; color: #000000;">Date</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">HBsAb</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${lab.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || emp?.hepbTiter || ''}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${hbsabDate}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">HBsAg</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${lab.hbsagResult || (lab.HBsAg ? lab.HBsAg.result : '') || ''}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(lab.hbsagDate || (lab.HBsAg ? lab.HBsAg.date : '') || '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">HCV</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${lab.hcvResult || (lab.HCV ? lab.HCV.result : '') || ''}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(lab.hcvDate || (lab.HCV ? lab.HCV.date : '') || emp?.hcvDate || '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">HIV</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${lab.hivResult || (lab.HIV ? lab.HIV.result : '') || ''}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${formatDate(lab.hivDate || (lab.HIV ? lab.HIV.date : '') || emp?.hivDate || '')}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">PPD</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${ppdIndVal || (lab.ppdStep1Result || lab.ppdResult || '')}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${ppd1ReadDate}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Varicella Zoster, IgG</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${varicellaStatusText}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${varicellaDateVal}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Mumps IgG Titer</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${mumpsIgGResult}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${mumpsIgGDate}</td>
            </tr>
            <tr style="border-bottom: 1px solid #000000;">
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Measles IgG Titer</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${measlesIgGResult}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${measlesIgGDate}</td>
            </tr>
            <tr>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; font-weight: bold;">Rubella IgG Titer</td>
              <td style="padding: 3px 5px; border-right: 1px solid #000000; text-align: center; font-weight: bold;">${rubellaIgGResult}</td>
              <td style="padding: 3px 5px; text-align: center; font-weight: bold;">${rubellaIgGDate}</td>
            </tr>
          </tbody>
        </table>

        <!-- CLEARANCE STATEMENT -->
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; line-height: 1.45; margin-bottom: 8px; font-weight: bold; text-align: left; color: #000000;">
          Conclusion: The above-named healthcare worker is medically cleared for clinical rotations, training, and activity at King Hussein Cancer Center (KHCC).
        </div>

        <!-- CLOSING REMARK -->
        <div class="cert-closing-block" style="text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 10.5pt; margin-top: 6px; margin-bottom: 6px; color: #000000; page-break-inside: avoid !important;">
          <div>This certificate letter has been issued upon request.</div>
          <div style="margin-top: 2px;">Sincerely,</div>
        </div>

        <!-- SIGNATURE BLOCK -->
        <div class="signature-block" style="display: flex; justify-content: space-between; align-items: flex-start; font-family: 'Times New Roman', Times, serif; font-size: 10pt; padding: 0 10px; margin-bottom: 6px; color: #000000; page-break-inside: avoid !important;">
          <div style="text-align: center; width: 45%;">
            <div style="font-weight: bold; font-size: 10.5pt;">Infectious Disease Unit</div>
            <div style="margin-top: 2px; font-weight: bold; font-size: 10.5pt;">${currentDateFormatted}</div>
          </div>
          <div style="text-align: center; width: 50%;">
            <div style="font-weight: bold; font-size: 10.5pt;">Dr. Ali Sabateen</div>
            <div style="font-size: 9.5pt; margin-top: 1px;">Infectious disease specialist</div>
            <div style="font-size: 9.5pt; font-weight: bold;">Head of Infectious Disease Unit</div>
          </div>
        </div>

        <!-- FOOTER BAR -->
        <div class="cert-footer-bar" style="margin-top: 6px; width: 100%; page-break-inside: avoid !important;">
          <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none; -webkit-filter: none;" />
        </div>

      </div>
      </div>

      <!-- BOTTOM ACTIONS BAR -->
      <div style="max-width: 820px; margin: 20px auto 10px auto; display: flex; justify-content: center; gap: 16px;" class="no-print">
        <button type="button" class="btn btn-success" style="background: #10B981; border: none; font-weight: 700; padding: 12px 28px; font-size: 1rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);" onclick="saveAndPrintCertificate()">
          💾 Save & Print KHCC Certificate Letter (PDF)
        </button>
      </div>
    `;
    return;
  }

  if (activeCertDocumentType === 'ppd') {
    // 1. Employee Identification
    const empName = fullName || '________________________________';
    const empId = idNo || '____________________';

    // 2. First Step PPD extraction
    const rawPpd1Date = lab.ppdStep1Date || (lab.PPD ? lab.PPD.date : '') || emp.ppdStep1Date || '';
    const ppd1AdminDate = formatDate(rawPpd1Date);
    const rawPpd1ReadDate = lab.ppdStep1ReadDate || emp.ppdStep1ReadDate || '';
    const ppd1ReadDate = formatDate(rawPpd1ReadDate) || (ppd1AdminDate ? (typeof addDaysToDateStr === 'function' ? addDaysToDateStr(ppd1AdminDate, 3) : ppd1AdminDate) : '');

    let rawInd1 = toSafeLabString(getFirstDefinedLabValue(lab.ppdStep1Induration, (lab.PPD ? lab.PPD.test1 : ''), emp.ppdStep1Induration)).replace(/mm/gi, '').trim();
    if (rawInd1 === '' && (lab.ppdStep1Result || emp.ppdStep1Result || (lab.PPD && lab.PPD.result))) rawInd1 = '0';
    const ppd1IndDisplay = rawInd1 !== '' ? `${rawInd1} mm` : '__________ mm';

    const ppd1ResultText = lab.ppdStep1Result || (lab.PPD ? lab.PPD.result : '') || emp.ppdStep1Result || '';
    const ppd1ResultDisplay = ppd1ResultText || '____________________';

    // 3. Second Step PPD extraction
    const rawPpd2Date = lab.ppdStep2Date || (lab.PPD ? lab.PPD.test2Date : '') || emp.ppdStep2Date || '';
    const ppd2AdminDate = formatDate(rawPpd2Date);
    const rawPpd2ReadDate = lab.ppdStep2ReadDate || emp.ppdStep2ReadDate || '';
    const ppd2ReadDate = formatDate(rawPpd2ReadDate) || (ppd2AdminDate ? (typeof addDaysToDateStr === 'function' ? addDaysToDateStr(ppd2AdminDate, 3) : ppd2AdminDate) : '');

    let rawInd2 = toSafeLabString(getFirstDefinedLabValue(lab.ppdStep2Induration, (lab.PPD ? lab.PPD.test2 : ''), emp.ppdStep2Induration)).replace(/mm/gi, '').trim();
    if (rawInd2 === '' && (lab.ppdStep2Result || emp.ppdStep2Result)) rawInd2 = '0';
    const ppd2IndDisplay = rawInd2 !== '' ? `${rawInd2} mm` : '__________ mm';

    const ppd2ResultText = lab.ppdStep2Result || (lab.PPD ? (lab.PPD.test2Result || lab.PPD.result) : '') || emp.ppdStep2Result || '';
    const ppd2ResultDisplay = ppd2ResultText || '____________________';

    container.innerHTML = topToolbarHTML + `
      <!-- FORMAL PPD TEST CERTIFICATE PREVIEW (EXACT MATCH TO ppd test.docx - BALANCED A4 LAYOUT) -->
      <div id="printPage" class="print-page">
        <div id="certificatePrintArea" class="certificate-print-area formal-cert-wrapper print-a4" style="background: white; width: 100%; max-width: 820px; min-height: 1020px; margin: 0 auto; padding: 35px 50px 30px 50px; border: 1px solid #CBD5E1; box-shadow: none; font-family: 'Times New Roman', Times, serif; color: #000000; box-sizing: border-box; display: flex !important; flex-direction: column !important; justify-content: space-between !important;">
        
        <!-- TOP SECTION: HEADER & DATE & BODY -->
        <div>
          <!-- HEADER -->
          <div style="margin-bottom: 25px; text-align: center;">
            <div style="display: inline-block; text-align: center; width: 100%;">
              <img src="assets/branded_header_75.png" alt="Augusta Victoria Hospital Branded Header" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none;" />
            </div>
            <div style="border-bottom: 1.5px solid #000000; margin: 15px 0 22px 0; width: 100%;"></div>
            <div style="text-align: right; font-family: 'Times New Roman', Times, serif; font-size: 13pt; font-weight: bold; color: #000000; padding-right: 4px; margin-bottom: 10px;">
              Date: <span contenteditable="true" style="text-decoration: underline; text-underline-offset: 4px; min-width: 120px; display: inline-block; text-align: center;">${currentDateStr}</span>
            </div>
          </div>

          <!-- TITLE (MOVED DOWNWARDS WITH GENEROUS SPACING) -->
          <div style="text-align: center; margin-top: 35px; margin-bottom: 45px;">
            <h2 style="font-family: 'Times New Roman', Times, serif; font-size: 17pt; font-weight: bold; text-decoration: underline; text-underline-offset: 5px; margin: 0; color: #000000; letter-spacing: 0.5px;">To Whom It May Concern</h2>
          </div>

          <!-- SALUTATION & EMPLOYEE IDENTIFIER -->
          <div style="font-family: 'Times New Roman', Times, serif; font-size: 13pt; line-height: 2.3; margin-bottom: 38px; text-align: left; color: #000000;">
            This is to certify that &nbsp;<span contenteditable="true" style="font-family: 'Times New Roman', Times, serif; font-size: 13pt; font-weight: bold; text-decoration: underline; text-underline-offset: 4px; padding: 0 4px; display: inline; color: #000000;">${empName}</span>,&nbsp; identification number &nbsp;<span contenteditable="true" style="font-family: 'Times New Roman', Times, serif; font-size: 13pt; font-weight: bold; text-decoration: underline; text-underline-offset: 4px; padding: 0 4px; display: inline; color: #000000;">${empId}</span>, underwent a two-step tuberculin skin test (PPD), with the following findings:
          </div>

          <!-- FIRST STEP -->
          <div style="font-family: 'Times New Roman', Times, serif; font-size: 13pt; line-height: 2.4; margin-bottom: 35px; padding-left: 15px; color: #000000;">
            <div style="font-weight: bold; font-size: 14pt; margin-bottom: 10px; text-decoration: underline; text-underline-offset: 4px;">First Step</div>
            <div style="margin-bottom: 8px;">
              Date of administration: &nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; min-width: 120px; display: inline-block; text-align: center;">${ppd1AdminDate || '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'}</span>
            </div>
            <div style="margin-bottom: 8px;">
              Date of reading: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; min-width: 120px; display: inline-block; text-align: center;">${ppd1ReadDate || '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'}</span>
            </div>
            <div style="margin-bottom: 8px;">
              Induration: &nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; padding: 0 4px; display: inline; min-width: 40px; text-align: center;">${ppd1IndDisplay}</span>, &nbsp;&nbsp;&nbsp;&nbsp;Interpretation: &nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; padding: 0 4px; display: inline; min-width: 100px; text-align: center;">${ppd1ResultDisplay}</span>
            </div>
          </div>

          <!-- SECOND STEP -->
          <div style="font-family: 'Times New Roman', Times, serif; font-size: 13pt; line-height: 2.4; margin-bottom: 42px; padding-left: 15px; color: #000000;">
            <div style="font-weight: bold; font-size: 14pt; margin-bottom: 10px; text-decoration: underline; text-underline-offset: 4px;">Second Step</div>
            <div style="margin-bottom: 8px;">
              Date of administration: &nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; min-width: 120px; display: inline-block; text-align: center;">${ppd2AdminDate || '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'}</span>
            </div>
            <div style="margin-bottom: 8px;">
              Date of reading: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; min-width: 120px; display: inline-block; text-align: center;">${ppd2ReadDate || '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'}</span>
            </div>
            <div style="margin-bottom: 8px;">
              Induration: &nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; padding: 0 4px; display: inline; min-width: 40px; text-align: center;">${ppd2IndDisplay}</span>, &nbsp;&nbsp;&nbsp;&nbsp;Interpretation: &nbsp;<span contenteditable="true" style="font-weight: bold; text-decoration: underline; text-underline-offset: 4px; padding: 0 4px; display: inline; min-width: 100px; text-align: center;">${ppd2ResultDisplay}</span>
            </div>
          </div>

          <!-- CLOSING REMARK -->
          <div style="text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 13pt; margin-top: 45px; margin-bottom: 35px; color: #000000; line-height: 2.0;">
            <div>This certificate is issued at the request of the above-named individual.</div>
            <div style="margin-top: 10px;">Sincerely,</div>
          </div>
        </div>

        <!-- BOTTOM SECTION: SIGNATURE BLOCK & FOOTER -->
        <div style="margin-top: auto; width: 100%;">
          <!-- SIGNATURE BLOCK -->
          <div style="display: flex; justify-content: space-between; align-items: flex-start; font-family: 'Times New Roman', Times, serif; font-size: 12pt; padding: 0 10px; margin-top: 30px; margin-bottom: 35px; color: #000000;">
            <div style="text-align: left; width: 45%;">
              <div style="font-weight: bold; font-size: 13pt;">Infection Control Committee</div>
              <div style="margin-top: 8px; font-weight: bold; font-size: 12pt; color: #334155;">${currentDateFormatted}</div>
            </div>
            <div style="text-align: right; width: 50%;">
              <div style="font-weight: bold; font-size: 13pt;">Dr. Ali Sabateen</div>
              <div style="font-size: 12pt; margin-top: 3px;">Infectious Disease Specialist</div>
              <div style="font-size: 12pt; font-weight: bold;">Head of Infectious Disease Unit</div>
            </div>
          </div>

          <!-- OFFICIAL FORMAL FOOTER BAR -->
          <div class="cert-footer-bar" style="margin-top: 15px; width: 100%; page-break-inside: avoid !important;">
            <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none; -webkit-filter: none;" />
          </div>
        </div>

      </div>
      </div>

      <!-- BOTTOM ACTIONS BAR (NO PRINT) -->
      <div style="max-width: 820px; margin: 20px auto 10px auto; display: flex; justify-content: center; gap: 16px;" class="no-print">
        <button type="button" class="btn btn-success" style="background: #10B981; border: none; font-weight: 700; padding: 12px 28px; font-size: 1rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);" onclick="saveAndPrintCertificate()">
          💾 Save & Print PPD Test Certificate (PDF)
        </button>
      </div>
    `;
    return;
  }

  // DEFAULT MODE: Render Vaccination & Immunity Certificate matching AVH_Staff_Vaccination_Screening_Template.docx
  const mmr1Date = formatDate(vac.mmrDose1 || (vac.MMR ? vac.MMR.d1 : '') || '');
  const mmrBoosterDate = formatDate(vac.mmrDose2 || (vac.MMR ? vac.MMR.d2 || vac.MMR.d5 : '') || '');
  const ipvDate = formatDate(vac.ipvDate || (vac.IPV ? vac.IPV.d5 || vac.IPV.d1 : '') || '');
  const tdapDate = formatDate(vac.tdapDate || (vac.Tdap ? vac.Tdap.d5 || vac.Tdap.d1 : '') || '');
  // Extract Varicella dates and results from Excel Sync & Master Vaccination Reports columns:
  // - "Chicken pox infected or Vaccinated" (vac.chickenpoxStatus / emp['Chicken pox infected or Vaccinated'])
  // - "Varicella Zoster, IgG" (lab.varicellaIgG / vac.varicellaIgG / emp['Varicella Zoster, IgG'])
  // - "Varicella Zoster, IgG date" (lab.varicellaIgGDate / vac.varicellaIgGDate / emp['Varicella Zoster, IgG date'])
  function parseAllDatesFromVal(rawVal) {
    if (!rawVal) return [];
    const str = String(rawVal).trim();
    if (!str) return [];
    const dates = [];
    const single = formatDate(str, true);
    if (single && /\d/.test(single)) {
      dates.push(single);
      return dates;
    }
    const parts = str.split(/[\/\,\;\|]+/).map(p => p.trim()).filter(Boolean);
    for (let p of parts) {
      const d = formatDate(p, true);
      if (d && /\d/.test(d) && !dates.includes(d)) {
        dates.push(d);
      }
    }
    return dates;
  }

  const rawCpStatus = emp ? (vac.chickenpoxStatus || emp.chickenpoxStatus || emp['Chicken pox infected or Vaccinated'] || emp['Chickenpox Infected or Vaccinated'] || '') : '';
  const rawCpDose1 = emp ? (vac.chickenpoxDose1 || vac.varicella1Date || emp.varicella1Date || '') : '';
  const rawCpDose2 = emp ? (vac.chickenpoxDose2 || vac.varicella2Date || emp.varicella2Date || emp['Chickenpox 2nd Dose or IgG Level'] || '') : '';
  const rawVarIgGVal = emp ? (lab.varicellaIgG || lab.varicellaIgGResult || vac.varicellaIgG || emp.varicellaIgG || emp['Varicella Zoster, IgG'] || emp['Varicella Zoster IgG'] || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '') : '';
  const rawVarIgGDateVal = emp ? (lab.varicellaIgGDate || lab.varicellaDate || vac.chickenpoxDate || vac.varicellaIgGDate || emp.varicellaDate || emp.varicellaIgGDate || emp['Varicella Zoster, IgG date'] || emp['Varicella Zoster IgG Date'] || (lab.Varicella_IgG ? lab.Varicella_IgG.date : '') || '') : '';

  let varicella1Date = emp ? formatDate(rawCpDose1, true) : '';
  let varicella2Date = emp ? formatDate(rawCpDose2, true) : '';
  let varicellaIgGDate = emp ? formatDate(rawVarIgGDateVal, true) : '';

  const cpStatusDates = parseAllDatesFromVal(rawCpStatus);
  if (cpStatusDates.length > 0) {
    if (!varicella1Date && cpStatusDates[0]) varicella1Date = cpStatusDates[0];
    if (!varicella2Date && cpStatusDates[1]) varicella2Date = cpStatusDates[1];
  }

  let varicellaIgGResult = '';
  if (emp) {
    if (rawVarIgGVal && !/\d{2}\/\d{2}\/\d{4}/.test(rawVarIgGVal)) {
      varicellaIgGResult = rawVarIgGVal;
    } else if (rawCpStatus && cpStatusDates.length === 0) {
      varicellaIgGResult = rawCpStatus;
    } else if (rawCpDose2 && !varicella2Date) {
      varicellaIgGResult = rawCpDose2;
    }
  }

  const mumpsIgGResult = lab.mumpsIgGTiter || (lab.Mumps_IgG ? lab.Mumps_IgG.result : '') || '';
  const mumpsIgGDate = formatDate(lab.mumpsIgGTiterDate || (lab.Mumps_IgG ? lab.Mumps_IgG.date : '') || emp.mumpsIgGTiterDate || '');

  const measlesIgGResult = lab.measlesIgGTiter || (lab.Measles_IgG ? lab.Measles_IgG.result : '') || '';
  const measlesIgGDate = formatDate(lab.measlesIgGTiterDate || (lab.Measles_IgG ? lab.Measles_IgG.date : '') || emp.measlesIgGTiterDate || '');

  const rubellaIgGResult = lab.rubellaIgGTiter || (lab.Rubella_IgG ? lab.Rubella_IgG.result : '') || '';
  const rubellaIgGDate = formatDate(lab.rubellaIgGTiterDate || (lab.Rubella_IgG ? lab.Rubella_IgG.date : '') || emp.rubellaIgGTiterDate || '');

  const hcvResult = lab.hcvResult || (lab.HCV ? lab.HCV.result : '') || emp.hcvResult || '';
  const hcvDate = formatDate(lab.hcvDate || (lab.HCV ? lab.HCV.date : '') || emp.hcvDate || '');

  const hivResult = lab.hivResult || (lab.HIV ? lab.HIV.result : '') || emp.hivResult || '';
  const hivDate = formatDate(lab.hivDate || (lab.HIV ? lab.HIV.date : '') || emp.hivDate || '');

  const rawHbsab = emp.hepbTiter || lab.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || '';
  const hbsabTiter = rawHbsab ? (rawHbsab.includes('mIU') || rawHbsab.includes('IU') || rawHbsab.includes('IU/L') ? rawHbsab : `${rawHbsab} mIU/mL`) : '';
  const hbsabDate = formatDate(lab.hbsabDate || (lab.HBsAb ? lab.HBsAb.date : '') || emp.hbsabDate || emp.hbvBoosterDate || '');

  const ppd1Date = formatDate(lab.ppdStep1Date || (lab.PPD ? lab.PPD.date : '') || '');
  const ppd1ReadDate = formatDate(lab.ppdStep1ReadDate || '') || (ppd1Date ? (typeof addDaysToDateStr === 'function' ? addDaysToDateStr(ppd1Date, 3) : ppd1Date) : '');
  const ppd1ResultText = lab.ppdStep1Result || lab.ppdResult || (lab.PPD ? lab.PPD.result : '') || '';
  let rawInd1 = toSafeLabString(getFirstDefinedLabValue(lab.ppdStep1Induration, (lab.PPD ? lab.PPD.test1 : ''))).replace(/mm/gi, '').trim();
  const ppd1Ind = rawInd1 !== '' ? (rawInd1 + 'mm') : '';
  const ppd1DoseOrResult = ppd1Ind ? (ppd1ResultText ? `${ppd1Ind}, ${ppd1ResultText}` : `${ppd1Ind} induration`) : ppd1ResultText;

  let ppd1DatesFormatted = '';
  if (ppd1Date && ppd1ReadDate && ppd1ReadDate !== ppd1Date) {
    ppd1DatesFormatted = `${ppd1Date} (Test done) / ${ppd1ReadDate} (Read date)`;
  } else if (ppd1Date) {
    ppd1DatesFormatted = `${ppd1Date} (Test done)`;
  }

  const ppd2Date = formatDate(lab.ppdStep2Date || '');
  const ppd2ReadDate = formatDate(lab.ppdStep2ReadDate || '') || (ppd2Date ? (typeof addDaysToDateStr === 'function' ? addDaysToDateStr(ppd2Date, 3) : ppd2Date) : '');
  const ppd2ResultText = lab.ppdStep2Result || '';
  let rawInd2 = toSafeLabString(getFirstDefinedLabValue(lab.ppdStep2Induration, (lab.PPD ? lab.PPD.test2 : ''))).replace(/mm/gi, '').trim();
  const ppd2Ind = rawInd2 !== '' ? (rawInd2 + 'mm') : '';
  const ppd2DoseOrResult = ppd2Ind ? (ppd2ResultText ? `${ppd2Ind}, ${ppd2ResultText}` : `${ppd2Ind} induration`) : ppd2ResultText;

  let ppd2DatesFormatted = '';
  if (ppd2Date && ppd2ReadDate && ppd2ReadDate !== ppd2Date) {
    ppd2DatesFormatted = `${ppd2Date} (Test done) / ${ppd2ReadDate} (Read date)`;
  } else if (ppd2Date) {
    ppd2DatesFormatted = `${ppd2Date} (Test done)`;
  }

  let salutation = '';
  let possessivePronoun = 'his/her';
  if (emp) {
    const genderStr = String(emp.gender || (emp.demographic ? emp.demographic.gender : '') || '').toLowerCase();
    if (genderStr.includes('female') || genderStr.includes('f')) {
      salutation = 'Ms.';
      possessivePronoun = 'her';
    } else if (genderStr.includes('male') || genderStr.includes('m')) {
      salutation = 'Mr.';
      possessivePronoun = 'his';
    }
  }
  const titleNameStr = salutation ? `${salutation} ${fullName || '--------------------'}`.trim() : String(fullName || '--------------------').trim();

  container.innerHTML = topToolbarHTML + `
    <!-- FORMAL CERTIFICATE DOCUMENT PREVIEW (AVH_Staff_Vaccination_Screening_Template.docx MATCH) -->
    <div id="printPage" class="print-page">
      <div id="certificatePrintArea" class="certificate-print-area formal-cert-wrapper print-a4" style="background: white; width: 100%; max-width: 840px; margin: 0 auto; padding: 30px 40px; border: 1px solid #CBD5E1; box-shadow: none; font-family: 'Times New Roman', Times, serif; font-size: 14pt; color: #000000; box-sizing: border-box;">
      
      <!-- DOCUMENT HEADER -->
      <div style="margin-bottom: 20px;">
        <div style="width: 100%;">
          <img src="assets/branded_header_75.png" alt="Augusta Victoria Hospital Branded Header" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; border: none; box-shadow: none; filter: none;" />
        </div>
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; color: #000000; text-align: right; margin-top: 6px;">
          Date of issue: <span style="text-decoration: underline; padding: 0 4px;">${currentDateStr}</span>
        </div>
      </div>

      <!-- TITLE & SUBJECT -->
      <div style="margin-bottom: 18px;">
        <h2 style="font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; text-decoration: underline; text-underline-offset: 4px; text-align: center; margin: 0 0 12px 0; color: #000000;">To Whom It May Concern</h2>
        <div style="font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; text-align: left; margin-bottom: 16px; color: #000000;">
          Subject: Staff Vaccination and Screening Record
        </div>
      </div>

      <!-- SUBTITLE PARAGRAPH WITH INLINE EMPLOYEE DETAILS -->
      <div style="font-family: 'Times New Roman', Times, serif; font-size: 14pt; line-height: 1.8; margin-bottom: 22px; text-align: left; color: #000000;">
        This is to certify that the vaccination history and occupational health screening results of <span style="font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; white-space: nowrap;">${titleNameStr}</span>, holder of ID No. <span style="font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; text-decoration: underline; text-underline-offset: 3px; white-space: nowrap;">${idNo || '----------'}</span>, have been documented in the records of Augusta Victoria Hospital. The details presented below reflect the information available in ${possessivePronoun} occupational health record as of the date of issue.
      </div>

      <!-- 3-COLUMN VACCINATION & SCREENING TABLE -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px; font-family: 'Times New Roman', Times, serif; font-size: 12pt; border: 1.5px solid #000000;">
        <thead>
          <tr style="background: #FFFFFF; border-bottom: 1.5px solid #000000;">
            <th style="padding: 7px 10px; border-right: 1px solid #000000; text-align: left; width: 44%; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; color: #000000;">Vaccine or screening test</th>
            <th style="padding: 7px 10px; border-right: 1px solid #000000; text-align: center; width: 30%; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; color: #000000;">Date of vaccine / test</th>
            <th style="padding: 7px 10px; text-align: center; width: 26%; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; color: #000000;">Test result</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">MMR vaccine, first dose</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${mmr1Date || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;"></td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">MMR vaccine, second dose or booster</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${mmrBoosterDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;"></td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">IPV vaccine, booster</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${ipvDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;"></td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Tdap vaccine, booster</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${tdapDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;"></td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Varicella vaccine, first dose</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${varicella1Date || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;"></td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Varicella vaccine, second dose</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${varicella2Date || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;"></td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Varicella IgG test</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${varicellaIgGDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${varicellaIgGResult || ''}</td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Mumps IgG test</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${mumpsIgGDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${mumpsIgGResult || ''}</td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Measles IgG test</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${measlesIgGDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${measlesIgGResult || ''}</td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Rubella IgG test</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${rubellaIgGDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${rubellaIgGResult || ''}</td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">HCV test</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${hcvDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${hcvResult || ''}</td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">HIV test</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${hivDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${hivResult || ''}</td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">Hepatitis B surface antibody (anti-HBs), mIU/mL</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${hbsabDate || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${hbsabTiter || ''}</td>
          </tr>
          <tr style="border-bottom: 1px solid #000000;">
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">PPD test, first step (placement and reading)</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${ppd1DatesFormatted || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${ppd1DoseOrResult || ''}</td>
          </tr>
          <tr>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; font-family: 'Times New Roman', Times, serif; font-size: 12pt;">PPD test, second step (placement and reading)</td>
            <td style="padding: 6px 10px; border-right: 1px solid #000000; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${ppd2DatesFormatted || ''}</td>
            <td style="padding: 6px 10px; text-align: center; font-weight: bold; font-family: 'Times New Roman', Times, serif; font-size: 12pt; text-decoration: underline;">${ppd2DoseOrResult || ''}</td>
          </tr>
        </tbody>
      </table>

      <!-- CLOSING REMARK -->
      <div style="text-align: center; font-family: 'Times New Roman', Times, serif; font-size: 14pt; margin-top: 18px; margin-bottom: 22px; color: #000000;">
        This certificate is issued upon request.
      </div>

      <!-- SIGNATURE BLOCK -->
      <div style="display: flex; justify-content: space-between; align-items: flex-start; font-family: 'Times New Roman', Times, serif; font-size: 14pt; padding: 0 10px; margin-bottom: 18px; color: #000000;">
        <div style="text-align: center; width: 45%;">
          <div style="font-weight: bold; font-size: 14pt;">Infectious Disease Unit</div>
          <div style="margin-top: 6px; font-weight: bold; font-size: 14pt;">Date: <span style="text-decoration: underline;">${currentDateStr}</span></div>
        </div>
        <div style="text-align: center; width: 50%;">
          <div style="font-weight: bold; font-size: 14pt;">Dr. Ali Sabateen</div>
          <div style="font-size: 14pt; margin-top: 2px;">Infectious Disease Specialist</div>
          <div style="font-size: 14pt; font-weight: bold;">Head of Infectious Disease Unit</div>
          <div style="margin-top: 6px; font-weight: bold;">__________________</div>
        </div>
      </div>

      <!-- OFFICIAL FORMAL FOOTER BAR -->
      <div style="margin-top: 14px; width: 100%;">
        <img src="assets/branded_footer_75.png" alt="Augusta Victoria Hospital Branded Footer" style="width: 100%; height: auto; display: block; object-fit: contain; image-rendering: -webkit-optimize-contrast; box-shadow: none; filter: none; -webkit-filter: none; border: none;" />
      </div>

    </div>
    </div>

    <!-- BOTTOM ACTIONS BAR (NO PRINT) -->
    <div style="max-width: 840px; margin: 20px auto 10px auto; display: flex; justify-content: center; gap: 16px;" class="no-print">
      <button type="button" class="btn btn-success" style="background: #10B981; border: none; font-weight: 700; padding: 12px 28px; font-size: 1rem; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);" onclick="saveAndPrintCertificate()">
        💾 Save & Print Official Certificate (PDF)
      </button>
    </div>
  `;
}

async function waitForCertificateImages(certificate) {
  if (!certificate) return;
  const images = Array.from(certificate.querySelectorAll('img'));
  await Promise.all(
    images.map(img => {
      if (img.complete) return Promise.resolve();
      return new Promise(resolve => {
        img.onload = resolve;
        img.onerror = resolve;
      });
    })
  );
}

function fitCertificateToPrintPage() {
  const page = document.getElementById('printPage');
  const certificate = document.getElementById('certificatePrintArea');
  if (!page || !certificate) return;

  // Reset transform to accurately measure natural unscaled content dimensions
  certificate.style.transform = 'none';
  certificate.style.webkitTransform = 'none';

  // Force reflow to get fresh unscaled height
  const contentWidth = certificate.offsetWidth || certificate.getBoundingClientRect().width;
  const contentHeight = certificate.offsetHeight || certificate.getBoundingClientRect().height;

  if (contentWidth <= 0 || contentHeight <= 0) return;

  // A4 Printable Target Box: 194mm width x 276mm height (at 96 DPI: 1mm = 3.779527559px)
  // Letter Printable Target Box: 185mm width x 250mm height
  const isLetter = certificate.classList.contains('print-letter');
  const targetWidthPx = isLetter ? (185 * 3.779527559) : (194 * 3.779527559); // ~699px vs ~733px
  const targetHeightPx = isLetter ? (250 * 3.779527559) : (276 * 3.779527559); // ~945px vs ~1043px

  const widthScale = targetWidthPx / contentWidth;
  const heightScale = targetHeightPx / contentHeight;

  // Scale down so content fits BOTH width and height completely on 1 page
  let scale = Math.min(widthScale, heightScale);

  // Clamp scale: allow down to 0.45 for large content to guarantee 1-page fit, max 1.25
  scale = Math.max(0.45, Math.min(scale, 1.25));

  certificate.style.transform = `scale(${scale})`;
  certificate.style.webkitTransform = `scale(${scale})`;
  certificate.style.transformOrigin = 'top center';

  console.log('PRINT SCALE APPLIED:', {
    isLetter,
    targetWidthPx,
    targetHeightPx,
    contentWidth,
    contentHeight,
    widthScale,
    heightScale,
    finalScale: scale
  });
}

async function printCertificate() {
  const certificate = document.getElementById('certificatePrintArea');
  if (certificate) {
    await waitForCertificateImages(certificate);
  }
  const selectEl = document.getElementById('cert_paper_size_select');
  const paperSize = selectEl ? selectEl.value : 'a4';

  if (window.AVHPrintController) {
    await window.AVHPrintController.printContainer('certificatePrintArea', {
      mode: paperSize,
      printClass: 'printing-cert-document',
      onBeforePrint: () => {
        fitCertificateToPrintPage();
      },
      onAfterPrint: () => {
        if (certificate) certificate.style.transform = '';
      }
    });
  } else {
    document.body.classList.add('printing-cert-document', `print-mode-${paperSize}`);
    fitCertificateToPrintPage();

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        window.print();
        setTimeout(() => {
          document.body.classList.remove('printing-cert-document', `print-mode-${paperSize}`);
          if (certificate) certificate.style.transform = '';
        }, 1000);
      });
    });
  }
}

async function saveAndPrintCertificate() {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  let emp = null;
  if (typeof activeEmpPersonNo !== 'undefined' && activeEmpPersonNo) {
    emp = employees.find(e => String(e.empNo || e.personNumber || e.id || e.idNo) === String(activeEmpPersonNo));
  }
  if (!emp || !activeEmpPersonNo) {
    const isAr = (window.i18n && typeof window.i18n.isRTL === 'function') ? window.i18n.isRTL() : false;
    alert(isAr ? 'âڑ ï¸ڈ ظٹط±ط¬ظ‰ ط§ظ„ط¨ط­ط« ظˆط§ط®طھظٹط§ط± ظ…ظˆط¸ظپ ط£ظˆظ„ط§ظ‹ ظ‚ط¨ظ„ ط§ظ„ط·ط¨ط§ط¹ط©.' : 'âڑ ï¸ڈ Please search or select a staff member first before printing.');
    return;
  }

  if (emp && typeof CertificateDataService !== 'undefined' && typeof CertificateDataService.saveIssuance === 'function') {
    const certType = typeof activeCertDocumentType !== 'undefined' ? activeCertDocumentType : 'vaccination';
    const demo = emp.demographic || {};
    const certPayload = {
      employeeId: emp.empNo || emp.id || demo.personNumber || emp.idNo,
      employeeName: emp.name || demo.fullName || '',
      certificateType: certType,
      issuedDate: new Date().toISOString(),
      issuedBy: window.authManager && window.authManager.currentUser ? window.authManager.currentUser.username : 'system'
    };
    try {
      const res = await CertificateDataService.saveIssuance(certPayload);
      if (res && res.certificateNumber) {
        if (typeof showSuccessToast === 'function') {
          showSuccessToast(`Certificate recorded in central database (${res.certificateNumber})`, 'Certificate Recorded 📜');
        }
      }
    } catch (err) {
      console.warn("Certificate database recording notice:", err);
    }
  }

  await printCertificate();
}

function setCertPaperSize(size) {
  const cert = document.getElementById('certificatePrintArea');
  if (!cert) return;
  if (size === 'letter') {
    cert.classList.remove('print-a4');
    cert.classList.add('print-letter');
  } else {
    cert.classList.remove('print-letter');
    cert.classList.add('print-a4');
  }
  fitCertificateToPrintPage();
}

function generateCertForEmp(empNoOrIdx) {
  const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || (typeof INITIAL_EMPLOYEES !== 'undefined' ? INITIAL_EMPLOYEES : [])));
  if (typeof empNoOrIdx === 'string' || typeof empNoOrIdx === 'number') {
    const idx = employees.findIndex(e => String(e.empNo || e.personNumber || e.id) === String(empNoOrIdx) || String(e.idNo || e.nationalId) === String(empNoOrIdx));
    if (idx !== -1) {
      activeEmpIndex = idx;
      activeEmpPersonNo = String(employees[idx].empNo || employees[idx].personNumber || employees[idx].id || '');
    } else if (typeof empNoOrIdx === 'number' && employees[empNoOrIdx]) {
      activeEmpIndex = empNoOrIdx;
      activeEmpPersonNo = String(employees[empNoOrIdx].empNo || employees[empNoOrIdx].personNumber || employees[empNoOrIdx].id || '');
    }
  }
  activeCertDocumentType = 'vaccination';
  if (typeof switchNav === 'function') {
    switchNav('vaccination-certificate');
  } else {
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea && typeof renderVaccinationCertificate === 'function') {
      renderVaccinationCertificate(mainArea);
    }
  }
}

if (typeof window !== 'undefined') {
  window.addEventListener('beforeprint', function () {
    fitCertificateToPrintPage();
  });

  window.addEventListener('afterprint', function () {
    const certificate = document.getElementById('certificatePrintArea');
    if (certificate) {
      certificate.style.transform = '';
    }
  });

  const refreshCertOnUpdate = function() {
    if (typeof window.invalidateEmployeesCache === 'function') window.invalidateEmployeesCache();
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea && typeof activeNavTab !== 'undefined' && (activeNavTab === 'vaccination-certificate' || activeNavTab === 'certificates') && typeof renderVaccinationCertificate === 'function') {
      renderVaccinationCertificate(mainArea);
    }
  };
  window.addEventListener('avh_data_updated', refreshCertOnUpdate);
  window.addEventListener('staffDataUpdated', refreshCertOnUpdate);
}

function generatePpdCertForEmp(empNoOrIdx) {
  const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || (typeof INITIAL_EMPLOYEES !== 'undefined' ? INITIAL_EMPLOYEES : [])));
  if (typeof empNoOrIdx === 'string' || typeof empNoOrIdx === 'number') {
    const idx = employees.findIndex(e => String(e.empNo || e.personNumber || e.id) === String(empNoOrIdx) || String(e.idNo || e.nationalId) === String(empNoOrIdx));
    if (idx !== -1) {
      activeEmpIndex = idx;
      activeEmpPersonNo = String(employees[idx].empNo || employees[idx].personNumber || employees[idx].id || '');
    } else if (typeof empNoOrIdx === 'number' && employees[empNoOrIdx]) {
      activeEmpIndex = empNoOrIdx;
      activeEmpPersonNo = String(employees[empNoOrIdx].empNo || employees[empNoOrIdx].personNumber || employees[empNoOrIdx].id || '');
    }
  }
  activeCertDocumentType = 'ppd';
  if (typeof switchNav === 'function') {
    switchNav('vaccination-certificate');
  } else {
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea && typeof renderVaccinationCertificate === 'function') {
      renderVaccinationCertificate(mainArea);
    }
  }
}

window.generatePpdCertForEmp = generatePpdCertForEmp;
window.fitCertificateToPrintPage = fitCertificateToPrintPage;
window.printCertificate = printCertificate;
window.setCertPaperSize = setCertPaperSize;
window.generateCertForEmp = generateCertForEmp;
window.saveAndPrintCertificate = saveAndPrintCertificate;
window.renderVaccinationCertificate = renderVaccinationCertificate;
