/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - SYSTEM MANAGEMENT & USER AUTHORIZATIONS CONTROLLER
   Admin Privileges: Create User, Reset Password, Delete User, Assign Roles & Permissions
   ========================================================================== */

function renderSystemManagementReport(container) {
  const demoUsernames = ['admin', 'employee', 'occ_health', 'auditor'];
  let deletedUsernames = [];
  try {
    deletedUsernames = JSON.parse(localStorage.getItem('avh_deleted_users') || '[]');
    if (!Array.isArray(deletedUsernames)) deletedUsernames = [];
  } catch (e) {}
  const users = (window.authManager && window.authManager.users ? window.authManager.users : []).filter(u => u && u.username && !demoUsernames.includes(u.username.toLowerCase()) && !deletedUsernames.includes(u.username.toLowerCase()));
  const auditLogs = JSON.parse(localStorage.getItem('avh_logs')) || (typeof INITIAL_AUDIT_LOGS !== 'undefined' ? INITIAL_AUDIT_LOGS : []);
  const t = key => window.i18n.t(key);
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const activeSubTab = window.currentSysMgmtSubTab || 'users';

  // Sub-Navigation Tabs Header
  const navHeaderHtml = `
    <div style="display: flex; gap: 8px; margin-bottom: 20px; border-bottom: 2px solid var(--border-color); padding-bottom: 12px; flex-wrap: wrap;">
      <button class="btn ${activeSubTab === 'users' ? 'btn-primary' : 'btn-outline'}" 
              style="display: flex; align-items: center; gap: 8px; font-weight: 700; padding: 10px 18px;" 
              onclick="switchSystemMgmtSubTab('users')">
        <span>👥</span>
        <span>${isAr ? 'صلاحيات المستخدمين وكلمات المرور' : 'User Accounts, Authorities & Passwords'}</span>
      </button>
      <button class="btn ${activeSubTab === 'database' ? 'btn-primary' : 'btn-outline'}" 
              style="display: flex; align-items: center; gap: 8px; font-weight: 700; padding: 10px 18px;" 
              onclick="switchSystemMgmtSubTab('database')">
        <span>🗄️</span>
        <span>${isAr ? 'قاعدة البيانات المركزية وسلة المهملات' : 'Central Database, Backup & Trash Bin'}</span>
      </button>
      <button class="btn ${activeSubTab === 'sync' ? 'btn-primary' : 'btn-outline'}" 
              style="display: flex; align-items: center; gap: 8px; font-weight: 700; padding: 10px 18px;" 
              onclick="switchSystemMgmtSubTab('sync')">
        <span>☁️</span>
        <span>${isAr ? 'التزامن السحابي (Google Sheets & GitHub)' : 'Cloud & Repository Sync'}</span>
      </button>
    </div>
  `;

  // CHOICE 2: CENTRAL DATABASE, TRASH & AUDIT MANAGEMENT
  if (activeSubTab === 'database') {
    container.innerHTML = navHeaderHtml + '<div id="database_panel_mount"></div>';
    const mount = document.getElementById('database_panel_mount');
    if (typeof renderDatabaseManagementPanel === 'function') {
      renderDatabaseManagementPanel(mount || container);
    }
    return;
  }

  // CHOICE 3: CLOUD & REPOSITORY SYNCHRONIZATION
  if (activeSubTab === 'sync') {
    container.innerHTML = navHeaderHtml + `
      <!-- GOOGLE SHEETS LIVE SYNC INTEGRATION CARD -->
      <div class="card" style="border: 2px solid var(--accent-teal); background: #F0FDF4; margin-bottom: 20px;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
          <span>📊 Google Sheets Real-Time Cloud Sync Integration</span>
          <span class="role-pill" style="background: ${window.googleSheetsSync && window.googleSheetsSync.isConnected() ? '#DCFCE7; color: #166534;' : '#FEF3C7; color: #92400E;'}">
            ${window.googleSheetsSync && window.googleSheetsSync.isConnected() ? '🟢 Google Sheets Connected' : '🟡 Offline / Saved Locally'}
          </span>
        </div>

        <p style="color: var(--text-main); font-size: 0.9rem; margin-bottom: 16px;">
          Connect your web application to any Google Sheet in real-time. Every saved staff vaccination form, injury report, and employee entry will be automatically pushed as rows into your Google Sheet tabs.
        </p>

        <div class="form-row" style="display: flex; gap: 12px; align-items: center; margin-bottom: 16px; flex-wrap: wrap;">
          <div style="flex: 1; min-width: 280px;">
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">Google Apps Script Web App URL:</label>
            <input type="text" id="gs_url_input" placeholder="https://script.google.com/macros/s/.../exec" value="${window.googleSheetsSync ? window.googleSheetsSync.getUrl() : ''}" style="width: 100%; padding: 8px 12px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.85rem;">
          </div>
          <div style="display: flex; gap: 8px; align-self: flex-end; flex-wrap: wrap;">
            <button class="btn btn-primary" onclick="saveGoogleSheetsUrlSetting()">💾 Save URL</button>
            <button class="btn btn-success" onclick="triggerFullGoogleSheetsSync()">🔄 Sync All Data Now</button>
            <button class="btn btn-outline" style="border-color: #0284C7; color: #0369A1; font-weight: bold;" onclick="if(typeof downloadStaffDatabaseBackup === 'function') downloadStaffDatabaseBackup();">💾 Backup Staff DB (JSON)</button>
            <button class="btn btn-outline" style="border-color: #D97706; color: #B45309;" onclick="resetToOriginalMasterList()">🧹 Reset to Master 511 Staff</button>
            <button class="btn btn-outline" onclick="toggleAppsScriptInstructions()">📋 Setup Instructions</button>
          </div>
        </div>

        <div id="gs_sync_status_msg" style="font-size: 0.85rem; font-weight: bold; color: var(--primary-blue); margin-bottom: 10px;">
          Last Synced to Cloud: <code>${window.googleSheetsSync ? window.googleSheetsSync.getLastSync() : 'Never'}</code>
        </div>

        <div id="gs_instructions_box" style="display: none; background: #ffffff; border: 1px dashed var(--accent-teal); padding: 16px; border-radius: 8px; margin-top: 12px;">
          <h4 style="color: var(--primary-blue); margin-bottom: 8px;">How to Link Google Sheets in 3 Easy Steps:</h4>
          <ol style="margin-left: 20px; font-size: 0.88rem; line-height: 1.6;">
            <li>Open your <strong>Google Sheet</strong> -> Click <strong>Extensions</strong> -> <strong>Apps Script</strong>.</li>
            <li>Paste the Google Apps Script code below into <code>Code.gs</code>.</li>
            <li>Click <strong>Deploy</strong> -> <strong>New Deployment</strong> -> Choose <strong>Web App</strong> -> Set <i>Execute as: Me</i> & <i>Who has access: Anyone</i> -> Copy Web App URL and paste above!</li>
          </ol>
          <div style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
            <strong>Google Apps Script (Code.gs):</strong>
            <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem;" onclick="copyAppsScriptCode()">📋 Copy Code</button>
          </div>
          <textarea id="gs_code_area" readonly style="width: 100%; height: 160px; font-family: monospace; font-size: 0.78rem; background: #F8FAFC; border: 1px solid var(--border-color); border-radius: 4px; padding: 8px; margin-top: 6px;">${window.googleSheetsSync ? window.googleSheetsSync.getAppsScriptCode() : ''}</textarea>
        </div>
      </div>

      <!-- GITHUB REPOSITORY AUTOMATED LIVE SYNC CARD -->
      <div class="card" style="border: 2px solid #2563EB; background: #EFF6FF;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px;">
          <span>🐙 GitHub Repository Automated Live Sync</span>
          <span class="role-pill" style="background: ${window.githubSync && window.githubSync.isConnected() ? '#DBEAFE; color: #1E40AF;' : '#FEF3C7; color: #92400E;'}">
            ${window.githubSync && window.githubSync.isConnected() ? '🟢 GitHub Auto-Sync Connected' : '🟡 Offline / Saved Locally'}
          </span>
        </div>

        <p style="color: var(--text-main); font-size: 0.9rem; margin-bottom: 16px;">
          Connect your web application directly to GitHub REST API. Any change made will automatically commit updated dataset files directly to your GitHub repository.
        </p>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; margin-bottom: 16px;">
          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">GitHub Personal Access Token (PAT):</label>
            <input type="password" id="gh_token_input" placeholder="ghp_xxxxxxxxxxxxxxxxxxxx" value="${window.githubSync ? window.githubSync.getToken() : ''}" style="width: 100%; padding: 8px 12px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.85rem;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">GitHub Account / Owner:</label>
            <input type="text" id="gh_owner_input" placeholder="hammamrjoup" value="${window.githubSync ? window.githubSync.getOwner() : 'hammamrjoup'}" style="width: 100%; padding: 8px 12px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.85rem;">
          </div>
          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">GitHub Repository Name:</label>
            <input type="text" id="gh_repo_input" placeholder="AVH-occupational-health-dashboard" value="${window.githubSync ? window.githubSync.getRepo() : 'AVH-occupational-health-dashboard'}" style="width: 100%; padding: 8px 12px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.85rem;">
          </div>
        </div>

        <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center; justify-content: space-between;">
          <div id="gh_sync_status_msg" style="font-size: 0.85rem; font-weight: bold; color: #1E40AF;">
            Last Synced to GitHub: <code>${window.githubSync ? window.githubSync.getLastSync() : 'Never'}</code>
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button class="btn btn-primary" style="background: #2563EB;" onclick="saveGitHubSyncSettings()">💾 Save GitHub Settings</button>
            <button class="btn btn-success" style="background: #059669;" onclick="triggerFullGitHubSync()">🐙 Commit & Sync to GitHub Now</button>
          </div>
        </div>
      </div>
    `;
    return;
  }

  // CHOICE 1: USER AUTHORIZATIONS, PASSWORDS & ROLES MATRIX (DEFAULT VIEW)
  container.innerHTML = navHeaderHtml + `
    <!-- 1. CREATE NEW USER ACCOUNT CARD -->
    <div class="card" style="border-top: 4px solid var(--primary-blue); margin-bottom: 24px;">
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 1.25rem;">👤</span>
          <div>
            <span style="font-size: 1.05rem; font-weight: 800; color: var(--primary-blue);">
              ${isAr ? 'إضافة حساب مستخدم جديد وتحديد الصلاحيات' : 'Create New User Account & Set Authorities'}
            </span>
            <div style="font-size: 0.78rem; color: var(--text-muted); margin-top: 2px;">
              ${isAr ? 'تسجيل مستخدم جديد، تحديد كلمة المرور، وتفويض الصلاحيات عبر النظام' : 'Register a new user, assign a password, and delegate module authorities'}
            </div>
          </div>
        </div>
        <span class="role-pill role-admin">👑 Admin Privileges</span>
      </div>

      <form onsubmit="handleCreateNewUser(event)" style="margin-top: 18px;">
        <!-- INPUT FIELDS GRID -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 16px;">
          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">
              ${isAr ? 'اسم الموظف / المستخدم:' : 'Full Name:'} <span style="color: #DC2626;">*</span>
            </label>
            <input type="text" id="nu_name" required placeholder="${isAr ? 'مثال: د. رامي صالح' : 'e.g. Dr. Rami Saleh'}" style="width: 100%; padding: 9px 12px; border: 1.5px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.88rem;">
          </div>

          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">
              ${isAr ? 'اسم المستخدم (لتسجيل الدخول):' : 'Username (Login):'} <span style="color: #DC2626;">*</span>
            </label>
            <input type="text" id="nu_username" required placeholder="${isAr ? 'مثال: rami_s' : 'e.g. rami_s'}" style="width: 100%; padding: 9px 12px; border: 1.5px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.88rem;">
          </div>

          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">
              ${isAr ? 'كلمة المرور الأولية:' : 'Initial Password:'} <span style="color: #DC2626;">*</span>
            </label>
            <div style="position: relative;">
              <input type="text" id="nu_password" required value="123456" placeholder="••••••••" style="width: 100%; padding: 9px 12px; border: 1.5px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.88rem; font-family: monospace; font-weight: bold; color: #1E293B;">
            </div>
          </div>

          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">
              ${isAr ? 'القسم / الدائرة:' : 'Department:'} <span style="color: #DC2626;">*</span>
            </label>
            <input type="text" id="nu_department" required placeholder="${isAr ? 'مثال: Occupational Health' : 'e.g. Occupational Health'}" value="Occupational Health" style="width: 100%; padding: 9px 12px; border: 1.5px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.88rem;">
          </div>

          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">
              ${isAr ? 'المسمى الوظيفي:' : 'Job Title:'} <span style="color: #DC2626;">*</span>
            </label>
            <input type="text" id="nu_jobTitle" required placeholder="${isAr ? 'مثال: Occupational Health Officer' : 'e.g. Occupational Health Officer'}" value="Health Officer" style="width: 100%; padding: 9px 12px; border: 1.5px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.88rem;">
          </div>

          <div>
            <label style="font-weight: bold; font-size: 0.85rem; display: block; margin-bottom: 4px;">
              ${isAr ? 'الصلاحية الرئيسية (الدور):' : 'System Role:'} <span style="color: #DC2626;">*</span>
            </label>
            <select id="nu_role" style="width: 100%; padding: 9px 12px; border: 1.5px solid var(--border-color); border-radius: var(--radius-sm); font-size: 0.88rem; font-weight: bold; background: white;" onchange="handleNewUserRoleChange(this.value)">
              <option value="specialist" selected>👩‍⚕️ Specialist / أخصائي صحة مهنية</option>
              <option value="employee">👤 Staff / كادر تمريضي / موظف</option>
              <option value="auditor">📋 Auditor / مدقق جودة</option>
              <option value="admin">👑 Admin / مدير النظام</option>
            </select>
          </div>
        </div>

        <!-- AUTHORITY DELEGATION CHECKBOXES ROW -->
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 14px 16px; margin-top: 18px;">
          <div style="font-weight: 800; font-size: 0.88rem; color: #1E293B; margin-bottom: 10px; display: flex; align-items: center; gap: 6px;">
            <span>🛡️</span>
            <span>${isAr ? 'تخصيص الصلاحيات الممنوحة للمستخدم الجديد:' : 'Module Authorities & Privileges for New User:'}</span>
          </div>

          <div style="display: flex; gap: 20px; flex-wrap: wrap; align-items: center;">
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.86rem; font-weight: 600; color: #0284C7;">
              <input type="checkbox" id="nu_auth_vac" checked style="width: 18px; height: 18px; cursor: pointer;">
              <span>💉 ${isAr ? 'نماذج التطعيمات والسجلات المركزية' : 'Vaccination Forms & Clinical Intake'}</span>
            </label>

            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.86rem; font-weight: 600; color: #DC2626;">
              <input type="checkbox" id="nu_auth_inj" checked style="width: 18px; height: 18px; cursor: pointer;">
              <span>⚠️ ${isAr ? 'تقرير إصابات العمل (SQE 02.01)' : 'Injury Reports (SQE 02.01)'}</span>
            </label>

            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.86rem; font-weight: 600; color: #D97706;">
              <input type="checkbox" id="nu_auth_crt" checked style="width: 18px; height: 18px; cursor: pointer;">
              <span>📜 ${isAr ? 'الشهادات الرسمية' : 'Official Certificates'}</span>
            </label>

            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.86rem; font-weight: 600; color: #059669;">
              <input type="checkbox" id="nu_auth_rpt" checked style="width: 18px; height: 18px; cursor: pointer;">
              <span>📈 ${isAr ? 'تقارير وإحصائيات التطعيم' : 'Reports & Analytics'}</span>
            </label>

            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 0.86rem; font-weight: 600; color: #6D28D9;">
              <input type="checkbox" id="nu_auth_sys" style="width: 18px; height: 18px; cursor: pointer;">
              <span>⚙️ ${isAr ? 'إدارة النظام وصلاحيات المستخدمين' : 'System Administration'}</span>
            </label>
          </div>
        </div>

        <div style="margin-top: 18px; display: flex; justify-content: flex-end;">
          <button type="submit" class="btn btn-success" style="padding: 10px 22px; font-weight: 800; font-size: 0.92rem; display: flex; align-items: center; gap: 8px; background: #059669; border: none; cursor: pointer; border-radius: 6px; color: white;">
            <span>➕</span>
            <span>${isAr ? 'إنشاء حساب المستخدم وتثبيت الصلاحيات' : 'Create User Account & Grant Authority'}</span>
          </button>
        </div>
      </form>
    </div>

    <!-- 2. USER ACCOUNTS & PERMISSIONS MATRIX TABLE -->
    <div class="card" style="margin-bottom: 24px;">
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 1.25rem;">🛡️</span>
          <div>
            <span style="font-size: 1.05rem; font-weight: 800; color: var(--primary-blue);">
              ${isAr ? 'جدول حسابات المستخدمين وتفويض الصلاحيات' : 'User Accounts, Roles & Authority Matrix'}
            </span>
            <div style="font-size: 0.78rem; color: var(--text-muted); margin-top: 2px;">
              ${isAr ? 'إدارة الأدوار، تعيين وتغيير كلمات المرور، ومنح أو سحب الصلاحيات للمستخدمين' : 'Manage roles, set/reset passwords, and grant or revoke authorizations for each user'}
            </div>
          </div>
        </div>
        <span class="role-pill" style="background: #E0E7FF; color: #3730A3; font-weight: 700;">
          👥 ${users.length} ${isAr ? 'مستخدمين مسجلين' : 'Registered Users'}
        </span>
      </div>

      <p style="color: var(--text-muted); font-size: 0.88rem; margin: 12px 0 16px 0;">
        ${isAr 
          ? 'بصفتك مدير النظام، يمكنك تعديل الصلاحيات بالنقر على مربعات الاختيار ثم الضغط على <strong>💾 حفظ الصلاحيات</strong>، أو تغيير كلمة المرور عبر <strong>🔑 تغيير كلمة المرور</strong>.' 
          : 'As an Administrator, you can assign roles, reset passwords, delete users, and grant or revoke module authorizations. Check or uncheck permissions and click <strong>💾 Save Authority</strong>.'}
      </p>

      <div class="clinical-table-wrapper" style="overflow-x: auto;">
        <table class="clinical-table" style="width: 100%;">
          <thead>
            <tr>
              <th style="min-width: 150px; text-align: ${isAr ? 'right' : 'left'};">${isAr ? 'بيانات المستخدم' : 'User Details'}</th>
              <th style="min-width: 130px; text-align: center;">${isAr ? 'الدور / الصلاحية' : 'Role'}</th>
              <th style="min-width: 140px; text-align: ${isAr ? 'right' : 'left'};">${isAr ? 'القسم والمسمى' : 'Department & Title'}</th>
              <th style="text-align: center; background: #F0F9FF; color: #0284C7; min-width: 95px;" title="Vaccination Forms & Clinical Intake">
                💉<br><span style="font-size: 0.76rem;">${isAr ? 'نماذج التطعيم' : 'Vac Forms'}</span>
              </th>
              <th style="text-align: center; background: #FEF2F2; color: #DC2626; min-width: 95px;" title="Work Injury Reports (SQE 02.01)">
                ⚠️<br><span style="font-size: 0.76rem;">${isAr ? 'إصابات العمل' : 'Injury Rpt'}</span>
              </th>
              <th style="text-align: center; background: #FFFBEB; color: #D97706; min-width: 95px;" title="Official Certificates Generator">
                📜<br><span style="font-size: 0.76rem;">${isAr ? 'الشهادات الرسمية' : 'Certificate'}</span>
              </th>
              <th style="text-align: center; background: #F0FDF4; color: #15803D; min-width: 95px;" title="Vaccination Reports & Analytics">
                📈<br><span style="font-size: 0.76rem;">${isAr ? 'التقارير والإحصاء' : 'Vac Reports'}</span>
              </th>
              <th style="text-align: center; background: #F5F3FF; color: #6D28D9; min-width: 95px;" title="System Administration & Permissions">
                ⚙️<br><span style="font-size: 0.76rem;">${isAr ? 'إدارة النظام' : 'System Admin'}</span>
              </th>
              <th style="text-align: center; min-width: 220px;">${isAr ? 'العمليات وكلمة المرور' : 'Account & Password Actions'}</th>
            </tr>
          </thead>
          <tbody>
            ${users.map(u => {
              const a = u.authorizations || {};
              const isCurrentAdmin = window.authManager.currentUser && (window.authManager.currentUser.id === u.id || window.authManager.currentUser.username === u.username);
              const isHammam = u.username && u.username.toLowerCase() === 'hammam';
              return `
                <tr tabindex="0" style="background: ${isCurrentAdmin ? '#F8FAFC' : 'transparent'}; outline: none;" onkeydown="if((event.key === 'Delete' || event.keyCode === 46) && !${isCurrentAdmin} && !${isHammam}) { event.preventDefault(); handleDeleteUserAccount('${u.id || u.username}'); }">
                  <td>
                    <div style="display: flex; align-items: center; gap: 8px;">
                      <div style="width: 32px; height: 32px; border-radius: 50%; background: #E0E7FF; color: #3730A3; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem;">
                        ${(u.name || u.username).slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <strong style="color: var(--text-main); font-size: 0.9rem;">${u.name || u.username}</strong>
                        <div style="font-size: 0.78rem; color: var(--text-muted); font-family: monospace;">@${u.username}</div>
                      </div>
                    </div>
                  </td>

                  <td style="text-align: center;">
                    <select id="role_sel_${u.id}" class="role-switcher-select" style="font-weight: 700; font-size: 0.82rem; padding: 6px 8px; border-radius: 6px; border: 1.5px solid #CBD5E1; background: white;" onchange="handleRoleSelectChange('${u.id}', this.value)">
                      <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>👑 Admin / مدير</option>
                      <option value="specialist" ${u.role === 'specialist' || u.role === 'occ_health' ? 'selected' : ''}>👩‍⚕️ Specialist / أخصائي</option>
                      <option value="employee" ${u.role === 'employee' ? 'selected' : ''}>👤 Staff / موظف</option>
                      <option value="auditor" ${u.role === 'auditor' ? 'selected' : ''}>📋 Auditor / مدقق</option>
                    </select>
                  </td>

                  <td>
                    <div style="font-size: 0.86rem; font-weight: 600; color: #334155;">${u.department || 'Occupational Health'}</div>
                    <small style="color: var(--text-muted); font-size: 0.78rem;">${u.jobTitle || 'Health Staff'}</small>
                  </td>

                  <td style="text-align: center; background: #F0F9FF;">
                    <input type="checkbox" id="auth_${u.id}_vac" ${a.vaccinationForms !== false ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
                  </td>

                  <td style="text-align: center; background: #FEF2F2;">
                    <input type="checkbox" id="auth_${u.id}_inj" ${a.injuryReport !== false && u.role !== 'auditor' ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
                  </td>

                  <td style="text-align: center; background: #FFFBEB;">
                    <input type="checkbox" id="auth_${u.id}_crt" ${a.certificateGenerator !== false && u.role !== 'auditor' ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
                  </td>

                  <td style="text-align: center; background: #F0FDF4;">
                    <input type="checkbox" id="auth_${u.id}_rpt" ${a.vaccinationReports !== false ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
                  </td>

                  <td style="text-align: center; background: #F5F3FF;">
                    <input type="checkbox" id="auth_${u.id}_sys" ${a.systemManagement || u.role === 'admin' ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
                  </td>

                  <td style="text-align: center;">
                    <div style="display: flex; gap: 6px; justify-content: center; flex-wrap: wrap;">
                      <button type="button" class="btn btn-outline" style="padding: 5px 10px; font-size: 0.78rem; font-weight: 700; border-color: #0284C7; color: #0369A1;" onclick="handleSaveUserSettings('${u.id}')" title="${isAr ? 'حفظ الصلاحيات' : 'Save Authorities'}">
                        💾 ${isAr ? 'حفظ الصلاحيات' : 'Save'}
                      </button>
                      <button type="button" class="btn btn-outline" style="padding: 5px 10px; font-size: 0.78rem; font-weight: 700; border-color: #D97706; color: #B45309;" onclick="handleResetUserPassword('${u.id}')" title="${isAr ? 'تغيير كلمة المرور' : 'Set Password'}">
                        🔑 ${isAr ? 'كلمة المرور' : 'Password'}
                      </button>
                      ${!isCurrentAdmin && !isHammam ? `
                        <button type="button" class="btn btn-danger" style="padding: 5px 12px; font-size: 0.78rem; font-weight: 700; display: inline-flex; align-items: center; gap: 4px; border-radius: 6px; box-shadow: 0 1px 3px rgba(220,38,38,0.25);" onclick="handleDeleteUserAccount('${u.id || u.username}')" title="${isAr ? 'حذف الحساب نهائياً' : 'Delete Account Permanently'}">
                          🗑️ <span>${isAr ? 'حذف' : 'Delete'}</span>
                        </button>
                      ` : ''}
                    </div>
                  </td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- 3. SYSTEM MAINTENANCE, STORAGE OPTIMIZATION & AUDIT TRAIL -->
    <div class="card">
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 1.2rem;">⚡</span>
          <span style="font-size: 1rem; font-weight: 700;">
            ${isAr ? 'صيانة النظام والذاكرة وسجل التدقيق' : 'System Performance, Storage Optimization & Audit Log'}
          </span>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button class="btn btn-primary" style="font-size: 0.8rem; background: #0D9488; border-color: #0F766E; font-weight: 700;" onclick="optimizeSystemPerformance()">
            ⚡ ${isAr ? 'تنظيف الذاكرة وتسريع النظام' : 'Clean Cache & Optimize'}
          </button>
          <button class="btn btn-outline" style="font-size: 0.8rem; border-color: #0284C7; color: #0369A1; font-weight: 700;" onclick="if(typeof downloadStaffDatabaseBackup === 'function') downloadStaffDatabaseBackup();">
            💾 ${isAr ? 'تصدير نسخة JSON' : 'Export DB (JSON)'}
          </button>
          <button class="btn btn-outline" style="font-size: 0.8rem;" onclick="clearAuditLogs()">
            ${isAr ? 'مسح السجلات' : 'Clear Logs'}
          </button>
        </div>
      </div>

      <div class="clinical-table-wrapper" style="max-height: 260px; overflow-y: auto; margin-top: 14px;">
        <table class="clinical-table">
          <thead>
            <tr>
              <th style="width: 160px; text-align: ${isAr ? 'right' : 'left'};">${isAr ? 'التاريخ والوقت' : 'Timestamp'}</th>
              <th style="width: 130px; text-align: ${isAr ? 'right' : 'left'};">${isAr ? 'المستخدم' : 'User'}</th>
              <th style="text-align: ${isAr ? 'right' : 'left'};">${isAr ? 'تفاصيل الإجراء' : 'Action / Event Description'}</th>
            </tr>
          </thead>
          <tbody>
            ${auditLogs.length > 0 ? auditLogs.map(log => `
              <tr>
                <td><code>${log.timestamp}</code></td>
                <td><strong>@${log.user}</strong></td>
                <td>${log.action}</td>
              </tr>
            `).join('') : `
              <tr><td colspan="3" style="text-align: center; color: var(--text-muted);">${isAr ? 'لا توجد سجلات تدقيق حالية' : 'No audit entries recorded'}</td></tr>
            `}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function handleNewUserRoleChange(role) {
  const vac = document.getElementById('nu_auth_vac');
  const inj = document.getElementById('nu_auth_inj');
  const crt = document.getElementById('nu_auth_crt');
  const rpt = document.getElementById('nu_auth_rpt');
  const sys = document.getElementById('nu_auth_sys');
  if (!vac) return;

  if (role === 'admin') {
    vac.checked = true;
    inj.checked = true;
    crt.checked = true;
    rpt.checked = true;
    sys.checked = true;
  } else if (role === 'specialist') {
    vac.checked = true;
    inj.checked = true;
    crt.checked = true;
    rpt.checked = true;
    sys.checked = false;
  } else if (role === 'auditor') {
    vac.checked = false;
    inj.checked = false;
    crt.checked = false;
    rpt.checked = true;
    sys.checked = false;
  } else {
    // staff / employee
    vac.checked = true;
    inj.checked = false;
    crt.checked = false;
    rpt.checked = false;
    sys.checked = false;
  }
}
window.handleNewUserRoleChange = handleNewUserRoleChange;

async function handleCreateNewUser(e) {
  e.preventDefault();
  const name = document.getElementById('nu_name')?.value?.trim();
  const username = document.getElementById('nu_username')?.value?.trim();
  const password = document.getElementById('nu_password')?.value?.trim() || '123456';
  const department = document.getElementById('nu_department')?.value?.trim() || 'Occupational Health';
  const jobTitle = document.getElementById('nu_jobTitle')?.value?.trim() || 'Health Officer';
  const role = document.getElementById('nu_role')?.value || 'specialist';

  const vac = document.getElementById('nu_auth_vac')?.checked;
  const inj = document.getElementById('nu_auth_inj')?.checked;
  const crt = document.getElementById('nu_auth_crt')?.checked;
  const rpt = document.getElementById('nu_auth_rpt')?.checked;
  const sys = document.getElementById('nu_auth_sys')?.checked;

  const result = await window.authManager.addUser({
    name,
    username,
    password,
    department,
    jobTitle,
    role,
    authorizations: {
      occHealthModule: true,
      vaccinationForms: !!vac,
      injuryReport: !!inj,
      certificateGenerator: !!crt,
      vaccinationReports: !!rpt,
      systemManagement: !!sys || role === 'admin'
    }
  });

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  if (result.success) {
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(
        isAr ? `تم إنشاء حساب المستخدم (@${username}) بنجاح وتعيين كلمة المرور!` : `New User Account (@${username}) successfully created! Password set.`,
        isAr ? 'تم إنشاء المستخدم' : 'User Created'
      );
    } else {
      alert(`✅ New User Account (@${username}) successfully created!`);
    }
    addAuditLog(`Created new user account for ${name} (@${username}) with role: ${role}`);
    renderSystemManagementReport(document.getElementById('mainAppArea'));
  } else {
    alert(`❌ Error: ${result.message}`);
  }
}
window.handleCreateNewUser = handleCreateNewUser;

async function handleResetUserPassword(userId) {
  const user = (window.authManager && window.authManager.users ? window.authManager.users : []).find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
  if (!user) return;

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const promptMsg = isAr
    ? `🔑 أدخل كلمة المرور الجديدة للمستخدم @${user.username} (${user.name}):`
    : `🔑 Enter new password for @${user.username} (${user.name}):`;

  const newPass = prompt(promptMsg, '123456');
  if (newPass === null) return;
  if (newPass.trim() === '') {
    alert(isAr ? '❌ كلمة المرور لا يمكن أن تكون فارغة.' : '❌ Password cannot be empty.');
    return;
  }

  const result = await window.authManager.resetPassword(user.id || userId, newPass.trim());
  if (result.success) {
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(
        isAr ? `تم تحديث كلمة المرور للمستخدم @${user.username} بنجاح!` : `Password for @${user.username} updated successfully!`,
        isAr ? 'تم تغيير كلمة المرور' : 'Password Reset'
      );
    } else {
      alert(`🔑 Password for @${user.username} updated successfully!`);
    }
    addAuditLog(`Set/reset password for user @${user.username}`);
    renderSystemManagementReport(document.getElementById('mainAppArea'));
  } else {
    alert(`❌ Error: ${result.message || 'Failed to update password'}`);
  }
}
window.handleResetUserPassword = handleResetUserPassword;

function closeDeleteUserModal() {
  const el = document.getElementById('deleteUserConfirmModal');
  if (el) el.remove();
}
window.closeDeleteUserModal = closeDeleteUserModal;

async function executeUserDeletion(userId) {
  closeDeleteUserModal();
  const user = (window.authManager && window.authManager.users ? window.authManager.users : []).find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
  const username = user && user.username ? user.username : String(userId);
  const isAr = window.i18n ? window.i18n.isRTL() : false;

  const result = await window.authManager.deleteUser(user ? (user.id || user.username) : userId);
  if (result.success) {
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(
        isAr ? `تم حذف حساب المستخدم @${username} نهائياً بنجاح.` : `User account @${username} permanently deleted.`,
        isAr ? 'تم حذف المستخدم' : 'User Deleted'
      );
    } else {
      alert(isAr ? `🗑️ تم حذف حساب المستخدم @${username} نهائياً بنجاح.` : `🗑️ User @${username} deleted successfully.`);
    }
    if (typeof addAuditLog === 'function') {
      addAuditLog(`Permanently deleted user account @${username}`);
    }
    renderSystemManagementReport(document.getElementById('mainAppArea'));
  } else {
    alert(`❌ Error: ${result.message || 'Failed to delete user'}`);
  }
}
window.executeUserDeletion = executeUserDeletion;

function handleDeleteUserAccount(userId) {
  const user = (window.authManager && window.authManager.users ? window.authManager.users : []).find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
  if (!user) return;

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  closeDeleteUserModal();

  const modalHtml = `
    <div id="deleteUserConfirmModal" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 999999; padding: 20px;">
      <div style="background: white; border-radius: 16px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); max-width: 500px; width: 100%; overflow: hidden; border-top: 6px solid #DC2626;">
        <div style="padding: 24px;">
          <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 16px;">
            <div style="width: 48px; height: 48px; border-radius: 50%; background: #FEE2E2; color: #DC2626; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; flex-shrink: 0;">
              🗑️
            </div>
            <div>
              <h3 style="margin: 0; font-size: 1.15rem; font-weight: 800; color: #0F172A;">
                ${isAr ? 'تأكيد حذف حساب المستخدم نهائياً' : 'Permanently Delete User Account'}
              </h3>
              <div style="font-size: 0.85rem; color: #64748B; margin-top: 2px;">
                ${isAr ? 'إجراء إداري دائم لا يمكن التراجع عنه' : 'Irreversible administrative deletion'}
              </div>
            </div>
          </div>

          <div style="background: #F8FAFC; border: 1.5px solid #E2E8F0; border-radius: 10px; padding: 14px; margin-bottom: 18px;">
            <div style="font-size: 0.95rem; font-weight: 700; color: #1E293B; margin-bottom: 4px;">
              👤 ${user.name || user.username}
            </div>
            <div style="font-family: monospace; font-size: 0.85rem; color: #0369A1; margin-bottom: 4px;">
              @${user.username}
            </div>
            <div style="font-size: 0.8rem; color: #64748B;">
              ${user.department || 'Hospital Staff'} &bull; ${user.role ? user.role.toUpperCase() : 'USER'}
            </div>
          </div>

          <p style="color: #475569; font-size: 0.9rem; line-height: 1.5; margin: 0 0 20px 0;">
            ${isAr 
              ? 'هل أنت متأكد من رغبتك في حذف هذا المستخدم من النظام وقاعدة البيانات نهائياً؟ سيتم إلغاء وصوله ومسح صلاحياته فوراً.' 
              : 'Are you sure you want to delete this user from the system and database permanently? Their login access and module authorities will be revoked immediately.'}
          </p>

          <div style="display: flex; justify-content: flex-end; gap: 10px; flex-wrap: wrap;">
            <button type="button" class="btn btn-outline" style="padding: 9px 18px; font-weight: 700; font-size: 0.88rem;" onclick="closeDeleteUserModal()">
              ${isAr ? 'إلغاء الأمر' : 'Cancel'}
            </button>
            <button type="button" class="btn btn-danger" style="padding: 9px 20px; font-weight: 800; font-size: 0.88rem; background: #DC2626; border-color: #B91C1C; box-shadow: 0 4px 10px rgba(220,38,38,0.3); display: inline-flex; align-items: center; gap: 6px;" onclick="executeUserDeletion('${user.id || user.username}')">
              🗑️ ${isAr ? 'نعم، حذف الحساب نهائياً' : 'Yes, Delete Permanently'}
            </button>
          </div>
        </div>
      </div>
    </div>
  `;

  const div = document.createElement('div');
  div.innerHTML = modalHtml;
  document.body.appendChild(div.firstElementChild);
}
window.handleDeleteUserAccount = handleDeleteUserAccount;

function handleRoleSelectChange(userId, newRole) {
  const vac = document.getElementById(`auth_${userId}_vac`);
  const inj = document.getElementById(`auth_${userId}_inj`);
  const crt = document.getElementById(`auth_${userId}_crt`);
  const rpt = document.getElementById(`auth_${userId}_rpt`);
  const sys = document.getElementById(`auth_${userId}_sys`);

  if (newRole === 'admin') {
    if (vac) vac.checked = true;
    if (inj) inj.checked = true;
    if (crt) crt.checked = true;
    if (rpt) rpt.checked = true;
    if (sys) sys.checked = true;
  } else if (newRole === 'specialist') {
    if (vac) vac.checked = true;
    if (inj) inj.checked = true;
    if (crt) crt.checked = true;
    if (rpt) rpt.checked = true;
    if (sys) sys.checked = false;
  } else if (newRole === 'auditor') {
    if (vac) vac.checked = false;
    if (inj) inj.checked = false;
    if (crt) crt.checked = false;
    if (rpt) rpt.checked = true;
    if (sys) sys.checked = false;
  } else {
    // employee / staff
    if (vac) vac.checked = true;
    if (inj) inj.checked = false;
    if (crt) crt.checked = false;
    if (rpt) rpt.checked = false;
    if (sys) sys.checked = false;
  }
}
window.handleRoleSelectChange = handleRoleSelectChange;

async function handleSaveUserSettings(userId) {
  const user = (window.authManager && window.authManager.users ? window.authManager.users : []).find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
  if (!user) return;

  const role = document.getElementById(`role_sel_${userId}`)?.value || user.role || 'employee';
  const sys = document.getElementById(`auth_${userId}_sys`)?.checked;
  const vac = document.getElementById(`auth_${userId}_vac`)?.checked;
  const inj = document.getElementById(`auth_${userId}_inj`)?.checked;
  const rpt = document.getElementById(`auth_${userId}_rpt`)?.checked;
  const crt = document.getElementById(`auth_${userId}_crt`)?.checked;

  await window.authManager.updateUserRole(user.id || userId, role);
  await window.authManager.updateUserAuthorizations(user.id || userId, {
    occHealthModule: true,
    systemManagement: !!sys || role === 'admin',
    vaccinationForms: !!vac,
    injuryReport: !!inj,
    vaccinationReports: !!rpt,
    certificateGenerator: !!crt
  });

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  addAuditLog(`Updated role (${role}) and permissions for user @${user.username}`);

  if (typeof showSuccessToast === 'function') {
    showSuccessToast(
      isAr ? `تم حفظ صلاحيات ودور المستخدم @${user.username} بنجاح!` : `User role & permissions saved & updated successfully!`,
      isAr ? 'تم حفظ الصلاحيات' : 'Permissions Saved'
    );
  } else {
    alert('✅ User role & permissions saved successfully!');
  }

  if (typeof renderSidebar === 'function') {
    renderSidebar();
  }
  renderSystemManagementReport(document.getElementById('mainAppArea'));
}
window.handleSaveUserSettings = handleSaveUserSettings;

function addAuditLog(actionDescription) {
  let logs = JSON.parse(localStorage.getItem('avh_logs')) || INITIAL_AUDIT_LOGS;
  if (!Array.isArray(logs)) logs = [];
  logs.unshift({
    timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
    user: (window.authManager && window.authManager.currentUser) ? window.authManager.currentUser.username : 'admin',
    action: actionDescription
  });
  if (logs.length > 50) logs = logs.slice(0, 50);
  localStorage.setItem('avh_logs', JSON.stringify(logs));
}

function optimizeSystemPerformance() {
  try {
    // 1. Cap audit logs
    let logs = JSON.parse(localStorage.getItem('avh_logs')) || [];
    if (logs.length > 30) {
      logs = logs.slice(0, 30);
      localStorage.setItem('avh_logs', JSON.stringify(logs));
    }

    // 2. Clean temporary localStorage keys
    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('temp_') || key.startsWith('scratch_') || key.includes('draft_temp'))) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(k => localStorage.removeItem(k));

    // 3. Clear audit logs display
    if (typeof showSuccessToast === 'function') {
      showSuccessToast('System cache cleaned & storage memory optimized! Browser responsiveness restored.', '⚡ Performance Optimized / تم تسريع النظام');
    } else {
      alert('⚡ System cache cleaned & storage memory optimized! Browser responsiveness restored.');
    }
    renderSystemManagementReport(document.getElementById('mainAppArea'));
  } catch(e) {
    console.error('Performance optimization error:', e);
  }
}
window.optimizeSystemPerformance = optimizeSystemPerformance;

function saveGoogleSheetsUrlSetting() {
  const input = document.getElementById('gs_url_input');
  if (!input) return;
  const url = input.value.trim();
  window.googleSheetsSync.setUrl(url);
  if (typeof showSuccessToast === 'function') {
    showSuccessToast('Google Sheets Web App URL saved successfully!', 'Sheets Config Saved / تم حفظ الإعدادات');
  } else {
    alert('✅ Google Sheets Web App URL saved successfully!');
  }
  renderSystemManagementReport(document.getElementById('mainAppArea'));
}

function triggerFullGoogleSheetsSync() {
  const statusEl = document.getElementById('gs_sync_status_msg');
  if (statusEl) {
    statusEl.innerHTML = '⏳ Syncing all staff records and injury reports to Google Sheets...';
  }
  
  window.googleSheetsSync.syncAllData((completed, total, msg) => {
    if (statusEl) {
      statusEl.innerHTML = `⏳ ${msg} (${completed}/${total})`;
    }
  }).then(success => {
    if (success) {
      if (typeof showSuccessToast === 'function') {
        showSuccessToast('All staff records and injury reports successfully synced to Google Sheets!', 'Cloud Sync Complete / تم التزامن الكامل');
      } else {
        alert('🟢 All records successfully synced to Google Sheets!');
      }
    }
    renderSystemManagementReport(document.getElementById('mainAppArea'));
  });
}

function toggleAppsScriptInstructions() {
  const box = document.getElementById('gs_instructions_box');
  if (!box) return;
  box.style.display = box.style.display === 'none' ? 'block' : 'none';
}

function copyAppsScriptCode() {
  const area = document.getElementById('gs_code_area');
  if (!area) return;
  area.select();
  document.execCommand('copy');
  alert('📋 Google Apps Script code copied to clipboard!');
}

function clearAuditLogs() {
  localStorage.setItem('avh_logs', JSON.stringify([]));
  renderSystemManagementReport(document.getElementById('mainAppArea'));
}

/* ==========================================================================
   GITHUB AUTOMATED REPOSITORY LIVE SYNC HANDLERS
   ========================================================================== */
function saveGitHubSyncSettings() {
  const tokenInput = document.getElementById('gh_token_input');
  const ownerInput = document.getElementById('gh_owner_input');
  const repoInput = document.getElementById('gh_repo_input');

  if (window.githubSync) {
    if (tokenInput) window.githubSync.setToken(tokenInput.value);
    if (ownerInput) window.githubSync.setOwner(ownerInput.value);
    if (repoInput) window.githubSync.setRepo(repoInput.value);
  }

  addAuditLog('Saved GitHub repository sync configuration & Personal Access Token');

  if (typeof showSuccessToast === 'function') {
    showSuccessToast('GitHub auto-sync settings saved successfully!', 'GitHub Settings Saved / تم حفظ إعدادات جيت هاب');
  } else {
    alert('✅ GitHub auto-sync settings saved successfully!');
  }
  renderSystemManagementReport(document.getElementById('mainAppArea'));
}

function triggerFullGitHubSync() {
  const statusEl = document.getElementById('gh_sync_status_msg');
  if (statusEl) {
    statusEl.innerHTML = '⏳ Committing & Syncing master staff dataset directly to GitHub...';
  }

  if (window.githubSync) {
    window.githubSync.syncMasterDatasetToGitHub().then(success => {
      if (success) {
        if (typeof showSuccessToast === 'function') {
          showSuccessToast('Master dataset committed & pushed to GitHub repository!', 'GitHub Sync Complete / تم التزامن مع جيت هاب');
        } else {
          alert('🟢 Master dataset successfully committed to GitHub!');
        }
      } else {
        alert('⚠️ Please enter a valid GitHub Personal Access Token (PAT) first.');
      }
      renderSystemManagementReport(document.getElementById('mainAppArea'));
    }).catch(err => {
      alert('❌ Error syncing to GitHub: ' + err.message);
      renderSystemManagementReport(document.getElementById('mainAppArea'));
    });
  }
}

function toggleGitHubInstructions() {
  const box = document.getElementById('gh_instructions_box');
  if (!box) return;
  box.style.display = box.style.display === 'none' ? 'block' : 'none';
}

function resetToOriginalMasterList() {
  if (confirm('🧹 Are you sure you want to reset your local browser cache back to the original 511 Master Staff records?')) {
    localStorage.removeItem('avh_employees');
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.clearAllEmployees === 'function') {
      EmployeeDataService.clearAllEmployees().catch(() => {});
    }
    if (typeof _masterEmployeesList !== 'undefined') _masterEmployeesList = null;
    if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();
    alert('✅ Reset successful! Reloading original 511 staff dataset...');
    location.reload();
  }
}

/**
 * Permanently deletes all system data stored in local browser storage (avh_employees, avh_injuries, IPC vaults, audit logs, etc.)
 */
function deleteAllSystemData() {
  const isArabic = window.i18n && typeof window.i18n.currentLang === 'string' && window.i18n.currentLang === 'ar';
  
  const msgFirst = isArabic
    ? '🚨 منطقة الخطر: هل أنت متأكد تماماً من رغبتك في مسح كافة البيانات من النظام؟\n\n' +
      'سيؤدي هذا الإجراء إلى حذف جميع البيانات المخزنة بشكل دائم، بما في ذلك:\n' +
      '• سجلات الموظفين والتطعيمات المعدلة\n' +
      '• تقارير إصابات العمل (SQE 02.01)\n' +
      '• سجلات مكافحة العدوى (IPC) والعزل والترصد\n' +
      '• سجلات التدقيق والقوائم المنسدلة المخصصة\n\n' +
      'لا يمكن التراجع عن هذا الإجراء! هل ترغب في المتابعة؟'
    : '🚨 DANGER ZONE: Are you sure you want to DELETE ALL DATA from the system?\n\n' +
      'This action will permanently wipe ALL stored records including:\n' +
      '• Modified staff profiles & vaccination records\n' +
      '• Work injury reports (SQE 02.01)\n' +
      '• Infection Prevention & Control (IPC) isolation & surveillance logs\n' +
      '• Custom audit logs & dropdown options\n\n' +
      'This action CANNOT BE UNDONE! Do you wish to continue?';

  if (!confirm(msgFirst)) return;

  const promptMsg = isArabic
    ? '⚠️ تأكيد نهائي للأمان:\nالرجاء كتابة كلمة "DELETE" باللغة الإنجليزية في الخانة أدناه لتأكيد مسح جميع البيانات:'
    : '⚠️ FINAL SAFETY VERIFICATION:\nPlease type "DELETE" below to confirm wiping all system data:';

  const confirmationInput = prompt(promptMsg);
  if (!confirmationInput || confirmationInput.trim().toUpperCase() !== 'DELETE') {
    alert(isArabic ? '❌ تم إلغاء العملية. لم يتم مسح أي بيانات.' : '❌ Action cancelled. System data was not deleted.');
    return;
  }

  try {
    // 1. Array of core AVH local storage keys
    const avhKeys = [
      'avh_employees',
      'avh_employees_customized',
      'avh_injuries',
      'avh_logs',
      'avh_ipc_hai_vault',
      'avh_ipc_surveillance_vault',
      'avh_master_dropdowns',
      'avh_users',
      'avh_gs_url',
      'avh_gh_token',
      'avh_gh_owner',
      'avh_gh_repo'
    ];

    avhKeys.forEach(k => localStorage.removeItem(k));

    // 2. Clear any remaining local storage keys prefixed with avh_, temp_, draft_, or scratch_
    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.startsWith('avh_') || key.startsWith('temp_') || key.startsWith('scratch_') || key.includes('draft_temp'))) {
        keysToRemove.push(key);
      }
    }
    keysToRemove.forEach(k => localStorage.removeItem(k));

    // 3. Clear IndexedDB storage
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.clearAllEmployees === 'function') {
      EmployeeDataService.clearAllEmployees().catch(() => {});
    }

    // 4. Reset in-memory dataset cache
    if (typeof _masterEmployeesList !== 'undefined') _masterEmployeesList = null;
    if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();

    alert(isArabic ? '🧹 تم مسح جميع بيانات النظام بنجاح! سيتم الآن إعادة تحميل التطبيق مع البيانات الافتراضية الأصلية.' : '🧹 All system data has been successfully deleted! The application will now reload with original default datasets.');
    location.reload();
  } catch (err) {
    console.error('Error deleting system data:', err);
    alert('❌ Error: ' + err.message);
  }
}
window.deleteAllSystemData = deleteAllSystemData;

/* ==========================================================================
   MASTER DROPDOWN OPTIONS AUTHORITY CONTROLLERS
   ========================================================================== */
function renderMasterDropdownCategoryEditor(catKey = 'master_microorganisms') {
  const container = document.getElementById('master_dropdown_options_editor_area');
  if (!container) return;

  const categories = MasterDropdownManager.getCategories();
  const cat = categories[catKey] || categories['master_microorganisms'];

  container.innerHTML = `
    <div style="background: white; border: 1px solid #DDD6FE; border-radius: 10px; padding: 16px;">
      
      <!-- ADD NEW OPTION ROW -->
      <div style="background: #F3E8FF; padding: 12px; border-radius: 8px; border: 1px solid #D8B4FE; margin-bottom: 16px;">
        <div style="font-weight: bold; color: #6B21A8; font-size: 0.86rem; margin-bottom: 6px;">
          ➕ Add New Option to "${cat.title}":
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <input type="text" id="new_dropdown_option_input" placeholder="Enter new option name (e.g. Serratia liquefaciens)..." style="flex: 1; min-width: 250px; padding: 8px 12px; border: 1px solid #C084FC; border-radius: 6px; font-weight: 600;" onkeypress="if(event.key === 'Enter') handleAddDropdownOption('${catKey}')">
          <button class="btn btn-primary" style="background: #7C3AED; border: none; font-weight: bold;" onclick="handleAddDropdownOption('${catKey}')">
            ➕ Add Option
          </button>
        </div>
      </div>

      <!-- EXISTING OPTIONS TABLE -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
        <h5 style="margin: 0; color: #5B21B6; font-weight: bold;">Current Dropdown Options (${cat.options.length} items):</h5>
        <span style="font-size: 0.78rem; color: #6B21A8;">Changes apply immediately across all dashboards</span>
      </div>

      <div class="clinical-table-wrapper" style="max-height: 380px; overflow-y: auto; border: 1px solid #E9D5FF;">
        <table class="clinical-table" style="width: 100%;">
          <thead>
            <tr style="background: #F5F3FF; color: #5B21B6;">
              <th style="width: 50px; text-align: center;">#</th>
              <th>Option Name / Text</th>
              <th style="width: 160px; text-align: center;">Reorder Position</th>
              <th style="width: 150px; text-align: center;">Management Actions</th>
            </tr>
          </thead>
          <tbody>
            ${cat.options.map((opt, idx) => `
              <tr>
                <td style="text-align: center; font-weight: bold; color: #7C3AED;">${idx + 1}</td>
                <td>
                  <input type="text" id="opt_edit_input_${idx}" value="${opt.replace(/"/g, '&quot;')}" style="width: 100%; padding: 6px 10px; border: 1px solid #CBD5E1; border-radius: 6px; font-weight: 600; color: #1E293B;" onblur="handleEditDropdownOption('${catKey}', ${idx}, this.value)">
                </td>
                <td style="text-align: center;">
                  <div style="display: flex; gap: 4px; justify-content: center;">
                    <button class="btn btn-outline" style="padding: 2px 6px; font-size: 0.75rem; border-color: #A855F7;" onclick="handleMoveDropdownOption('${catKey}', ${idx}, -1)" ${idx === 0 ? 'disabled' : ''} title="Move Up">⬆️ Up</button>
                    <button class="btn btn-outline" style="padding: 2px 6px; font-size: 0.75rem; border-color: #A855F7;" onclick="handleMoveDropdownOption('${catKey}', ${idx}, 1)" ${idx === cat.options.length - 1 ? 'disabled' : ''} title="Move Down">⬇️ Down</button>
                  </div>
                </td>
                <td style="text-align: center;">
                  <button class="btn btn-danger" style="padding: 4px 10px; font-size: 0.76rem;" onclick="handleRemoveDropdownOption('${catKey}', ${idx})">
                    🗑️ Remove
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}
window.renderMasterDropdownCategoryEditor = renderMasterDropdownCategoryEditor;

function handleAddDropdownOption(catKey) {
  const input = document.getElementById('new_dropdown_option_input');
  if (!input) return;
  const text = input.value.trim();
  if (!text) {
    alert('Please enter an option name.');
    return;
  }
  const success = MasterDropdownManager.addOption(catKey, text);
  if (success) {
    addAuditLog(`Added new dropdown option "${text}" to category ${catKey}`);
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(`Option "${text}" added successfully!`, 'Dropdown Option Added / تم إضافة الخيار');
    }
    renderMasterDropdownCategoryEditor(catKey);
  }
}
window.handleAddDropdownOption = handleAddDropdownOption;

function handleEditDropdownOption(catKey, index, updatedText) {
  const options = MasterDropdownManager.getOptions(catKey);
  if (!options[index] || options[index] === updatedText.trim()) return;
  const oldText = options[index];
  const success = MasterDropdownManager.editOption(catKey, index, updatedText);
  if (success) {
    addAuditLog(`Renamed dropdown option from "${oldText}" to "${updatedText}" in ${catKey}`);
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(`Option name updated to "${updatedText}"`, 'Option Updated / تم التعديل');
    }
    renderMasterDropdownCategoryEditor(catKey);
  }
}
window.handleEditDropdownOption = handleEditDropdownOption;

function handleRemoveDropdownOption(catKey, index) {
  const options = MasterDropdownManager.getOptions(catKey);
  const text = options[index];
  if (confirm(`🗑️ Are you sure you want to remove "${text}" from this dropdown list?`)) {
    MasterDropdownManager.removeOption(catKey, index);
    addAuditLog(`Removed dropdown option "${text}" from ${catKey}`);
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(`Option "${text}" removed successfully.`, 'Option Removed / تم الحذف');
    }
    renderMasterDropdownCategoryEditor(catKey);
  }
}
window.handleRemoveDropdownOption = handleRemoveDropdownOption;

function handleMoveDropdownOption(catKey, index, direction) {
  MasterDropdownManager.moveOption(catKey, index, direction);
  renderMasterDropdownCategoryEditor(catKey);
}
window.handleMoveDropdownOption = handleMoveDropdownOption;

function resetCurrentDropdownCategoryToDefault() {
  const select = document.getElementById('sys_dropdown_category_select');
  const catKey = select ? select.value : 'blood_culture_organisms';
  if (confirm(`🔄 Reset dropdown list to system defaults for this category?`)) {
    MasterDropdownManager.resetCategoryToDefault(catKey);
    addAuditLog(`Reset dropdown options to defaults for ${catKey}`);
    if (typeof showSuccessToast === 'function') {
      showSuccessToast('Dropdown list reset to default settings.', 'Reset Default / تم إعادة الضبط');
    }
    renderMasterDropdownCategoryEditor(catKey);
  }
}
window.resetCurrentDropdownCategoryToDefault = resetCurrentDropdownCategoryToDefault;

/* ==========================================================================
   CENTRAL DATABASE, TRASH & AUDIT MANAGEMENT PANEL (OWNER PRIVILEGES)
   ========================================================================== */
async function renderDatabaseManagementPanel(container) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const isOwner = window.authManager && window.authManager.currentUser && window.authManager.currentUser.username.toLowerCase() === 'hammam';
  const currentUser = window.authManager && window.authManager.currentUser ? window.authManager.currentUser.username : 'guest';

  container.innerHTML = `
    <div style="display: flex; flex-direction: column; gap: 20px;">
      <!-- TOP STATUS & ARCHITECTURE CARD -->
      <div class="card" style="border-top: 4px solid #0284C7; background: #F8FAFC;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 1.4rem;">🗄️</span>
            <div>
              <span style="font-size: 1.1rem; font-weight: 800; color: #0369A1;">
                ${isAr ? 'إدارة قاعدة البيانات المركزية وسلة المهملات والنسخ الاحتياطي' : 'Central Database, Trash Bin & Backup Controller'}
              </span>
              <div style="font-size: 0.8rem; color: #64748B; margin-top: 2px;">
                ${isAr ? 'محرك SQLite الأصلي عالي الأداء مع دعم وضع WAL والحذف القابل للاسترداد' : 'Native High-Performance SQLite Engine with WAL Mode & Recoverable Soft Deletion'}
              </div>
            </div>
          </div>
          <div style="display: flex; gap: 8px; align-items: center;">
            <span class="role-pill" style="background: ${isOwner ? '#D1FAE5' : '#E2E8F0'}; color: ${isOwner ? '#065F46' : '#475569'}; font-weight: bold;">
              ${isOwner ? '👑 Designated Owner (hammam)' : `👤 User: @${currentUser}`}
            </span>
          </div>
        </div>

        <!-- TELEMETRY STATS GRID -->
        <div id="db_telemetry_grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-top: 18px;">
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 8px; padding: 14px; text-align: center;">
            <div style="font-size: 0.8rem; color: #64748B; font-weight: bold;">${isAr ? 'الموظفون النشطون' : 'Active Staff Records'}</div>
            <div id="telemetry_active_emp" style="font-size: 1.6rem; font-weight: 800; color: #0284C7; margin-top: 4px;">--</div>
          </div>
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 8px; padding: 14px; text-align: center;">
            <div style="font-size: 0.8rem; color: #64748B; font-weight: bold;">${isAr ? 'في سلة المهملات' : 'Staff in Trash'}</div>
            <div id="telemetry_trash_emp" style="font-size: 1.6rem; font-weight: 800; color: #DC2626; margin-top: 4px;">--</div>
          </div>
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 8px; padding: 14px; text-align: center;">
            <div style="font-size: 0.8rem; color: #64748B; font-weight: bold;">${isAr ? 'حوادث الإصابات النشطة' : 'Active Injury Reports'}</div>
            <div id="telemetry_active_inj" style="font-size: 1.6rem; font-weight: 800; color: #10B981; margin-top: 4px;">--</div>
          </div>
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 8px; padding: 14px; text-align: center;">
            <div style="font-size: 0.8rem; color: #64748B; font-weight: bold;">${isAr ? 'إصابات في سلة المهملات' : 'Injuries in Trash'}</div>
            <div id="telemetry_trash_inj" style="font-size: 1.6rem; font-weight: 800; color: #EA580C; margin-top: 4px;">--</div>
          </div>
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 8px; padding: 14px; text-align: center;">
            <div style="font-size: 0.8rem; color: #64748B; font-weight: bold;">${isAr ? 'حجم قاعدة البيانات' : 'Database Size'}</div>
            <div id="telemetry_db_size" style="font-size: 1.6rem; font-weight: 800; color: #475569; margin-top: 4px;">--</div>
          </div>
        </div>

        <!-- ACTION BUTTONS ROW -->
        <div style="display: flex; gap: 10px; flex-wrap: wrap; justify-content: flex-end; margin-top: 18px; padding-top: 14px; border-top: 1px solid #E2E8F0;">
          <button type="button" class="btn btn-success" style="background: #10B981; color: white; border: none; font-weight: bold; padding: 8px 16px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 6px;" onclick="handleManualBackupTrigger()">
            ⚡ ${isAr ? 'إنشاء نسخة احتياطية ذرية فورية (VACUUM INTO)' : 'Create Online DB Backup Now'}
          </button>
          <button type="button" class="btn btn-primary" style="background: #2563EB; color: white; border: none; font-weight: bold; padding: 8px 16px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 6px;" onclick="if(typeof downloadStaffDatabaseBackup === 'function') downloadStaffDatabaseBackup();">
            📥 ${isAr ? 'تحميل نسخة JSON' : 'Export DB JSON'}
          </button>
          <button type="button" class="btn btn-outline" style="border: 1px solid #64748B; color: #475569; font-weight: bold; padding: 8px 16px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 6px;" onclick="if(typeof downloadPreMigrationBackup === 'function') downloadPreMigrationBackup();">
            📦 ${isAr ? 'نسخة ما قبل الهجرة' : 'Pre-Migration Backup'}
          </button>
        </div>
      </div>

      <!-- OWNER TRASH BIN CARD -->
      <div class="card" style="border-top: 4px solid #DC2626;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 8px; color: #991B1B;">
            <span style="font-size: 1.3rem;">🗑️</span>
            <span style="font-size: 1.05rem; font-weight: 800;">
              ${isAr ? 'سلة المحذوفات القابلة للاسترداد (خاصة بالمالك)' : 'Recoverable Trash Bin (Owner Exclusive)'}
            </span>
          </div>
          <span style="font-size: 0.82rem; color: #64748B;">
            ${isAr ? 'السجلات المحذوفة ناعماً تظل قابلة للاستعادة الكاملة' : 'Soft-deleted records remain fully restorable'}
          </span>
        </div>

        ${!isOwner ? `
          <div style="background: #FEF2F2; border: 1px solid #F87171; color: #991B1B; padding: 14px; border-radius: 8px; font-weight: bold; font-size: 0.88rem; margin-top: 12px;">
            🔒 ${isAr ? 'ملاحظة: حساب المالك المعتمد (hammam) هو الحساب الوحيد المصرح له بعرض واستعادة وحذف السجلات نهائياً.' : 'Access Notice: Only the designated owner account (hammam) is authorized to delete and restore records.'}
          </div>
        ` : `
          <!-- OWNER TRASH CONTENT -->
          <div style="margin-top: 14px;">
            <h4 style="color: #991B1B; font-size: 0.95rem; margin-bottom: 8px;">
              👤 ${isAr ? 'سجلات الموظفين المحذوفة في السلة' : 'Soft-Deleted Staff Records in Trash'}:
            </h4>
            <div class="clinical-table-wrapper" style="max-height: 250px; overflow-y: auto;">
              <table class="clinical-table">
                <thead>
                  <tr>
                    <th style="width: 100px;">ID / Emp No</th>
                    <th>Full Name</th>
                    <th>Department</th>
                    <th style="width: 160px;">Deleted At</th>
                    <th style="width: 110px;">Deleted By</th>
                    <th style="width: 100px; text-align: center;">Action</th>
                  </tr>
                </thead>
                <tbody id="trash_employees_tbody">
                  <tr><td colspan="6" style="text-align: center; color: #64748B;">Loading trash records...</td></tr>
                </tbody>
              </table>
            </div>

            <h4 style="color: #991B1B; font-size: 0.95rem; margin-top: 18px; margin-bottom: 8px;">
              🩹 ${isAr ? 'بلاغات إصابات العمل المحذوفة في السلة' : 'Soft-Deleted Injury Reports in Trash'}:
            </h4>
            <div class="clinical-table-wrapper" style="max-height: 250px; overflow-y: auto;">
              <table class="clinical-table">
                <thead>
                  <tr>
                    <th style="width: 140px;">Serial No</th>
                    <th>Employee Name</th>
                    <th>Incident Date</th>
                    <th style="width: 160px;">Deleted At</th>
                    <th style="width: 110px;">Deleted By</th>
                    <th style="width: 100px; text-align: center;">Action</th>
                  </tr>
                </thead>
                <tbody id="trash_injuries_tbody">
                  <tr><td colspan="6" style="text-align: center; color: #64748B;">Loading trash records...</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        `}
      </div>

      <!-- LIVE CENTRAL AUDIT LOG CARD -->
      <div class="card" style="border-top: 4px solid #8B5CF6;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 8px; color: #5B21B6;">
            <span style="font-size: 1.3rem;">📜</span>
            <span style="font-size: 1.05rem; font-weight: 800;">
              ${isAr ? 'سجل التدقيق المركزي المباشر (SQLite Audit Trail)' : 'Live Central Audit Trail (SQLite)'}
            </span>
          </div>
          <button type="button" class="btn btn-outline" style="border: 1px solid #8B5CF6; color: #6D28D9; font-weight: bold; padding: 4px 12px; font-size: 0.8rem; border-radius: 4px; cursor: pointer;" onclick="loadLiveAuditLogsTable()">
            🔄 ${isAr ? 'تحديث السجل' : 'Refresh Logs'}
          </button>
        </div>

        <div class="clinical-table-wrapper" style="max-height: 350px; overflow-y: auto; margin-top: 14px;">
          <table class="clinical-table">
            <thead>
              <tr>
                <th style="width: 160px;">Timestamp</th>
                <th style="width: 120px;">User</th>
                <th style="width: 110px;">Action</th>
                <th style="width: 110px;">Entity</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody id="central_audit_logs_tbody">
              <tr><td colspan="5" style="text-align: center; color: #64748B;">Loading audit logs...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;

  // Hydrate telemetry stats asynchronously
  loadDbTelemetryStats();
  if (isOwner) {
    loadOwnerTrashTables();
  }
  loadLiveAuditLogsTable();
}

async function loadDbTelemetryStats() {
  try {
    if (typeof SystemDbService !== 'undefined' && typeof SystemDbService.getDbStatus === 'function') {
      const data = await SystemDbService.getDbStatus();
      if (data) {
        const elActive = document.getElementById('telemetry_active_emp');
        const elTrash = document.getElementById('telemetry_trash_emp');
        const elActiveInj = document.getElementById('telemetry_active_inj');
        const elTrashInj = document.getElementById('telemetry_trash_inj');
        const elSize = document.getElementById('telemetry_db_size');

        if (elActive) elActive.textContent = data.activeEmployees ?? '--';
        if (elTrash) elTrash.textContent = data.deletedEmployees ?? '0';
        if (elActiveInj) elActiveInj.textContent = data.activeInjuries ?? '--';
        if (elTrashInj) elTrashInj.textContent = data.deletedInjuries ?? '0';
        if (elSize) {
          const mb = data.dbSizeBytes ? (data.dbSizeBytes / (1024 * 1024)).toFixed(2) + ' MB' : '--';
          elSize.textContent = mb;
        }
      }
    }
  } catch (err) {
    console.warn("Failed to load DB telemetry:", err);
  }
}

async function loadOwnerTrashTables() {
  // 1. Employees Trash
  try {
    const empTbody = document.getElementById('trash_employees_tbody');
    if (empTbody && typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.getTrashEmployees === 'function') {
      const trashEmps = await EmployeeDataService.getTrashEmployees();
      if (!Array.isArray(trashEmps) || trashEmps.length === 0) {
        empTbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: #10B981; font-weight: bold; padding: 14px;">✅ سلة مهملات الموظفين فارغة (No deleted employees in Trash)</td></tr>`;
      } else {
        empTbody.innerHTML = trashEmps.map(e => `
          <tr>
            <td><code>${e.id || e.empNo || '--'}</code></td>
            <td><strong>${e.name || e.fullName || '--'}</strong></td>
            <td>${e.dept || e.department || '--'}</td>
            <td><small>${e.deleted_at || '--'}</small></td>
            <td><span class="role-pill" style="padding: 2px 6px; font-size: 0.72rem;">@${e.deleted_by || 'owner'}</span></td>
            <td style="text-align: center;">
              <button type="button" class="btn btn-success" style="padding: 4px 10px; font-size: 0.78rem; background: #10B981; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;" onclick="handleOwnerRestoreEmployee('${e.id || e.empNo}')">
                ♻️ Restore
              </button>
            </td>
          </tr>
        `).join('');
      }
    }
  } catch (err) {
    console.warn("Failed to load employees trash:", err);
  }

  // 2. Injuries Trash
  try {
    const injTbody = document.getElementById('trash_injuries_tbody');
    if (injTbody && typeof InjuryDataService !== 'undefined' && typeof InjuryDataService.getTrashInjuries === 'function') {
      const trashInjs = await InjuryDataService.getTrashInjuries();
      if (!Array.isArray(trashInjs) || trashInjs.length === 0) {
        injTbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: #10B981; font-weight: bold; padding: 14px;">✅ سلة مهملات بلاغات الإصابات فارغة (No deleted injury reports in Trash)</td></tr>`;
      } else {
        injTbody.innerHTML = trashInjs.map(i => `
          <tr>
            <td><code>${i.id || i.serialNo || '--'}</code></td>
            <td><strong>${i.employee_name || i.employeeName || '--'}</strong></td>
            <td>${i.incident_date || i.incidentDate || '--'}</td>
            <td><small>${i.deleted_at || '--'}</small></td>
            <td><span class="role-pill" style="padding: 2px 6px; font-size: 0.72rem;">@${i.deleted_by || 'owner'}</span></td>
            <td style="text-align: center;">
              <button type="button" class="btn btn-success" style="padding: 4px 10px; font-size: 0.78rem; background: #10B981; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;" onclick="handleOwnerRestoreInjury('${i.id || i.serialNo}')">
                ♻️ Restore
              </button>
            </td>
          </tr>
        `).join('');
      }
    }
  } catch (err) {
    console.warn("Failed to load injuries trash:", err);
  }
}

async function loadLiveAuditLogsTable() {
  const tbody = document.getElementById('central_audit_logs_tbody');
  if (!tbody) return;
  try {
    if (typeof SystemDbService !== 'undefined' && typeof SystemDbService.getAuditLogs === 'function') {
      const logs = await SystemDbService.getAuditLogs();
      if (!Array.isArray(logs) || logs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: #64748B; padding: 14px;">No audit records found.</td></tr>`;
      } else {
        tbody.innerHTML = logs.map(l => `
          <tr>
            <td><code>${l.timestamp || '--'}</code></td>
            <td><strong>@${l.username || 'system'}</strong></td>
            <td><span class="role-pill" style="padding: 2px 6px; font-size: 0.74rem;">${l.action || '--'}</span></td>
            <td><small>${l.entity_type || '--'} ${l.entity_id ? `(${l.entity_id})` : ''}</small></td>
            <td><span style="font-size: 0.85rem;">${l.details || '--'}</span></td>
          </tr>
        `).join('');
      }
    }
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: #EF4444; padding: 14px;">Failed to load live audit logs: ${err.message}</td></tr>`;
  }
}

async function handleOwnerRestoreEmployee(empId) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  if (!confirm(isAr ? `هل تريد استعادة سجل الموظف (${empId}) إلى السجلات النشطة؟` : `Restore employee record (${empId}) back to active database?`)) return;

  try {
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.restoreEmployee === 'function') {
      await EmployeeDataService.restoreEmployee(empId);
      if (typeof showSuccessToast === 'function') {
        showSuccessToast(
          isAr ? `تمت استعادة سجل الموظف (${empId}) بنجاح 🟢` : `Staff record (${empId}) restored successfully 🟢`,
          'Restored / تمت الاستعادة'
        );
      }
      loadDbTelemetryStats();
      loadOwnerTrashTables();
      loadLiveAuditLogsTable();
    }
  } catch (err) {
    alert(`Restore failed: ${err.message}`);
  }
}
window.handleOwnerRestoreEmployee = handleOwnerRestoreEmployee;

async function handleOwnerRestoreInjury(serialNo) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  if (!confirm(isAr ? `هل تريد استعادة بلاغ الإصابة (${serialNo}) إلى السجلات النشطة؟` : `Restore injury incident report (${serialNo}) back to active database?`)) return;

  try {
    if (typeof InjuryDataService !== 'undefined' && typeof InjuryDataService.restoreInjury === 'function') {
      await InjuryDataService.restoreInjury(serialNo);
      if (typeof showSuccessToast === 'function') {
        showSuccessToast(
          isAr ? `تمت استعادة بلاغ الإصابة (${serialNo}) بنجاح 🟢` : `Injury report (${serialNo}) restored successfully 🟢`,
          'Restored / تمت الاستعادة'
        );
      }
      loadDbTelemetryStats();
      loadOwnerTrashTables();
      loadLiveAuditLogsTable();
    }
  } catch (err) {
    alert(`Restore failed: ${err.message}`);
  }
}
window.handleOwnerRestoreInjury = handleOwnerRestoreInjury;

async function handleManualBackupTrigger() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  try {
    if (typeof SystemDbService !== 'undefined' && typeof SystemDbService.triggerBackup === 'function') {
      const res = await SystemDbService.triggerBackup();
      if (typeof showSuccessToast === 'function') {
        showSuccessToast(
          isAr ? `تم إنشاء النسخة الاحتياطية بنجاح (${res.backupFile || 'SQLite VACUUM'}) 🟢` : `Online database backup created successfully (${res.backupFile || 'SQLite VACUUM'}) 🟢`,
          'Backup Complete 💾'
        );
      }
      loadDbTelemetryStats();
      loadLiveAuditLogsTable();
    }
  } catch (err) {
    alert(`Backup failed: ${err.message}`);
  }
}
window.handleManualBackupTrigger = handleManualBackupTrigger;
window.renderDatabaseManagementPanel = renderDatabaseManagementPanel;



