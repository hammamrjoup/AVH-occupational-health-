/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - STAFF OCCUPATIONAL HEALTH & VACCINATION
   Standalone Application Controller & Navigation Architecture
   ========================================================================== */

let activeNavTab = 'portal-home';

let openSidebarCategories = {
  'cat-vac-forms': true,
  'cat-injuries': false,
  'cat-system': false
};

function getCategoryForTab(tabKey) {
  if (['vaccination-forms'].includes(tabKey)) return 'cat-vac-forms';
  if (['injury-report'].includes(tabKey)) return 'cat-injuries';
  if (['system-management'].includes(tabKey)) return 'cat-system';
  return null;
}

function toggleSidebarCategory(catId) {
  openSidebarCategories[catId] = !openSidebarCategories[catId];
  renderSidebar();
}
window.toggleSidebarCategory = toggleSidebarCategory;

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  if (typeof window.EmployeeDataService !== 'undefined' && typeof window.EmployeeDataService.init === 'function') {
    window.EmployeeDataService.init().catch(err => console.warn("EmployeeDataService init:", err));
  }

  if (!window.authManager || !window.authManager.isLoggedIn || !window.authManager.currentUser) {
    renderLoginScreen();
    return;
  }
  
  // Ensure portal DOM is restored if previously replaced by login screen
  const wrapper = document.querySelector('.portal-wrapper');
  if (!wrapper) {
    location.reload();
    return;
  }

  // 1. Render UI immediately with local/pre-loaded master dataset (Instant launch <50ms)
  renderSidebar();
  renderTopBar();
  switchNav(activeNavTab);

  // 2. Fetch latest Master dataset asynchronously in background from authoritative SQLite backend
  if (typeof window.fetchMasterEmployeesFromBackend === 'function') {
    window.fetchMasterEmployeesFromBackend().then(() => {
      if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();
      const mainArea = document.getElementById('mainAppArea');
      if (mainArea && (activeNavTab === 'vaccination-reports' || activeNavTab === 'reports') && typeof renderVaccinationReports === 'function') {
        renderVaccinationReports(mainArea);
      } else if (mainArea && activeNavTab === 'dashboard' && typeof renderDashboardOverview === 'function') {
        renderDashboardOverview(mainArea);
      }
    }).catch(err => console.warn("Background fetch info:", err));
  }

  // Listen for real-time data updates to keep open reports & dashboard synced instantly
  window.addEventListener('avh_data_updated', () => {
    if (typeof invalidateEmployeesCache === 'function') {
      invalidateEmployeesCache();
    }
    const mainArea = document.getElementById('mainAppArea');
    if (mainArea) {
      if ((activeNavTab === 'vaccination-reports' || activeNavTab === 'reports') && typeof renderVaccinationReports === 'function') {
        renderVaccinationReports(mainArea);
      } else if (activeNavTab === 'dashboard' && typeof renderDashboardOverview === 'function') {
        renderDashboardOverview(mainArea);
      } else if ((activeNavTab === 'staff-entry' || activeNavTab === 'staffEntry') && typeof loadStaffRecordIntoForm === 'function' && typeof currentEditingEmpNo !== 'undefined' && currentEditingEmpNo) {
        const emps = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
        const activeEmp = emps.find(e => e.empNo === currentEditingEmpNo || e.id === currentEditingEmpNo);
        if (activeEmp) loadStaffRecordIntoForm(activeEmp);
      }
    }

    // Refresh open Unvaccinated Follow-Up Action Report Modal live
    const unvacContainer = document.getElementById('unvaccinatedReportModalContainer');
    if (unvacContainer && unvacContainer.innerHTML.trim() !== '') {
      const cat = window._currentUnvacModalCategory || 'ALL';
      if (typeof openUnvaccinatedFollowupReport === 'function') {
        openUnvaccinatedFollowupReport(cat);
      }
    }

    // Refresh open Contraindications Report Modal live
    const contraContainer = document.getElementById('contraindicationsReportModalContainer');
    if (contraContainer && contraContainer.innerHTML.trim() !== '') {
      if (typeof openContraindicationsReport === 'function') {
        openContraindicationsReport();
      }
    }

    // Refresh open Refusals Report Modal live
    const refusalContainer = document.getElementById('refusalsReportModalContainer');
    if (refusalContainer && refusalContainer.innerHTML.trim() !== '') {
      if (typeof openRefusalsReport === 'function') {
        openRefusalsReport();
      }
    }

    // Refresh open MOH Statutory Immunity Breakdown Report Modal live
    const mohContainer = document.getElementById('mohImmunityBreakdownModalContainer');
    if (mohContainer && mohContainer.innerHTML.trim() !== '') {
      if (typeof openMOHImmunityBreakdownReport === 'function') {
        const st = window._currentMOHModalStatus || 'ALL';
        const cat = window._currentMOHModalCategory || 'ALL';
        openMOHImmunityBreakdownReport(st, cat);
      }
    }
  });
}

function renderLoginScreen() {
  const t = key => window.i18n.t(key);
  document.body.innerHTML = `
    <div class="medical-login-wrapper">
      <div class="medical-bg-vectors">
        <svg class="med-svg-stethoscope" viewBox="0 0 200 200" fill="none" stroke="#26A69A" stroke-width="6" stroke-linecap="round">
          <path d="M 40,30 L 40,70 C 40,110 90,120 100,80 C 110,120 160,110 160,70 L 160,30" />
          <circle cx="40" cy="25" r="8" fill="#26A69A" />
          <circle cx="160" cy="25" r="8" fill="#26A69A" />
          <circle cx="100" cy="140" r="16" fill="#26A69A" stroke="#FFFFFF" stroke-width="4"/>
        </svg>

        <svg class="med-svg-syringe" viewBox="0 0 100 200" fill="none" stroke="#26A69A" stroke-width="5" stroke-linecap="round">
          <rect x="35" y="50" width="30" height="90" rx="4" fill="rgba(38, 166, 154, 0.15)"/>
          <line x1="50" y1="20" x2="50" y2="50" />
          <line x1="30" y1="20" x2="70" y2="20" />
          <line x1="50" y1="140" x2="50" y2="180" stroke-width="3"/>
          <line x1="35" y1="70" x2="50" y2="70" />
          <line x1="35" y1="90" x2="50" y2="90" />
          <line x1="35" y1="110" x2="50" y2="110" />
        </svg>

        <svg class="med-svg-heart" viewBox="0 0 120 120" fill="none">
          <path d="M 60,100 C 20,70 10,45 25,25 C 40,5 55,20 60,30 C 65,20 80,5 95,25 C 110,45 100,70 60,100 Z" fill="#26A69A" opacity="0.9"/>
          <path d="M 25,60 L 45,60 L 52,40 L 60,80 L 68,50 L 75,65 L 95,65" stroke="#FFFFFF" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>

      <div class="medical-login-card">
        <div style="display: flex; justify-content: flex-end; margin-bottom: 12px;">
          <button type="button" class="btn btn-outline" style="padding: 4px 10px; font-size: 0.8rem; border-color: var(--accent-teal); color: var(--accent-teal);" onclick="window.i18n.toggleLanguage()">${t('lang_btn_text')}</button>
        </div>

        <div style="margin-bottom: 20px; text-align: center;">
          ${typeof window.getAVHLogoHTML === 'function' ? window.getAVHLogoHTML(120) : '<img src="assets/avh_logo.png" style="height:120px;" />'}
        </div>

        <h1 class="login-card-title">${t('login_title')}</h1>

        <form onsubmit="handleLoginSubmit(event)">
          <div class="login-input-group">
            <input type="text" id="loginUsername" placeholder="${t('username')}" required autocomplete="username">
          </div>

          <div class="login-input-group">
            <input type="password" id="loginPassword" placeholder="${t('password')}" required autocomplete="current-password">
          </div>

          <div class="login-forgot-link">
            <a href="#" onclick="alert('System Administrator Account:\n• Username: hammam\n• Password: 123456'); return false;">${t('forgot_password')}</a>
          </div>

          <div id="loginErrorMessage" class="login-error-msg" style="display: none;"></div>

          <div class="login-btn-container">
            <button type="submit" class="login-submit-btn">${t('login_btn')}</button>
          </div>
        </form>
      </div>
    </div>
  `;
}

async function handleLoginSubmit(e) {
  e.preventDefault();
  const u = document.getElementById('loginUsername').value;
  const p = document.getElementById('loginPassword').value;

  const result = await window.authManager.login(u, p);
  if (result.success) {
    location.reload();
  } else {
    const errEl = document.getElementById('loginErrorMessage');
    errEl.innerText = result.message;
    errEl.style.display = 'block';
  }
}

async function quickLogin(roleUsername) {
  await window.authManager.login(roleUsername, '123456');
  location.reload();
}

async function handleLogout() {
  await window.authManager.logout();
  location.reload();
}

function getLucideIcon(name, size = 20, strokeWidth = 2) {
  const iconPaths = {
    home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    syringe: '<path d="m18 2 4 4"/><path d="m17 7 3-3"/><path d="M19 9 8.7 19.3c-.4.4-1 .6-1.6.6H3v-4.1c0-.6.2-1.2.6-1.6L14 3.9"/><path d="m9 11 4 4"/><path d="m5 19-3 3"/><path d="m14 4 6 6"/>',
    shieldAlert: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
    fileCheck: '<path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><path d="m9 15 2 2 4-4"/>',
    dashboard: '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
    reports: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M8 13h2"/><path d="M14 13h2"/><path d="M8 17h2"/><path d="M14 17h2"/>',
    settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    clipboardEdit: '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M10.42 12.61a2.1 2.1 0 1 1 2.97 2.97L7.95 21 4 22l.99-3.95 5.43-5.44Z"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-5.5"/>',
    barChart: '<line x1="18" x2="18" y1="20" y2="10"/><line x1="12" x2="12" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="14"/>',
    hospital: '<rect width="16" height="20" x="4" y="2" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M8 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M16 14h.01"/><path d="M12 6v4"/><path d="M10 8h4"/>',
    clipboardList: '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
    calendar: '<rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/>'
  };
  const body = iconPaths[name] || '';
  return `<svg class="lucide lucide-${name}" xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${strokeWidth}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}
window.getLucideIcon = getLucideIcon;

function renderSidebar() {
  const sidebarContainer = document.getElementById('portalSidebar');
  if (!sidebarContainer) return;
  const user = window.authManager ? window.authManager.currentUser : null;
  const t = key => window.i18n.t(key);
  const isAr = window.i18n ? window.i18n.isRTL() : false;

  sidebarContainer.innerHTML = `
    <div class="sidebar-brand">
      <div class="sidebar-brand-logo">
        ${typeof window.getAVHLogoHTML === 'function' ? window.getAVHLogoHTML(110) : '<img src="assets/avh_logo.png" style="width:100%; max-height:110px;" />'}
      </div>
    </div>

    <div class="sidebar-section-label">
      <span>${t('portal_title')}</span>
    </div>

    <nav class="sidebar-nav">
      <!-- 0. PORTAL HOME / OPEN PICTURE -->
      <button type="button" class="sidebar-nav-tab ${activeNavTab === 'portal-home' ? 'active' : ''}" onclick="switchNav('portal-home')">
        <span class="nav-icon">${getLucideIcon('home')}</span>
        <span class="nav-text">${isAr ? '\u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0644\u0644\u0628\u0648\u0627\u0628\u0629' : 'Portal Home Screen'}</span>
      </button>

      <!-- 1. STAFF REGISTRATION & CLINICAL INTAKE -->
      <button type="button" class="sidebar-nav-tab ${activeNavTab === 'staff-entry' ? 'active' : ''}" onclick="switchNav('staff-entry')">
        <span class="nav-icon">${getLucideIcon('users')}</span>
        <span class="nav-text">${t('tab_staff_entry')}</span>
      </button>

      <!-- 2. VACCINATION FORMS & SCHEDULES -->
      ${window.authManager && window.authManager.hasPermission('vaccinationForms') ? `
        <button type="button" class="sidebar-nav-tab ${activeNavTab === 'vaccination-forms' ? 'active' : ''}" onclick="switchNav('vaccination-forms')">
          <span class="nav-icon">${getLucideIcon('syringe')}</span>
          <span class="nav-text">${t('tab_vaccination_forms')}</span>
        </button>
        ${activeNavTab === 'vaccination-forms' ? `
          <div class="sidebar-sub-menu">
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'exemption' ? 'active' : ''}" onclick="selectSubTabFromSidebar('exemption')">
              ${t('sub_exemption')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'checklist' ? 'active' : ''}" onclick="selectSubTabFromSidebar('checklist')">
              ${t('sub_checklist')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'history' ? 'active' : ''}" onclick="selectSubTabFromSidebar('history')">
              ${t('sub_history')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'old_vac' ? 'active' : ''}" onclick="selectSubTabFromSidebar('old_vac')">
              ${t('sub_old_vac')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'chickenpox' ? 'active' : ''}" onclick="selectSubTabFromSidebar('chickenpox')">
              ${t('sub_chickenpox')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'covid_flu' ? 'active' : ''}" onclick="selectSubTabFromSidebar('covid_flu')">
              ${t('sub_covid_flu')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'special' ? 'active' : ''}" onclick="selectSubTabFromSidebar('special')">
              ${t('sub_special')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'pep' ? 'active' : ''}" onclick="selectSubTabFromSidebar('pep')">
              ${t('sub_pep')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'refusal' ? 'active' : ''}" onclick="selectSubTabFromSidebar('refusal')">
              ${t('sub_refusal')}
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentSubTab !== 'undefined' ? currentSubTab : 'exemption') === 'infection_control' ? 'active' : ''}" onclick="selectSubTabFromSidebar('infection_control')">
              ${t('sub_infection_control')}
            </button>
          </div>
        ` : ''}
      ` : ''}

      <!-- 3. OCCUPATIONAL INJURY REPORT (SQE 02.01) -->
      ${window.authManager && window.authManager.hasPermission('injuryReport') ? `
        <button type="button" class="sidebar-nav-tab ${activeNavTab === 'injury-report' ? 'active' : ''}" onclick="switchNav('injury-report')">
          <span class="nav-icon">${getLucideIcon('shieldAlert')}</span>
          <span class="nav-text">${t('tab_injury_report')}</span>
        </button>
        ${activeNavTab === 'injury-report' ? `
          <div class="sidebar-sub-menu">
            <button type="button" class="sidebar-sub-tab ${(typeof currentInjurySubTab !== 'undefined' ? currentInjurySubTab : 'form') === 'form' ? 'active' : ''}" onclick="switchInjurySubTab('form')">
              <span class="sub-tab-icon">${getLucideIcon('clipboardEdit', 16)}</span>
              <span>${isAr ? '\u0646\u0645\u0648\u0630\u062c \u0627\u0644\u0625\u0635\u0627\u0628\u0629 (SQE 02.01)' : 'Injury Form (SQE 02.01)'}</span>
            </button>
            <button type="button" class="sidebar-sub-tab ${(typeof currentInjurySubTab !== 'undefined' ? currentInjurySubTab : 'form') === 'periodic_log' ? 'active' : ''}" onclick="switchInjurySubTab('periodic_log')">
              <span class="sub-tab-icon">${getLucideIcon('barChart', 16)}</span>
              <span>${isAr ? '\u0633\u062c\u0644 \u0627\u0644\u0628\u0644\u0627\u063a\u0627\u062a \u062d\u0633\u0628 \u0627\u0644\u0641\u062a\u0631\u0629' : 'All Incidents (By Period)'}</span>
            </button>
          </div>
        ` : ''}
      ` : ''}

      <!-- 4. OFFICIAL VACCINATION & IMMUNITY CERTIFICATES -->
      ${window.authManager && window.authManager.hasPermission('certificateGenerator') ? `
        <button type="button" class="sidebar-nav-tab ${activeNavTab === 'vaccination-certificate' ? 'active' : ''}" onclick="switchNav('vaccination-certificate')">
          <span class="nav-icon">${getLucideIcon('fileCheck')}</span>
          <span class="nav-text">${t('tab_vaccination_certificate')}</span>
        </button>
      ` : ''}

      <!-- 4.5 CLINICAL FOLLOW-UP & REPEAT TEST CALENDAR (DEDICATED STANDALONE ICON) -->
      <button type="button" class="sidebar-nav-tab ${activeNavTab === 'followup-calendar' ? 'active' : ''}" onclick="switchNav('followup-calendar')">
        <span class="nav-icon">${getLucideIcon('calendar')}</span>
        <span class="nav-text">${isAr ? 'تقويم المتابعات والمواعيد' : 'Follow-up & Appointments Calendar'}</span>
        ${(() => {
          if (typeof window.getClinicalAppointmentSummary === 'function') {
            const s = window.getClinicalAppointmentSummary();
            if (s && s.overdueCount > 0) {
              return `<span style="background: #DC2626; color: white; border-radius: 10px; padding: 1px 7px; font-size: 0.72rem; font-weight: 800; margin-left: auto;">${s.overdueCount}</span>`;
            }
          }
          return '';
        })()}
      </button>

      <!-- 5. STATISTICAL & REPORTING DASHBOARD -->
      <button type="button" class="sidebar-nav-tab ${activeNavTab === 'dashboard' ? 'active' : ''}" onclick="switchNav('dashboard')">
        <span class="nav-icon">${getLucideIcon('dashboard')}</span>
        <span class="nav-text">${t('tab_dashboard')}</span>
      </button>
      ${activeNavTab === 'dashboard' ? `
        <div class="sidebar-sub-menu">
          <button type="button" class="sidebar-sub-tab sidebar-sub-tab-dashboard ${(typeof currentDashboardSubTab !== 'undefined' ? currentDashboardSubTab : 'avh') === 'avh' ? 'active' : ''}" data-subtab="avh" onclick="switchDashboardSubTab('avh')">
            <span class="sub-tab-icon">${getLucideIcon('hospital', 16)}</span>
            <span>${isAr ? '\u062a\u0642\u0631\u064a\u0631 \u0645\u0633\u062a\u0634\u0641\u0649 \u0627\u0644\u0645\u064f\u0637\u0644\u0639 (AVH Report)' : 'AVH Report'}</span>
          </button>
          <button type="button" class="sidebar-sub-tab sidebar-sub-tab-dashboard ${(typeof currentDashboardSubTab !== 'undefined' ? currentDashboardSubTab : 'avh') === 'moh' ? 'active' : ''}" data-subtab="moh" onclick="switchDashboardSubTab('moh')">
            <span class="sub-tab-icon">${getLucideIcon('clipboardList', 16)}</span>
            <span>${isAr ? '\u062a\u0642\u0631\u064a\u0631 \u0648\u0632\u0627\u0631\u0629 \u0627\u0644\u0635\u062d\u0629 (MOH Report)' : 'MOH Report'}</span>
          </button>
          <button type="button" class="sidebar-sub-tab sidebar-sub-tab-dashboard ${(typeof currentDashboardSubTab !== 'undefined' ? currentDashboardSubTab : 'avh') === 'body_fluid_injury' ? 'active' : ''}" data-subtab="body_fluid_injury" onclick="switchDashboardSubTab('body_fluid_injury')">
            <span class="sub-tab-icon">${getLucideIcon('shieldAlert', 16)}</span>
            <span>${isAr ? '\u062a\u0642\u0631\u064a\u0631 \u062d\u0648\u0627\u062f\u062b \u0627\u0644\u0648\u062e\u0632 \u0648\u0632\u0645\u0646 \u0627\u0644\u0627\u0633\u062a\u062c\u0627\u0628\u0629' : 'Injury & Response Time Report'}</span>
          </button>
        </div>
      ` : ''}

      <!-- 6. DETAILED VACCINATION REPORTS & EXCEL SYNC -->
      ${window.authManager && window.authManager.hasPermission('vaccinationReports') ? `
        <button type="button" class="sidebar-nav-tab ${activeNavTab === 'vaccination-reports' ? 'active' : ''}" onclick="switchNav('vaccination-reports')">
          <span class="nav-icon">${getLucideIcon('reports')}</span>
          <span class="nav-text">${t('tab_vaccination_reports')}</span>
        </button>
      ` : ''}

      <!-- 7. SYSTEM ADMINISTRATION & USER AUTHORITIES (SEPARATE WITH DIVIDER) -->
      ${window.authManager && (window.authManager.currentUser.role === 'admin' || window.authManager.hasPermission('systemManagement')) ? `
        <div class="sidebar-nav-divider" role="separator" aria-orientation="horizontal"></div>
        <button type="button" class="sidebar-nav-tab ${activeNavTab === 'system-management' ? 'active' : ''}" onclick="switchNav('system-management')">
          <span class="nav-icon">${getLucideIcon('settings')}</span>
          <span class="nav-text">${isAr ? '\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0646\u0638\u0627\u0645 \u0648\u0635\u0644\u0627\u062d\u064a\u0627\u062a \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645\u064a\u0646' : 'System Administration'}</span>
        </button>
      ` : ''}
    </nav>

    <div class="sidebar-footer">
      <div class="sidebar-75-logo-container">
        <img src="assets/75_years_logo.png" alt="75 Years - 75 \u0639\u0627\u0645\u0627\u064b \u0648\u0645\u0633\u062a\u0645\u0631\u0648\u0646" class="sidebar-75-logo" />
      </div>
      <div class="sidebar-badge-item iso">
        <span class="badge-icon">${getLucideIcon('globe', 14)}</span> ISO 9001:2015 CERTIFIED
      </div>
    </div>
  `;
}

function renderTopBar() {
  const topBarContainer = document.getElementById('portalTopBar') || document.getElementById('portalTopbar');
  if (!topBarContainer) return;
  const user = window.authManager ? window.authManager.currentUser : { name: 'User', role: 'staff', department: 'Clinical' };
  const t = key => window.i18n.t(key);

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const tabTitles = {
    'portal-home': '🏥 ' + (isAr ? 'الصفحة الرئيسية للبوابة' : 'Portal Home Screen'),
    'dashboard': '📊 ' + t('tab_dashboard'),
    'staff-entry': '👥 ' + t('tab_staff_entry'),
    'vaccination-forms': '💉 ' + t('tab_vaccination_forms'),
    'injury-report': '⚠️ ' + t('tab_injury_report'),
    'vaccination-reports': '📈 ' + t('tab_vaccination_reports'),
    'vaccination-certificate': '📜 ' + t('tab_vaccination_certificate'),
    'system-management': '⚙️ ' + t('tab_system_management')
  };

  topBarContainer.innerHTML = `
    <div class="topbar-content">
      <div style="display: flex; align-items: center; gap: 12px;">
        <button type="button" class="mobile-menu-btn" onclick="toggleMobileSidebar()" aria-label="Toggle Navigation Menu">
          <span>☰</span> ${t('menu_toggle')}
        </button>

        <div class="topbar-title">
          <h2>${tabTitles[activeNavTab] || t('unit_name')}</h2>
        </div>
      </div>

      <div class="topbar-user-controls">
        <!-- CLINICAL APPOINTMENT ALARM BELL IN TOPBAR -->
        ${(() => {
          if (typeof window.getClinicalAppointmentSummary === 'function') {
            const s = window.getClinicalAppointmentSummary();
            if (s && (s.overdueCount > 0 || s.todayCount > 0)) {
              return `
                <button type="button" class="btn btn-outline btn-sm" onclick="switchNav('followup-calendar')" title="${isAr ? 'إنذار المواعيد السريرية المعلقة' : 'Clinical Appointments Alarm'}" style="background: #FEF2F2; border: 1.5px solid #FCA5A5; color: #DC2626; font-weight: 800; display: inline-flex; align-items: center; gap: 5px; cursor: pointer;">
                  <span>🚨</span>
                  <span>${s.overdueCount + s.todayCount}</span>
                </button>
              `;
            }
          }
          return '';
        })()}

        <!-- BILINGUAL LANGUAGE SWITCHER BUTTON -->
        <button type="button" class="btn btn-neutral btn-sm" onclick="window.i18n.toggleLanguage()">
          ${t('lang_btn_text')}
        </button>

        <div class="user-badge">
          <span>👤</span>
          <div>
            <strong>${user.name || user.username}</strong>
            <div style="font-size: 0.72rem; color: var(--text-muted);">${user.department || 'Hospital'}</div>
          </div>
          <span class="role-pill role-${user.role}">${t('role_' + user.role) || user.role}</span>
        </div>

        <button class="btn btn-danger btn-sm" onclick="handleLogout()">🔒 ${t('logout_btn')}</button>
      </div>
    </div>
  `;
}

function toggleMobileSidebar(forceState) {
  const sidebar = document.getElementById('portalSidebar');
  const overlay = document.getElementById('sidebarOverlay');
  if (!sidebar) return;

  const shouldOpen = typeof forceState === 'boolean' ? forceState : !sidebar.classList.contains('open');
  if (shouldOpen) {
    sidebar.classList.add('open');
    if (overlay) overlay.classList.add('active');
  } else {
    sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('active');
  }
}

function updateSidebarActiveState() {
  renderSidebar();
  renderTopBar();
}

function renderMissingRendererDiagnostic(container, moduleKey, expectedFn, scriptFile) {
  console.error(`[Navigation Error] Missing renderer for module "${moduleKey}". Expected global function "${expectedFn}()" from "${scriptFile}".`);
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  container.innerHTML = `
    <div class="card" style="border-top: 4px solid #DC2626; padding: 24px; margin: 20px 0; background: #FEF2F2; border-radius: 8px;">
      <h3 style="color: #991B1B; margin: 0 0 8px 0;">
        ${isAr ? 'تعذر تحميل النموذج / الشاشة المطلوبة' : 'Module Loading Error'}
      </h3>
      <p style="color: #7F1D1D; margin: 4px 0 0 0; font-size: 0.9rem;">
        ${isAr ? `دالة العرض البرمجية (${expectedFn}) غير متوفرة في النظام.` : `The required renderer function (${expectedFn}) is not available.`}
      </p>
      <div style="display: flex; gap: 10px; margin-top: 16px;">
        <button class="btn btn-primary" onclick="switchNav('${moduleKey}')">
          ${isAr ? '🔄 إعادة المحاولة' : '🔄 Retry'}
        </button>
        <button class="btn btn-outline" onclick="switchNav('dashboard')">
          ${isAr ? '🏠 العودة للرئيسية' : '🏠 Return to Dashboard'}
        </button>
      </div>
    </div>
  `;
}
window.renderMissingRendererDiagnostic = renderMissingRendererDiagnostic;

function renderPortalHomeScreen(container) {
  container.innerHTML = `
    <div class="portal-home-container" style="max-width: 1400px; margin: 0 auto; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 10px 0 24px 0;">
      <!-- HERO OPEN PICTURE BANNER CARD -->
      <div class="card" style="padding: 0; overflow: hidden; border: 2px solid #E0F2FE; border-radius: 16px; box-shadow: 0 10px 30px -5px rgba(2, 132, 199, 0.14), 0 8px 12px -6px rgba(2, 132, 199, 0.08); background: #ffffff; width: 100%; display: flex; justify-content: center; align-items: center;">
        <div style="width: 100%; position: relative; background: #F8FAFC; min-height: 300px; display: flex; justify-content: center; align-items: center; overflow: hidden;">
          <img src="assets/welcome_banner.jpg?v=20261024_HOME_V2" 
               alt="Augusta Victoria Hospital - Staff Health & Occupational Health" 
               style="width: 100%; height: auto; max-height: calc(100vh - 200px); object-fit: contain; object-position: center; display: block;"
               onerror="this.onerror=null; this.src='assets/branded_header_75.png';">
        </div>
      </div>
    </div>
  `;
}
window.renderPortalHomeScreen = renderPortalHomeScreen;

function switchNav(tabKey, keepStaff = true) {
  const staffTabs = ['staff-entry', 'vaccination-forms', 'injury-report', 'vaccination-certificate'];
  const isTargetStaffTab = staffTabs.includes(tabKey);

  // Preserve globally selected staff across staff-related clinical screens
  if (!keepStaff && !isTargetStaffTab) {
    if (typeof activeEmpIndex !== 'undefined') activeEmpIndex = -1;
    if (typeof activeInjuryEmpIndex !== 'undefined') activeInjuryEmpIndex = -1;
    if (typeof activeEmpPersonNo !== 'undefined') activeEmpPersonNo = '';
    if (typeof currentEditingEmpNo !== 'undefined') currentEditingEmpNo = null;
    if (typeof vacSearchQuery !== 'undefined') vacSearchQuery = '';
    if (typeof injurySearchQuery !== 'undefined') injurySearchQuery = '';
    if (typeof certSearchQuery !== 'undefined') certSearchQuery = '';
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(null);
    }
  }
  if (window.authManager && window.authManager.isLoggedIn) {
    let allowed = true;
    if (tabKey === 'vaccination-forms' && !window.authManager.hasPermission('vaccinationForms')) allowed = false;
    if (tabKey === 'injury-report' && !window.authManager.hasPermission('injuryReport')) allowed = false;
    if (tabKey === 'vaccination-reports' && !window.authManager.hasPermission('vaccinationReports')) allowed = false;
    if (tabKey === 'vaccination-certificate' && !window.authManager.hasPermission('certificateGenerator')) allowed = false;
    if (tabKey === 'system-management' && !window.authManager.hasPermission('systemManagement')) allowed = false;

    if (!allowed) {
      if (typeof showSuccessToast === 'function') {
        showSuccessToast('Access Denied: You do not have permission to view this module.', 'Access Restricted / غير مصرح');
      } else {
        alert('⛔ Access Denied: You do not have permission to view this module.');
      }
      tabKey = 'portal-home';
    }
  }

  activeNavTab = tabKey;
  const cat = getCategoryForTab(tabKey);
  if (cat) {
    openSidebarCategories[cat] = true;
  }
  toggleMobileSidebar(false);
  updateSidebarActiveState();

  const mainArea = document.getElementById('mainAppArea');
  if (!mainArea) return;

  try {
    switch (tabKey) {
      case 'portal-home':
      case 'home':
        mainArea.innerHTML = '';
        renderPortalHomeScreen(mainArea);
        break;

      case 'dashboard':
        mainArea.innerHTML = '';
        if (typeof window.renderDashboardOverview === 'function') {
          window.renderDashboardOverview(mainArea);
        } else if (typeof renderDashboardOverview === 'function') {
          renderDashboardOverview(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'dashboard', 'renderDashboardOverview', 'js/dashboard.js');
        }
        break;

      case 'staff-entry':
        mainArea.innerHTML = '';
        if (typeof window.renderStaffEntryForm === 'function') {
          window.renderStaffEntryForm(mainArea);
        } else if (typeof renderStaffEntryForm === 'function') {
          renderStaffEntryForm(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'staff-entry', 'renderStaffEntryForm', 'js/staffEntryForm.js');
        }
        break;

      case 'vaccination-forms':
        mainArea.innerHTML = '';
        if (typeof window.renderVaccinationForm === 'function') {
          window.renderVaccinationForm(mainArea);
        } else if (typeof renderVaccinationForm === 'function') {
          renderVaccinationForm(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'vaccination-forms', 'renderVaccinationForm', 'js/vaccinationForm.js');
        }
        break;

      case 'injury-report':
        mainArea.innerHTML = '';
        if (typeof currentInjurySubTab !== 'undefined' && currentInjurySubTab === 'periodic_log' && typeof window.renderPeriodicIncidentLog === 'function') {
          window.renderPeriodicIncidentLog(mainArea);
        } else if (typeof window.renderInjuryReportForm === 'function') {
          window.renderInjuryReportForm(mainArea);
        } else if (typeof renderInjuryReportForm === 'function') {
          renderInjuryReportForm(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'injury-report', 'renderInjuryReportForm', 'js/injuryForm.js');
        }
        break;

      case 'vaccination-reports':
        mainArea.innerHTML = '';
        if (typeof window.renderVaccinationReports === 'function') {
          window.renderVaccinationReports(mainArea);
        } else if (typeof renderVaccinationReports === 'function') {
          renderVaccinationReports(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'vaccination-reports', 'renderVaccinationReports', 'js/reports.js');
        }
        break;

      case 'vaccination-certificate':
        mainArea.innerHTML = '';
        if (typeof window.renderVaccinationCertificate === 'function') {
          window.renderVaccinationCertificate(mainArea);
        } else if (typeof renderVaccinationCertificate === 'function') {
          renderVaccinationCertificate(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'vaccination-certificate', 'renderVaccinationCertificate', 'js/certificate.js');
        }
        break;

            case 'followup-calendar':
        mainArea.innerHTML = '';
        if (typeof window.renderFollowupCalendar === 'function') {
          window.renderFollowupCalendar(mainArea);
        } else if (typeof renderFollowupCalendar === 'function') {
          renderFollowupCalendar(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'followup-calendar', 'renderFollowupCalendar', 'js/followupCalendar.js');
        }
        break;

      case 'system-management':
        mainArea.innerHTML = '';
        if (typeof window.renderSystemManagementReport === 'function') {
          window.renderSystemManagementReport(mainArea);
        } else if (typeof renderSystemManagementReport === 'function') {
          renderSystemManagementReport(mainArea);
        } else {
          renderMissingRendererDiagnostic(mainArea, 'system-management', 'renderSystemManagementReport', 'js/systemManagement.js');
        }
        break;

      default:
        mainArea.innerHTML = '';
        switchNav('dashboard');
    }
  } catch (error) {
    console.error(`[Navigation Error] Screen render crashed for "${tabKey}":`, error);
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    mainArea.innerHTML = `
      <div class="card" style="border-top: 4px solid #DC2626; padding: 24px; margin: 20px 0; background: #FEF2F2; border-radius: 8px;">
        <h3 style="color: #991B1B; margin: 0 0 8px 0;">${isAr ? 'خطأ أثناء تنفيذ عرض الشاشة' : 'Screen Rendering Error'}</h3>
        <p style="color: #7F1D1D; margin: 4px 0 0 0; font-size: 0.9rem;">${error.message || String(error)}</p>
        <div style="display: flex; gap: 10px; margin-top: 16px;">
          <button class="btn btn-primary" onclick="switchNav('${tabKey}')">${isAr ? '🔄 إعادة المحاولة' : '🔄 Retry'}</button>
          <button class="btn btn-outline" onclick="switchNav('dashboard')">${isAr ? '🏠 العودة للرئيسية' : '🏠 Return to Dashboard'}</button>
        </div>
      </div>
    `;
  }
}
window.switchNav = switchNav;

function switchDashboardSubTab(subTab) {
  if (typeof currentDashboardSubTab !== 'undefined') {
    currentDashboardSubTab = subTab;
  }
  window.currentDashboardSubTab = subTab;
  toggleMobileSidebar(false);
  activeNavTab = 'dashboard';
  renderSidebar();
  renderTopBar();
  const mainArea = document.getElementById('mainAppArea');
  if (mainArea && typeof renderDashboardOverview === 'function') {
    renderDashboardOverview(mainArea);
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
window.switchDashboardSubTab = switchDashboardSubTab;

function switchInjurySubTab(subTab) {
  if (typeof currentInjurySubTab !== 'undefined') {
    currentInjurySubTab = subTab;
  }
  window.currentInjurySubTab = subTab;
  toggleMobileSidebar(false);
  activeNavTab = 'injury-report';
  renderSidebar();
  renderTopBar();
  const mainArea = document.getElementById('mainAppArea');
  if (mainArea) {
    if (subTab === 'periodic_log' && typeof renderPeriodicIncidentLog === 'function') {
      renderPeriodicIncidentLog(mainArea);
    } else if (typeof renderInjuryReportForm === 'function') {
      renderInjuryReportForm(mainArea);
    }
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
window.switchInjurySubTab = switchInjurySubTab;

function switchSystemMgmtSubTab(subTab) {
  window.currentSysMgmtSubTab = subTab;
  toggleMobileSidebar(false);
  activeNavTab = 'system-management';
  renderSidebar();
  renderTopBar();
  const mainArea = document.getElementById('mainAppArea');
  if (mainArea && typeof renderSystemManagementReport === 'function') {
    renderSystemManagementReport(mainArea);
  }
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
window.switchSystemMgmtSubTab = switchSystemMgmtSubTab;

function selectSubTabFromSidebar(subKey) {
  toggleMobileSidebar(false);
  if (typeof currentSubTab !== 'undefined') {
    currentSubTab = subKey;
  }
  if (activeNavTab !== 'vaccination-forms') {
    activeNavTab = 'vaccination-forms';
    renderSidebar();
    renderTopBar();
  }
  const mainArea = document.getElementById('mainAppArea');
  if (typeof renderVaccinationForm === 'function' && mainArea) {
    renderVaccinationForm(mainArea);
  }
  renderSidebar();
}
window.selectSubTabFromSidebar = selectSubTabFromSidebar;

function triggerCloudSync() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const syncBtn = document.getElementById('global_cloud_sync_btn');
  const originalText = syncBtn ? syncBtn.innerHTML : '';

  if (syncBtn) {
    syncBtn.disabled = true;
    syncBtn.innerHTML = `⏳ ${isAr ? 'جاري التزامن...' : 'Syncing...'}`;
  }

  if (window.googleSheetsSync && typeof window.googleSheetsSync.syncAllDataFromGoogleSheets === 'function') {
    window.googleSheetsSync.syncAllDataFromGoogleSheets()
      .then(employees => {
        if (employees && employees.length > 0) {
          alert(isAr 
            ? '✅ تم تحديث وجلب ' + employees.length + ' سجل من جوجل درايف وشيت بنجاح وعرضها في البرنامج!' 
            : '✅ Successfully loaded ' + employees.length + ' staff records from Google Drive / Sheets into the dashboard!');
          switchNav(activeNavTab);
        } else {
          alert(isAr 
            ? 'ℹ️ الاتصال بجوجل درايف نشط ومستعد لجلب وتخزين كافة البيانات.' 
            : 'ℹ️ Google Drive connection is active and ready for read/write sync.');
        }
      })
      .catch(error => {
        console.error('Cloud sync failed:', error);
        alert(isAr 
          ? '❌ فشلت عملية المزامنة السحابية. تم الاحتفاظ ببياناتك المحلية دون تغيير.' 
          : '❌ Cloud synchronization failed. Your local data has been preserved.');
      })
      .finally(() => {
        if (syncBtn) {
          syncBtn.disabled = false;
          syncBtn.innerHTML = originalText || `🔄 ${isAr ? 'تزامن من السحابة' : 'Cloud Sync'}`;
        }
      });
  } else {
    if (syncBtn) {
      syncBtn.disabled = false;
      syncBtn.innerHTML = originalText || `🔄 ${isAr ? 'تزامن من السحابة' : 'Cloud Sync'}`;
    }
    alert(isAr ? 'ℹ️ خدمة المزامنة غير متاحة حالياً.' : 'ℹ️ Cloud sync service is currently unavailable.');
  }
}
window.triggerCloudSync = triggerCloudSync;

function showSuccessToast(message, title) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const defaultTitle = isAr ? 'تم تنفيذ العملية بنجاح 🟢' : 'ACTION DONE SUCCESSFULLY 🟢';
  const toastTitle = title ? `${title} (Done Successfully)` : defaultTitle;
  const toastMsg = message || (isAr ? 'تم حفظ وتحديث البيانات بنجاح في النظام.' : 'Data saved & updated successfully.');

  let container = document.getElementById('global_toast_container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'global_toast_container';
    container.style.cssText = 'position: fixed; top: 25px; right: 25px; z-index: 999999; display: flex; flex-direction: column; gap: 12px; max-width: 450px; pointer-events: none;';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.style.cssText = `
    background: linear-gradient(135deg, #059669 0%, #047857 100%);
    color: #FFFFFF;
    padding: 16px 20px;
    border-radius: 10px;
    box-shadow: 0 12px 28px -5px rgba(5, 150, 105, 0.45), 0 8px 10px -6px rgba(0, 0, 0, 0.15);
    border-left: 6px solid #34D399;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 0.94rem;
    pointer-events: auto;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 14px;
    opacity: 0;
    transform: translateY(-20px);
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1);
  `;

  toast.innerHTML = `
    <div style="font-size: 1.8rem; line-height: 1; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));">✅</div>
    <div style="flex: 1;">
      <div style="font-weight: 800; font-size: 1.02rem; margin-bottom: 3px; letter-spacing: 0.2px;">${toastTitle}</div>
      <div style="font-size: 0.88rem; opacity: 0.98; line-height: 1.4; font-weight: 600;">${toastMsg}</div>
    </div>
    <div style="font-size: 1.1rem; opacity: 0.8; font-weight: bold; margin-left: 6px;">✕</div>
  `;

  toast.onclick = () => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-20px)';
    setTimeout(() => toast.remove(), 300);
  };

  container.appendChild(toast);

  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
  });

  setTimeout(() => {
    if (toast.parentNode) {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-20px)';
      setTimeout(() => toast.remove(), 300);
    }
  }, 4200);
}
window.showSuccessToast = showSuccessToast;

function showDashboardError(container, message) {
  if (!container) container = document.getElementById('mainAppArea');
  if (!container) return;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  container.innerHTML = `
    <div class="card" style="border-top: 4px solid #DC2626; padding: 28px 24px; text-align: center; margin: 24px 0; background: #FEF2F2; border-radius: 12px;">
      <div style="font-size: 2.2rem; margin-bottom: 8px;">⚠️</div>
      <h3 style="color: #991B1B; margin: 0 0 8px 0; font-size: 1.25rem; font-weight: 800;">
        ${isAr ? 'تعذر تحميل هذه الشاشة' : 'Unable to Load Screen'}
      </h3>
      <p style="color: #7F1D1D; font-size: 0.9rem; margin: 0 0 18px 0;">
        ${message || (isAr ? 'حدث خطأ غير متوقع أثناء تحميل هذا القسم.' : 'An unexpected error occurred.')}
      </p>
      <button class="btn btn-primary" style="background: #0F766E; border-color: #0F766E; font-weight: bold; padding: 9px 20px; font-size: 0.9rem; cursor: pointer; border-radius: 6px; color: white;" onclick="window.location.reload()">
        🔄 ${isAr ? 'إعادة تحميل الشاشة' : 'Reload'}
      </button>
    </div>
  `;
}
window.showDashboardError = showDashboardError;
