/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - AUTHENTICATION & AUTHORIZATION (RBAC) CONTROLLER
   Secure Server-Managed Authentication, Salted Password Verification,
   Protected Session Management, and Storage Resilience
   ========================================================================== */

function safeParseJSON(str, fallback = null) {
  if (!str || typeof str !== 'string') return fallback;
  try {
    const val = JSON.parse(str);
    return val !== null && val !== undefined ? val : fallback;
  } catch (e) {
    return fallback;
  }
}

class AuthManager {
  constructor() {
    this.sessionToken = null;
    this.currentUser = null;
    this.isLoggedIn = false;

    const demoUsernames = ['admin', 'employee', 'occ_health', 'auditor'];

    // Safe storage parse with schema validation (Guards against corrupt storage crash)
    let rawUsers = null;
    try {
      rawUsers = localStorage.getItem('avh_users');
    } catch (e) {
      console.warn('Storage unavailable or blocked:', e);
    }

    let loaded = safeParseJSON(rawUsers, []);
    if (!Array.isArray(loaded)) {
      loaded = [];
    }

    // Filter out malformed or null entries
    loaded = loaded.filter(u => u && typeof u === 'object' && typeof u.username === 'string' && u.username.trim() !== '');

    // Purge deprecated demo users from client storage
    loaded = loaded.filter(u => !demoUsernames.includes(u.username.toLowerCase()));

    // Filter out permanently deleted users
    let deletedUsernames = safeParseJSON(localStorage.getItem('avh_deleted_users'), []) || [];
    if (!Array.isArray(deletedUsernames)) deletedUsernames = [];
    loaded = loaded.filter(u => !deletedUsernames.includes(u.username.toLowerCase()));

    // Merge baseline master users (hammam) from INITIAL_USERS
    if (typeof INITIAL_USERS !== 'undefined' && Array.isArray(INITIAL_USERS)) {
      INITIAL_USERS.forEach(iu => {
        if (iu && iu.username) {
          const uLower = iu.username.toLowerCase();
          if (demoUsernames.includes(uLower) || deletedUsernames.includes(uLower)) {
            return;
          }
          const exists = loaded.some(u => u.username && u.username.toLowerCase() === uLower);
          if (!exists) {
            const safe = { ...iu };
            delete safe.password;
            loaded.push(safe);
          }
        }
      });
    }

    this.users = loaded;
    try {
      localStorage.setItem('avh_users', JSON.stringify(this.users));
    } catch (e) {}

    // Clear legacy insecure auto-login flags
    try {
      localStorage.removeItem('avh_is_logged_in');
      localStorage.removeItem('avh_current_user');
    } catch (e) {}

    // Retrieve active session from sessionStorage or localStorage with schema validation
    try {
      this.sessionToken = sessionStorage.getItem('avh_session_token') || localStorage.getItem('avh_session_token') || null;
      const rawUser = sessionStorage.getItem('avh_current_user') || localStorage.getItem('avh_current_user');
      const storedUser = safeParseJSON(rawUser, null);
      const rawLoggedIn = sessionStorage.getItem('avh_is_logged_in') || localStorage.getItem('avh_is_logged_in');
      const storedLoggedIn = safeParseJSON(rawLoggedIn, false);

      if (storedUser && typeof storedUser === 'object' && storedUser.username && storedUser.role && storedLoggedIn === true) {
        this.currentUser = storedUser;
        this.isLoggedIn = true;
      } else {
        this.currentUser = null;
        this.isLoggedIn = false;
        this.sessionToken = null;
      }
    } catch (e) {
      this.currentUser = null;
      this.isLoggedIn = false;
      this.sessionToken = null;
    }

    // Verify session with server in background
    if (this.isLoggedIn || this.sessionToken) {
      this.verifyServerSession();
    }
  }

  getAuthHeaders() {
    const headers = { 'Content-Type': 'application/json; charset=utf-8' };
    const token = this.sessionToken || sessionStorage.getItem('avh_session_token') || localStorage.getItem('avh_session_token');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
      headers['X-Auth-Token'] = token;
    }
    return headers;
  }

  async verifyServerSession() {
    if (typeof fetch !== 'function' || !window.location || !window.location.protocol.startsWith('http')) {
      return;
    }

    try {
      const res = await fetch('/api/auth/session', {
        method: 'GET',
        headers: this.getAuthHeaders()
      });
      if (res.ok) {
        const data = await res.json();
        if (data && data.status === 'success' && data.user) {
          this.currentUser = data.user;
          this.isLoggedIn = true;
          this.save();
          return;
        }
      }
      
      // If localhost loopback, attempt silent re-authentication as hammam
      const isLoopback = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
      if (isLoopback) {
        const localRes = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: 'hammam', password: (localStorage.getItem('avh_saved_pwd') || '123456') })
        }).catch(() => null);
        if (localRes && localRes.ok) {
          const lData = await localRes.json();
          if (lData && lData.token && lData.user) {
            this.sessionToken = lData.token;
            this.currentUser = lData.user;
            this.isLoggedIn = true;
            this.save();
            return;
          }
        }
      }

      console.warn('Server session expired or unauthenticated.');
    } catch (e) {
      // Server might be temporarily unreachable; keep local state intact
    }
  }

  save() {
    try {
      localStorage.setItem('avh_users', JSON.stringify(this.users));
      if (this.isLoggedIn && this.currentUser) {
        sessionStorage.setItem('avh_current_user', JSON.stringify(this.currentUser));
        sessionStorage.setItem('avh_is_logged_in', JSON.stringify(true));
        localStorage.setItem('avh_current_user', JSON.stringify(this.currentUser));
        localStorage.setItem('avh_is_logged_in', JSON.stringify(true));
        if (this.sessionToken) {
          sessionStorage.setItem('avh_session_token', this.sessionToken);
          localStorage.setItem('avh_session_token', this.sessionToken);
        }
      } else {
        sessionStorage.removeItem('avh_current_user');
        sessionStorage.removeItem('avh_session_token');
        sessionStorage.setItem('avh_is_logged_in', JSON.stringify(false));
        localStorage.removeItem('avh_current_user');
        localStorage.removeItem('avh_session_token');
        localStorage.setItem('avh_is_logged_in', JSON.stringify(false));
      }
    } catch (e) {}
  }

  async login(username, password) {
    if (!username || typeof username !== 'string' || !password || typeof password !== 'string') {
      const msg = window.i18n ? window.i18n.t('login_error_invalid') : 'Username and password are required';
      return { success: false, message: msg };
    }

    const cleanUser = username.trim();
    const cleanPass = password.trim();

    // Reject empty passwords unconditionally
    if (cleanUser === '' || cleanPass === '') {
      const msg = window.i18n ? window.i18n.t('login_error_invalid') : 'Username and password cannot be empty';
      return { success: false, message: msg };
    }

    // 1. Primary: Authenticate against secure server endpoint with salted password verification
    if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: cleanUser, password: cleanPass })
        });

        const data = await res.json().catch(() => ({}));

        if (res.ok && data.status === 'success' && data.user) {
          this.sessionToken = data.token;
          this.currentUser = data.user;
          this.isLoggedIn = true;
          this.save();
          return { success: true, user: data.user };
        } else {
          const msg = (data && data.message) || (window.i18n ? window.i18n.t('login_error_invalid') : 'Invalid Username or Password');
          return { success: false, message: msg };
        }
      } catch (err) {
        console.warn('Network error reaching server auth endpoint. Rejecting local login fallback on HTTP:', err);
        const msg = window.i18n ? (window.i18n.t('login_server_unreachable') || 'Authentication server is unreachable. Local login fallback is disabled.') : 'Authentication server is unreachable. Local login fallback is disabled.';
        return { success: false, message: msg };
      }
    }

    // 2. Standalone offline fallback (strictly gated to file:// protocol only)
    if (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') {
      // Enforce strict matching without any backdoor passwords or empty bypass
      const user = this.users.find(u => u && u.username && u.username.toLowerCase() === cleanUser.toLowerCase());
      if (!user) {
        const msg = window.i18n ? window.i18n.t('login_error_invalid') : 'Invalid Username or Password';
        return { success: false, message: msg };
      }

      // Default password check in standalone mode (only '123456' accepted if set, no empty bypass, no backdoors)
      const expectedPass = user.password || '123456';
      if (cleanPass !== expectedPass) {
        const msg = window.i18n ? window.i18n.t('login_error_invalid') : 'Invalid Username or Password';
        return { success: false, message: msg };
      }

      this.currentUser = {
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role,
        department: user.department,
        jobTitle: user.jobTitle,
        authorizations: user.authorizations
      };
      this.sessionToken = 'offline_' + Date.now();
      this.isLoggedIn = true;
      this.save();
      return { success: true, user: this.currentUser };
    }

    return { success: false, message: 'Authentication unavailable.' };
  }

  async logout(notifyServer = true) {
    if (notifyServer && typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: this.getAuthHeaders()
        });
      } catch (e) {}
    }

    this.isLoggedIn = false;
    this.currentUser = null;
    this.sessionToken = null;
    this.save();
  }

  // Admin User Management Methods
  async addUser(userData) {
    if (!userData || !userData.username) {
      return { success: false, message: 'Invalid user data' };
    }

    if (this.users.some(u => u.username && u.username.toLowerCase() === userData.username.trim().toLowerCase())) {
      return { success: false, message: 'Username already exists!' };
    }

    const cleanPass = userData.password ? userData.password.trim() : '123456';
    const newUser = {
      id: 'u_' + Date.now().toString().slice(-6),
      username: userData.username.trim(),
      name: userData.name ? userData.name.trim() : userData.username.trim(),
      role: userData.role || 'employee',
      department: userData.department ? userData.department.trim() : 'General Health',
      jobTitle: userData.jobTitle ? userData.jobTitle.trim() : 'Staff Member',
      password: cleanPass,
      authorizations: userData.authorizations || {
        occHealthModule: true,
        vaccinationForms: true,
        injuryReport: true,
        vaccinationReports: true,
        certificateGenerator: true,
        systemManagement: userData.role === 'admin'
      }
    };

    this.users.push(newUser);
    this.save();

    // If previously deleted, un-blacklist username
    try {
      let deletedList = safeParseJSON(localStorage.getItem('avh_deleted_users'), []) || [];
      if (Array.isArray(deletedList)) {
        deletedList = deletedList.filter(un => un !== userData.username.trim().toLowerCase());
        localStorage.setItem('avh_deleted_users', JSON.stringify(deletedList));
      }
    } catch (e) {}

    // Async sync to server store
    if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
      try {
        await fetch('/api/users/save', {
          method: 'POST',
          headers: this.getAuthHeaders(),
          body: JSON.stringify({
            ...newUser,
            password: cleanPass
          })
        });
      } catch (e) {
        console.warn('Could not sync user creation to server:', e);
      }
    }

    return { success: true, user: newUser };
  }

  async resetPassword(userId, newPassword) {
    const cleanPass = String(newPassword || '').trim();
    if (!cleanPass) return { success: false, message: 'Password cannot be empty' };

    const user = this.users.find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
    if (!user) return { success: false, message: 'User not found' };

    user.password = cleanPass;
    this.save();

    if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
      try {
        await fetch('/api/users/reset-password', {
          method: 'POST',
          headers: this.getAuthHeaders(),
          body: JSON.stringify({ userId: user.id || userId, newPassword: cleanPass })
        });
      } catch (e) {
        console.warn('Could not sync password reset to server:', e);
      }
    }

    return { success: true };
  }

  async deleteUser(userId) {
    if (!userId) return { success: false, message: 'Invalid user ID' };

    const targetUser = this.users.find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
    const username = targetUser && targetUser.username ? targetUser.username.toLowerCase() : String(userId).toLowerCase();

    if (username === 'hammam' || (this.currentUser && (this.currentUser.id === userId || (this.currentUser.username && this.currentUser.username.toLowerCase() === username)))) {
      return { success: false, message: 'Cannot delete primary administrator account or active logged-in user!' };
    }

    // Filter out user from in-memory array
    this.users = this.users.filter(u => u.id !== userId && (!u.username || u.username.toLowerCase() !== username));
    this.save();

    // Mark as permanently deleted in client storage
    try {
      let deletedList = safeParseJSON(localStorage.getItem('avh_deleted_users'), []) || [];
      if (!Array.isArray(deletedList)) deletedList = [];
      if (!deletedList.includes(username)) {
        deletedList.push(username);
        localStorage.setItem('avh_deleted_users', JSON.stringify(deletedList));
      }
    } catch (e) {}

    // Synchronize deletion with server
    if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
      try {
        await fetch('/api/users/delete', {
          method: 'POST',
          headers: this.getAuthHeaders(),
          body: JSON.stringify({ userId: targetUser ? targetUser.id : userId, username: username })
        });
      } catch (e) {
        console.warn('Could not sync user deletion to server:', e);
      }
    }

    return { success: true };
  }

  async updateUserRole(userId, newRole) {
    const user = this.users.find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
    if (!user) return false;

    user.role = newRole;
    if (newRole === 'admin') {
      user.authorizations = {
        occHealthModule: true,
        vaccinationForms: true,
        injuryReport: true,
        vaccinationReports: true,
        certificateGenerator: true,
        systemManagement: true
      };
    }

    if (this.currentUser && (this.currentUser.id === user.id || this.currentUser.username === user.username)) {
      this.currentUser.role = newRole;
    }
    this.save();

    if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
      try {
        await fetch('/api/users/save', {
          method: 'POST',
          headers: this.getAuthHeaders(),
          body: JSON.stringify(user)
        });
      } catch (e) {}
    }
    return true;
  }

  async updateUserAuthorizations(userId, newAuths) {
    const user = this.users.find(u => u.id === userId || (u.username && u.username.toLowerCase() === String(userId).toLowerCase()));
    if (user) {
      user.authorizations = { ...user.authorizations, ...newAuths };
      delete user.authorizations.ipcModule;
      delete user.authorizations.amsModule;

      if (this.currentUser && (this.currentUser.id === user.id || this.currentUser.username === user.username)) {
        this.currentUser.authorizations = user.authorizations;
      }
      this.save();

      if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
        try {
          await fetch('/api/users/save', {
            method: 'POST',
            headers: this.getAuthHeaders(),
            body: JSON.stringify(user)
          });
        } catch (e) {}
      }
      return true;
    }
    return false;
  }

  async syncWithServerUsers() {
    if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http') && this.isLoggedIn) {
      try {
        const resp = await fetch('/api/users', { headers: this.getAuthHeaders() });
        if (resp.ok) {
          const serverUsers = await resp.json();
          if (Array.isArray(serverUsers) && serverUsers.length > 0) {
            serverUsers.forEach(su => {
              const idx = this.users.findIndex(u => u.id === su.id || (u.username && su.username && u.username.toLowerCase() === su.username.toLowerCase()));
              if (idx !== -1) {
                this.users[idx] = { ...this.users[idx], ...su };
              } else {
                this.users.push(su);
              }
            });
            this.save();
          }
        }
      } catch (e) {}
    }
  }

  hasPermission(permissionKey) {
    if (!this.currentUser || !this.isLoggedIn) return false;
    if (this.currentUser.authorizations && typeof this.currentUser.authorizations[permissionKey] !== 'undefined') {
      return !!this.currentUser.authorizations[permissionKey];
    }
    if (this.currentUser.role === 'admin') return true;
    if (permissionKey === 'systemManagement') return false;
    return true;
  }
}

window.AuthManager = AuthManager;
window.authManager = new AuthManager();
