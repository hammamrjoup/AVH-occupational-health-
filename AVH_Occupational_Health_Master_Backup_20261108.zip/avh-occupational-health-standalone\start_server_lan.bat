@echo off
title AVH Staff Occupational Health & Vaccination Server (LAN / iPad Access - Port 8085)
cd /d "%~dp0"
echo ==========================================================================
echo   AUGUSTA VICTORIA HOSPITAL - STAFF OCCUPATIONAL HEALTH SYSTEM (LAN ACCESS)
echo ==========================================================================
echo Starting server for Hospital LAN & iPad access on Port 8085 ...
echo.
powershell -ExecutionPolicy Bypass -NoProfile -File .\serve.ps1 -Port 8085 -AllowNetworkAccess
pause
