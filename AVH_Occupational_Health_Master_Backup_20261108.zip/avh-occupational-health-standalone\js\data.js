const AVH_DEPARTMENTS = [
  "Accounting",
  "Anatomical Pathology Department",
  "Anatomical Pathology Department/Tech",
  "Anesthesia / Doctor",
  "Anesthesia / Tech",
  "Apheresis and Bone Marrow Transplant Lab",
  "Billing",
  "Bio- Medical Engineer Unit",
  "Bio- Medical Engineering",
  "Cancer Care Center",
  "CEO Office",
  "Chemotherapy day care",
  "Chief Financial Office",
  "Chief Medical Office",
  "Chief Nursing Office",
  "Chief Operating Office",
  "Clinical Laboratory",
  "Community Outreach programs",
  "Gardening",
  "Gaza Project",
  "Hematology and BMT Department/Nursing",
  "Hematology and Bone Morrow Transplantation Department/ Doctors",
  "Hematopathology ,Cellular Therapy and Applied Genomics Department",
  "Hematomolecular Pathology",
  "Hospital Supervisors Office",
  "Housekeeping",
  "Human Resources Office",
  "Infectious Diseases Unit / Officer",
  "Infectious Diseases Unit Doctors",
  "Information Technology",
  "Intensive Care Unit (Doctors)",
  "Intensive Care Unit / Nursing",
  "Internal Medicine",
  "Internal Medicine Department/ Nursing",
  "Kidney Care Center for Adults",
  "Kidney Care Center for Adults( Doctors)",
  "Kidney Care Center for Adults/Nursing",
  "Kitchen",
  "Laboratory Medicine Department",
  "Long Term Skilled Nursing Department",
  "Long Term Skilled Nursing Department/ Nursing",
  "LWF Gardening",
  "LWF Maintenance",
  "Maintenance",
  "Medical Oncology (Doctors)",
  "Medical Physics",
  "Molecular Laboratory Unit",
  "Nursing Clinics Affairs",
  "Nursing Continuing Education",
  "Nursing Coordinators",
  "Nutrition Unit",
  "Oncology Specialists Doctors",
  "Operation Theater",
  "Palliative Care Department",
  "Patient Affairs Department",
  "Pediatric Hematology- Oncology / Specialists",
  "Pediatric Hematology-Oncology Department/ Nursing",
  "Pediatric Hematology-Oncology/ Doctors",
  "Pediatric Hemodialysis",
  "Pediatric Nephrology & Pediatric Intensive Care Unit/ Nursing",
  "Pediatric Nephrology and Dialysis Department/Doctors",
  "Pediatric Nephrology and Dialysis Department/Specialists",
  "Permits & Logistics Unit",
  "Pharmacy",
  "Physiotherapy Unit",
  "Procurement",
  "Psychosocial Support Unit",
  "Public Services Office",
  "Quality Control Unit",
  "Radiation Oncology Specialists",
  "Radiation Therapy Department",
  "Radiation Therapy Department / Nurses",
  "Radiation Therapy Department / Tech",
  "Radiology / Doctors",
  "Radiology / Tech",
  "Radiology/ Pet",
  "Ramallah Clinic",
  "Secretary Office/ Anatomical Pathology Department",
  "Security",
  "Specialized Child Care Center / Specialist",
  "Surgery Specialist Doctors",
  "Surgical Department / Doctors",
  "Surgical Department / Nursing",
  "Surgical Department / Specialists",
  "Treatment Room and Out-patient Clinics"
];

function getCombinedDepartmentList() {
  const set = new Set(AVH_DEPARTMENTS);
  try {
    const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
    employees.forEach(e => {
      if (!e) return;
      const demo = e.demographic || {};
      const dept = demo.orgName || e.organizationName || demo.organizationName || e['Organization Name'] || demo['Organization Name'] || e.department || demo.deptTreating || demo.department;
      if (dept && typeof dept === 'string' && dept.trim()) {
        set.add(dept.trim());
      }
    });
  } catch(e) {}
  return Array.from(set).filter(Boolean).map(d => String(d).trim()).sort((a, b) => a.localeCompare(b));
}

function getAVHLogoHTML(height = 90) {
  return `
    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; background: transparent; width: 100%;">
      <img src="assets/avh_logo.png" alt="Augusta Victoria Hospital - مستشفى الأوغستا فكتوريا (المُطلع)" style="width: 100%; max-width: 100%; height: auto; max-height: ${height}px; object-fit: contain; display: block; image-rendering: -webkit-optimize-contrast; margin: 0 auto;" />
    </div>
  `;
}

if (typeof window !== 'undefined') {
  window.getAVHLogoHTML = getAVHLogoHTML;
}

function escapeHtmlAttr(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
if (typeof window !== 'undefined') {
  window.escapeHtmlAttr = escapeHtmlAttr;
}

const _dateStrCache = new Map();

function standardizeDateStr(val, strictDateOnly = false) {
  if (val === null || val === undefined) return '';
  const cacheKey = String(val) + '|' + strictDateOnly;
  if (_dateStrCache.has(cacheKey)) {
    return _dateStrCache.get(cacheKey);
  }

  let str = String(val).trim();
  if (!str) {
    _dateStrCache.set(cacheKey, '');
    return '';
  }

  // Preserve text values and status presets (e.g. child hood, Natural Immunity, Positive IGG, etc.)
  if (/child|natural|history|vaccin|declarat|n\/a|not vaccin|no need|positive|negative|igg|immune|mui\/ml|titer/i.test(str)) {
    _dateStrCache.set(cacheKey, str);
    return str;
  }

  let res = str;

  // 1. Check ISO format YYYY-MM-DD or YYYY-MM-DDTHH:mm:ss.sssZ
  let isoMatch = str.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
  if (isoMatch) {
    let [_, year, month, day] = isoMatch;
    day = day.padStart(2, '0');
    month = month.padStart(2, '0');
    res = `${day}/${month}/${year}`;
    _dateStrCache.set(cacheKey, res);
    return res;
  }

  // 2. Check if numeric Excel Serial Date Number (e.g. 39264, 42552, 44317, 38777, 45693)
  if (/^\d{4,5}(\.\d+)?$/.test(str) || (typeof val === 'number' && val > 10000 && val < 60000)) {
    const num = parseFloat(str);
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const utcDays = Math.floor(num);
    const msPerDay = 24 * 60 * 60 * 1000;
    const dateObj = new Date(excelEpoch.getTime() + utcDays * msPerDay);
    if (!isNaN(dateObj.getTime())) {
      const d = String(dateObj.getUTCDate()).padStart(2, '0');
      const m = String(dateObj.getUTCMonth() + 1).padStart(2, '0');
      const y = dateObj.getUTCFullYear();
      res = `${d}/${m}/${y}`;
      _dateStrCache.set(cacheKey, res);
      return res;
    }
  }

  // 3. Check dot format D.M.YYYY or DD.MM.YYYY or D.M.YY (e.g. 25.7.2018, 4.8.2016, 14.6.17)
  let dotMatch = str.match(/^(\d{1,2})\.(\d{1,2})\.(\d{2,4})/);
  if (dotMatch) {
    let [_, day, month, year] = dotMatch;
    if (year.length === 2) {
      year = (parseInt(year, 10) > 30 ? '19' : '20') + year;
    }
    day = day.padStart(2, '0');
    month = month.padStart(2, '0');
    res = `${day}/${month}/${year}`;
    _dateStrCache.set(cacheKey, res);
    return res;
  }

  // 4. Check slash format D/M/YYYY or DD/MM/YYYY or D/M/YY (e.g. 25/7/2018, 4/8/2016, 14/6/17)
  let slashMatch = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
  if (slashMatch) {
    let [_, p1, p2, p3] = slashMatch;
    if (p3.length === 2) {
      p3 = (parseInt(p3, 10) > 30 ? '19' : '20') + p3;
    }
    let day = p1, month = p2, year = p3;
    if (parseInt(p1, 10) <= 12 && parseInt(p2, 10) > 12) {
      day = p2;
      month = p1;
    }
    day = day.padStart(2, '0');
    month = month.padStart(2, '0');
    res = `${day}/${month}/${year}`;
    _dateStrCache.set(cacheKey, res);
    return res;
  }

  // 5. Try standard JS Date parsing fallback (excluding pure words)
  if (/\d/.test(str)) {
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime()) && parsed.getUTCFullYear() > 1900 && parsed.getUTCFullYear() < 2100) {
      const day = String(parsed.getUTCDate()).padStart(2, '0');
      const month = String(parsed.getUTCMonth() + 1).padStart(2, '0');
      const year = parsed.getUTCFullYear();
      res = `${day}/${month}/${year}`;
      _dateStrCache.set(cacheKey, res);
      return res;
    }
  }

  res = strictDateOnly ? '' : str;
  _dateStrCache.set(cacheKey, res);
  return res;
}

function formatDateDDMMYYYY(dateStr) {
  return standardizeDateStr(dateStr);
}

function formatDate(dateStr, strictDateOnly = false) {
  return standardizeDateStr(dateStr, strictDateOnly);
}

function formatAgeToOneDecimal(val) {
  if (val === null || val === undefined || val === '') return '';
  let str = String(val).trim();
  if (!str) return '';
  const match = str.match(/^(\d+(\.\d+)?)/);
  if (match) {
    const num = parseFloat(match[1]);
    if (!isNaN(num)) {
      const formatted = num.toFixed(1);
      const suffix = str.replace(match[0], '');
      return formatted + suffix;
    }
  }
  return str;
}

function addDaysToDateStr(dateStr, days = 3) {
  if (!dateStr) return '';
  let str = String(dateStr).trim();
  if (!str) return '';
  let day, month, year;
  const parts = str.split(/[\/\-\.]/);
  if (parts.length === 3) {
    if (parts[0].length === 4) {
      year = parseInt(parts[0], 10);
      month = parseInt(parts[1], 10) - 1;
      day = parseInt(parts[2], 10);
    } else {
      day = parseInt(parts[0], 10);
      month = parseInt(parts[1], 10) - 1;
      year = parseInt(parts[2], 10);
    }
    if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
      const d = new Date(year, month, day);
      if (!isNaN(d.getTime())) {
        d.setDate(d.getDate() + days);
        const dd = String(d.getDate()).padStart(2, '0');
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const yyyy = d.getFullYear();
        return `${dd}/${mm}/${yyyy}`;
      }
    }
  }
  return str;
}

if (typeof window !== 'undefined') {
  window.formatDate = formatDate;
  window.formatDateDDMMYYYY = formatDateDDMMYYYY;
  window.getCurrentDateDDMMYYYY = getCurrentDateDDMMYYYY;
  window.standardizeDateStr = standardizeDateStr;
  window.formatAgeToOneDecimal = formatAgeToOneDecimal;
  window.addDaysToDateStr = addDaysToDateStr;
}

function getCurrentDateDDMMYYYY() {
  const d = new Date();
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}/${month}/${year}`;
}

const INITIAL_USERS = [
  {
    id: "u_hammam",
    username: "hammam",
    name: "Hammam Rjoup",
    role: "admin",
    department: "Hospital Administration",
    jobTitle: "System Administrator",
    authorizations: {
      occHealthModule: true,
      vaccinationForms: true,
      injuryReport: true,
      vaccinationReports: true,
      certificateGenerator: true,
      systemManagement: true
    }
  }
];

let _masterEmployeesList = null;

function deepMergeEmployeeObjects(target, source, overwriteWithBlanks = false) {
  if (!target && !source) return {};
  if (!target) return JSON.parse(JSON.stringify(source));
  if (!source) return JSON.parse(JSON.stringify(target));

  const targetUpdated = target.updated_at ? new Date(target.updated_at).getTime() : 0;
  const sourceUpdated = source.updated_at ? new Date(source.updated_at).getTime() : 0;
  
  // If source is newer by timestamp or explicit form update, source wins
  const shouldOverwrite = overwriteWithBlanks || (sourceUpdated > targetUpdated && sourceUpdated > 0);

  const result = JSON.parse(JSON.stringify(target));

  const isValueNonEmpty = (val) => {
    if (val === null || val === undefined) return false;
    if (typeof val === 'string') return val.trim().length > 0 && val.trim() !== 'N/A';
    if (typeof val === 'boolean') return true;
    if (typeof val === 'number') return !isNaN(val);
    if (Array.isArray(val)) return val.length > 0;
    if (typeof val === 'object') return Object.keys(val).length > 0;
    return true;
  };

  const mergeSubObject = (resObj, srcObj) => {
    if (!srcObj || typeof srcObj !== 'object') return;
    Object.keys(srcObj).forEach(key => {
      const srcVal = srcObj[key];
      if (Array.isArray(srcVal)) {
        if (srcVal.length > 0 || shouldOverwrite) {
          resObj[key] = JSON.parse(JSON.stringify(srcVal));
        }
      } else if (srcVal && typeof srcVal === 'object') {
        if (!resObj[key] || typeof resObj[key] !== 'object') resObj[key] = {};
        mergeSubObject(resObj[key], srcVal);
      } else {
        if (shouldOverwrite || isValueNonEmpty(srcVal)) {
          resObj[key] = srcVal;
        }
      }
    });
  };

  mergeSubObject(result, source);

  // Preserve canonical covidFluRecords if source provides them
  if (Array.isArray(source.covidFluRecords)) {
    result.covidFluRecords = JSON.parse(JSON.stringify(source.covidFluRecords));
  } else if (source.covidFlu && Array.isArray(source.covidFlu.covidFluRecords)) {
    result.covidFluRecords = JSON.parse(JSON.stringify(source.covidFlu.covidFluRecords));
  }

  // Synchronize MMR, IPV, Tdap and Core Vaccines
  if (!result.vaccines) result.vaccines = {};
  if (source.vaccines?.mmrDose1 !== undefined || source.mmrDose1 !== undefined) {
    const val1 = source.vaccines?.mmrDose1 !== undefined ? source.vaccines.mmrDose1 : source.mmrDose1;
    result.vaccines.mmrDose1 = val1;
    result.mmrDose1 = val1;
    if (!result.vaccines.MMR) result.vaccines.MMR = {};
    result.vaccines.MMR.d1 = val1;
  }
  if (source.vaccines?.mmrDose2 !== undefined || source.mmrDose2 !== undefined) {
    const val2 = source.vaccines?.mmrDose2 !== undefined ? source.vaccines.mmrDose2 : source.mmrDose2;
    result.vaccines.mmrDose2 = val2;
    result.mmrDose2 = val2;
    if (!result.vaccines.MMR) result.vaccines.MMR = {};
    result.vaccines.MMR.d2 = val2;
  }
  if (source.vaccines?.ipvDate !== undefined || source.ipvDate !== undefined) {
    const vIpv = source.vaccines?.ipvDate !== undefined ? source.vaccines.ipvDate : source.ipvDate;
    result.vaccines.ipvDate = vIpv;
    result.ipvDate = vIpv;
    if (!result.vaccines.IPV) result.vaccines.IPV = {};
    result.vaccines.IPV.d1 = vIpv;
    result.vaccines.IPV.d5 = vIpv;
  }
  if (source.vaccines?.tdapDate !== undefined || source.tdapDate !== undefined) {
    const vTdap = source.vaccines?.tdapDate !== undefined ? source.vaccines.tdapDate : source.tdapDate;
    result.vaccines.tdapDate = vTdap;
    result.tdapDate = vTdap;
    if (!result.vaccines.Tdap) result.vaccines.Tdap = {};
    result.vaccines.Tdap.d1 = vTdap;
    result.vaccines.Tdap.d5 = vTdap;
  }

  // Synchronize COVID-19 doses if present in source
  if (source.covidDose1Date !== undefined || source.covidFlu?.covidDose1Date !== undefined || source.vaccines?.['Covid - 19']?.d1 !== undefined) {
    const cd1 = source.covidDose1Date || source.covidFlu?.covidDose1Date || source.vaccines?.['Covid - 19']?.d1 || '';
    const cp1 = source.covidDose1Batch || source.covidFlu?.covidDose1Batch || source.vaccines?.['Covid - 19']?.p1 || '';
    const cd2 = source.covidDose2Date || source.covidFlu?.covidDose2Date || source.vaccines?.['Covid - 19']?.d2 || '';
    const cp2 = source.covidDose2Batch || source.covidFlu?.covidDose2Batch || source.vaccines?.['Covid - 19']?.p2 || '';
    const cd3 = source.covidDose3Date || source.covidFlu?.covidDose3Date || source.vaccines?.['Covid - 19']?.d3 || '';
    const cp3 = source.covidDose3Batch || source.covidFlu?.covidDose3Batch || source.vaccines?.['Covid - 19']?.p3 || '';
    const cd4 = source.covidDose4Date || source.covidFlu?.covidDose4Date || '';
    const cp4 = source.covidDose4Batch || source.covidFlu?.covidDose4Batch || '';

    result.covidDose1Date = cd1; result.covidDose1Batch = cp1;
    result.covidDose2Date = cd2; result.covidDose2Batch = cp2;
    result.covidDose3Date = cd3; result.covidDose3Batch = cp3;
    result.covidDose4Date = cd4; result.covidDose4Batch = cp4;

    if (!result.covidFlu) result.covidFlu = {};
    result.covidFlu.covidDose1Date = cd1; result.covidFlu.covidDose1Batch = cp1;
    result.covidFlu.covidDose2Date = cd2; result.covidFlu.covidDose2Batch = cp2;
    result.covidFlu.covidDose3Date = cd3; result.covidFlu.covidDose3Batch = cp3;
    result.covidFlu.covidDose4Date = cd4; result.covidFlu.covidDose4Batch = cp4;

    if (!result.vaccines['Covid - 19']) result.vaccines['Covid - 19'] = {};
    result.vaccines['Covid - 19'].d1 = cd1;
    result.vaccines['Covid - 19'].p1 = cp1;
    result.vaccines['Covid - 19'].d2 = cd2;
    result.vaccines['Covid - 19'].p2 = cp2;
    result.vaccines['Covid - 19'].d3 = cd3;
    result.vaccines['Covid - 19'].p3 = cp3;
  }

  // Synchronize key top-level properties with demographic sub-object
  const demo = result.demographic || {};
  if (demo.personNumber && !result.empNo) result.empNo = demo.personNumber;
  if (result.empNo && !demo.personNumber) demo.personNumber = result.empNo;
  if (demo.nationalId && !result.idNo) result.idNo = demo.nationalId;
  if (result.idNo && !demo.nationalId) demo.nationalId = result.idNo;
  if (demo.fullName && !result.name) result.name = demo.fullName;
  if (result.name && !demo.fullName) demo.fullName = result.name;
  if (demo.positionName && !result.jobTitle) result.jobTitle = demo.positionName;
  if (result.jobTitle && !demo.positionName) demo.positionName = result.jobTitle;
  if (demo.department && !result.department) result.department = demo.department;
  if (result.department && !demo.department) demo.department = result.department;

  // Sync canonical vaccination records with legacy fields
  if (typeof syncCanonicalRecordsToLegacyFields === 'function') {
    const canonical = typeof getCanonicalVaccineRecords === 'function' ? getCanonicalVaccineRecords(result) : (result.covidFluRecords || []);
    syncCanonicalRecordsToLegacyFields(result, canonical);
  }

  // Preserve timestamps
  result.updated_at = source.updated_at || target.updated_at || new Date().toISOString();
  result.created_at = target.created_at || source.created_at || new Date().toISOString();
  result.last_synced_at = source.last_synced_at || target.last_synced_at || '';
  result.sync_status = source.sync_status || target.sync_status || 'Synced';

  result.demographic = demo;
  return result;
}

function getNormalizedEmpKey(emp) {
  if (!emp) return '';

  const demo = emp.demographic || {};

  const idNo = String(
    emp.idNo ||
    demo.nationalId ||
    ''
  )
  .replace(/^0+/, '')
  .trim();

  const empNo = String(
    emp.empNo ||
    emp.id ||
    demo.personNumber ||
    ''
  )
  .replace(/^EMP-/i, '')
  .replace(/^0+/, '')
  .trim();

  const name = String(
    emp.name ||
    demo.fullName ||
    demo.arabicFullName ||
    ''
  )
  .trim()
  .toLowerCase()
  .replace(/[^a-z0-9\u0600-\u06FF]/g, '');

  if (
    idNo &&
    idNo.toLowerCase() !== 'n/a' &&
    idNo.toLowerCase() !== 'undefined' &&
    idNo.toLowerCase() !== 'null' &&
    idNo !== '0'
  ) {
    return 'ID:' + idNo;
  }

  if (
    empNo &&
    empNo.toLowerCase() !== 'n/a' &&
    empNo.toLowerCase() !== 'undefined' &&
    empNo.toLowerCase() !== 'null' &&
    empNo !== '0'
  ) {
    return 'EMP:' + empNo;
  }

  return '';
}

function getEmpKeys(emp) {
  if (!emp) return [];
  const demo = emp.demographic || {};
  const keys = [];

  const idNo = String(emp.idNo || demo.nationalId || '').replace(/^0+/, '').trim();
  if (idNo && idNo.toLowerCase() !== 'n/a' && idNo.toLowerCase() !== 'undefined' && idNo.toLowerCase() !== 'null' && idNo !== '0') {
    keys.push('ID:' + idNo);
  }

  const empNo = String(emp.empNo || emp.id || demo.personNumber || '').replace(/^EMP-/i, '').replace(/^0+/, '').trim();
  if (empNo && empNo.toLowerCase() !== 'n/a' && empNo.toLowerCase() !== 'undefined' && empNo.toLowerCase() !== 'null' && empNo !== '0') {
    keys.push('EMP:' + empNo);
  }

  // Never match or merge different employees merely based on shared names
  return keys;
}

function isTestOrDemoRecord(emp) {
  if (!emp || typeof emp !== 'object') return true;
  const demo = emp.demographic || {};
  const name = String(emp.name || demo.fullName || demo.arabicFullName || '').trim();
  const empNo = String(emp.empNo || emp.id || demo.personNumber || '').trim();
  const idNo = String(emp.idNo || demo.nationalId || '').trim();

  // A record is only excluded if it has no name, no employee number, and no ID (empty shell)
  if (!name && !empNo && !idNo) {
    return true;
  }
  return false;
}
window.isTestOrDemoRecord = isTestOrDemoRecord;

function deduplicateEmployeeArray(arr) {
  if (!Array.isArray(arr)) return [];
  const result = [];
  const keyToEmpMap = new Map();

  arr.forEach(emp => {
    if (!emp || isTestOrDemoRecord(emp)) return;

    const keys = getEmpKeys(emp);
    let matchedEmp = null;

    for (const k of keys) {
      if (keyToEmpMap.has(k)) {
        matchedEmp = keyToEmpMap.get(k);
        break;
      }
    }

    if (matchedEmp) {
      const matchedTime = matchedEmp.updated_at ? new Date(matchedEmp.updated_at).getTime() : 0;
      const empTime = emp.updated_at ? new Date(emp.updated_at).getTime() : 0;
      const merged = (empTime > matchedTime)
        ? deepMergeEmployeeObjects(matchedEmp, emp, true)
        : deepMergeEmployeeObjects(emp, matchedEmp, true);
      const newKeys = getEmpKeys(merged);
      newKeys.forEach(k => keyToEmpMap.set(k, merged));
      const idx = result.indexOf(matchedEmp);
      if (idx !== -1) {
        result[idx] = merged;
      }
    } else {
      result.push(emp);
      keys.forEach(k => keyToEmpMap.set(k, emp));
    }
  });

  return result;
}

function mergeMasterEmployeeLists(baseList, incomingList) {
  if (!Array.isArray(baseList)) baseList = [];
  if (!Array.isArray(incomingList) || incomingList.length === 0) return deduplicateEmployeeArray(baseList);

  const combined = [...baseList, ...incomingList];
  return deduplicateEmployeeArray(combined);
}

async function fetchMasterEmployeesFromBackend() {
  const baseMaster = (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) ? AVH_MASTER_EXCEL_EMPLOYEES : [];
  let localList = getParsedLocalStorageEmployees();

  // 1. AUTHORITATIVE SOURCE: Query central SQLite database via /api/employees FIRST
  if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
    try {
      const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
        ? window.authManager.getAuthHeaders()
        : { 'Content-Type': 'application/json; charset=utf-8' };
      const res = await fetch('/api/employees', { headers: authHeaders });
      if (res.ok) {
        const data = await res.json();
        const list = Array.isArray(data) ? data : (data.data || []);
        if (Array.isArray(list) && list.length > 0) {
          const cleanList = list.filter(e => {
            if (!e || typeof e !== 'object') return false;
            const num = String(e.employeeNumber || e.empNo || e.id || (e.demographic && e.demographic.personNumber) || '').trim();
            const name = String(e.name || e.fullName || (e.demographic && e.demographic.fullName) || '').trim();
            const idNo = String(e.idNo || e.nationalId || (e.demographic && e.demographic.nationalId) || '').trim();
            if (!num && !idNo && !name) return false;
            return true;
          });
          
          if (cleanList.length > 0) {
            _masterEmployeesList = cleanList;
            // Update reference array
            if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
              AVH_MASTER_EXCEL_EMPLOYEES.length = 0;
              cleanList.forEach(e => AVH_MASTER_EXCEL_EMPLOYEES.push(e));
            }
            // Update IndexedDB offline cache
            if (typeof EmployeeIndexedDB !== 'undefined') {
              EmployeeIndexedDB.putBatch(cleanList).catch(e => console.warn("Cache sync putBatch warn:", e));
            }
            // Update LocalStorage cache for immediate synchronous accessibility
            try {
              localStorage.setItem('avh_employees', JSON.stringify(cleanList));
              _lastLocalEmployeesStr = null;
              _lastParsedLocalEmployees = null;
            } catch(e) {}
            invalidateEmployeesCache(false);
            return cleanList;
          }
        }
      }
    } catch (err) {
      console.warn("Central /api/employees fetch error, falling back to local storage cache:", err);
    }
  }

  // 2. Offline / disconnected fallback: IndexedDB cache
  if (typeof EmployeeIndexedDB !== 'undefined') {
    try {
      const idbList = await EmployeeIndexedDB.getAll();
      if (Array.isArray(idbList) && idbList.length > 0) {
        _masterEmployeesList = idbList;
        invalidateEmployeesCache(false);
        return idbList;
      }
    } catch (idbErr) {
      console.warn("IndexedDB cache read fallback error:", idbErr);
    }
  }

  // 3. Last fallback: Seed master list merged with local storage
  const defaultMerged = localList.length > 0 ? mergeMasterEmployeeLists(baseMaster, localList) : baseMaster;
  _masterEmployeesList = deduplicateEmployeeArray(defaultMerged);
  return _masterEmployeesList;
}

let _lastLocalEmployeesStr = null;
let _lastParsedLocalEmployees = null;

function getParsedLocalStorageEmployees() {
  try {
    const raw = localStorage.getItem('avh_employees');
    if (!raw) return [];
    if (raw === _lastLocalEmployeesStr && Array.isArray(_lastParsedLocalEmployees)) {
      return _lastParsedLocalEmployees;
    }
    _lastLocalEmployeesStr = raw;
    const parsed = JSON.parse(raw);
    let list = Array.isArray(parsed) ? parsed : [];
    const cleaned = list.filter(e => {
      if (!e || typeof e !== 'object') return false;
      const num = String(e.employeeNumber || e.empNo || e.id || (e.demographic && e.demographic.personNumber) || '').trim();
      const name = String(e.name || e.fullName || (e.demographic && e.demographic.fullName) || '').trim();
      const idNo = String(e.idNo || e.nationalId || (e.demographic && e.demographic.nationalId) || '').trim();
      if (!num && !idNo && !name) return false;
      return true;
    });
    if (cleaned.length !== list.length) {
      // Legacy cleanup - no longer writes back to localStorage to avoid quota errors
    }
    _lastParsedLocalEmployees = cleaned;
    return _lastParsedLocalEmployees;
  } catch (e) {
    return [];
  }
}

function getEmployeeKey(emp) {
  if (!emp) return '';
  const demo = emp.demographic || {};
  const empNo = String(
    emp.empNo ||
    emp.id ||
    emp.personNumber ||
    demo.personNumber ||
    ''
  ).trim();

  if (empNo && empNo.toLowerCase() !== 'n/a') {
    return 'EMP:' + empNo;
  }

  const nationalId = String(
    emp.idNo ||
    emp.nationalId ||
    demo.nationalId ||
    ''
  ).trim();

  if (nationalId && nationalId.toLowerCase() !== 'n/a') {
    return 'ID:' + nationalId;
  }

  return '';
}
if (typeof window !== 'undefined') {
  window.getEmployeeKey = getEmployeeKey;
}

if (typeof window === 'undefined') {
  window = {};
}
if (!window._employeesCacheVersion) {
  window._employeesCacheVersion = 1;
}

/**
 * Safely converts clinical and lab values (strings, numbers, null, undefined) to strings.
 * Preserves 0 as "0". Rejects unexpected objects (does not return "[object Object]").
 */
function toSafeLabString(value) {
  if (value === null || value === undefined) {
    return '';
  }
  if (typeof value === 'number') {
    if (Number.isNaN(value)) return '';
    return String(value).trim();
  }
  if (typeof value === 'object') {
    // If it's a wrapper object with result/value/titer/induration property, extract the primitive
    if (value.result !== undefined && value.result !== null && typeof value.result !== 'object') {
      return toSafeLabString(value.result);
    }
    if (value.value !== undefined && value.value !== null && typeof value.value !== 'object') {
      return toSafeLabString(value.value);
    }
    if (value.titer !== undefined && value.titer !== null && typeof value.titer !== 'object') {
      return toSafeLabString(value.titer);
    }
    if (value.induration !== undefined && value.induration !== null && typeof value.induration !== 'object') {
      return toSafeLabString(value.induration);
    }
    // Any unexpected or generic object: do NOT convert to "[object Object]"
    return '';
  }
  return String(value ?? '').trim();
}

/**
 * Returns the first defined, non-empty candidate value while strictly preserving 0.
 */
function getFirstDefinedLabValue(...candidates) {
  for (let i = 0; i < candidates.length; i++) {
    const val = candidates[i];
    if (val === undefined || val === null) continue;
    if (typeof val === 'number') {
      if (!Number.isNaN(val)) return val;
      continue;
    }
    if (typeof val === 'object') {
      const inner = val.result !== undefined && val.result !== null ? val.result :
                    (val.value !== undefined && val.value !== null ? val.value :
                    (val.titer !== undefined && val.titer !== null ? val.titer : undefined));
      if (inner !== undefined && inner !== null && typeof inner !== 'object') {
        const s = String(inner ?? '').trim();
        if (s !== '') return inner;
      }
    } else {
      const s = String(val ?? '').trim();
      if (s !== '') return val;
    }
  }
  return '';
}

if (typeof window !== 'undefined') {
  window.toSafeLabString = toSafeLabString;
  window.getFirstDefinedLabValue = getFirstDefinedLabValue;
}

function getUniqueEmployees() {
  if (
    typeof window !== 'undefined' &&
    Array.isArray(window._cachedUniqueEmployees) &&
    window._cachedUniqueEmployees.length > 0 &&
    window._cachedEmployeesCacheVersion === window._employeesCacheVersion
  ) {
    return window._cachedUniqueEmployees;
  }

  const baseMaster = (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) ? AVH_MASTER_EXCEL_EMPLOYEES : [];
  const localData = getParsedLocalStorageEmployees();

  let list = _masterEmployeesList;
  if (!list || !Array.isArray(list) || list.length === 0) {
    list = localData.length > 0 ? mergeMasterEmployeeLists(baseMaster, localData) : baseMaster;
    _masterEmployeesList = list;
  } else if (localData.length > 0) {
    list = mergeMasterEmployeeLists(list, localData);
    _masterEmployeesList = list;
  }

  const deduped = deduplicateEmployeeArray(list);

  // Standardize employee properties for seamless searching and data auto-filling
  const result = new Array(deduped.length);
  const indexMap = new Map();

  for (let i = 0; i < deduped.length; i++) {
    const e = deduped[i];
    if (!e) {
      result[i] = {};
      continue;
    }
    const demo = e.demographic || {};
    const empDataEmployment = e.employment || {};
    const nameStr = String(e.name || demo.fullName || demo.arabicFullName || 'Staff Member').trim();
    const idStr = String(e.idNo || demo.nationalId || 'N/A').trim();
    const empStr = String(e.empNo || e.id || demo.personNumber || 'N/A').trim();
    const dobStr = String(demo.dob || demo.dateOfBirth || e.dob || '').trim();
    const orgStr = String(demo.orgName || e.organizationName || demo.organizationName || e['Organization Name'] || demo['Organization Name'] || empDataEmployment.organizationName || empDataEmployment.orgName || e.orgName || '').trim();
    const deptStr = (orgStr || String(e.department || demo.department || empDataEmployment.department || demo.deptTreating || 'Hospital Staff')).trim();
    const treatingStr = String(demo.deptTreating || e.deptTreating || '').trim();
    const jobStr = String(e.jobTitle || demo.positionName || demo.positionArabic || empDataEmployment.jobTitle || 'Healthcare Staff').trim();
    const groupStr = String(e.staffGroup || demo.staffGroup || empDataEmployment.staffGroup || 'Extended Program').trim();
    const invStr = String(demo.invasiveProcedure || e.invasiveProcedure || '').trim();
    const invClean = (invStr.toLowerCase() === 'yes' || invStr.toLowerCase() === 'true') ? 'Yes' : (invStr.toLowerCase() === 'no' || invStr.toLowerCase() === 'false') ? 'No' : '';
    const finalInv = invClean || (typeof window.isInvasiveProcedureStaff === 'function' && window.isInvasiveProcedureStaff(e) ? 'Yes' : 'No');
    const statusStr = String(e.employmentStatus || demo.employmentStatus || e.workStatus || demo.workStatus || empDataEmployment.status || 'Active Staff').trim() || 'Active Staff';

    const rawLab = (e.labResults && typeof e.labResults === 'object') ? e.labResults : ((e.lab && typeof e.lab === 'object') ? e.lab : {});
    let hbsabRaw = '';
    if (rawLab.hbsabResult !== undefined && rawLab.hbsabResult !== null) {
      hbsabRaw = rawLab.hbsabResult;
    } else if (rawLab.hbsAb !== undefined && rawLab.hbsAb !== null) {
      hbsabRaw = rawLab.hbsAb;
    } else if (e.hepbTiter !== undefined && e.hepbTiter !== null) {
      hbsabRaw = e.hepbTiter;
    } else if (e.HBsAb !== undefined && e.HBsAb !== null) {
      hbsabRaw = e.HBsAb;
    }
    const hbsabResult = toSafeLabString(hbsabRaw);
    const rawHbsabDate = getFirstDefinedLabValue(rawLab.hbsabDate, rawLab.hbsAbDate, e.hbsabDate, (e.HBsAb && typeof e.HBsAb === 'object' ? e.HBsAb.date : ''));
    const hbsabDate = (hbsabResult !== '') ? toSafeLabString(rawHbsabDate) : '';

    const engrixDose1 = toSafeLabString(getFirstDefinedLabValue(rawLab.engrixDose1, e.engrixDose1));
    const engrixDose2 = toSafeLabString(getFirstDefinedLabValue(rawLab.engrixDose2, e.engrixDose2));
    const engrixDose3 = toSafeLabString(getFirstDefinedLabValue(rawLab.engrixDose3, e.engrixDose3));
    const engrixBooster = toSafeLabString(getFirstDefinedLabValue(rawLab.engrixBooster, e.engrixBooster, e.hbvBoosterDate));

    const hbsagRaw = getFirstDefinedLabValue(rawLab.hbsagResult, rawLab.hbsAg, e.hbsagResult, e.hbsAg, e.HBsAg);
    const hbsagResult = toSafeLabString(hbsagRaw);
    const rawHbsagDate = getFirstDefinedLabValue(rawLab.hbsagDate, rawLab.hbsAgDate, e.hbsagDate, e.hbsAgDate, (e.HBsAg && typeof e.HBsAg === 'object' ? e.HBsAg.date : ''));
    const hbsagDate = (hbsagResult !== '') ? toSafeLabString(rawHbsagDate) : '';

    const hcvRaw = getFirstDefinedLabValue(rawLab.hcvResult, rawLab.hcv, e.hcvResult, e.hcv, e.HCV);
    const hcvResult = toSafeLabString(hcvRaw);
    const rawHcvDate = getFirstDefinedLabValue(rawLab.hcvDate, e.hcvDate, (e.HCV && typeof e.HCV === 'object' ? e.HCV.date : ''));
    const hcvDate = (hcvResult !== '') ? toSafeLabString(rawHcvDate) : '';

    const hivRaw = getFirstDefinedLabValue(rawLab.hivResult, rawLab.hiv, e.hivResult, e.hiv, e.HIV);
    const hivResult = toSafeLabString(hivRaw);
    const rawHivDate = getFirstDefinedLabValue(rawLab.hivDate, e.hivDate, (e.HIV && typeof e.HIV === 'object' ? e.HIV.date : ''));
    const hivDate = (hivResult !== '') ? toSafeLabString(rawHivDate) : '';

    const ppdStep1ResultRaw = getFirstDefinedLabValue(rawLab.ppdStep1Result, e.ppdStep1Result, e.ppdResult, (e.PPD && typeof e.PPD === 'object' ? e.PPD.result1 : ''));
    const ppdStep1Result = toSafeLabString(ppdStep1ResultRaw);
    const ppdStep1IndurationRaw = getFirstDefinedLabValue(rawLab.ppdStep1Induration, e.ppdStep1Induration, (e.PPD && typeof e.PPD === 'object' ? e.PPD.ind1 : ''));
    const ppdStep1Induration = toSafeLabString(ppdStep1IndurationRaw);
    const rawPpdStep1Date = getFirstDefinedLabValue(rawLab.ppdStep1Date, e.ppdStep1Date, (e.PPD && typeof e.PPD === 'object' ? e.PPD.date1 : ''));
    const ppdStep1Date = (ppdStep1Result !== '' || (ppdStep1Induration !== '' && ppdStep1Induration !== '0mm')) ? toSafeLabString(rawPpdStep1Date) : '';

    const ppdStep2ResultRaw = getFirstDefinedLabValue(rawLab.ppdStep2Result, e.ppdStep2Result, (e.PPD && typeof e.PPD === 'object' ? e.PPD.result2 : ''));
    const ppdStep2Result = toSafeLabString(ppdStep2ResultRaw);
    const ppdStep2IndurationRaw = getFirstDefinedLabValue(rawLab.ppdStep2Induration, e.ppdStep2Induration, (e.PPD && typeof e.PPD === 'object' ? e.PPD.ind2 : ''));
    const ppdStep2Induration = toSafeLabString(ppdStep2IndurationRaw);
    const rawPpdStep2Date = getFirstDefinedLabValue(rawLab.ppdStep2Date, e.ppdStep2Date, (e.PPD && typeof e.PPD === 'object' ? e.PPD.date2 : ''));
    const ppdStep2Date = (ppdStep2Result !== '' || (ppdStep2Induration !== '' && ppdStep2Induration !== '0mm')) ? toSafeLabString(rawPpdStep2Date) : '';

    const varicellaIgGRaw = getFirstDefinedLabValue(rawLab.varicellaIgG, (e.vaccines ? e.vaccines.varicellaIgG : undefined), e.varicellaIgG, e.Varicella_IgG);
    const varicellaIgG = toSafeLabString(varicellaIgGRaw);
    const varicellaIgGDate = toSafeLabString(getFirstDefinedLabValue(rawLab.varicellaIgGDate, rawLab.varicellaDate, (e.vaccines ? e.vaccines.varicellaIgGDate : undefined), e.varicellaIgGDate, e.varicellaDate, (e.Varicella_IgG && typeof e.Varicella_IgG === 'object' ? e.Varicella_IgG.date : '')));

    const mumpsIgGTiterRaw = getFirstDefinedLabValue(rawLab.mumpsIgG, rawLab.mumpsIgGTiter, e.mumpsIgG, e.mumpsIgGTiter, e.Mumps_IgG);
    const mumpsIgGTiter = toSafeLabString(mumpsIgGTiterRaw);
    const mumpsIgGTiterDate = toSafeLabString(getFirstDefinedLabValue(rawLab.mumpsIgGDate, rawLab.mumpsIgGTiterDate, e.mumpsIgGDate, e.mumpsIgGTiterDate, (e.Mumps_IgG && typeof e.Mumps_IgG === 'object' ? e.Mumps_IgG.date : '')));

    const measlesIgGTiterRaw = getFirstDefinedLabValue(rawLab.measlesIgG, rawLab.measlesIgGTiter, e.measlesIgG, e.measlesIgGTiter, e.Measles_IgG);
    const measlesIgGTiter = toSafeLabString(measlesIgGTiterRaw);
    const measlesIgGTiterDate = toSafeLabString(getFirstDefinedLabValue(rawLab.measlesIgGDate, rawLab.measlesIgGTiterDate, e.measlesIgGDate, e.measlesIgGTiterDate, (e.Measles_IgG && typeof e.Measles_IgG === 'object' ? e.Measles_IgG.date : '')));

    const rubellaIgGTiterRaw = getFirstDefinedLabValue(rawLab.rubellaIgG, rawLab.rubellaIgGTiter, e.rubellaIgG, e.rubellaIgGTiter, e.Rubella_IgG);
    const rubellaIgGTiter = toSafeLabString(rubellaIgGTiterRaw);
    const rubellaIgGTiterDate = toSafeLabString(getFirstDefinedLabValue(rawLab.rubellaIgGDate, rawLab.rubellaIgGTiterDate, e.rubellaIgGDate, e.rubellaIgGTiterDate, (e.Rubella_IgG && typeof e.Rubella_IgG === 'object' ? e.Rubella_IgG.date : '')));

    const otherLabResultRaw = getFirstDefinedLabValue(rawLab.otherLabResult, e.otherLabResult);
    const otherLabResult = toSafeLabString(otherLabResultRaw);
    const otherLabDate = (otherLabResult !== '') ? toSafeLabString(getFirstDefinedLabValue(rawLab.otherLabDate, e.otherLabDate)) : '';

    const normalizedLab = {
      ...rawLab,
      hbsAg: hbsagResult,
      hbsAgDate: hbsagDate,
      hbsagResult: hbsagResult,
      hbsagDate: hbsagDate,
      hbsAb: hbsabResult,
      hbsAbDate: hbsabDate,
      hbsabResult: hbsabResult,
      hbsabDate: hbsabDate,
      hcv: hcvResult,
      hcvResult: hcvResult,
      hcvDate: hcvDate,
      hiv: hivResult,
      hivResult: hivResult,
      hivDate: hivDate,
      mumpsIgG: mumpsIgGTiter,
      mumpsIgGDate: mumpsIgGTiterDate,
      mumpsIgGTiter: mumpsIgGTiter,
      mumpsIgGTiterDate: mumpsIgGTiterDate,
      measlesIgG: measlesIgGTiter,
      measlesIgGDate: measlesIgGTiterDate,
      measlesIgGTiter: measlesIgGTiter,
      measlesIgGTiterDate: measlesIgGTiterDate,
      rubellaIgG: rubellaIgGTiter,
      rubellaIgGDate: rubellaIgGTiterDate,
      rubellaIgGTiter: rubellaIgGTiter,
      rubellaIgGTiterDate: rubellaIgGTiterDate,
      varicellaIgG: varicellaIgG,
      varicellaIgGDate: varicellaIgGDate,
      engrixDose1,
      engrixDose2,
      engrixDose3,
      engrixBooster,
      ppdStep1Result,
      ppdStep1Induration,
      ppdStep1Date,
      ppdStep2Result,
      ppdStep2Induration,
      ppdStep2Date,
      otherLabResult,
      otherLabDate
    };

    const genderRaw = demo.gender || e.gender || '';
    const isMaleGender = /^(male|m|ذكر)$/i.test(String(genderRaw).trim());
    const clData = { ...(e.preVaccinationChecklist || e.checklist || {}) };
    if (isMaleGender) {
      clData.q3 = 'N/A';
      clData.q4 = 'N/A';
    }
    const healthStatusData = { ...(e.healthStatus || {}) };
    if (isMaleGender) {
      healthStatusData.pregnancyStatus = 'Not Pregnant / N/A';
    }

    // Comprehensive vaccine & immunity field extraction from nested and root sources
    const rawVac = e.vaccines || {};
    const rawSp = e.specialVaccines || {};
    const rawCf = e.covidFlu || {};

    const ipvDate = rawVac.ipvDate || e.ipvDate || (rawVac.IPV ? (rawVac.IPV.d5 || rawVac.IPV.d1) : '') || '';
    const tdapDate = rawVac.tdapDate || e.tdapDate || (rawVac.Tdap ? (rawVac.Tdap.d5 || rawVac.Tdap.d1) : '') || '';
    const mmrDose1 = rawVac.mmrDose1 || e.mmrDose1 || (rawVac.MMR ? rawVac.MMR.d1 : '') || '';
    const mmrDose2 = rawVac.mmrDose2 || e.mmrDose2 || (rawVac.MMR ? (rawVac.MMR.d2 || rawVac.MMR.d5) : '') || '';
    const chickenpoxStatus = rawVac.chickenpoxStatus || e.chickenpoxStatus || (rawVac['Varicella Zoster (Chicken pox)'] ? '2 doses vaccine' : '') || '';
    const chickenpoxDose1 = rawVac.chickenpoxDose1 || e.chickenpoxDose1 || '';
    const chickenpoxDose2 = rawVac.chickenpoxDose2 || e.chickenpoxDose2 || '';
    const finalVaricellaIgG = rawVac.varicellaIgG || varicellaIgG || e.varicellaIgG || '';
    const finalVaricellaDate = rawVac.varicellaIgGDate || varicellaIgGDate || e.varicellaIgGDate || '';

    const meningococcal = rawSp.meningococcal || e.meningococcal || '';
    const hepA1 = rawSp.hepA1 || e.hepA1 || '';
    const hepA2 = rawSp.hepA2 || e.hepA2 || '';
    const typhoid = rawSp.typhoid || e.typhoid || '';
    const pneumovax = rawSp.pneumovax || rawSp.pnemovax || e.pneumovax || e.pnemovax || '';

    const finalImmunityStatus = e.immunityStatus || (demo && demo.immunityStatus) || 'Pending Verification';

    const covD1 = rawCf.covidDose1Date || e.covidDose1Date || (rawVac['Covid - 19'] ? rawVac['Covid - 19'].d1 : '') || '';
    const covP1 = rawCf.covidDose1Batch || e.covidDose1Batch || (rawVac['Covid - 19'] ? rawVac['Covid - 19'].p1 : '') || '';
    const covD2 = rawCf.covidDose2Date || e.covidDose2Date || (rawVac['Covid - 19'] ? rawVac['Covid - 19'].d2 : '') || '';
    const covP2 = rawCf.covidDose2Batch || e.covidDose2Batch || (rawVac['Covid - 19'] ? rawVac['Covid - 19'].p2 : '') || '';
    const covD3 = rawCf.covidDose3Date || e.covidDose3Date || (rawVac['Covid - 19'] ? rawVac['Covid - 19'].d3 : '') || '';
    const covP3 = rawCf.covidDose3Batch || e.covidDose3Batch || (rawVac['Covid - 19'] ? rawVac['Covid - 19'].p3 : '') || '';

    const normalizedVac = {
      ...rawVac,
      ipvDate,
      tdapDate,
      mmrDose1,
      mmrDose2,
      MMR: {
        d1: mmrDose1,
        d2: mmrDose2
      },
      IPV: {
        d1: ipvDate,
        d5: ipvDate
      },
      Tdap: {
        d1: tdapDate,
        d5: tdapDate
      },
      'Covid - 19': {
        d1: covD1,
        p1: covP1,
        d2: covD2,
        p2: covP2,
        d3: covD3,
        p3: covP3
      },
      chickenpoxStatus,
      chickenpoxDose1,
      chickenpoxDose2,
      varicellaIgG: finalVaricellaIgG,
      varicellaIgGDate: finalVaricellaDate
    };

    const normalizedSp = {
      ...rawSp,
      meningococcal,
      hepA1,
      hepA2,
      typhoid,
      pneumovax,
      pnemovax: pneumovax
    };

    const normalized = {
      ...e,
      name: nameStr,
      idNo: idStr,
      empNo: empStr,
      id: empStr,
      dob: dobStr,
      department: deptStr,
      organizationName: orgStr || deptStr,
      orgName: orgStr || deptStr,
      jobTitle: jobStr,
      staffGroup: groupStr,
      invasiveProcedure: finalInv,
      employmentStatus: statusStr,
      immunityStatus: finalImmunityStatus,
      hepbTiter: hbsabResult,
      hbsabDate,
      hbsAb: hbsabResult,
      hbsAbDate: hbsabDate,
      hbsAg: hbsagResult,
      hbsagResult: hbsagResult,
      hbsAgDate: hbsagDate,
      hbsagDate: hbsagDate,
      hcv: hcvResult,
      hcvResult: hcvResult,
      hcvDate: hcvDate,
      hiv: hivResult,
      hivResult: hivResult,
      hivDate: hivDate,
      engrixDose1,
      engrixDose2,
      engrixDose3,
      engrixBooster,
      hbvBoosterDate: engrixBooster,
      ppdStep1Result,
      ppdStep1Induration,
      ppdStep1Date,
      ppdStep2Result,
      ppdStep2Induration,
      ppdStep2Date,
      varicellaIgG: finalVaricellaIgG,
      varicellaIgGDate: finalVaricellaDate,
      ipvDate,
      tdapDate,
      mmrDose1,
      mmrDose2,
      chickenpoxStatus,
      chickenpoxDose1,
      chickenpoxDose2,
      meningococcal,
      hepA1,
      hepA2,
      typhoid,
      pneumovax,
      pnemovax: pneumovax,
      vaccines: normalizedVac,
      specialVaccines: normalizedSp,
      mumpsIgG: mumpsIgGTiter,
      mumpsIgGDate: mumpsIgGTiterDate,
      mumpsIgGTiter,
      mumpsIgGTiterDate,
      measlesIgG: measlesIgGTiter,
      measlesIgGDate: measlesIgGTiterDate,
      measlesIgGTiter,
      measlesIgGTiterDate,
      rubellaIgG: rubellaIgGTiter,
      rubellaIgGDate: rubellaIgGTiterDate,
      rubellaIgGTiter,
      rubellaIgGTiterDate,
      otherLabResult,
      otherLabDate,
      labResults: normalizedLab,
      lab: normalizedLab,
      preVaccinationChecklist: clData,
      checklist: clData,
      healthStatus: healthStatusData,
      demographic: {
        ...demo,
        fullName: demo.fullName || nameStr,
        arabicFullName: demo.arabicFullName || '',
        nationalId: demo.nationalId || idStr,
        personNumber: demo.personNumber || empStr,
        dob: demo.dob || demo.dateOfBirth || dobStr,
        dateOfBirth: demo.dateOfBirth || demo.dob || dobStr,
        gender: demo.gender || e.gender || '',
        age: demo.age || e.age || '',
        deptTreating: (treatingStr === 'babies under 1 years' || treatingStr === 'Employees in oncology, hematooncology') ? treatingStr : '',
        invasiveProcedure: finalInv,
        employmentStatus: statusStr,
        immunityStatus: finalImmunityStatus,
        department: demo.department || deptStr,
        positionName: demo.positionName || jobStr,
        assignmentEffectiveDate: demo.assignmentEffectiveDate || e.assignEffectiveDate || '',
        staffGroup: groupStr
      },
      employment: {
        ...empDataEmployment,
        department: empDataEmployment.department || deptStr,
        unit: empDataEmployment.unit || treatingStr,
        jobTitle: empDataEmployment.jobTitle || jobStr,
        profession: empDataEmployment.profession || jobStr,
        staffGroup: empDataEmployment.staffGroup || groupStr,
        status: empDataEmployment.status || statusStr,
        joiningDate: empDataEmployment.joiningDate || demo.startDate || e.startDate || ''
      }
    };

    if (typeof syncCanonicalRecordsToLegacyFields === 'function') {
      const canonical = typeof getCanonicalVaccineRecords === 'function' ? getCanonicalVaccineRecords(normalized) : (normalized.covidFluRecords || []);
      syncCanonicalRecordsToLegacyFields(normalized, canonical);
    }

    result[i] = normalized;
    if (empStr && empStr !== 'N/A') indexMap.set(empStr, normalized);
    if (idStr && idStr !== 'N/A') indexMap.set(idStr, normalized);
  }

  if (typeof window !== 'undefined') {
    window._cachedUniqueEmployees = result;
    window._cachedEmpIndexMap = indexMap;
    window._cachedEmployeesCacheVersion = window._employeesCacheVersion;
  }
  return result;
}

function getEmployeeByEmpNo(empNoKey) {
  if (!empNoKey) return null;
  const key = String(empNoKey).trim();
  if (window._cachedEmpIndexMap && window._cachedEmpIndexMap.has(key)) {
    return window._cachedEmpIndexMap.get(key);
  }
  const emps = getUniqueEmployees();
  const cleanKey = key.replace(/^EMP-/i, '').replace(/^0+/, '').toLowerCase();
  return emps.find(e => {
    if (!e) return false;
    const demo = e.demographic || {};
    const eNo = String(e.empNo || e.id || demo.personNumber || '').replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
    const eId = String(e.idNo || demo.nationalId || '').replace(/^0+/, '').trim().toLowerCase();
    return (eNo === cleanKey || eId === cleanKey || String(e.empNo) === key || String(e.id) === key || String(e.idNo) === key);
  }) || null;
}
if (typeof window !== 'undefined') {
  window.getEmployeeByEmpNo = getEmployeeByEmpNo;
}

function invalidateEmployeesCache(resetMasterList = false) {
  if (typeof window !== 'undefined') {
    window._cachedUniqueEmployees = null;
    window._cachedEmpIndexMap = null;
    window._cachedRawEmployeesStr = null;
    window._cachedEmployeesSource = null;
    window._cachedEmployeesCacheVersion = null;
    window._cachedAVHMetrics = null;
    window._cachedAVHMetricsVersion = null;
    window._employeesCacheVersion = (window._employeesCacheVersion || 1) + 1;
  }

  _lastLocalEmployeesStr = null;
  _lastParsedLocalEmployees = null;

  if (Array.isArray(_masterEmployeesList)) {
    _masterEmployeesList.forEach(e => { if (e && e._mohStatusCache) delete e._mohStatusCache; });
  }

  if (resetMasterList === true) {
    _masterEmployeesList = null;
  }
}
window.invalidateEmployeesCache = invalidateEmployeesCache;

async function saveEmployeeToMasterSheet(empData, actionType = null) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const nowIso = new Date().toISOString();

  // Set mandatory timestamps and audit properties
  empData.updated_at = nowIso;
  if (!empData.created_at) empData.created_at = nowIso;
  empData.updated_by = typeof getCurrentSystemUserName === 'function' ? getCurrentSystemUserName() : 'System User';

  // Record audit log entry
  try {
    const logs = JSON.parse(localStorage.getItem('avh_audit_logs')) || [];
    const empNo = empData.empNo || empData.id || 'N/A';
    logs.unshift({
      timestamp: new Date().toLocaleString(),
      user: empData.updated_by,
      personNo: empNo,
      action: actionType === 'update' ? `Updated staff record (${empData.name || empNo})` : `Saved new staff record (${empData.name || empNo})`
    });
    if (logs.length > 200) logs.length = 200;
    localStorage.setItem('avh_audit_logs', JSON.stringify(logs));
  } catch(e) {}

  if (actionType === 'create' || !actionType) {
    empData._isNewStaff = true;
  }

  let syncResult = null;
  let syncSuccess = false;
  let syncError = null;

  try {
    // 1. Save directly to Google Sheets Web App API
    if (window.googleSheetsSync && typeof window.googleSheetsSync.saveEmployeeToGoogleSheets === 'function') {
      syncResult = await window.googleSheetsSync.saveEmployeeToGoogleSheets(empData);
      syncSuccess = !!(syncResult && (syncResult.success === true || syncResult.status === 'success'));
    }
  } catch (error) {
    console.warn("Google Sheets sync attempt warning:", error);
    syncSuccess = false;
    syncError = error ? (error.message || String(error)) : 'Network or configuration error';
  }

  if (syncSuccess) {
    empData.sync_status = 'Synced';
    empData.last_synced_at = new Date().toISOString();
  } else {
    empData.sync_status = 'Pending Sync';
    // Queue record for automatic background retry
    try {
      const queue = JSON.parse(localStorage.getItem('avh_pending_sync_queue')) || [];
      const key = getNormalizedEmpKey(empData);
      const existingIdx = queue.findIndex(item => getNormalizedEmpKey(item) === key);
      if (existingIdx !== -1) {
        queue[existingIdx] = empData;
      } else {
        queue.push(empData);
      }
      localStorage.setItem('avh_pending_sync_queue', JSON.stringify(queue));
    } catch(e) {}
  }

  // Update localStorage with accurate sync_status
  try {
    const employees = getUniqueEmployees();
    const key = getNormalizedEmpKey(empData);
    const idx = employees.findIndex(e => getNormalizedEmpKey(e) === key);
    if (idx !== -1) {
      employees[idx].sync_status = empData.sync_status;
      employees[idx].last_synced_at = empData.last_synced_at;
      employees[idx].updated_at = empData.updated_at;
      if (typeof EmployeeIndexedDB !== 'undefined') {
        EmployeeIndexedDB.put(employees[idx]).catch(() => {});
      }
      if (typeof saveEmployeesToLocalStorage === 'function') {
        saveEmployeesToLocalStorage(employees);
      }
    }
  } catch(e) {}

  // Dual-save to local server endpoint if running on local server
  if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
    try {
      const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
        ? window.authManager.getAuthHeaders()
        : { 'Content-Type': 'application/json; charset=utf-8' };

      const srvRes = await fetch('/api/employees/save', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ actionType, employee: empData })
      });

      if (!srvRes.ok) {
        const srvErr = await srvRes.json().catch(() => ({ message: `HTTP ${srvRes.status}: ${srvRes.statusText}` }));
        throw new Error(srvErr.message || `Server save failed with status ${srvRes.status}`);
      }
    } catch (err) {
      console.warn("Local server /api/employees/save warning:", err);
      // Mark as pending retry queue
      empData.sync_status = 'Pending Sync';
      try {
        const serverQueue = JSON.parse(localStorage.getItem('avh_server_pending_sync_queue')) || [];
        const key = getNormalizedEmpKey(empData);
        const qIdx = serverQueue.findIndex(item => getNormalizedEmpKey(item) === key);
        if (qIdx !== -1) {
          serverQueue[qIdx] = empData;
        } else {
          serverQueue.push(empData);
        }
        localStorage.setItem('avh_server_pending_sync_queue', JSON.stringify(serverQueue));
      } catch (e) {}
    }
  }

  // Invalidate caches and trigger update events across all dashboard views
  invalidateEmployeesCache();
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('staffDataUpdated'));
    window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: getUniqueEmployees().length } }));
  }

  // Asynchronously trigger GitHub repository auto-commit if GitHub Sync is connected
  if (window.githubSync && window.githubSync.isConnected()) {
    window.githubSync.syncMasterDatasetToGitHub().catch(err => console.warn("GitHub auto-commit warning:", err));
  }

  return { status: syncSuccess ? 'success' : 'pending', success: syncSuccess, error: syncError, employee: empData, syncResult };
}

async function processPendingSyncQueue() {
  try {
    const queue = JSON.parse(localStorage.getItem('avh_pending_sync_queue')) || [];
    if (!Array.isArray(queue) || queue.length === 0) return;
    if (!window.googleSheetsSync || typeof window.googleSheetsSync.saveEmployeeToGoogleSheets !== 'function') return;

    const remaining = [];
    for (const item of queue) {
      try {
        const res = await window.googleSheetsSync.saveEmployeeToGoogleSheets(item);
        if (res && (res.success === true || res.status === 'success')) {
          item.sync_status = 'Synced';
          item.last_synced_at = new Date().toISOString();
          // Update in local store
          const employees = getUniqueEmployees();
          const key = getNormalizedEmpKey(item);
          const idx = employees.findIndex(e => getNormalizedEmpKey(e) === key);
          if (idx !== -1) {
            employees[idx].sync_status = 'Synced';
            employees[idx].last_synced_at = item.last_synced_at;
            saveEmployeesToLocalStorage(employees);
          }
        } else {
          remaining.push(item);
        }
      } catch (err) {
        remaining.push(item);
      }
    }
    localStorage.setItem('avh_pending_sync_queue', JSON.stringify(remaining));
  } catch (e) {}
}

if (typeof window !== 'undefined') {
  window.processPendingSyncQueue = processPendingSyncQueue;
  window.retryPendingSyncs = processPendingSyncQueue;
  window.addEventListener('online', processPendingSyncQueue);
}

async function deleteEmployeeFromMasterSheet(empId) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;

  // Show "Deleting..." status toast
  if (typeof showSuccessToast === 'function') {
    showSuccessToast(
      isAr ? 'جاري الحذف من Google Sheets... ⏳' : 'Deleting from Google Sheets... ⏳',
      isAr ? 'حذف السجل ⏳' : 'Deleting Record ⏳'
    );
  }

  try {
    // 1. Delete from Google Sheets Web App API
    if (window.googleSheetsSync && typeof window.googleSheetsSync.deleteEmployeeFromGoogleSheets === 'function') {
      await window.googleSheetsSync.deleteEmployeeFromGoogleSheets(empId);
    }

    // 2. Dual-delete on local server endpoint if available
    if (typeof fetch === 'function' && window.location && window.location.protocol.startsWith('http')) {
      const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
        ? window.authManager.getAuthHeaders()
        : { 'Content-Type': 'application/json; charset=utf-8' };

      const srvRes = await fetch('/api/employees/delete', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ id: empId })
      });

      if (!srvRes.ok) {
        const srvErr = await srvRes.json().catch(() => ({ message: `HTTP ${srvRes.status}: ${srvRes.statusText}` }));
        const failMsg = srvErr.message || `Server deletion failed with status ${srvRes.status}`;
        throw new Error(failMsg);
      }
    }

    // 2.5 Purge from IndexedDB storage
    if (typeof EmployeeIndexedDB !== 'undefined') {
      const targetClean = String(empId).replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
      await EmployeeIndexedDB.delete('ID:' + targetClean).catch(() => {});
      await EmployeeIndexedDB.delete('EMP:' + targetClean).catch(() => {});
    }

    // 3. Purge normalized matching records from memory master lists
    const targetClean = String(empId).replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
    if (_masterEmployeesList && Array.isArray(_masterEmployeesList)) {
      _masterEmployeesList = _masterEmployeesList.filter(e => {
        if (!e) return false;
        const demo = e.demographic || {};
        const idNo = String(e.idNo || demo.nationalId || '').replace(/^0+/, '').trim().toLowerCase();
        const empNo = String(e.empNo || e.id || demo.personNumber || '').replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
        return idNo !== targetClean && empNo !== targetClean;
      });
    }
    if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
      const filtered = AVH_MASTER_EXCEL_EMPLOYEES.filter(e => {
        if (!e) return false;
        const demo = e.demographic || {};
        const idNo = String(e.idNo || demo.nationalId || '').replace(/^0+/, '').trim().toLowerCase();
        const empNo = String(e.empNo || e.id || demo.personNumber || '').replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
        return idNo !== targetClean && empNo !== targetClean;
      });
      AVH_MASTER_EXCEL_EMPLOYEES.length = 0;
      filtered.forEach(e => AVH_MASTER_EXCEL_EMPLOYEES.push(e));
    }

    // 4. Invalidate caches and trigger update events across all dashboard views
    invalidateEmployeesCache();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('staffDataUpdated'));
      window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: getUniqueEmployees().length } }));
    }

    // 5. Show Success Notification
    const toastTitle = isAr ? 'تم الحذف بنجاح 🔴' : 'Deleted Successfully 🔴';
    const toastBody = isAr ? 'تم حذف السجل مباشرة من Google Sheets.' : 'Record deleted successfully from Google Sheets.';
    
    if (typeof showSuccessToast === 'function') {
      showSuccessToast(toastTitle, toastBody);
    } else {
      console.log(`${toastTitle}: ${toastBody}`);
    }

    return { status: 'success' };

  } catch (error) {
    console.error("Delete from Google Sheets Failed:", error);
    const errMsg = isAr ? `خطأ أثناء الحذف من Google Sheets: ${error.message}` : `Error deleting from Google Sheets: ${error.message}`;
    alert(errMsg);
    throw error;
  }
}

const DB_NAME = 'AVH_OCCUPATIONAL_HEALTH_DB';
const DB_VERSION = 1;
const STORE_EMPLOYEES = 'employees';
const STORE_META = 'meta';
const STORE_SYNC_QUEUE = 'sync_queue';

const EmployeeIndexedDB = {
  dbPromise: null,

  getIDBFactory: function() {
    if (typeof indexedDB !== 'undefined') return indexedDB;
    if (typeof window !== 'undefined' && window.indexedDB) return window.indexedDB;
    if (typeof global !== 'undefined' && global.indexedDB) return global.indexedDB;
    return null;
  },

  open: function() {
    if (this.dbPromise) return this.dbPromise;
    const idb = this.getIDBFactory();
    if (!idb) {
      return Promise.resolve(null);
    }

    this.dbPromise = new Promise((resolve, reject) => {
      try {
        const req = idb.open(DB_NAME, DB_VERSION);

        req.onupgradeneeded = (event) => {
          const db = event.target.result;
          if (!db.objectStoreNames.contains(STORE_EMPLOYEES)) {
            const empStore = db.createObjectStore(STORE_EMPLOYEES, { keyPath: 'storageKey' });
            empStore.createIndex('empNo', 'empNo', { unique: false });
            empStore.createIndex('idNo', 'idNo', { unique: false });
            empStore.createIndex('name', 'name', { unique: false });
            empStore.createIndex('department', 'department', { unique: false });
          }
          if (!db.objectStoreNames.contains(STORE_META)) {
            db.createObjectStore(STORE_META, { keyPath: 'key' });
          }
          if (!db.objectStoreNames.contains(STORE_SYNC_QUEUE)) {
            db.createObjectStore(STORE_SYNC_QUEUE, { keyPath: 'id', autoIncrement: true });
          }
        };

        req.onsuccess = (event) => {
          resolve(event.target.result);
        };

        req.onerror = (event) => {
          console.error("IndexedDB open error:", event.target.error);
          this.dbPromise = null;
          reject(event.target.error);
        };
      } catch (err) {
        this.dbPromise = null;
        reject(err);
      }
    });

    return this.dbPromise;
  },

  getAll: async function() {
    const db = await this.open();
    if (!db) return [];
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_EMPLOYEES, 'readonly');
        const store = tx.objectStore(STORE_EMPLOYEES);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  get: async function(storageKey) {
    if (!storageKey) return null;
    const db = await this.open();
    if (!db) return null;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_EMPLOYEES, 'readonly');
        const store = tx.objectStore(STORE_EMPLOYEES);
        const req = store.get(storageKey);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  count: async function() {
    const db = await this.open();
    if (!db) return 0;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_EMPLOYEES, 'readonly');
        const store = tx.objectStore(STORE_EMPLOYEES);
        const req = store.count();
        req.onsuccess = () => resolve(req.result || 0);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  put: async function(employee) {
    if (!employee) throw new Error("Invalid employee object to store");
    const key = getNormalizedEmpKey(employee);
    if (!key) throw new Error("Employee record missing national ID or employee number");
    employee.storageKey = key;

    const db = await this.open();
    if (!db) return employee;

    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_EMPLOYEES, 'readwrite');
        const store = tx.objectStore(STORE_EMPLOYEES);
        store.put(employee);
        tx.oncomplete = () => resolve(employee);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error || new Error("Transaction aborted"));
      } catch (err) {
        reject(err);
      }
    });
  },

  putBatch: async function(employeesList) {
    if (!Array.isArray(employeesList)) throw new Error("putBatch expects an array");
    const db = await this.open();
    if (!db) return employeesList;

    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_EMPLOYEES, 'readwrite');
        const store = tx.objectStore(STORE_EMPLOYEES);

        for (let i = 0; i < employeesList.length; i++) {
          const emp = employeesList[i];
          if (!emp) continue;
          const key = getNormalizedEmpKey(emp);
          if (!key) continue;
          emp.storageKey = key;
          store.put(emp);
        }

        tx.oncomplete = () => resolve(employeesList);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error || new Error("putBatch transaction aborted"));
      } catch (err) {
        reject(err);
      }
    });
  },

  delete: async function(storageKey) {
    if (!storageKey) return false;
    const db = await this.open();
    if (!db) return true;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_EMPLOYEES, 'readwrite');
        const store = tx.objectStore(STORE_EMPLOYEES);
        store.delete(storageKey);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  clear: async function() {
    const db = await this.open();
    if (!db) return true;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_EMPLOYEES, 'readwrite');
        const store = tx.objectStore(STORE_EMPLOYEES);
        store.clear();
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  setMeta: async function(key, val) {
    const db = await this.open();
    if (!db) return;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_META, 'readwrite');
        const store = tx.objectStore(STORE_META);
        store.put({ key: key, value: val, updatedAt: new Date().toISOString() });
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  getMeta: async function(key) {
    const db = await this.open();
    if (!db) return null;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_META, 'readonly');
        const store = tx.objectStore(STORE_META);
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result ? req.result.value : null);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  enqueueSync: async function(deltaItem) {
    const db = await this.open();
    if (!db) return;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_SYNC_QUEUE, 'readwrite');
        const store = tx.objectStore(STORE_SYNC_QUEUE);
        store.add({
          ...deltaItem,
          queuedAt: new Date().toISOString()
        });
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  getSyncQueue: async function() {
    const db = await this.open();
    if (!db) return [];
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_SYNC_QUEUE, 'readonly');
        const store = tx.objectStore(STORE_SYNC_QUEUE);
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result || []);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  },

  removeSyncQueueItems: async function(ids) {
    if (!Array.isArray(ids) || ids.length === 0) return;
    const db = await this.open();
    if (!db) return;
    return new Promise((resolve, reject) => {
      try {
        const tx = db.transaction(STORE_SYNC_QUEUE, 'readwrite');
        const store = tx.objectStore(STORE_SYNC_QUEUE);
        ids.forEach(id => store.delete(id));
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
      } catch (err) {
        reject(err);
      }
    });
  }
};

function saveEmployeesToLocalStorage(employees) {
  if (!Array.isArray(employees)) {
    throw new Error("Invalid employee dataset: expected Array");
  }

  // 1. Synchronize in-memory _masterEmployeesList and AVH_MASTER_EXCEL_EMPLOYEES immediately
  _masterEmployeesList = employees;
  if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
    employees.forEach(emp => {
      const key = getNormalizedEmpKey(emp);
      if (!key) return;
      const existingIdx = AVH_MASTER_EXCEL_EMPLOYEES.findIndex(e => getNormalizedEmpKey(e) === key);
      if (existingIdx !== -1) {
        AVH_MASTER_EXCEL_EMPLOYEES[existingIdx] = emp;
      } else {
        AVH_MASTER_EXCEL_EMPLOYEES.unshift(emp);
      }
    });
  }

  // 2. Persist to localStorage safely so all components relying on synchronous storage stay in sync
  try {
    localStorage.setItem('avh_employees', JSON.stringify(employees));
    _lastLocalEmployeesStr = null;
    _lastParsedLocalEmployees = null;
  } catch (lsErr) {
    console.warn("localStorage quota notice (using IndexedDB & memory):", lsErr);
  }

  // 3. Persist to IndexedDB asynchronously
  if (typeof EmployeeIndexedDB !== 'undefined') {
    EmployeeIndexedDB.putBatch(employees).catch(err => {
      console.error("IndexedDB putBatch persistence error:", err);
    });
  }

  // 4. Invalidate caches for instant application UI updates
  invalidateEmployeesCache();

  // 5. Dispatch real-time events across all open modules
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('staffDataUpdated'));
    window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: employees.length } }));
  }

  // 6. Async sync to local server API endpoint if available (non-blocking)
  if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
    try {
      const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
        ? window.authManager.getAuthHeaders()
        : { 'Content-Type': 'application/json; charset=utf-8' };

      fetch('/api/employees/save', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ employees })
      }).then(res => {
        if (!res.ok) {
          console.warn("Background server sync non-ok response status:", res.status);
        }
      }).catch(err => console.warn("Background server sync info:", err));
    } catch(e) {}
  }

  return { success: true, count: employees.length };
}

const EmployeeDataService = {
  _initialized: false,
  _initPromise: null,

  init: function() {
    if (this._initPromise) return this._initPromise;
    this._initPromise = (async () => {
      try {
        // 1. Run safe migration from localStorage if avh_employees exists
        await this.safeMigrateFromLocalStorage();

        // 2. Load records from IndexedDB
        let records = await EmployeeIndexedDB.getAll();

        // 3. If IndexedDB is empty (first run, fresh environment), seed from AVH_MASTER_EXCEL_EMPLOYEES (511 baseline records)
        if (!records || records.length === 0) {
          const baseMaster = (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES))
            ? AVH_MASTER_EXCEL_EMPLOYEES
            : [];
          if (baseMaster.length > 0) {
            console.log(`Seeding IndexedDB with ${baseMaster.length} master employees...`);
            await EmployeeIndexedDB.putBatch(baseMaster);
            records = await EmployeeIndexedDB.getAll();
          }
        }

        // 4. Update in-memory hot cache
        if (records && records.length > 0) {
          _masterEmployeesList = records;
          invalidateEmployeesCache();
        }

        // 5. Query authoritative backend /api/employees to hydrate with central DB
        if (typeof fetchMasterEmployeesFromBackend === 'function') {
          const srvList = await fetchMasterEmployeesFromBackend().catch(e => {
            console.warn("fetchMasterEmployeesFromBackend notice:", e);
            return null;
          });
          if (Array.isArray(srvList) && srvList.length > 0) {
            records = srvList;
          }
        }

        // 6. Flush any queued changes if server is accessible
        this.flushSyncQueue().catch(e => console.warn("Sync queue flush notice:", e));

        this._initialized = true;

        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('staffDataUpdated'));
          window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: this.getAllEmployees().length } }));
        }

        return this.getAllEmployees();
      } catch (e) {
        console.error("EmployeeDataService.init error:", e);
        this._initialized = true;
        return this.getAllEmployees();
      }
    })();
    return this._initPromise;
  },

  safeMigrateFromLocalStorage: async function() {
    try {
      if (typeof localStorage === 'undefined' || localStorage.getItem('avh_employees_migrated') === 'true') {
        return { migrated: true };
      }
      const raw = localStorage.getItem('avh_employees');
      if (!raw || raw.trim().length <= 2) {
        return { migrated: false, count: 0 };
      }

      console.log("Found legacy localStorage avh_employees dataset. Initiating safe migration...");
      let parsed = [];
      try {
        parsed = JSON.parse(raw);
      } catch (pe) {
        console.error("Corrupted localStorage avh_employees JSON:", pe);
        return { migrated: false, error: pe.message };
      }

      if (!Array.isArray(parsed) || parsed.length === 0) {
        return { migrated: false, count: 0 };
      }

      // Step 1: Save pre-migration backup snapshot in IndexedDB meta store & window
      await EmployeeIndexedDB.setMeta('pre_migration_backup', {
        timestamp: new Date().toISOString(),
        count: parsed.length,
        rawJson: raw
      });

      if (typeof window !== 'undefined') {
        window.avhPreMigrationBackup = raw;
      }

      // Step 2: Batch write all parsed records to IndexedDB
      await EmployeeIndexedDB.putBatch(parsed);

      // Step 3: Verification - ensure records persisted accurately
      const idbCount = await EmployeeIndexedDB.count();
      if (idbCount < parsed.length) {
        throw new Error(`Migration verification failed: expected at least ${parsed.length} records in IDB, found ${idbCount}`);
      }

      // Verify sample records
      const sample1 = parsed[0];
      const sample2 = parsed[Math.floor(parsed.length / 2)];
      const sample3 = parsed[parsed.length - 1];
      const k1 = getNormalizedEmpKey(sample1);
      const k2 = getNormalizedEmpKey(sample2);
      const k3 = getNormalizedEmpKey(sample3);

      const r1 = k1 ? await EmployeeIndexedDB.get(k1) : true;
      const r2 = k2 ? await EmployeeIndexedDB.get(k2) : true;
      const r3 = k3 ? await EmployeeIndexedDB.get(k3) : true;

      if (!r1 || !r2 || !r3) {
        throw new Error("Migration integrity verification failed: sample records missing from IndexedDB");
      }

      // Step 4: Verification SUCCEEDED! Safe to record migration status and remove old localStorage copy
      await EmployeeIndexedDB.setMeta('migration_status', {
        verified: true,
        count: idbCount,
        completedAt: new Date().toISOString()
      });

      localStorage.setItem('avh_employees_migrated', 'true');
      console.log(`Migration verified successfully (${idbCount} records). Retained synchronous warm cache.`);

      return { migrated: true, count: idbCount };
    } catch (err) {
      console.error("Safe migration aborted due to verification failure:", err);
      // DO NOT delete localStorage['avh_employees'] on failure!
      return { migrated: false, error: err.message };
    }
  },

  getAllEmployees: function() {
    if (_masterEmployeesList && Array.isArray(_masterEmployeesList) && _masterEmployeesList.length > 0) {
      return getUniqueEmployees();
    }
    return (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES))
      ? AVH_MASTER_EXCEL_EMPLOYEES
      : [];
  },

  getEmployeeById: function(idKey) {
    return getEmployeeByEmpNo(idKey);
  },

  saveEmployee: async function(empData, actionType = 'update') {
    if (!empData) throw new Error("Missing employee data to save");
    const targetKey = getNormalizedEmpKey(empData);
    if (!targetKey) {
      throw new Error("Employee record missing national ID or employee number");
    }

    empData.storageKey = targetKey;

    // Sanitize case-duplicate keys that cause PowerShell 5.1 ConvertFrom-Json parser errors
    if (empData.hbsabDate && empData.hbsAbDate) delete empData.hbsAbDate;
    if (empData.hbsagDate && empData.hbsAgDate) delete empData.hbsAgDate;
    if (empData.hbsabResult && empData.hbsAb) delete empData.hbsAb;
    if (empData.hbsagResult && empData.hbsAg) delete empData.hbsAg;

    // Check if we are connected to the central backend
    const isHttp = typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http');

    if (isHttp) {
      try {
        const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
          ? window.authManager.getAuthHeaders()
          : { 'Content-Type': 'application/json; charset=utf-8' };

        const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
        const timeoutId = controller ? setTimeout(() => controller.abort(), 12000) : null;

        const res = await fetch('/api/employees/save', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ employee: empData, actionType: actionType }),
          signal: controller ? controller.signal : undefined
        });
        if (timeoutId) clearTimeout(timeoutId);

        const resData = await res.json().catch(() => ({}));

        if (res.status === 409) {
          // OCC Conflict detected: Another user has edited this record concurrently
          return {
            success: false,
            conflict: true,
            status: 'conflict',
            serverSaved: false,
            message: resData.message || 'Concurrent edit conflict: Record was modified by another user on another device.',
            employee: empData,
            serverEmployee: resData.currentEmployee
          };
        }

        if (res.status === 403) {
          return {
            success: false,
            forbidden: true,
            status: 'forbidden',
            serverSaved: false,
            message: resData.message || 'Permission denied: Insufficient privileges.',
            employee: empData
          };
        }

        if (res.ok && (resData.success || resData.status === 'success')) {
          // CENTRAL DATABASE COMMIT CONFIRMED!
          const committedEmp = resData.employee || empData;
          if (resData.employee) {
            empData._version = resData.employee._version;
            empData._serverUpdatedAt = resData.employee._serverUpdatedAt;
          }
          delete empData._pendingSync;

          // 1. Commit to IndexedDB cache
          await EmployeeIndexedDB.put(committedEmp).catch(e => console.warn("IndexedDB cache put notice:", e));

          // 2. Update memory hot cache
          let employees = _masterEmployeesList || (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' ? AVH_MASTER_EXCEL_EMPLOYEES.slice() : []);
          const idx = employees.findIndex(e => getNormalizedEmpKey(e) === targetKey);
          if (idx !== -1) {
            employees[idx] = deepMergeEmployeeObjects(employees[idx], committedEmp, true);
          } else {
            employees.unshift(committedEmp);
          }
          _masterEmployeesList = employees;

          if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
            const bIdx = AVH_MASTER_EXCEL_EMPLOYEES.findIndex(e => getNormalizedEmpKey(e) === targetKey);
            if (bIdx !== -1) {
              AVH_MASTER_EXCEL_EMPLOYEES[bIdx] = employees[idx !== -1 ? idx : 0];
            } else {
              AVH_MASTER_EXCEL_EMPLOYEES.unshift(employees[0]);
            }
          }

          // 3. Mirror directly to localStorage
          try {
            localStorage.setItem('avh_employees', JSON.stringify(employees));
            _lastLocalEmployeesStr = null;
            _lastParsedLocalEmployees = null;
          } catch(e) {}

          invalidateEmployeesCache();

          if (typeof window !== 'undefined') {
            window.dispatchEvent(new Event('staffDataUpdated'));
            window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: employees.length } }));
          }

          return {
            success: true,
            serverSaved: true,
            status: 'success',
            action: resData.action || (actionType === 'save' ? 'created' : 'updated'),
            employee: committedEmp,
            version: committedEmp._version
          };
        } else {
          return {
            success: false,
            status: 'error',
            serverSaved: false,
            message: resData.message || `Server returned HTTP ${res.status}`,
            employee: empData
          };
        }
      } catch (netErr) {
        console.warn("Backend save request failed, enqueuing for offline sync:", netErr);
        empData._pendingSync = true;
        await EmployeeIndexedDB.put(empData).catch(() => {});
        await EmployeeIndexedDB.enqueueSync({
          action: 'save',
          key: targetKey,
          employee: empData,
          actionType: actionType
        }).catch(err => console.warn("Failed to enqueue sync:", err));

        // Update memory hot cache and localStorage even offline
        let employees = _masterEmployeesList || (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' ? AVH_MASTER_EXCEL_EMPLOYEES.slice() : []);
        const idx = employees.findIndex(e => getNormalizedEmpKey(e) === targetKey);
        if (idx !== -1) {
          employees[idx] = deepMergeEmployeeObjects(employees[idx], empData, true);
        } else {
          employees.unshift(empData);
        }
        _masterEmployeesList = employees;
        try {
          localStorage.setItem('avh_employees', JSON.stringify(employees));
          _lastLocalEmployeesStr = null;
          _lastParsedLocalEmployees = null;
        } catch(e) {}
        invalidateEmployeesCache();
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('staffDataUpdated'));
          window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: employees.length } }));
        }

        return {
          success: false,
          pendingSync: true,
          status: 'pending',
          serverSaved: false,
          message: 'Server unreachable. Changes stored as Pending sync on this device.',
          employee: empData
        };
      }
    } else {
      empData._pendingSync = true;
      await EmployeeIndexedDB.put(empData).catch(() => {});
      let employees = _masterEmployeesList || (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' ? AVH_MASTER_EXCEL_EMPLOYEES.slice() : []);
      const idx = employees.findIndex(e => getNormalizedEmpKey(e) === targetKey);
      if (idx !== -1) {
        employees[idx] = deepMergeEmployeeObjects(employees[idx], empData, true);
      } else {
        employees.unshift(empData);
      }
      _masterEmployeesList = employees;
      try {
        localStorage.setItem('avh_employees', JSON.stringify(employees));
        _lastLocalEmployeesStr = null;
        _lastParsedLocalEmployees = null;
      } catch(e) {}
      invalidateEmployeesCache();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event('staffDataUpdated'));
        window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: employees.length } }));
      }
      return {
        success: false,
        pendingSync: true,
        status: 'pending',
        serverSaved: false,
        message: 'Running in offline mode. Changes marked as Pending sync.',
        employee: empData
      };
    }
  },

  saveEmployees: async function(employeesList) {
    if (!Array.isArray(employeesList)) throw new Error("saveEmployees expects an array");

    await EmployeeIndexedDB.putBatch(employeesList);
    _masterEmployeesList = employeesList;
    if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
      AVH_MASTER_EXCEL_EMPLOYEES.length = 0;
      employeesList.forEach(e => AVH_MASTER_EXCEL_EMPLOYEES.push(e));
    }

    try {
      localStorage.setItem('avh_employees', JSON.stringify(employeesList));
      _lastLocalEmployeesStr = null;
      _lastParsedLocalEmployees = null;
    } catch(e) {}

    invalidateEmployeesCache();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('staffDataUpdated'));
      window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: employeesList.length } }));
    }

    if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
      try {
        const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
          ? window.authManager.getAuthHeaders()
          : { 'Content-Type': 'application/json; charset=utf-8' };

        fetch('/api/employees/save', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ employees: employeesList })
        }).catch(err => console.warn("Background server batch sync info:", err));
      } catch(e) {}
    }

    return { success: true, count: employeesList.length };
  },

  deleteEmployee: async function(empId) {
    if (!empId) return { success: false, message: 'Missing employee ID' };
    const targetClean = String(empId).replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
    const idKey = 'ID:' + targetClean;
    const empKey = 'EMP:' + targetClean;

    const isHttp = typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http');

    if (isHttp) {
      const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
        ? window.authManager.getAuthHeaders()
        : { 'Content-Type': 'application/json; charset=utf-8' };

      const res = await fetch('/api/employees/delete', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ id: empId })
      });

      const resData = await res.json().catch(() => ({}));

      if (res.status === 403) {
        const msg = resData.message || "Permission Denied: Only the designated owner account ('hammam') is authorized to delete employee records.";
        throw new Error(msg);
      }

      if (!res.ok) {
        throw new Error(resData.message || `Server deletion failed with status ${res.status}`);
      }
    }

    // 1. Delete from IndexedDB
    await EmployeeIndexedDB.delete(idKey).catch(() => {});
    await EmployeeIndexedDB.delete(empKey).catch(() => {});

    // 2. Delete from in-memory cache
    if (_masterEmployeesList && Array.isArray(_masterEmployeesList)) {
      _masterEmployeesList = _masterEmployeesList.filter(e => {
        if (!e) return false;
        const demo = e.demographic || {};
        const idNo = String(e.idNo || demo.nationalId || '').replace(/^0+/, '').trim().toLowerCase();
        const empNo = String(e.empNo || e.id || demo.personNumber || '').replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
        return idNo !== targetClean && empNo !== targetClean;
      });
    }

    if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
      const filtered = AVH_MASTER_EXCEL_EMPLOYEES.filter(e => {
        if (!e) return false;
        const demo = e.demographic || {};
        const idNo = String(e.idNo || demo.nationalId || '').replace(/^0+/, '').trim().toLowerCase();
        const empNo = String(e.empNo || e.id || demo.personNumber || '').replace(/^EMP-/i, '').replace(/^0+/, '').trim().toLowerCase();
        return idNo !== targetClean && empNo !== targetClean;
      });
      AVH_MASTER_EXCEL_EMPLOYEES.length = 0;
      filtered.forEach(e => AVH_MASTER_EXCEL_EMPLOYEES.push(e));
    }

    try {
      localStorage.setItem('avh_employees', JSON.stringify(_masterEmployeesList || []));
      _lastLocalEmployeesStr = null;
      _lastParsedLocalEmployees = null;
    } catch(e) {}

    invalidateEmployeesCache();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('staffDataUpdated'));
      window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: this.getAllEmployees().length } }));
    }

    return { success: true, softDeleted: true };
  },

  getTrashEmployees: async function() {
    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };
    const res = await fetch('/api/employees/trash', { headers: authHeaders });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    return await res.json();
  },

  restoreEmployee: async function(empId) {
    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };
    const res = await fetch('/api/employees/restore', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({ id: empId })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    await fetchMasterEmployeesFromBackend();
    return await res.json();
  },

  clearAllEmployees: async function() {
    await EmployeeIndexedDB.clear();
    _masterEmployeesList = [];
    if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
      AVH_MASTER_EXCEL_EMPLOYEES.length = 0;
    }
    invalidateEmployeesCache();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('staffDataUpdated'));
      window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: 0 } }));
    }
  },

  flushSyncQueue: async function() {
    if (typeof fetch !== 'function' || typeof window === 'undefined' || !window.location || !window.location.protocol || !window.location.protocol.startsWith('http')) {
      return;
    }
    const queue = await EmployeeIndexedDB.getSyncQueue();
    if (!queue || queue.length === 0) return;

    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };

    const processedIds = [];
    for (const item of queue) {
      try {
        if (item.action === 'save' && item.employee) {
          const res = await fetch('/api/employees/save', {
            method: 'POST',
            headers: authHeaders,
            body: JSON.stringify({ employee: item.employee, actionType: item.actionType || 'update' })
          });
          if (res.ok) {
            processedIds.push(item.id);
          }
        } else if (item.action === 'delete') {
          processedIds.push(item.id);
        }
      } catch (err) {
        console.warn("Sync queue retry paused:", err);
        break;
      }
    }

    if (processedIds.length > 0) {
      await EmployeeIndexedDB.removeSyncQueueItems(processedIds);
      console.log(`Flushed ${processedIds.length} queued delta updates to server.`);
    }
  },

  downloadPreMigrationBackup: async function() {
    let raw = (typeof window !== 'undefined' && window.avhPreMigrationBackup) ? window.avhPreMigrationBackup : null;
    if (!raw) {
      const meta = await EmployeeIndexedDB.getMeta('pre_migration_backup');
      if (meta && meta.rawJson) {
        raw = meta.rawJson;
      }
    }
    if (!raw) {
      alert(window.i18n && window.i18n.isRTL()
        ? 'لا توجد نسخة احتياطية سابقة للهجرة مخزنة. يمكنك تحميل نسخة احتياطية من قاعدة البيانات الحالية.'
        : 'No pre-migration backup found in storage. You can export a live database backup instead.');
      return;
    }
    const blob = new Blob([raw], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `avh_staff_pre_migration_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  downloadDatabaseBackup: function() {
    const list = this.getAllEmployees();
    const jsonStr = JSON.stringify(list, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `avh_staff_database_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  refreshReports: function() {
    invalidateEmployeesCache();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('avh_data_updated', { detail: { count: this.getAllEmployees().length } }));
    }
  }
};

const InjuryDataService = {
  _cache: null,

  getAllInjuries: async function(forceRefresh = false) {
    if (this._cache && !forceRefresh) return this._cache;
    if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
      try {
        const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
          ? window.authManager.getAuthHeaders()
          : { 'Content-Type': 'application/json; charset=utf-8' };
        const res = await fetch('/api/injuries', { headers: authHeaders });
        if (res.ok) {
          const list = await res.json();
          if (Array.isArray(list)) {
            this._cache = list;
            try { localStorage.setItem('avh_injuries', JSON.stringify(list)); } catch(e){}
            return list;
          }
        }
      } catch (err) {
        console.warn("InjuryDataService.getAllInjuries server fetch warning:", err);
      }
    }
    // Fallback to local cache
    try {
      const local = JSON.parse(localStorage.getItem('avh_injuries')) || [];
      this._cache = local;
      return local;
    } catch(e) {
      return [];
    }
  },

  saveInjury: async function(injuryData) {
    if (!injuryData) throw new Error("Missing injury data to save");
    let serverSaved = false;
    let savedInjury = injuryData;
    let serverError = null;

    if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
      try {
        const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
          ? window.authManager.getAuthHeaders()
          : { 'Content-Type': 'application/json; charset=utf-8' };
        const res = await fetch('/api/injuries/save', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ injury: injuryData })
        });
        const resData = await res.json().catch(() => ({}));
        if (res.ok && (resData.success || resData.status === 'success')) {
          serverSaved = true;
          savedInjury = resData.injury || injuryData;
        } else {
          serverError = resData.message || `Server error HTTP ${res.status}`;
        }
      } catch (err) {
        serverError = err.message || 'Network error';
      }
    } else {
      serverError = 'Offline mode';
    }

    let injuries = await this.getAllInjuries();
    const sId = savedInjury.id || savedInjury.part1?.serialNo;
    const idx = injuries.findIndex(i => (i.id === sId || i.part1?.serialNo === sId));
    if (idx !== -1) {
      injuries[idx] = savedInjury;
    } else {
      injuries.unshift(savedInjury);
    }
    this._cache = injuries;
    try { localStorage.setItem('avh_injuries', JSON.stringify(injuries)); } catch(e){}

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('avh_injuries_updated', { detail: { count: injuries.length } }));
    }

    return {
      success: serverSaved,
      serverSaved: serverSaved,
      pendingSync: !serverSaved,
      error: serverError,
      injury: savedInjury
    };
  },

  deleteInjury: async function(serialNo) {
    if (!serialNo) return { success: false, message: 'No serial number provided' };
    if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
      const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
        ? window.authManager.getAuthHeaders()
        : { 'Content-Type': 'application/json; charset=utf-8' };
      const res = await fetch('/api/injuries/delete', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ id: serialNo })
      });
      const resData = await res.json().catch(() => ({}));
      if (res.status === 403) {
        throw new Error(resData.message || "Permission Denied: Only the designated owner account ('hammam') is authorized to delete injury records.");
      }
      if (!res.ok) {
        throw new Error(resData.message || `HTTP ${res.status}: Failed to delete injury report`);
      }
    }

    let injuries = await this.getAllInjuries();
    injuries = injuries.filter(i => (i.id !== serialNo && i.part1?.serialNo !== serialNo));
    this._cache = injuries;
    try { localStorage.setItem('avh_injuries', JSON.stringify(injuries)); } catch(e){}

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('avh_injuries_updated', { detail: { count: injuries.length } }));
    }
    return { success: true };
  },

  getTrashInjuries: async function() {
    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };
    const res = await fetch('/api/injuries/trash', { headers: authHeaders });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    return await res.json();
  },

  restoreInjury: async function(serialNo) {
    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };
    const res = await fetch('/api/injuries/restore', {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({ id: serialNo })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.message || `HTTP ${res.status}`);
    }
    await this.getAllInjuries(true);
    return await res.json();
  }
};

const CertificateDataService = {
  saveIssuance: async function(certData) {
    if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
      try {
        const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
          ? window.authManager.getAuthHeaders()
          : { 'Content-Type': 'application/json; charset=utf-8' };
        const res = await fetch('/api/certificates/save', {
          method: 'POST',
          headers: authHeaders,
          body: JSON.stringify({ certificate: certData })
        });
        if (res.ok) {
          const resData = await res.json();
          return { success: true, certificateNumber: resData.certificateNumber, certId: resData.certId };
        }
      } catch(e) {
        console.warn("Certificate save warning:", e);
      }
    }
    return { success: false, certificateNumber: 'AVH-CERT-' + new Date().getFullYear() + '-OFFLINE' };
  },

  getAllIssuances: async function() {
    if (typeof fetch === 'function' && typeof window !== 'undefined' && window.location && window.location.protocol && window.location.protocol.startsWith('http')) {
      try {
        const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
          ? window.authManager.getAuthHeaders()
          : { 'Content-Type': 'application/json; charset=utf-8' };
        const res = await fetch('/api/certificates', { headers: authHeaders });
        if (res.ok) {
          return await res.json();
        }
      } catch(e) {}
    }
    return [];
  }
};

const SystemDbService = {
  getDbStatus: async function() {
    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };
    const res = await fetch('/api/system/db-status', { headers: authHeaders });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  },

  triggerBackup: async function() {
    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };
    const res = await fetch('/api/system/backup', { method: 'POST', headers: authHeaders });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  },

  getAuditLogs: async function() {
    const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
      ? window.authManager.getAuthHeaders()
      : { 'Content-Type': 'application/json; charset=utf-8' };
    const res = await fetch('/api/audit-logs', { headers: authHeaders });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  }
};

function isGazaStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const org = String(demo.orgName || emp.department || demo.department || '').toLowerCase();
  return org.includes('gaza');
}

function isActiveStaff(emp) {
  if (!emp || typeof emp !== 'object') return false;
  
  // 1. Explicit boolean archive flags
  if (emp.isArchived === true || emp.archived === true) return false;
  const demo = emp.demographic || {};
  if (demo.isArchived === true || demo.archived === true) return false;

  // 2. Collect all status strings across root and demographic
  const rawStatus = String(emp.employmentStatus || demo.employmentStatus || emp.workStatus || demo.workStatus || '').trim().toLowerCase();

  // 3. Known non-active / former staff status indicators
  const nonActiveIndicators = [
    'leave', 'transf', 'resign', 'retir', 'decea', 'terminat', 'contract', 'discharg', 'archiv', 'former',
    'إجازة', 'منقول', 'استقال', 'مستقيل', 'تقاعد', 'متقاعد', 'متوف', 'إنهاء', 'عقد', 'تسريح', 'إخلاء', 'مؤرشف', 'سابق'
  ];
  for (let i = 0; i < nonActiveIndicators.length; i++) {
    if (rawStatus.includes(nonActiveIndicators[i])) {
      return false;
    }
  }

  // 4. If status is blank, 'active', 'active staff', or contains 'على رأس عمله', it is Active Staff
  if (!rawStatus || rawStatus === 'active' || rawStatus === 'active staff' || rawStatus.includes('على رأس عمله')) {
    return true;
  }

  return false;
}

function isArchivedStaff(emp) {
  if (!emp || typeof emp !== 'object') return false;
  return !isActiveStaff(emp);
}

if (typeof window !== 'undefined') {
  window.currentSelectedEmpNo = null;

  function setGlobalSelectedStaff(empNoOrIdOrObj) {
    if (empNoOrIdOrObj === null || empNoOrIdOrObj === undefined || empNoOrIdOrObj === '') {
      window.currentSelectedEmpNo = null;
      try { sessionStorage.removeItem('avh_selected_staff_no'); } catch(e) {}
      if (typeof currentEditingEmpNo !== 'undefined') currentEditingEmpNo = null;
      if (typeof activeEmpPersonNo !== 'undefined') activeEmpPersonNo = '';
      if (typeof activeEmpIndex !== 'undefined') activeEmpIndex = -1;
      if (typeof activeInjuryEmpIndex !== 'undefined') activeInjuryEmpIndex = -1;
      return null;
    }

    const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
    let emp = null;
    let idx = -1;

    if (typeof empNoOrIdOrObj === 'object' && empNoOrIdOrObj !== null) {
      emp = empNoOrIdOrObj;
      const demo = emp.demographic || {};
      const targetKey = String(emp.empNo || emp.id || demo.personNumber || emp.idNo || demo.nationalId || '').trim();
      idx = employees.findIndex(e => {
        const d = e.demographic || {};
        return (e.empNo && String(e.empNo).trim() === targetKey) ||
               (e.id && String(e.id).trim() === targetKey) ||
               (d.personNumber && String(d.personNumber).trim() === targetKey) ||
               (e.idNo && String(e.idNo).trim() === targetKey) ||
               (d.nationalId && String(d.nationalId).trim() === targetKey);
      });
      if (idx === -1) {
        idx = employees.indexOf(emp);
      }
    } else if (typeof empNoOrIdOrObj === 'number' && empNoOrIdOrObj >= 0 && empNoOrIdOrObj < employees.length) {
      idx = empNoOrIdOrObj;
      emp = employees[idx];
    } else {
      const keyStr = String(empNoOrIdOrObj).trim();
      idx = employees.findIndex(e => {
        const d = e.demographic || {};
        return String(e.empNo || e.id || d.personNumber || '').trim() === keyStr ||
               String(e.idNo || d.nationalId || '').trim() === keyStr;
      });
      if (idx !== -1) {
        emp = employees[idx];
      }
    }

    if (emp) {
      const demo = emp.demographic || {};
      const empNo = String(emp.empNo || emp.id || demo.personNumber || emp.idNo || '').trim();
      window.currentSelectedEmpNo = empNo;
      try { sessionStorage.setItem('avh_selected_staff_no', empNo); } catch(e) {}

      if (typeof currentEditingEmpNo !== 'undefined') currentEditingEmpNo = empNo;
      if (typeof activeEmpPersonNo !== 'undefined') activeEmpPersonNo = empNo;
      if (typeof activeEmpIndex !== 'undefined') activeEmpIndex = idx;
      if (typeof activeInjuryEmpIndex !== 'undefined') activeInjuryEmpIndex = idx;

      return emp;
    }

    return null;
  }

  function getGlobalSelectedStaff() {
    const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
    if (!employees || employees.length === 0) return null;

    let key = window.currentSelectedEmpNo;
    if (!key) {
      try { key = sessionStorage.getItem('avh_selected_staff_no'); } catch(e) {}
    }
    if (!key && typeof currentEditingEmpNo !== 'undefined' && currentEditingEmpNo) {
      key = currentEditingEmpNo;
    }
    if (!key && typeof activeEmpPersonNo !== 'undefined' && activeEmpPersonNo) {
      key = activeEmpPersonNo;
    }

    if (key) {
      const keyStr = String(key).trim();
      const emp = employees.find(e => {
        const d = e.demographic || {};
        return String(e.empNo || e.id || d.personNumber || '').trim() === keyStr ||
               String(e.idNo || d.nationalId || '').trim() === keyStr;
      });
      if (emp) return emp;
    }

    let idx = -1;
    if (typeof activeEmpIndex !== 'undefined' && activeEmpIndex >= 0 && activeEmpIndex < employees.length) {
      idx = activeEmpIndex;
    } else if (typeof activeInjuryEmpIndex !== 'undefined' && activeInjuryEmpIndex >= 0 && activeInjuryEmpIndex < employees.length) {
      idx = activeInjuryEmpIndex;
    }

    if (idx >= 0 && employees[idx]) {
      const emp = employees[idx];
      const demo = emp.demographic || {};
      window.currentSelectedEmpNo = String(emp.empNo || emp.id || demo.personNumber || '').trim();
      return emp;
    }

    return null;
  }

  function buildStaffQuickSelectOptionsHtml(employees, isAr, selectedEmpNo = null) {
    const list = employees || (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : []);
    const activeStaff = [];
    const archivedStaff = [];
    const selStr = selectedEmpNo ? String(selectedEmpNo).trim().toLowerCase() : null;

    (list || []).forEach(e => {
      if (!e) return;
      if (typeof isActiveStaff === 'function' ? isActiveStaff(e) : true) {
        activeStaff.push(e);
      } else {
        archivedStaff.push(e);
      }
    });

    let html = `<option value="">-- 👤 ${isAr ? 'اختر موظفاً من القائمة' : 'Select Employee from List'} --</option>`;

    const checkSelected = (e) => {
      if (!selStr) return false;
      const demo = e.demographic || {};
      const eNo = String(e.empNo || e.id || demo.personNumber || '').trim().toLowerCase();
      const eCleanNo = eNo.replace(/^emp-/i, '').replace(/^0+/, '');
      const eId = String(e.idNo || demo.nationalId || '').trim().toLowerCase();
      const eCleanId = eId.replace(/^0+/, '');
      const eName = String(e.name || demo.fullName || '').trim().toLowerCase();
      const selClean = selStr.replace(/^emp-/i, '').replace(/^0+/, '');

      return eNo === selStr || eCleanNo === selClean || eId === selStr || eCleanId === selClean || eName === selStr;
    };

    if (activeStaff.length > 0) {
      html += `<optgroup label="🟢 ${isAr ? 'الكادر النشط' : 'Active Staff'} (${activeStaff.length})">`;
      activeStaff.forEach(e => {
        const eNo = e.empNo || e.id || '';
        const dept = e.demographic?.orgName || e.organizationName || e.department || 'Staff';
        const isSel = checkSelected(e);
        html += `<option value="${eNo}" ${isSel ? 'selected' : ''}>${e.name} (${eNo}) - ${dept}</option>`;
      });
      html += `</optgroup>`;
    }

    if (archivedStaff.length > 0) {
      html += `<optgroup label="📁 ${isAr ? 'الكادر المؤرشف / السابق' : 'Archived / Former Staff'} (${archivedStaff.length})">`;
      archivedStaff.forEach(e => {
        const eNo = e.empNo || e.id || '';
        const st = e.employmentStatus || (e.demographic ? e.demographic.employmentStatus : '') || (isAr ? 'مؤرشف' : 'Archived');
        const dept = e.demographic?.orgName || e.organizationName || e.department || 'Staff';
        const isSel = checkSelected(e);
        html += `<option value="${eNo}" ${isSel ? 'selected' : ''}>${e.name} (${eNo}) [📁 ${st}] - ${dept}</option>`;
      });
      html += `</optgroup>`;
    }

    return html;
  }
  window.buildStaffQuickSelectOptionsHtml = buildStaffQuickSelectOptionsHtml;

  window.setGlobalSelectedStaff = setGlobalSelectedStaff;
  window.getGlobalSelectedStaff = getGlobalSelectedStaff;

  window.isGazaStaff = isGazaStaff;
  window.isActiveStaff = isActiveStaff;
  window.isArchivedStaff = isArchivedStaff;
  window.deepMergeEmployeeObjects = deepMergeEmployeeObjects;
  window.getUniqueEmployees = getUniqueEmployees;
  window.invalidateEmployeesCache = invalidateEmployeesCache;
  window.saveEmployeesToLocalStorage = saveEmployeesToLocalStorage;
  window.fetchMasterEmployeesFromBackend = fetchMasterEmployeesFromBackend;
  window.saveEmployeeToMasterSheet = saveEmployeeToMasterSheet;
  window.deleteEmployeeFromMasterSheet = deleteEmployeeFromMasterSheet;
  window.EmployeeIndexedDB = EmployeeIndexedDB;
  window.EmployeeDataService = EmployeeDataService;
  window.InjuryDataService = InjuryDataService;
  window.CertificateDataService = CertificateDataService;
  window.SystemDbService = SystemDbService;
  window.downloadPreMigrationBackup = () => EmployeeDataService.downloadPreMigrationBackup();
  window.downloadStaffDatabaseBackup = () => EmployeeDataService.downloadDatabaseBackup();
  window.retryPendingSyncs = () => EmployeeDataService.flushSyncQueue();

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => EmployeeDataService.init());
    } else {
      EmployeeDataService.init();
    }
  }
}

const INITIAL_EMPLOYEES = [];

const INITIAL_INJURY_REPORTS = [];

const INITIAL_AUDIT_LOGS = [
  { timestamp: "2026-07-27 10:15", user: "admin", action: "System initialized with AVH brand configuration." },
  { timestamp: "2026-07-27 10:30", user: "occ_health", action: "All entered staff data loaded per user request." }
];

const AVHPrintController = {
  syncFormState(container) {
    if (!container) return;
    try {
      // 1. Synchronize inputs (radios, checkboxes, text)
      container.querySelectorAll('input').forEach(input => {
        const type = (input.type || '').toLowerCase();
        if (type === 'checkbox' || type === 'radio') {
          if (input.checked) {
            input.setAttribute('checked', 'checked');
          } else {
            input.removeAttribute('checked');
          }
          // Ensure a companion print indicator exists and shows checked state
          let printIndicator = document.getElementById(input.id + '_print');
          if (!printIndicator) {
            printIndicator = input.nextElementSibling;
            if (!printIndicator || (!printIndicator.classList.contains('print-radio-indicator') && !printIndicator.classList.contains('print-check-indicator'))) {
              printIndicator = document.createElement('span');
              printIndicator.className = type === 'radio' ? 'print-only print-radio-indicator' : 'print-only print-check-indicator';
              if (input.parentNode) {
                input.parentNode.insertBefore(printIndicator, input.nextSibling);
              }
            }
          }
          if (printIndicator) {
            printIndicator.innerHTML = input.checked 
              ? (type === 'radio' ? '<b style="font-size:12pt;color:black;">●</b>' : '<b style="font-size:11pt;color:black;">✔</b>') 
              : (type === 'radio' ? '<span style="font-size:11pt;color:#555;">○</span>' : '<span style="font-size:10pt;color:#777;">□</span>');
          }
        } else {
          input.setAttribute('value', input.value || '');
        }
      });

      // 2. Synchronize select dropdowns into text companion spans
      container.querySelectorAll('select').forEach(select => {
        const val = select.value;
        let selectedText = '';
        Array.from(select.options).forEach(opt => {
          if (opt.value === val || opt.selected) {
            opt.setAttribute('selected', 'selected');
            selectedText = opt.text;
          } else {
            opt.removeAttribute('selected');
          }
        });
        if (!selectedText && select.selectedIndex >= 0 && select.options[select.selectedIndex]) {
          selectedText = select.options[select.selectedIndex].text;
        }
        if (selectedText && (selectedText.includes('-- Select --') || selectedText.includes('-- اختر --'))) {
          selectedText = '';
        }
        select.setAttribute('data-selected-text', selectedText);

        let printText = document.getElementById(select.id + '_print');
        if (!printText) {
          printText = select.nextElementSibling;
          if (!printText || (!printText.classList.contains('print-select-text') && !printText.classList.contains('print-select-val'))) {
            printText = document.createElement('span');
            printText.className = 'print-only print-select-text';
            if (select.parentNode) {
              select.parentNode.insertBefore(printText, select.nextSibling);
            }
          }
        }
        if (printText) {
          printText.textContent = selectedText;
        }
      });

      // 3. Synchronize textareas
      container.querySelectorAll('textarea').forEach(ta => {
        ta.textContent = ta.value || '';
        ta.setAttribute('data-value', ta.value || '');
      });
    } catch(e) {
      console.warn('Form sync warning:', e);
    }
  },

  async waitForAssets(container) {
    if (document.fonts && document.fonts.ready) {
      try { await document.fonts.ready; } catch(e){}
    }
    if (container) {
      const imgs = Array.from(container.querySelectorAll('img'));
      await Promise.all(imgs.map(img => {
        if (img.complete) return Promise.resolve();
        return new Promise(resolve => {
          img.onload = resolve;
          img.onerror = resolve;
        });
      }));
    }
  },

  async printContainer(containerId, options = {}) {
    const container = typeof containerId === 'string' ? document.getElementById(containerId) : containerId;
    if (container) {
      this.syncFormState(container);
      await this.waitForAssets(container);
    }

    const mode = options.mode || 'portrait';
    const printClass = options.printClass || 'printing-target-active';

    document.body.classList.add('is-printing', printClass, `print-mode-${mode}`);

    if (typeof options.onBeforePrint === 'function') {
      options.onBeforePrint(container);
    }

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        window.print();
        setTimeout(() => {
          document.body.classList.remove('is-printing', printClass, `print-mode-${mode}`, 'print-mode-portrait', 'print-mode-landscape', 'print-mode-a4', 'print-mode-letter');
          if (typeof options.onAfterPrint === 'function') {
            options.onAfterPrint(container);
          }
        }, 800);
      });
    });
  }
};

if (typeof window !== 'undefined') {
  window.AVHPrintController = AVHPrintController;
}

