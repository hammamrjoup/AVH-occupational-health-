# ==============================================================================
# AUGUSTA VICTORIA HOSPITAL - NATIVE SQLITE PERSISTENCE ENGINE (C# / WINSQLITE3)
# ACID Transactions, WAL Mode, Parameterized Queries, Audit Logging & Concurrency
# ==============================================================================

if (-not ([System.Management.Automation.PSTypeName]'AvhSqliteEngine').Type) {
    $csharpCode = @"
using System;
using System.Text;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public class AvhSqliteEngine : IDisposable {
    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_open_v2", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_open_v2(byte[] filename, out IntPtr db, int flags, IntPtr zVfs);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_close", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_close(IntPtr db);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_prepare16_v2", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
    private static extern int sqlite3_prepare16_v2(IntPtr db, string sql, int numBytes, out IntPtr stmt, IntPtr tail);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_step", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_step(IntPtr stmt);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_finalize", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_finalize(IntPtr stmt);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_reset", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_reset(IntPtr stmt);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_errmsg16", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_errmsg16(IntPtr db);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_bind_parameter_index", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern int sqlite3_bind_parameter_index(IntPtr stmt, string name);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_bind_text16", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
    private static extern int sqlite3_bind_text16(IntPtr stmt, int index, string val, int len, IntPtr destructor);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_bind_int64", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_bind_int64(IntPtr stmt, int index, long val);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_bind_double", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_bind_double(IntPtr stmt, int index, double val);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_bind_null", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_bind_null(IntPtr stmt, int index);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_column_count", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_column_count(IntPtr stmt);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_column_name16", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_column_name16(IntPtr stmt, int iCol);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_column_type", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_column_type(IntPtr stmt, int iCol);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_column_text16", CallingConvention = CallingConvention.Cdecl)]
    private static extern IntPtr sqlite3_column_text16(IntPtr stmt, int iCol);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_column_int64", CallingConvention = CallingConvention.Cdecl)]
    private static extern long sqlite3_column_int64(IntPtr stmt, int iCol);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_column_double", CallingConvention = CallingConvention.Cdecl)]
    private static extern double sqlite3_column_double(IntPtr stmt, int iCol);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_changes", CallingConvention = CallingConvention.Cdecl)]
    private static extern int sqlite3_changes(IntPtr db);

    [DllImport("winsqlite3.dll", EntryPoint = "sqlite3_last_insert_rowid", CallingConvention = CallingConvention.Cdecl)]
    private static extern long sqlite3_last_insert_rowid(IntPtr db);

    private const int SQLITE_OK = 0;
    private const int SQLITE_ROW = 100;
    private const int SQLITE_DONE = 101;
    private const int SQLITE_INTEGER = 1;
    private const int SQLITE_FLOAT = 2;
    private const int SQLITE_TEXT = 3;
    private const int SQLITE_BLOB = 4;
    private const int SQLITE_NULL = 5;

    private IntPtr _db = IntPtr.Zero;
    private readonly object _lock = new object();

    public AvhSqliteEngine(string dbPath) {
        byte[] bytes = System.Text.Encoding.UTF8.GetBytes(dbPath + "\0");
        int flags = 0x00000002 | 0x00000004 | 0x00010000; // SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX
        int rc = sqlite3_open_v2(bytes, out _db, flags, IntPtr.Zero);
        if (rc != SQLITE_OK) {
            string err = GetError();
            throw new Exception("Cannot open database: " + err + " (Code " + rc + ")");
        }
        Execute("PRAGMA journal_mode = TRUNCATE;");
        Execute("PRAGMA synchronous = NORMAL;");
        Execute("PRAGMA foreign_keys = ON;");
        Execute("PRAGMA busy_timeout = 15000;");
    }

    private string GetError() {
        if (_db == IntPtr.Zero) return "Null DB Handle";
        IntPtr ptr = sqlite3_errmsg16(_db);
        return ptr == IntPtr.Zero ? "Unknown error" : Marshal.PtrToStringUni(ptr);
    }

    public void Execute(string sql) {
        lock (_lock) {
            IntPtr stmt;
            int rc = sqlite3_prepare16_v2(_db, sql, -1, out stmt, IntPtr.Zero);
            if (rc != SQLITE_OK) {
                throw new Exception("Prepare failed: " + GetError() + " SQL: " + sql);
            }
            try {
                rc = sqlite3_step(stmt);
                if (rc != SQLITE_DONE && rc != SQLITE_ROW) {
                    throw new Exception("Step failed: " + GetError() + " SQL: " + sql);
                }
            } finally {
                sqlite3_finalize(stmt);
            }
        }
    }

    public int ExecuteNonQuery(string sql, Dictionary<string, object> parameters = null) {
        lock (_lock) {
            IntPtr stmt;
            int rc = sqlite3_prepare16_v2(_db, sql, -1, out stmt, IntPtr.Zero);
            if (rc != SQLITE_OK) {
                throw new Exception("Prepare failed: " + GetError() + " SQL: " + sql);
            }
            try {
                BindParameters(stmt, parameters);
                rc = sqlite3_step(stmt);
                if (rc != SQLITE_DONE && rc != SQLITE_ROW) {
                    throw new Exception("ExecuteNonQuery failed: " + GetError() + " SQL: " + sql);
                }
                return sqlite3_changes(_db);
            } finally {
                sqlite3_finalize(stmt);
            }
        }
    }

    public long GetLastInsertRowId() {
        lock (_lock) {
            return sqlite3_last_insert_rowid(_db);
        }
    }

    public List<Dictionary<string, object>> Query(string sql, Dictionary<string, object> parameters = null) {
        lock (_lock) {
            IntPtr stmt;
            int rc = sqlite3_prepare16_v2(_db, sql, -1, out stmt, IntPtr.Zero);
            if (rc != SQLITE_OK) {
                throw new Exception("Prepare failed: " + GetError() + " SQL: " + sql);
            }
            var list = new List<Dictionary<string, object>>();
            try {
                BindParameters(stmt, parameters);
                int colCount = sqlite3_column_count(stmt);
                string[] colNames = new string[colCount];
                for (int i = 0; i < colCount; i++) {
                    IntPtr namePtr = sqlite3_column_name16(stmt, i);
                    colNames[i] = Marshal.PtrToStringUni(namePtr);
                }

                while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
                    var row = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                    for (int i = 0; i < colCount; i++) {
                        int type = sqlite3_column_type(stmt, i);
                        object val = null;
                        switch (type) {
                            case SQLITE_INTEGER:
                                val = sqlite3_column_int64(stmt, i);
                                break;
                            case SQLITE_FLOAT:
                                val = sqlite3_column_double(stmt, i);
                                break;
                            case SQLITE_TEXT:
                                IntPtr ptr = sqlite3_column_text16(stmt, i);
                                val = Marshal.PtrToStringUni(ptr);
                                break;
                            case SQLITE_NULL:
                                val = null;
                                break;
                            default:
                                IntPtr defPtr = sqlite3_column_text16(stmt, i);
                                val = Marshal.PtrToStringUni(defPtr);
                                break;
                        }
                        row[colNames[i]] = val;
                    }
                    list.Add(row);
                }
                return list;
            } finally {
                sqlite3_finalize(stmt);
            }
        }
    }

    public Dictionary<string, object> QueryRow(string sql, Dictionary<string, object> parameters = null) {
        var list = Query(sql, parameters);
        return list.Count > 0 ? list[0] : null;
    }

    public object ExecuteScalar(string sql, Dictionary<string, object> parameters = null) {
        var row = QueryRow(sql, parameters);
        if (row != null && row.Count > 0) {
            foreach (var kv in row) return kv.Value;
        }
        return null;
    }

    public void BeginTransaction() {
        Execute("BEGIN IMMEDIATE TRANSACTION;");
    }

    public void Commit() {
        Execute("COMMIT;");
    }

    public void Rollback() {
        try { Execute("ROLLBACK;"); } catch {}
    }

    private void BindParameters(IntPtr stmt, Dictionary<string, object> parameters) {
        if (parameters == null) return;
        foreach (var kv in parameters) {
            string paramName = kv.Key.StartsWith("@") || kv.Key.StartsWith(":") ? kv.Key : ("@" + kv.Key);
            int idx = sqlite3_bind_parameter_index(stmt, paramName);
            if (idx == 0) continue;

            object val = kv.Value;
            if (val == null || val is DBNull) {
                sqlite3_bind_null(stmt, idx);
            } else if (val is int || val is short || val is byte) {
                sqlite3_bind_int64(stmt, idx, Convert.ToInt64(val));
            } else if (val is long) {
                sqlite3_bind_int64(stmt, idx, (long)val);
            } else if (val is bool) {
                sqlite3_bind_int64(stmt, idx, ((bool)val) ? 1 : 0);
            } else if (val is double || val is float || val is decimal) {
                sqlite3_bind_double(stmt, idx, Convert.ToDouble(val));
            } else {
                // SQLITE_TRANSIENT copies marshalled text before the managed buffer is released.
                sqlite3_bind_text16(stmt, idx, val.ToString(), -1, new IntPtr(-1));
            }
        }
    }

    public void Dispose() {
        lock (_lock) {
            if (_db != IntPtr.Zero) {
                sqlite3_close(_db);
                _db = IntPtr.Zero;
            }
        }
    }
}
"@
    Add-Type -TypeDefinition $csharpCode -Language CSharp
}

# --- Database Helper Functions ---

function Initialize-AvhDatabase([string]$dbPath) {
    $dbDir = Split-Path -Parent $dbPath
    if (-not (Test-Path $dbDir)) {
        New-Item -ItemType Directory -Path $dbDir -Force | Out-Null
    }

    $db = New-Object AvhSqliteEngine($dbPath)

    $schemaStatements = @(
        "PRAGMA journal_mode = TRUNCATE;",
        "PRAGMA synchronous = NORMAL;",
        "PRAGMA foreign_keys = ON;",
        "PRAGMA busy_timeout = 15000;",
        @"
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            emp_no TEXT NOT NULL UNIQUE,
            national_id TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            arabic_name TEXT,
            department TEXT,
            job_title TEXT,
            dob TEXT,
            hepb_titer TEXT,
            immunity_status TEXT,
            staff_group TEXT,
            invasive_procedure TEXT,
            data_json TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            is_deleted INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            created_by TEXT,
            updated_by TEXT,
            deleted_at TEXT,
            deleted_by TEXT
        );
"@,
        "CREATE INDEX IF NOT EXISTS idx_emp_no ON employees(emp_no);",
        "CREATE INDEX IF NOT EXISTS idx_national_id ON employees(national_id);",
        "CREATE INDEX IF NOT EXISTS idx_emp_dept ON employees(department);",
        "CREATE INDEX IF NOT EXISTS idx_emp_deleted ON employees(is_deleted);",
        @"
        CREATE TABLE IF NOT EXISTS injury_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial_no TEXT NOT NULL UNIQUE,
            emp_no TEXT,
            national_id TEXT,
            employee_name TEXT NOT NULL,
            department TEXT,
            job_title TEXT,
            incident_date TEXT NOT NULL,
            report_date TEXT NOT NULL,
            incident_type TEXT,
            exposure_type TEXT,
            data_json TEXT NOT NULL,
            version INTEGER NOT NULL DEFAULT 1,
            is_deleted INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            created_by TEXT,
            updated_by TEXT,
            deleted_at TEXT,
            deleted_by TEXT
        );
"@,
        "CREATE INDEX IF NOT EXISTS idx_injury_serial ON injury_reports(serial_no);",
        "CREATE INDEX IF NOT EXISTS idx_injury_emp_no ON injury_reports(emp_no);",
        "CREATE INDEX IF NOT EXISTS idx_injury_date ON injury_reports(incident_date);",
        "CREATE INDEX IF NOT EXISTS idx_injury_deleted ON injury_reports(is_deleted);",
        @"
        CREATE TABLE IF NOT EXISTS certificate_issuances (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            certificate_no TEXT NOT NULL UNIQUE,
            emp_no TEXT NOT NULL,
            national_id TEXT,
            employee_name TEXT NOT NULL,
            cert_type TEXT NOT NULL,
            issued_at TEXT NOT NULL,
            issued_by TEXT NOT NULL,
            data_json TEXT NOT NULL,
            is_deleted INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            deleted_at TEXT,
            deleted_by TEXT
        );
"@,
        "CREATE INDEX IF NOT EXISTS idx_cert_no ON certificate_issuances(certificate_no);",
        "CREATE INDEX IF NOT EXISTS idx_cert_emp ON certificate_issuances(emp_no);",
        @"
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            action TEXT NOT NULL,
            performed_by TEXT NOT NULL,
            ip_address TEXT,
            details_json TEXT,
            timestamp TEXT NOT NULL
        );
"@,
        "CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);",
        "CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_logs(timestamp);",
        @"
        CREATE TABLE IF NOT EXISTS system_meta (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
"@,
        @"
        CREATE TABLE IF NOT EXISTS user_sessions (
            token TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            user_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
"@,
        "CREATE INDEX IF NOT EXISTS idx_sessions_expires ON user_sessions(expires_at);"
    )

    foreach ($stmt in $schemaStatements) {
        $db.Execute($stmt)
    }

    # Record schema initialization metadata
    $now = (Get-Date).ToString("o")
    $params = New-Object 'System.Collections.Generic.Dictionary[string,object]'
    $params.Add("@key", "schema_version")
    $params.Add("@val", "2.0")
    $params.Add("@updated_at", $now)
    $db.ExecuteNonQuery("INSERT OR REPLACE INTO system_meta (key, value, updated_at) VALUES (@key, @val, @updated_at);", $params) | Out-Null

    return $db
}

function New-DbParameters([hashtable]$hash) {
    $dict = New-Object 'System.Collections.Generic.Dictionary[string,object]'
    if ($hash) {
        foreach ($k in $hash.Keys) {
            $key = if ($k.StartsWith("@")) { $k } else { "@" + $k }
            $dict.Add($key, $hash[$k])
        }
    }
    return $dict
}

function Write-DbAuditLog($db, [string]$entityType, [string]$entityId, [string]$action, [string]$performedBy, [string]$ip = "", [string]$detailsJson = "") {
    $params = New-DbParameters @{
        entity_type  = $entityType
        entity_id    = $entityId
        action       = $action
        performed_by = $performedBy
        ip_address   = $ip
        details_json = $detailsJson
        timestamp    = (Get-Date).ToString("o")
    }
    $sql = "INSERT INTO audit_logs (entity_type, entity_id, action, performed_by, ip_address, details_json, timestamp) 
            VALUES (@entity_type, @entity_id, @action, @performed_by, @ip_address, @details_json, @timestamp);"
    $db.ExecuteNonQuery($sql, $params) | Out-Null
}

function Backup-AvhDatabase($db, [string]$sourceDbPath, [string]$backupDir) {
    if (-not (Test-Path $backupDir)) {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    }
    # Increased timestamp precision with milliseconds
    $timestamp = (Get-Date).ToString("yyyyMMdd_HHmmss_fff")
    $backupFileName = "avh_occupational_health_backup_$timestamp.db"
    $backupFilePath = Join-Path $backupDir $backupFileName

    # In SQLite WAL mode, run VACUUM INTO to create an atomic, non-blocking online backup!
    # Escape apostrophes in SQLite backup paths and normalize directory separators
    $escapedPath = $backupFilePath.Replace('\', '/').Replace("'", "''")
    $vacuumSql = "VACUUM INTO '$escapedPath';"
    try {
        $db.Execute($vacuumSql)
        # Prune old backups, keep last 30
        Get-ChildItem -Path $backupDir -Filter "avh_occupational_health_backup_*.db" | 
            Sort-Object CreationTime -Descending | 
            Select-Object -Skip 30 | 
            Remove-Item -Force -ErrorAction SilentlyContinue

        return @{
            success    = $true
            filePath   = $backupFilePath
            fileName   = $backupFileName
            backupFile = $backupFileName
            time       = (Get-Date).ToString("o")
        }
    } catch {
        return @{
            success = $false
            error   = $_.Exception.Message
        }
    }
}

function Repair-AvhDatabaseArabicNames($db, [string]$masterJsonPath) {
    if (-not $db -or -not (Test-Path $masterJsonPath)) {
        return @{ success = $false; repaired = 0; status = "skipped_no_source" }
    }

    $raw = [System.IO.File]::ReadAllText($masterJsonPath, [System.Text.Encoding]::UTF8)
    $masterList = $raw | ConvertFrom-Json

    $cleanByEmpNo = @{}
    $cleanByIdNo = @{}
    $cleanPosByEmpNo = @{}
    $cleanPosByIdNo = @{}

    foreach ($m in $masterList) {
        $empNo = [string]$m.empNo
        if (-not $empNo -and $m.demographic) { $empNo = [string]$m.demographic.personNumber }
        $idNo = [string]$m.idNo
        if (-not $idNo -and $m.demographic) { $idNo = [string]$m.demographic.nationalId }

        $ar = if ($m.demographic -and $m.demographic.arabicFullName) { [string]$m.demographic.arabicFullName } elseif ($m.arabicFullName) { [string]$m.arabicFullName } else { "" }
        $posAr = if ($m.demographic -and $m.demographic.positionArabic) { [string]$m.demographic.positionArabic } elseif ($m.positionArabic) { [string]$m.positionArabic } else { "" }

        if ($empNo) {
            $cleanByEmpNo[$empNo.Trim().TrimStart('0')] = $ar
            $cleanPosByEmpNo[$empNo.Trim().TrimStart('0')] = $posAr
        }
        if ($idNo) {
            $cleanByIdNo[$idNo.Trim().TrimStart('0')] = $ar
            $cleanPosByIdNo[$idNo.Trim().TrimStart('0')] = $posAr
        }
    }

    $rows = $db.Query("SELECT id, emp_no, national_id, full_name, arabic_name, data_json FROM employees;")
    $repaired = 0

    $db.BeginTransaction()
    try {
        foreach ($r in $rows) {
            $id = $r["id"]
            $empNo = ([string]$r["emp_no"]).Trim().TrimStart('0')
            $idNo = ([string]$r["national_id"]).Trim().TrimStart('0')

            $cleanAr = ""
            $cleanPosAr = ""

            if ($cleanByEmpNo.ContainsKey($empNo) -and $cleanByEmpNo[$empNo]) {
                $cleanAr = $cleanByEmpNo[$empNo]
                $cleanPosAr = $cleanPosByEmpNo[$empNo]
            } elseif ($cleanByIdNo.ContainsKey($idNo) -and $cleanByIdNo[$idNo]) {
                $cleanAr = $cleanByIdNo[$idNo]
                $cleanPosAr = $cleanPosByIdNo[$idNo]
            } else {
                $mojibake = [string]$r["arabic_name"]
                if ($mojibake) {
                    try {
                        $cp1256 = [System.Text.Encoding]::GetEncoding(1256)
                        $bytes = $cp1256.GetBytes($mojibake)
                        $rev = [System.Text.Encoding]::UTF8.GetString($bytes)
                        if ($rev -match '[\u0600-\u06FF]') { $cleanAr = $rev }
                    } catch {}
                }
            }

            if (-not $cleanAr) { continue }

            $rawJson = $r["data_json"]
            $empObj = ConvertFrom-JsonSafe $rawJson
            if ($null -eq $empObj) { continue }

            if ($empObj -is [System.Collections.IDictionary]) {
                if (-not $empObj.ContainsKey("demographic") -or $null -eq $empObj["demographic"]) {
                    $empObj["demographic"] = @{}
                }
                $demo = $empObj["demographic"]
                if ($demo -is [System.Collections.IDictionary]) {
                    $demo["arabicFullName"] = $cleanAr
                    if ($cleanPosAr) { $demo["positionArabic"] = $cleanPosAr }
                } else {
                    $demo | Add-Member -NotePropertyName "arabicFullName" -NotePropertyValue $cleanAr -Force
                    if ($cleanPosAr) { $demo | Add-Member -NotePropertyName "positionArabic" -NotePropertyValue $cleanPosAr -Force }
                }
                if ($empObj.ContainsKey("arabicFullName")) { $empObj["arabicFullName"] = $cleanAr }
                if ($empObj.ContainsKey("arabicName")) { $empObj["arabicName"] = $cleanAr }
                if ($empObj.ContainsKey("positionArabic") -and $cleanPosAr) { $empObj["positionArabic"] = $cleanPosAr }
            } else {
                if (-not $empObj.demographic) {
                    $empObj | Add-Member -NotePropertyName "demographic" -NotePropertyValue (@{}) -Force
                }
                $empObj.demographic | Add-Member -NotePropertyName "arabicFullName" -NotePropertyValue $cleanAr -Force
                if ($cleanPosAr) {
                    $empObj.demographic | Add-Member -NotePropertyName "positionArabic" -NotePropertyValue $cleanPosAr -Force
                }
                if ($null -ne $empObj.arabicFullName) { $empObj.arabicFullName = $cleanAr }
                if ($null -ne $empObj.arabicName) { $empObj.arabicName = $cleanAr }
                if ($null -ne $empObj.positionArabic -and $cleanPosAr) { $empObj.positionArabic = $cleanPosAr }
            }

            $newDataJson = ConvertTo-Json -InputObject $empObj -Depth 15 -Compress
            $p = New-DbParameters @{
                id = $id
                arabic_name = $cleanAr
                data_json = $newDataJson
            }
            $db.ExecuteNonQuery("UPDATE employees SET arabic_name = @arabic_name, data_json = @data_json WHERE id = @id;", $p) | Out-Null
            $repaired++
        }

        $now = (Get-Date).ToString("o")
        $pMeta = New-DbParameters @{ key = "arabic_names_repaired"; val = "$repaired records restored at $now"; updated_at = $now }
        $db.ExecuteNonQuery("INSERT OR REPLACE INTO system_meta (key, value, updated_at) VALUES (@key, @val, @updated_at);", $pMeta) | Out-Null

        $db.Commit()
        return @{ success = $true; repaired = $repaired; status = "repaired" }
    } catch {
        $db.Rollback()
        return @{ success = $false; repaired = 0; status = "error"; error = $_.Exception.Message }
    }
}

function Repair-AvhDatabaseBlankTiterStaff($db) {
    if (-not $db) { return @{ success = $false; repaired = 0; status = "skipped" } }
    $targets = @('1461', '1463', '1476', '1483', '1374', '1487', '1480', '1478', '1481', '1479')
    $inClause = ($targets | ForEach-Object { "'$_'" }) -join ','
    $db.BeginTransaction()
    try {
        $rows = $db.Query("SELECT id, emp_no, data_json FROM employees WHERE emp_no IN ($inClause) AND is_deleted = 0;")
        $repaired = 0
        foreach ($r in $rows) {
            $id = $r["id"]
            $raw = [string]$r["data_json"]
            if (-not $raw) { continue }
            $empObj = $null
            try { $empObj = ConvertFrom-JsonSafe $raw } catch { try { $empObj = ConvertFrom-Json $raw } catch {} }
            if (-not $empObj) { continue }
            $changed = $false
            if ($empObj.hepbTiter -eq '> 1000 mIU/mL') {
                $empObj.hepbTiter = ''
                $changed = $true
            }
            if ($empObj.labResults -and $empObj.labResults.hbsabResult -eq '> 1000 mIU/mL') {
                $empObj.labResults.hbsabResult = ''
                $changed = $true
            }
            if ($changed) {
                $newDataJson = ConvertTo-Json -InputObject $empObj -Depth 15 -Compress
                $p = New-DbParameters @{
                    id = $id
                    hepb_titer = ''
                    data_json = $newDataJson
                }
                $db.ExecuteNonQuery("UPDATE employees SET hepb_titer = @hepb_titer, data_json = @data_json WHERE id = @id;", $p) | Out-Null
                $repaired++
            }
        }
        $db.Commit()
        return @{ success = $true; repaired = $repaired; status = "repaired" }
    } catch {
        $db.Rollback()
        return @{ success = $false; repaired = 0; status = "error"; error = $_.Exception.Message }
    }
}

function Sync-AvhInitialStaffBaseline($db, [string]$masterJsonPath) {
    if (-not $db -or -not (Test-Path $masterJsonPath)) {
        return @{ success = $false; imported = 0; status = "skipped_no_source" }
    }

    # Proactive self-healing: Check if existing employees require Arabic name repair
    try {
        $corruptCheck = $db.QueryRow("SELECT COUNT(*) AS c FROM employees WHERE (arabic_name LIKE '%ط%' OR arabic_name LIKE '%ظ%') AND is_deleted = 0;")
        if ($null -ne $corruptCheck -and [int]$corruptCheck["c"] -gt 0) {
            $heal = Repair-AvhDatabaseArabicNames -db $db -masterJsonPath $masterJsonPath
            if ($heal.success -and $heal.repaired -gt 0) {
                Write-Host " [DB] Auto-repaired $($heal.repaired) employee records with clean Arabic names from master baseline." -ForegroundColor Green
            }
        }
    } catch {}

    # Proactive self-healing: Auto-repair employees with blank HBsAb tests that were defaulted to >1000
    try {
        $blankRepair = Repair-AvhDatabaseBlankTiterStaff -db $db
        if ($blankRepair.success -and $blankRepair.repaired -gt 0) {
            Write-Host " [DB] Auto-repaired $($blankRepair.repaired) employee records with blank HBsAb tests." -ForegroundColor Green
        }
    } catch {}

    # Check if baseline import was already recorded
    $marker = $db.QueryRow("SELECT value FROM system_meta WHERE key = 'initial_staff_import';")
    if ($null -ne $marker) {
        return @{ success = $true; imported = 0; status = "already_imported"; marker = $marker["value"] }
    }

    # If database already has employee records from prior runs, preserve existing database and set marker
    $cntRow = $db.QueryRow("SELECT COUNT(*) AS c FROM employees;")
    $existingCount = if ($null -ne $cntRow) { [int]$cntRow["c"] } else { 0 }
    if ($existingCount -gt 0) {
        $now = (Get-Date).ToString("o")
        $p = New-DbParameters @{ key = "initial_staff_import"; val = "$existingCount (existing preserved)"; updated_at = $now }
        $db.ExecuteNonQuery("INSERT OR REPLACE INTO system_meta (key, value, updated_at) VALUES (@key, @val, @updated_at);", $p) | Out-Null
        return @{ success = $true; imported = 0; status = "existing_preserved"; count = $existingCount }
    }

    # Read packaged baseline JSON
    $raw = [System.IO.File]::ReadAllText($masterJsonPath, [System.Text.Encoding]::UTF8)
    $list = $raw | ConvertFrom-Json
    if (-not $list -or $list.Count -eq 0) {
        return @{ success = $false; imported = 0; status = "empty_dataset" }
    }

    $db.BeginTransaction()
    try {
        $now = (Get-Date).ToString("o")
        $insSql = @"
        INSERT INTO employees (
            emp_no, national_id, full_name, arabic_name, department, job_title,
            dob, hepb_titer, immunity_status, staff_group, invasive_procedure,
            data_json, version, is_deleted, created_at, updated_at, created_by, updated_by
        ) VALUES (
            @emp_no, @national_id, @full_name, @arabic_name, @department, @job_title,
            @dob, @hepb_titer, @immunity_status, @staff_group, @invasive_procedure,
            @data_json, 1, 0, @created_at, @updated_at, 'system_migration', 'system_migration'
        );
"@
        $imported = 0
        foreach ($emp in $list) {
            $tEmpNo = ""
            if ($null -ne $emp.empNo -and [string]$emp.empNo -ne "") { $tEmpNo = [string]$emp.empNo }
            elseif ($null -ne $emp.id -and [string]$emp.id -ne "") { $tEmpNo = [string]$emp.id }
            elseif ($null -ne $emp.employeeNumber -and [string]$emp.employeeNumber -ne "") { $tEmpNo = [string]$emp.employeeNumber }
            elseif ($null -ne $emp.demographic -and $null -ne $emp.demographic.personNumber) { $tEmpNo = [string]$emp.demographic.personNumber }
            $tEmpNo = $tEmpNo.Trim().TrimStart('0')

            $tIdNo = ""
            if ($null -ne $emp.idNo -and [string]$emp.idNo -ne "") { $tIdNo = [string]$emp.idNo }
            elseif ($null -ne $emp.nationalId -and [string]$emp.nationalId -ne "") { $tIdNo = [string]$emp.nationalId }
            elseif ($null -ne $emp.demographic -and $null -ne $emp.demographic.nationalId) { $tIdNo = [string]$emp.demographic.nationalId }
            $tIdNo = $tIdNo.Trim().TrimStart('0')

            $tName = ""
            if ($null -ne $emp.name -and [string]$emp.name -ne "") { $tName = [string]$emp.name }
            elseif ($null -ne $emp.fullName -and [string]$emp.fullName -ne "") { $tName = [string]$emp.fullName }
            elseif ($null -ne $emp.demographic -and $null -ne $emp.demographic.fullName) { $tName = [string]$emp.demographic.fullName }
            $tName = $tName.Trim()

            if (-not $tName) { continue }
            if (-not $tEmpNo) { $tEmpNo = "EMP-$tIdNo" }
            if (-not $tIdNo)  { $tIdNo  = "ID-$tEmpNo" }

            $demo = if ($emp.demographic) { $emp.demographic } else { @{} }
            $lab  = if ($emp.labResults)  { $emp.labResults }  else { @{} }

            $dataJson = ConvertTo-Json -InputObject $emp -Depth 12 -Compress

            $insParams = New-DbParameters @{
                emp_no             = $tEmpNo
                national_id        = $tIdNo
                full_name          = $tName
                arabic_name        = $(if ($demo.arabicFullName) { [string]$demo.arabicFullName } else { "" })
                department         = $(if ($emp.department) { [string]$emp.department } elseif ($demo.department) { [string]$demo.department } else { "General" })
                job_title          = $(if ($emp.jobTitle) { [string]$emp.jobTitle } elseif ($demo.positionName) { [string]$demo.positionName } else { "Staff" })
                dob                = $(if ($emp.dob) { [string]$emp.dob } elseif ($demo.dob) { [string]$demo.dob } else { "" })
                hepb_titer         = $(if ($emp.hepbTiter) { [string]$emp.hepbTiter } elseif ($lab.hbsabResult) { [string]$lab.hbsabResult } else { "" })
                immunity_status    = $(if ($emp.immunityStatus) { [string]$emp.immunityStatus } else { "Pending Verification" })
                staff_group        = $(if ($emp.staffGroup) { [string]$emp.staffGroup } elseif ($demo.staffGroup) { [string]$demo.staffGroup } else { "Standard" })
                invasive_procedure = $(if ($emp.invasiveProcedure) { [string]$emp.invasiveProcedure } else { "No" })
                data_json          = $dataJson
                created_at         = $now
                updated_at         = $now
            }

            $db.ExecuteNonQuery($insSql, $insParams) | Out-Null
            $imported++
        }

        # Import and migration marker commit together
        $mParams = New-DbParameters @{ key = "initial_staff_import"; val = "$imported"; updated_at = $now }
        $db.ExecuteNonQuery("INSERT OR REPLACE INTO system_meta (key, value, updated_at) VALUES (@key, @val, @updated_at);", $mParams) | Out-Null

        $db.Commit()
        return @{ success = $true; imported = $imported; status = "success" }
    } catch {
        $db.Rollback()
        throw $_
    }
}
