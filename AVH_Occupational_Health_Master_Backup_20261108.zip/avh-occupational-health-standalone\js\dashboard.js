
// Uses canonical toSafeLabString and getFirstDefinedLabValue from js/data.js

/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - STATISTICAL & REPORTING DASHBOARD CONTROLLER
   (100% Dynamic Live Calculated AVH & MOH Executive Excel Report)
   Each Table Card with Dedicated Chart Diagram, Percentages & Printing
   ========================================================================== */

let currentDashboardSubTab = 'avh';

function switchDashboardSubTab(subTabKey) {
  currentDashboardSubTab = subTabKey;
  if (subTabKey === 'body_fluid_injury' || subTabKey === 'injury_processing') {
    window.selectedInjurySubReport = 'both';
    if (window.selectedInjuryYear === '2023') {
      window.selectedInjuryYear = '2025';
    }
  }
  const container = document.getElementById('mainAppArea');
  if (container) renderDashboardOverview(container);

  document.querySelectorAll('.sidebar-sub-tab-dashboard').forEach(btn => {
    const isTarget = btn.getAttribute('data-subtab') === subTabKey;
    btn.classList.toggle('active', isTarget);
  });
}
window.switchDashboardSubTab = switchDashboardSubTab;

// Helper to print an individual table card on demand
function printSingleCard(cardId, title, isLandscape = false) {
  const cardElem = document.getElementById(cardId);
  if (!cardElem) return;
  
  const clone = cardElem.cloneNode(true);
  const canvasElements = cardElem.querySelectorAll('canvas');
  const cloneCanvases = clone.querySelectorAll('canvas');

  canvasElements.forEach((origCanvas, idx) => {
    if (cloneCanvases[idx]) {
      const img = document.createElement('img');
      img.src = origCanvas.toDataURL('image/png', 1.0);
      img.style.maxWidth = '100%';
      img.style.height = 'auto';
      img.style.display = 'block';
      img.style.margin = '15px auto';
      cloneCanvases[idx].parentNode.replaceChild(img, cloneCanvases[idx]);
    }
  });

  const printWin = window.open('', '_blank', 'width=1100,height=800');
  if (!printWin) {
    alert('Pop-up window was blocked by your browser. Please allow pop-ups for this site to print cards.');
    return;
  }
  printWin.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${title} - Augusta Victoria Hospital</title>
        <style>
          @page { size: ${isLandscape ? 'landscape' : 'portrait'}; margin: 12mm; }
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 20px; color: #1E293B; background: white; }
          .no-print { display: none !important; }
          table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 9.5pt; }
          th, td { border: 1px solid #CBD5E1; padding: 8px; text-align: left; }
          th { background-color: #F1F5F9; font-weight: bold; }
          .card-title { font-size: 1.25rem; font-weight: bold; margin-bottom: 12px; color: #1A5F7A; border-bottom: 2px solid #E2E8F0; padding-bottom: 8px; }
          img { max-width: 100%; height: auto; display: block; margin: 15px auto; }
        </style>
      </head>
      <body>
        <div style="text-align: center; border-bottom: 2px dashed #1A5F7A; padding-bottom: 12px; margin-bottom: 20px;">
          <div style="margin-bottom: 8px; display: flex; justify-content: center; align-items: center;">
            <img src="assets/formal_logo.png" alt="Augusta Victoria Hospital Logo" style="max-height: 80px; width: auto; object-fit: contain;">
          </div>
          <h3 style="margin: 4px 0 0 0; color: #0284C7; font-size: 1.2rem; font-weight: 800;">Infectious Disease Unit | وحدة الأمراض المعدية — ${title}</h3>
        </div>
        <div class="no-print" style="margin-bottom: 15px; display: flex; justify-content: flex-end; gap: 8px;">
          <button onclick="window.print()" style="padding: 6px 14px; background: #0284C7; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">🖨️ Print Now / طباعة الآن</button>
          <button onclick="window.close()" style="padding: 6px 14px; background: #64748B; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">✕ Close / إغلاق</button>
        </div>
        ${clone.innerHTML}
        <script>
          window.onafterprint = function() { window.close(); };
          setTimeout(function() {
            try { window.focus(); window.print(); } catch(e) {}
          }, 300);
        </script>
      </body>
    </html>
  `);
  printWin.document.close();
  printWin.focus();
  setTimeout(() => {
    try { printWin.focus(); printWin.print(); } catch(e) {}
  }, 400);
}
window.printSingleCard = printSingleCard;

// ==========================================================================
// &#128269; GLOBAL MOH AUDIT DRILLDOWN MODAL & PRINT HANDLERS
// ==========================================================================
window.openMOHCellStaffModal = function(key) {
  const store = (window.mohCellStaffStore && window.mohCellStaffStore[key]) ? window.mohCellStaffStore[key] : {
    title: (key || 'Staff Category').replace(/_/g, ' ').toUpperCase() + ' (0)',
    list: []
  };

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const isGenderList = (key === 'gender_male' || key === 'gender_female' || String(key).startsWith('gender'));
  const orgColHeader = isAr ? 'اسم المؤسسة / Organization Name' : 'Organization Name';

  const modalId = 'mohCellStaffModalContainer';
  let container = document.getElementById(modalId);
  if (!container) {
    container = document.createElement('div');
    container.id = modalId;
    document.body.appendChild(container);
  }

  window.mohCellStaffModalQuery = '';

  const renderModalContent = () => {
    const q = (window.mohCellStaffModalQuery || '').toLowerCase().trim();
    const rawList = store.list || [];
    const filtered = rawList.filter(e => {
      const demo = e.demographic || {};
      const name = String(e.name || demo.fullName || '').toLowerCase();
      const id = String(e.empNo || demo.personNo || e.idNo || '').toLowerCase();
      const dept = String(e.department || demo.department || demo.deptTreating || '').toLowerCase();
      const org = String(demo.orgName || e.orgName || '').toLowerCase();
      const title = String(e.jobTitle || demo.positionName || demo.jobTitle || e.staffGroup || '').toLowerCase();
      return name.includes(q) || id.includes(q) || dept.includes(q) || org.includes(q) || title.includes(q);
    });

    let tbodyContent = '';
    if (rawList.length === 0) {
      tbodyContent = `
        <tr>
          <td colspan="6" style="padding: 36px 20px; text-align: center; background: #F8FAFC; color: #475569;">
            <div style="font-size: 2.2rem; margin-bottom: 8px;">&#9989;</div>
            <div style="font-size: 1.05rem; font-weight: 800; color: #0F172A;">No Staff Members in this Category (Count: 0)</div>
            <div style="font-size: 0.85rem; color: #64748B; margin-top: 4px;">\u0644\u0627 \u062a\u0648\u062c\u062f \u0623\u064a \u0633\u062c\u0644\u0627\u062a \u0643\u0648\u0627\u062f\u0631 \u0645\u0633\u062c\u0644\u0629 \u0636\u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u062a\u0635\u0646\u064a\u0641 (\u0627\u0644\u0639\u062f\u062f: 0)</div>
          </td>
        </tr>
      `;
    } else if (filtered.length === 0) {
      tbodyContent = `<tr><td colspan="6" style="padding: 24px; text-align: center; color: #64748B; font-weight: bold;">No staff records match your search filter.</td></tr>`;
    } else {
      tbodyContent = filtered.map((emp, i) => {
        const demo = emp.demographic || {};
        const pNo = emp.empNo || demo.personNo || emp.idNo || demo.idNo || '';
        const orgColVal = demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || demo.deptTreating || 'Augusta Victoria Hospital';
        return `
          <tr style="background: ${i % 2 === 0 ? '#FFFFFF' : '#F8FAFC'};">
            <td style="padding: 7px 8px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${i + 1}</td>
            <td style="padding: 7px 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #0F172A;">${emp.name || demo.fullName || 'Unnamed Staff'}</td>
            <td style="padding: 7px 8px; border: 1px solid #E2E8F0; text-align: center; font-family: monospace; font-weight: bold; color: #0284C7;">${pNo}</td>
            <td style="padding: 7px 8px; border: 1px solid #E2E8F0; color: #475569;">${orgColVal}</td>
            <td style="padding: 7px 8px; border: 1px solid #E2E8F0; color: #475569;">${emp.jobTitle || demo.positionName || demo.jobTitle || emp.staffGroup || 'Staff'}</td>
            <td style="padding: 7px 8px; border: 1px solid #E2E8F0; text-align: center;">
              <button class="btn btn-primary" style="padding: 4px 10px; font-size: 0.75rem; background: #0284C7; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;" onclick="document.getElementById('${modalId}').innerHTML=''; if (typeof openQuickUpdateModal === 'function') openQuickUpdateModal('${pNo}');">&#9889; Edit Record</button>
            </td>
          </tr>
        `;
      }).join('');
    }

    const existingTbody = document.getElementById('mohModalTbody');
    const existingCounter = document.getElementById('mohModalCounter');
    if (existingTbody && existingCounter) {
      existingTbody.innerHTML = tbodyContent;
      existingCounter.textContent = `Showing ${filtered.length} of ${rawList.length}`;
      return;
    }

    container.innerHTML = `
      <div style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px); z-index: 99999; display: flex; align-items: center; justify-content: center; padding: 20px;">
        <div style="background: white; width: 100%; max-width: 950px; max-height: 88vh; border-radius: 12px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); display: flex; flex-direction: column; overflow: hidden; border: 1px solid #CBD5E1;">
          
          <div style="background: linear-gradient(135deg, #1E3A8A 0%, #0369A1 100%); color: white; padding: 16px 22px; display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                <span>&#128203; MOH Audit Drilldown</span>
                <span style="background: #0284C7; font-size: 0.8rem; padding: 2px 8px; border-radius: 12px; font-weight: normal;">${rawList.length} Staff</span>
              </div>
              <div style="font-size: 0.88rem; color: #BAE6FD; margin-top: 3px; font-weight: bold;">
                ${store.title}
              </div>
            </div>
            <button onclick="document.getElementById('${modalId}').innerHTML=''" style="background: rgba(255,255,255,0.2); border: none; color: white; font-size: 1.2rem; cursor: pointer; padding: 4px 12px; border-radius: 6px; font-weight: bold;">&times;</button>
          </div>

          <div style="padding: 12px 22px; background: #F8FAFC; border-bottom: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap;">
            <input type="text" 
                   id="mohModalSearchInput"
                   placeholder="&#128269; Search staff by name, ID, or organization name..." 
                   value="${window.mohCellStaffModalQuery || ''}" 
                   onkeyup="window.mohCellStaffModalQuery = this.value; window.renderMOHCellStaffModalContent();" 
                   style="flex: 1; min-width: 250px; padding: 8px 14px; border: 1.5px solid #CBD5E1; border-radius: 6px; font-size: 0.88rem; outline: none;">
            
            <div style="display: flex; gap: 8px; align-items: center;">
              <span id="mohModalCounter" style="font-size: 0.85rem; font-weight: bold; color: #475569;">Showing ${filtered.length} of ${rawList.length}</span>
              <button class="btn btn-outline" style="padding: 5px 12px; font-size: 0.8rem; background: white;" onclick="window.printMOHCellStaffModalList('${key}')">&#128424;&#65039; Print List</button>
            </div>
          </div>

          <div style="flex: 1; overflow-y: auto; padding: 16px 22px;">
            <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 8.5pt;">
              <thead>
                <tr style="background: #F1F5F9; color: #334155; position: sticky; top: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                  <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: center; width: 40px;">#</th>
                  <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: left;">Staff Full Name</th>
                  <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: center;">Person # / ID</th>
                  <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: left;">${orgColHeader}</th>
                  <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: left;">Job Title / Sector</th>
                  <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: center; width: 100px;">Action</th>
                </tr>
              </thead>
              <tbody id="mohModalTbody">
                ${tbodyContent}
              </tbody>
            </table>
          </div>

          <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 22px; display: flex; justify-content: flex-end;">
            <button onclick="document.getElementById('${modalId}').innerHTML=''" style="padding: 7px 18px; font-size: 0.85rem; font-weight: bold; background: #475569; color: white; border: none; border-radius: 6px; cursor: pointer;">Close</button>
          </div>
        </div>
      </div>
    `;
  };

  window.renderMOHCellStaffModalContent = renderModalContent;
  renderModalContent();
};

window.printMOHCellStaffModalList = function(key) {
  const store = window.mohCellStaffStore ? window.mohCellStaffStore[key] : null;
  if (!store || !store.list) return;

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const isGenderList = (key === 'gender_male' || key === 'gender_female' || String(key).startsWith('gender'));
  const orgColHeader = isAr ? 'اسم المؤسسة / Organization Name' : 'Organization Name';

  const printWin = window.open('', '_blank', 'width=900,height=700');
  if (!printWin) {
    alert('Pop-up window was blocked by your browser. Please allow pop-ups for this site to print lists.');
    return;
  }
  printWin.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>MOH Audit Sub-List &mdash; ${store.title}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; color: #1E293B; }
          h3 { color: #1E3A8A; margin-bottom: 4px; }
          h2 { color: #0284C7; border-bottom: 2px solid #0284C7; padding-bottom: 8px; margin-top: 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 9pt; }
          th, td { border: 1px solid #CBD5E1; padding: 6px; text-align: left; }
          th { background: #F1F5F9; font-weight: bold; }
          @media print {
            .no-print { display: none !important; }
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 15px; display: flex; justify-content: flex-end; gap: 8px;">
          <button onclick="window.print()" style="padding: 6px 14px; background: #0284C7; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">&#128424;&#65039; Print Now / \u0637\u0628\u0627\u0639\u0629 \u0627\u0644\u0622\u0646</button>
          <button onclick="window.close()" style="padding: 6px 14px; background: #64748B; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">Close</button>
        </div>
        <h3>Augusta Victoria Hospital &mdash; Occupational Health</h3>
        <h2>${store.title}</h2>
        <p><strong>Total Listed Staff:</strong> ${store.list.length} | <strong>Generated:</strong> ${new Date().toLocaleString()}</p>
        <table>
          <thead>
            <tr>
              <th style="width: 35px; text-align: center;">#</th>
              <th>Full Name</th>
              <th style="text-align: center;">Person # / ID</th>
              <th>${orgColHeader}</th>
              <th>Job Title / Sector</th>
            </tr>
          </thead>
          <tbody>
            ${(store.list || []).map((emp, i) => {
              const demo = emp.demographic || {};
              const pNo = emp.empNo || demo.personNo || emp.idNo || demo.idNo || '';
              const orgColVal = demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || demo.deptTreating || 'Augusta Victoria Hospital';
              return `
                <tr>
                  <td style="text-align: center; font-weight: bold;">${i + 1}</td>
                  <td style="font-weight: bold;">${emp.name || demo.fullName || 'Unnamed'}</td>
                  <td style="text-align: center; font-family: monospace;">${pNo}</td>
                  <td>${orgColVal}</td>
                  <td>${emp.jobTitle || demo.positionName || demo.jobTitle || emp.staffGroup || 'Staff'}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
      </body>
    </html>
  `);
  printWin.document.close();
  setTimeout(() => {
    try { printWin.focus(); printWin.print(); } catch(e) {}
  }, 400);
};


function categorizeDepartmentGroup(deptName, empRecord) {
  const dept = String(deptName || '').toLowerCase().trim();
  const demo = empRecord?.demographic || {};
  const jTitle = String(empRecord?.jobTitle || demo.jobTitle || demo.positionName || demo.positionArabic || empRecord?.title || '').toLowerCase().trim();
  const sGroup = String(empRecord?.staffGroup || demo.staffGroup || '').toLowerCase().trim();
  const combined = `${dept} ${jTitle} ${sGroup}`.toLowerCase();

  // 1. Nursing & Midwifery Staff (Checked first so nursing supervisors in surgical/ICU are classified under Nursing)
  if (/\b(nurse|nursing|midwife|midwives)\b/i.test(combined) || combined.includes('head nurse') || combined.includes('staff nurse') || combined.includes('aid nurse') || combined.includes('practical nurse')) {
    return 'Nursing & Midwifery Staff';
  }

  // 2. Doctors & Medical Specialists
  if (/\b(doctor|physician|specialist|consultant|surgeon|pathologist|anesthesiologist|oncologist|radiologist|internist|nephrologist|intensivist|urologist|cardiologist|endocrinolog|fellow|mho)\b/i.test(combined) ||
      combined.includes('medical house officer') || combined.includes('chief medical officer') || combined.includes('resident doctor') || combined.includes('junior specialist') ||
      /head of (anesthesia|surgical|pediatric|kidney|intensive care|inpatient|cancer care|hematology|radiology|infectious|day care|internal medicine|anatomical pathology|pathology|laboratory|clinical lab)/i.test(combined)) {
    if (!/\b(technologist|technician|tech|engineer)\b/i.test(jTitle)) {
      return 'Doctors & Medical Specialists';
    }
  }

  // 3. Allied Health Professionals (Pharmacy, Lab, Radiology, Tech, Physio, Bio-Medical, Nutrition, Pathology)
  if (/\b(technologist|technician|tech|pharmacist|pharmacy|physio|physiotherapist|physiotherapy|nutrition|nutritionist|dietitian|physicist|physics|dosimetrist|biomedical|bio-medical|psychologist|psychosocial|scientist|phlebotom|apheresis|cytometry|audiolog|optomet)\b/i.test(combined) ||
      combined.includes('social worker') || combined.includes('radiation therapist') || combined.includes('flow cytometry') || combined.includes('anesthesia tech') || combined.includes('pet scan')) {
    return 'Allied Health Professionals';
  }

  // 4. General Services & Support (Housekeeping, Maintenance, Security, Kitchen, Gardening, Logistics, Public Services)
  if (/\b(cleaner|housekeeping|security|maintenance|driver|cook|chef|kitchen|gardner|gardener|logistics|storekeeper|grounds)\b/i.test(combined) ||
      combined.includes('public services') || combined.includes('buildings & grounds') || combined.includes('laundry')) {
    return 'General Services & Support';
  }

  // 5. Administration & Operations (HR, Billing, Accounting, CEO, CFO, Quality, IT, Patient Affairs, Secretariat)
  return 'Administration & Operations';
}
window.categorizeDepartmentGroup = categorizeDepartmentGroup;

window.currentDeptChartView = 'groups'; // default to 5 Department Groups covering 100% of hospital staff

function toggleDeptChartView(mode) {
  window.currentDeptChartView = mode;
  const container = document.getElementById('mainAppArea');
  if (container) renderDashboardOverview(container);
}
window.toggleDeptChartView = toggleDeptChartView;

const SPECIAL_VAC_DEPARTMENTS = [
  'anatomical pathology department',
  'anatomical pathology department/tech',
  'clinical laboratory',
  'hematopathology ,cellular therapy and applied genomics department',
  'hematopathology, cellular therapy and applied genomics department',
  'hematopathology,cellular therapy and applied genomics department',
  'laboratory medicine department',
  'molecular laboratory unit',
  'apheresis and bone marrow transplant lab',
  'hematomolecular pathology'
];

function isSpecialVacStaffDepartment(deptName, emp) {
  if (typeof isSpecialVaccineStaff === 'function' && isSpecialVaccineStaff(emp)) {
    return true;
  }

  const demo = emp?.demographic || {};
  const sGroup = String(emp?.staffGroup || demo.staffGroup || '').toLowerCase().trim();

  // EXCLUDE Basic Plan staff from Special Vaccine Target Denominator
  if (sGroup.includes('basic')) return false;

  const d = String(emp?.department || demo.department || demo.deptTreating || deptName || '').toLowerCase().trim();
  const title = String(emp?.jobTitle || demo.positionName || demo.positionArabic || '').toLowerCase().trim();

  // EXCLUDE Secretary Office & administrative staff unless they are technologists/lab staff
  if ((d.includes('secretary') || title.includes('secretary') || d.includes('admin') || title.includes('admin')) && !title.includes('tech') && !title.includes('lab')) {
    return false;
  }

  if (sGroup.includes('special') || sGroup.includes('lab') || sGroup.includes('4-')) return true;

  // Title checks for laboratory technologists & technicians & special clinical staff
  if (title.includes('lab') || title.includes('laboratory') || title.includes('pathology') || title.includes('molecular') || title.includes('apheresis') || title.includes('genomics') || title.includes('microbiology')) {
    return true;
  }

  if (SPECIAL_VAC_DEPARTMENTS.includes(d)) return true;

  if (d.includes('pathology') || d.includes('clinical lab') || d.includes('laboratory') || d.includes('hematopathology') || d.includes('cellular therapy') || d.includes('applied genomics') || d.includes('molecular') || d.includes('apheresis') || d.includes('bone marrow') || d.includes('hematomolecular')) {
    return true;
  }

  const sp = emp?.specialVaccines || {};
  if (sp.typhoid || sp.meningococcal || sp.pneumovax || sp.hepA1 || sp.hepA2 || sp.typhoidDate || sp.meningococcalDate || sp.pneumovaxDate || sp.hepADate) {
    return true;
  }

  return false;
}
window.isSpecialVacStaffDepartment = isSpecialVacStaffDepartment;

// --------------------------------------------------------------------------
// 📊 FULL DYNAMIC EXCEL REPORT CALCULATION ENGINE (WITH % FOR ALL)
// --------------------------------------------------------------------------
function computeAVHExcelReportData(employees, injuryReports, forceRefresh = false) {
  if (!employees || !Array.isArray(employees) || employees.length === 0) {
    employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  }
  const empLen = (employees && Array.isArray(employees)) ? employees.length : 0;
  const injLen = (injuryReports && Array.isArray(injuryReports)) ? injuryReports.length : 0;

  const curVer = (typeof window !== 'undefined' && window._employeesCacheVersion) || 1;
  if (!forceRefresh && typeof window !== 'undefined' && window._cachedAVHMetrics && 
      window._cachedAVHMetrics.gender &&
      window._cachedAVHMetricsVersion === curVer &&
      window._cachedAVHMetricsEmpLen === empLen && window._cachedAVHMetricsInjLen === injLen) {
    return window._cachedAVHMetrics;
  }

  // Exclude Gaza Project Staff & Archived/Former Staff from all statistical dashboard calculations
  const nonGazaEmployees = (employees || []).filter(emp => {
    const isGaza = typeof isGazaStaff === 'function' ? isGazaStaff(emp) : false;
    const isActive = typeof isActiveStaff === 'function' ? isActiveStaff(emp) : true;
    return !isGaza && isActive;
  });
  const total = nonGazaEmployees.length;

  // Gender Demographic Breakdown (Male / Female)
  let maleCount = 0, femaleCount = 0;
  const maleList = [], femaleList = [];

  let basicPlan = 0, minPlan = 0, extProgram = 0;
  let invasiveDept = 0, babiesUnder1 = 0, oncologyDept = 0, otherDept = 0;
  let hbsImmune = 0, hbsVaccinating = 0, hbsResistance = 0, hbsOngoing = 0, hbsNoNeed = 0, hbsGaza = 0;
  
  // HCV, HIV, PPD 3-category metrics (Positive, Negative, Ongoing)
  let hcvPos = 0, hcvNeg = 0, hcvOngoing = 0;
  let hivPos = 0, hivNeg = 0, hivOngoing = 0;
  let ppdPos = 0, ppdNeg = 0, ppdOngoing = 0;

  // Follow-up list arrays for interactive inspection
  const hbsImmuneList = [], hbsVaccinatingList = [], hbsResistanceList = [], hbsOngoingList = [], hbsNoNeedList = [];
  const hcvPosList = [], hcvNegList = [], hcvOngoingList = [];
  const hivPosList = [], hivNegList = [], hivOngoingList = [];
  const ppdPosList = [], ppdNegList = [], ppdOngoingList = [];

  // Varicella (Chickenpox) 4-category metrics & lists
  let var2DosesCount = 0, varPosIgGCount = 0, varNatImmCount = 0, varOngoingCount = 0;
  const var2DosesList = [];
  const varPosIgGList = [];
  const varNatImmList = [];
  const varOngoingList = [];

  // Seasonal Flu Vaccine 2024-2025 4-category metrics & lists
  let fluAvhDateCount = 0, fluKupatCount = 0, fluRefusedCount = 0, fluUnvaccinatedCount = 0;
  const fluAvhDateList = [];
  const fluKupatList = [];
  const fluRefusedList = [];
  const fluUnvaccinatedList = [];

  let ipvVac = 0, ipvRefused = 0, ipvContra = 0, ipvNot = 0;
  let tdapVac = 0, tdapRefused = 0, tdapContra = 0, tdapNot = 0;
  let mmr1Vac = 0, mmr1Refused = 0, mmr1Contra = 0, mmr1Not = 0;
  let mmr2Vac = 0, mmr2Refused = 0, mmr2Contra = 0, mmr2Not = 0;
  let cpVac = 0, cpRefused = 0, cpContra = 0, cpNot = 0;
  let uniqueCoreUnvacCount = 0;
  let uniqueSpecialUnvacCount = 0;

  // Dedicated Core Vaccine Lists for audit drilldown
  const coreIpvVacList = [], coreIpvRefusedList = [], coreIpvContraList = [], coreIpvNotList = [];
  const coreTdapVacList = [], coreTdapRefusedList = [], coreTdapContraList = [], coreTdapNotList = [];
  const coreMmr1VacList = [], coreMmr1RefusedList = [], coreMmr1ContraList = [], coreMmr1NotList = [];
  const coreMmr2VacList = [], coreMmr2RefusedList = [], coreMmr2ContraList = [], coreMmr2NotList = [];
  const coreCpVacList = [], coreCpRefusedList = [], coreCpContraList = [], coreCpNotList = [];
  const coreUniqueUnvacList = [];
  const coreUniqueContraList = [];
  const coreUniqueRefusedList = [];

  let specialTargetTotal = 0;
  let menVac = 0, menRefused = 0, menContra = 0, menNot = 0;
  let hepA1Vac = 0, hepA1Refused = 0, hepA1Contra = 0, hepA1Not = 0;
  let hepA2Vac = 0, hepA2Refused = 0, hepA2Contra = 0, hepA2Not = 0;
  let typVac = 0, typRefused = 0, typContra = 0, typNot = 0;
  let pneVac = 0, pneRefused = 0, pneContra = 0, pneNot = 0;

  // Dedicated Special Vaccine Lists for audit drilldown
  const specialTargetList = [];
  const specialMenVacList = [], specialMenRefusedList = [], specialMenContraList = [], specialMenNotList = [];
  const specialHa1VacList = [], specialHa1RefusedList = [], specialHa1ContraList = [], specialHa1NotList = [];
  const specialHa2VacList = [], specialHa2RefusedList = [], specialHa2ContraList = [], specialHa2NotList = [];
  const specialTypVacList = [], specialTypRefusedList = [], specialTypContraList = [], specialTypNotList = [];
  const specialPneVacList = [], specialPneRefusedList = [], specialPneContraList = [], specialPneNotList = [];
  const specialUniqueUnvacList = [];
  const specialUniqueContraList = [];
  const specialUniqueRefusedList = [];

  const deptMap = {};
  const deptGroupMap = {
    'Doctors & Medical Specialists': { code: 'doctors', nameEn: 'Medical Doctors & Specialists', nameAr: '\u0627\u0644\u0623\u0637\u0628\u0627\u0621 \u0648\u0627\u0644\u0623\u062e\u0635\u0627\u0626\u064a\u0648\u0646 (Doctors & Specialists)', total: 0, immune: 0, icon: '\u{1F468}\u{200D}\u{2695}\u{FE0F}', list: [], immuneList: [], unvacList: [] },
    'Nursing & Midwifery Staff': { code: 'nursing', nameEn: 'Nursing Staff', nameAr: '\u0643\u0627\u062f\u0631 \u0627\u0644\u062a\u0645\u0631\u064a\u0636 (Nursing Staff)', total: 0, immune: 0, icon: '\u{1F469}\u{200D}\u{2695}\u{FE0F}', list: [], immuneList: [], unvacList: [] },
    'Allied Health Professionals': { code: 'allied', nameEn: 'Allied Health Professionals', nameAr: '\u0627\u0644\u0645\u0647\u0646 \u0627\u0644\u0637\u0628\u064a\u0629 \u0627\u0644\u0645\u0633\u0627\u0646\u062f\u0629 (Allied Health: Pharmacy/Lab/Radiology)', total: 0, immune: 0, icon: '\u{1F52C}', list: [], immuneList: [], unvacList: [] },
    'General Services & Support': { code: 'general', nameEn: 'General Services & Support', nameAr: '\u0627\u0644\u062e\u062f\u0645\u0627\u062a \u0627\u0644\u0639\u0627\u0645\u0629 \u0648\u0627\u0644\u0635\u064a\u0627\u0646\u0629 (General Services: Housekeeping/Security)', total: 0, immune: 0, icon: '\u{1F9F9}', list: [], immuneList: [], unvacList: [] },
    'Administration & Operations': { code: 'admin', nameEn: 'Administration & Operations', nameAr: '\u0627\u0644\u0625\u062f\u0627\u0631\u0629 \u0648\u0627\u0644\u0634\u0624\u0648\u0646 \u0627\u0644\u0625\u062f\u0627\u0631\u064a\u0629 (Administration & Operations)', total: 0, immune: 0, icon: '\u{1F4BC}', list: [], immuneList: [], unvacList: [] }
  };
  const highRiskKeywords = ['oncology', 'icu', 'dialysis', 'surgery', 'surgical', 'emergency', 'bmt', 'apheresis', 'chemo', 'pediatric'];
  let highRiskTotal = 0, highRiskImmune = 0;
  let mohFullyImmuneCount = 0, mohPartiallyCount = 0, mohPendingCount = 0;

  nonGazaEmployees.forEach(emp => {
    const demo = emp.demographic || {};
    const lab = emp.labResults || {};
    const vac = emp.vaccines || {};
    const sp = emp.specialVaccines || {};

    // Gender Demographic Categorization (Male / Female)
    const rawGen = String(emp.gender || demo.gender || emp.sex || demo.sex || '').trim().toLowerCase();
    let isFem = false;
    if (rawGen.startsWith('f') || rawGen.includes('female') || rawGen.includes('أنثى') || rawGen.includes('انثى')) {
      isFem = true;
    } else if (rawGen.startsWith('m') || rawGen.includes('male') || rawGen.includes('ذكر')) {
      isFem = false;
    } else {
      const text = `${emp.name || ''} ${demo.fullName || ''} ${demo.arabicFullName || ''} ${demo.name || ''}`.toLowerCase();
      const femalePattern = /\b(hala|mays|maysaa|salma|fatima|fatmeh|fateh|may|rania|reem|rima|ruba|amani|amal|khuloud|sahar|dina|mona|nisreen|samar|suha|nour|yasmin|layla|laila|hanan|huda|heba|nadia|najwa|nibal|manal|majda|maha|lina|lema|ghada|fida|basma|eman|iman|amira|aida|intisar|insaf|khetam|taghreed|zeinab|zainab|zaina|maryam|mariam|noor|rawan|raghad|razan|shireen|shirin|shadia|sawsan|sirin|wafa|wafaa|yara|mervat|nadine|suhad|ola|ula|dalal|kholoud|souad|suad|sohad|huba|neda|nada|ruwaida|rula|subhiya|sumaya)\b/i;
      const femaleArPattern = /(هالة|ميس|سلمى|فاطمة|مريم|مي|رانية|رانيا|ريم|ريما|ربى|أماني|اماني|أمل|امل|خلود|سحر|دينا|منى|نسرين|سمر|سهى|نور|ياسمين|ليلى|حنان|هدى|هبة|نادية|نجوى|نبال|منال|ماجدة|مها|لينا|غادة|فداء|بسمة|إيمان|ايمان|أميرة|اميرة|عائدة|انتصار|إنصاف|ختام|تغريد|زينب|زينة|روان|رغد|رزان|شرين|شيرين|شادية|سوسن|وفاء|يارا|ميرفت|نادين|سهاد|علا|دلال|سعاد|نداء|ندى|رويدة|رولا|صباح|سمية)/;
      if (femalePattern.test(text) || femaleArPattern.test(text)) {
        isFem = true;
      } else {
        isFem = false;
      }
    }

    if (isFem) {
      femaleCount++;
      femaleList.push(emp);
    } else {
      maleCount++;
      maleList.push(emp);
    }

    const rawDept = demo.orgName || emp.organizationName || demo.organizationName || emp['Organization Name'] || demo['Organization Name'] || emp.orgName || emp.department || demo.department || demo.deptTreating || 'General Hospital Staff';
    const dept = String(rawDept).trim();
    if (!deptMap[dept]) deptMap[dept] = { total: 0, immune: 0 };
    deptMap[dept].total++;

    const sGroup = String(emp.staffGroup || demo.staffGroup || '').toLowerCase();
    if (sGroup.includes('basic')) basicPlan++;
    else if (sGroup.includes('minimum')) minPlan++;
    else if (sGroup.includes('extended')) extProgram++;
    else basicPlan++;

    const dTreat = String(emp.deptTreating || demo.deptTreating || emp.department || demo.department || '').toLowerCase();
    const jTitle = String(emp.jobTitle || demo.jobTitle || emp.title || '').toLowerCase();
    
    const isInv = (typeof isInvasiveProcedureStaff === 'function') ? isInvasiveProcedureStaff(emp) : false;
    if (isInv) {
      invasiveDept++;
    }

    const isBaby = (typeof isBabiesPediatricStaff === 'function') ? isBabiesPediatricStaff(emp) : (dTreat.includes('baby') || dTreat.includes('babies') || dTreat.includes('1 year') || dTreat.includes('under 1') || dTreat.includes('pediatric') || dTreat.includes('nicu') || dTreat.includes('picu'));
    const isOnco = (typeof isOncologyStaff === 'function') ? isOncologyStaff(emp) : (dTreat.includes('oncology') || dTreat.includes('onco') || dTreat.includes('hemato') || dTreat.includes('haemato') || dTreat.includes('hematology'));

    if (isBaby) {
      babiesUnder1++;
    } else if (isOnco) {
      oncologyDept++;
    } else {
      otherDept++;
    }

    let rawTiter = '';
    if (lab.hbsabResult !== undefined && lab.hbsabResult !== null) {
      rawTiter = toSafeLabString(lab.hbsabResult);
    } else if (emp.hepbTiter !== undefined && emp.hepbTiter !== null) {
      rawTiter = toSafeLabString(emp.hepbTiter);
    } else if (emp.hepb && emp.hepb.titer !== undefined) {
      rawTiter = toSafeLabString(emp.hepb.titer);
    }
    rawTiter = rawTiter.toLowerCase().trim();

    const immStatus = String(emp.immunityStatus || '').toLowerCase().trim();
    const isMinStaff = typeof isMinimumStaff === 'function' ? isMinimumStaff(emp) : String(emp.staffGroup || demo.staffGroup || '').toLowerCase().includes('minimum');
    const isGaza = typeof isGazaStaff === 'function' ? isGazaStaff(emp) : false;

    const isResist = rawTiter.includes('non-responder') || rawTiter.includes('non responder') || rawTiter.includes('resistance') || immStatus.includes('non-responder') || immStatus.includes('non responder') || immStatus.includes('resistance');
    
    const numTiterMatch = rawTiter.match(/([<>])?\s*([0-9]+(?:\.[0-9]+)?)/);
    const hasLessThan = rawTiter.includes('<');
    const hasGreaterThan = rawTiter.includes('>') || rawTiter.includes('positive') || rawTiter.includes('pos') || rawTiter.includes('immune');
    let parsedVal = null;
    if (numTiterMatch) {
      parsedVal = parseFloat(numTiterMatch[2]);
    }

    const isBlank = !rawTiter || rawTiter === '' || rawTiter === 'blank' || rawTiter === 'pending';
    const isLessThan10 = (parsedVal !== null && parsedVal < 10) || hasLessThan;

    let isImmune = false;
    let isCompliant = false;

    // Strict User Priority:
    // 1. Resistance (Non-Responder)
    if (isResist) {
      hbsResistance++;
      hbsResistanceList.push(emp);
    }
    // 2. On vaccination program (In Progress): result HBsAb < 10 (had or hadent first dose of vaccine recorded here)
    else if (isLessThan10) {
      hbsVaccinating++;
      hbsVaccinatingList.push(emp);
    }
    // 3. Ongoing / Pending (Blank / No HBsAb Test): should be blank result
    else if (isBlank) {
      if (isMinStaff) {
        hbsNoNeed++;
        hbsNoNeedList.push(emp);
        isCompliant = true;
        deptMap[dept].immune++;
      } else {
        hbsOngoing++;
        hbsOngoingList.push(emp);
      }
    }
    // 4. No need according MOH guidelines: Routine Minimum Plan without active < 10 titer
    else if (isMinStaff || rawTiter.includes('no need') || rawTiter.includes('moh')) {
      hbsNoNeed++;
      hbsNoNeedList.push(emp);
      isCompliant = true;
      deptMap[dept].immune++;
    }
    // 5. Immune (HBsAb >= 10 mIU/mL)
    else if (!hasLessThan && (hasGreaterThan || (parsedVal !== null && parsedVal >= 10) || (parsedVal === null && immStatus.includes('immune') && !immStatus.includes('non-responder')))) {
      isImmune = true;
      isCompliant = true;
      hbsImmune++;
      hbsImmuneList.push(emp);
      deptMap[dept].immune++;
    }
    else if (isGaza && !rawTiter) {
      hbsGaza++;
    }
    else {
      hbsOngoing++;
      hbsOngoingList.push(emp);
    }



    const mohStatusEval = typeof calculateMOHImmunityStatus === 'function' ? calculateMOHImmunityStatus(emp) : 'Fully Immune';
    if (mohStatusEval.startsWith('Fully')) {
      mohFullyImmuneCount++;
    } else if (mohStatusEval.startsWith('Partially')) {
      mohPartiallyCount++;
    } else {
      mohPendingCount++;
    }

    const isHighRisk = highRiskKeywords.some(k => dept.toLowerCase().includes(k));
    if (isHighRisk) {
      highRiskTotal++;
      if (mohStatusEval.startsWith('Fully') || isCompliant) highRiskImmune++;
    }

    // 1. HCV Result Calculation (Positive, Negative, Ongoing)
    const hcvRes = String(lab.hcvResult || lab.HCV || '').toLowerCase().trim();
    if (hcvRes.includes('pos') || (hcvRes.includes('react') && !hcvRes.includes('non'))) {
      hcvPos++;
      hcvPosList.push(emp);
    } else if (hcvRes.includes('neg') || hcvRes.includes('non')) {
      hcvNeg++;
      hcvNegList.push(emp);
    } else {
      hcvOngoing++;
      hcvOngoingList.push(emp);
    }

    // 2. HIV Result Calculation (Positive, Negative, Ongoing)
    const hivRes = String(lab.hivResult || lab.HIV || '').toLowerCase().trim();
    if (hivRes.includes('pos') || (hivRes.includes('react') && !hivRes.includes('non'))) {
      hivPos++;
      hivPosList.push(emp);
    } else if (hivRes.includes('neg') || hivRes.includes('non')) {
      hivNeg++;
      hivNegList.push(emp);
    } else {
      hivOngoing++;
      hivOngoingList.push(emp);
    }

    // 3. PPD Result Calculation (Positive, Negative, Ongoing)
    const ppdRes = String(lab.ppdResult || emp.ppdResult || lab.PPD || emp.PPD || '').toLowerCase().trim();
    const ppdS1 = String(lab.ppdStep1Result || emp.ppdStep1Result || '').toLowerCase().trim();
    const ppdS2 = String(lab.ppdStep2Result || emp.ppdStep2Result || '').toLowerCase().trim();

    const isPpdPos = ppdS1.includes('pos') || ppdS2.includes('pos') || ppdRes.includes('pos') ||
                     ppdS1.includes('react') || ppdS2.includes('react') || ppdRes.includes('react');

    const isPpdNeg = !isPpdPos && (ppdS1.includes('neg') || ppdS2.includes('neg') || ppdRes.includes('neg') ||
                                   ppdS1.includes('non') || ppdS2.includes('non') || ppdRes.includes('non'));

    if (isPpdPos) {
      ppdPos++;
      ppdPosList.push(emp);
    } else if (isPpdNeg) {
      ppdNeg++;
      ppdNegList.push(emp);
    } else {
      ppdOngoing++;
      ppdOngoingList.push(emp);
    }

    // 4. VARICELLA (CHICKENPOX) 4-CATEGORY IMMUNITY STATUS:
    // - Category 1: Vaccinated 2 Doses (Vaccine dates documented)
    // - Category 2: Positive Serology (Positive IgG test)
    // - Category 3: Natural Immunity Declaration (Declaration of past illness)
    // - Category 4: Ongoing / Pending (Blank / Incomplete status)
    const cpStatus = String(vac.chickenpoxStatus || emp.chickenpoxStatus || vac.chickenpox || '').toLowerCase().trim();
    const cpDose1 = String(vac.chickenpoxDose1 || emp.chickenpoxDose1 || vac.chickenpoxDose1Date || '').toLowerCase().trim();
    const cpDose2 = String(vac.chickenpoxDose2 || emp.chickenpoxDose2 || vac.chickenpoxDose2Date || vac.cpDose2 || '').toLowerCase().trim();
    const varIgG = String(vac.varicellaIgG || lab.varicellaIgG || emp.varicellaIgG || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '').toLowerCase().trim();

    const has2Doses = cpStatus.includes('2 dose') || cpStatus.includes('two dose') || cpStatus.includes('2 doses') || 
                      (cpDose1 && cpDose2 && cpDose2 !== 'n/a' && cpDose2 !== 'none' && cpDose2 !== 'neg');

    const isPosIgG = !has2Doses && (
      cpStatus.includes('positive igg') || cpStatus.includes('positive ig') ||
      varIgG.includes('positive') || varIgG.includes('pos') || varIgG.includes('react') || varIgG.includes('>') || varIgG.includes('miu') || varIgG.includes('titer')
    );

    const isNatImm = !has2Doses && !isPosIgG && (
      cpStatus.includes('natural') || cpStatus.includes('history') || cpStatus.includes('infec') || 
      cpStatus.includes('childhood') || cpStatus.includes('declaration') || cpStatus.includes('decleration') ||
      varIgG.includes('natural') || varIgG.includes('history') || varIgG.includes('infec')
    );

    if (has2Doses) {
      var2DosesCount++;
      var2DosesList.push(emp);
    } else if (isPosIgG) {
      varPosIgGCount++;
      varPosIgGList.push(emp);
    } else if (isNatImm) {
      varNatImmCount++;
      varNatImmList.push(emp);
    } else {
      varOngoingCount++;
      varOngoingList.push(emp);
    }

    const fluSt = evalFlu2425Status(emp);
    if (fluSt === 'avh_date') {
      fluAvhDateCount++;
      fluAvhDateList.push(emp);
    } else if (fluSt === 'kupat_holim') {
      fluKupatCount++;
      fluKupatList.push(emp);
    } else if (fluSt === 'refused') {
      fluRefusedCount++;
      fluRefusedList.push(emp);
    } else {
      fluUnvaccinatedCount++;
      fluUnvaccinatedList.push(emp);
    }

    const evalVacStatus = (val) => {
      const str = String(val || '').toLowerCase().trim();
      if (!str) return 'unvaccinated';
      if (str.includes('refus')) return 'refused';
      if (str.includes('contra') || str.includes('exemp') || str.includes('defer')) return 'contra';
      if (str.includes('not') || str.includes('unvaccin') || str.includes('neg')) return 'unvaccinated';
      return 'vaccinated';
    };

    if (!isGaza) {
      const ipv = vac.ipvDate || emp.ipvDate || (vac.IPV ? (vac.IPV.d5 || vac.IPV.d1) : '') || '';
      const stIpv = evalVacStatus(ipv);
      if (stIpv === 'vaccinated') { ipvVac++; coreIpvVacList.push(emp); }
      else if (stIpv === 'refused') { ipvRefused++; coreIpvRefusedList.push(emp); }
      else if (stIpv === 'contra') { ipvContra++; coreIpvContraList.push(emp); }
      else { ipvNot++; coreIpvNotList.push(emp); }

      const tdap = vac.tdapDate || emp.tdapDate || (vac.Tdap ? (vac.Tdap.d5 || vac.Tdap.d1) : '') || '';
      const stTdap = evalVacStatus(tdap);
      if (stTdap === 'vaccinated') { tdapVac++; coreTdapVacList.push(emp); }
      else if (stTdap === 'refused') { tdapRefused++; coreTdapRefusedList.push(emp); }
      else if (stTdap === 'contra') { tdapContra++; coreTdapContraList.push(emp); }
      else { tdapNot++; coreTdapNotList.push(emp); }

      const mmr1 = vac.mmrDose1 || emp.mmrDose1 || (vac.MMR ? vac.MMR.d1 : '') || '';
      const stMmr1 = evalVacStatus(mmr1);
      if (stMmr1 === 'vaccinated') { mmr1Vac++; coreMmr1VacList.push(emp); }
      else if (stMmr1 === 'refused') { mmr1Refused++; coreMmr1RefusedList.push(emp); }
      else if (stMmr1 === 'contra') { mmr1Contra++; coreMmr1ContraList.push(emp); }
      else { mmr1Not++; coreMmr1NotList.push(emp); }

      const mmr2 = vac.mmrDose2 || emp.mmrDose2 || (vac.MMR ? (vac.MMR.d2 || vac.MMR.d5) : '') || '';
      const stMmr2 = evalVacStatus(mmr2);
      if (stMmr2 === 'vaccinated') { mmr2Vac++; coreMmr2VacList.push(emp); }
      else if (stMmr2 === 'refused') { mmr2Refused++; coreMmr2RefusedList.push(emp); }
      else if (stMmr2 === 'contra') { mmr2Contra++; coreMmr2ContraList.push(emp); }
      else { mmr2Not++; coreMmr2NotList.push(emp); }

      const cp = vac.chickenpoxStatus || vac.chickenpoxDose2 || lab.varicellaIgG || '';
      const stCp = evalVacStatus(cp);
      if (stCp === 'vaccinated') { cpVac++; coreCpVacList.push(emp); }
      else if (stCp === 'refused') { cpRefused++; coreCpRefusedList.push(emp); }
      else if (stCp === 'contra') { cpContra++; coreCpContraList.push(emp); }
      else { cpNot++; coreCpNotList.push(emp); }

      if (stIpv === 'unvaccinated' || stTdap === 'unvaccinated' || stMmr1 === 'unvaccinated' || stMmr2 === 'unvaccinated' || stCp === 'unvaccinated') {
        uniqueCoreUnvacCount++;
        coreUniqueUnvacList.push(emp);
      }
      if (stIpv === 'contra' || stTdap === 'contra' || stMmr1 === 'contra' || stMmr2 === 'contra' || stCp === 'contra') {
        coreUniqueContraList.push(emp);
      }
      if (stIpv === 'refused' || stTdap === 'refused' || stMmr1 === 'refused' || stMmr2 === 'refused' || stCp === 'refused') {
        coreUniqueRefusedList.push(emp);
      }

      // Department Groups Immunity & Unvaccinated calculation dependent on CORE VACCINATIONS
      const isCoreUnvac = (stIpv === 'unvaccinated' || stTdap === 'unvaccinated' || stMmr1 === 'unvaccinated' || stMmr2 === 'unvaccinated' || stCp === 'unvaccinated');
      const isCoreCompliant = !isCoreUnvac;

      const catGroup = categorizeDepartmentGroup(dept, emp);
      if (deptGroupMap[catGroup]) {
        deptGroupMap[catGroup].total++;
        deptGroupMap[catGroup].list.push(emp);
        if (isCoreCompliant) {
          deptGroupMap[catGroup].immune++;
          deptGroupMap[catGroup].immuneList.push(emp);
        } else {
          deptGroupMap[catGroup].unvacList.push(emp);
        }
      }
    }

    const isSpecialStaff = isSpecialVacStaffDepartment(dept, emp);

    if (isSpecialStaff) {
      specialTargetTotal++;
      specialTargetList.push(emp);
      const men = sp.meningococcal || sp.meningococcalDate || '';
      const ha1 = sp.hepA1 || sp.hepADate || '';
      const ha2 = sp.hepA2 || '';
      const typ = sp.typhoid || sp.typhoidDate || '';
      const pne = sp.pneumovax || sp.pnemovax || sp.pneumovaxDate || '';

      const stMen = evalVacStatus(men);
      if (stMen === 'vaccinated') { menVac++; specialMenVacList.push(emp); }
      else if (stMen === 'refused') { menRefused++; specialMenRefusedList.push(emp); }
      else if (stMen === 'contra') { menContra++; specialMenContraList.push(emp); }
      else { menNot++; specialMenNotList.push(emp); }

      const stHa1 = evalVacStatus(ha1);
      if (stHa1 === 'vaccinated') { hepA1Vac++; specialHa1VacList.push(emp); }
      else if (stHa1 === 'refused') { hepA1Refused++; specialHa1RefusedList.push(emp); }
      else if (stHa1 === 'contra') { hepA1Contra++; specialHa1ContraList.push(emp); }
      else { hepA1Not++; specialHa1NotList.push(emp); }

      const stHa2 = evalVacStatus(ha2);
      if (stHa2 === 'vaccinated') { hepA2Vac++; specialHa2VacList.push(emp); }
      else if (stHa2 === 'refused') { hepA2Refused++; specialHa2RefusedList.push(emp); }
      else if (stHa2 === 'contra') { hepA2Contra++; specialHa2ContraList.push(emp); }
      else { hepA2Not++; specialHa2NotList.push(emp); }

      const stTyp = evalVacStatus(typ);
      if (stTyp === 'vaccinated') { typVac++; specialTypVacList.push(emp); }
      else if (stTyp === 'refused') { typRefused++; specialTypRefusedList.push(emp); }
      else if (stTyp === 'contra') { typContra++; specialTypContraList.push(emp); }
      else { typNot++; specialTypNotList.push(emp); }

      const stPne = evalVacStatus(pne);
      if (stPne === 'vaccinated') { pneVac++; specialPneVacList.push(emp); }
      else if (stPne === 'refused') { pneRefused++; specialPneRefusedList.push(emp); }
      else if (stPne === 'contra') { pneContra++; specialPneContraList.push(emp); }
      else { pneNot++; specialPneNotList.push(emp); }

      if (stMen === 'unvaccinated' || stHa1 === 'unvaccinated' || stHa2 === 'unvaccinated' || stTyp === 'unvaccinated' || stPne === 'unvaccinated') {
        uniqueSpecialUnvacCount++;
        specialUniqueUnvacList.push(emp);
      }
      if (stMen === 'contra' || stHa1 === 'contra' || stHa2 === 'contra' || stTyp === 'contra' || stPne === 'contra') {
        specialUniqueContraList.push(emp);
      }
      if (stMen === 'refused' || stHa1 === 'refused' || stHa2 === 'refused' || stTyp === 'refused' || stPne === 'refused') {
        specialUniqueRefusedList.push(emp);
      }
    }
  });

  const specialTotal = Math.max(1, specialTargetTotal);
  const getSpecialPct = val => specialTotal > 0 ? Number((val / specialTotal * 100).toFixed(2)) : 0;
  const getPct = val => total > 0 ? Number((val / total * 100).toFixed(2)) : 0;

  const complianceRate = getPct(mohFullyImmuneCount);
  const highRiskComplianceRate = highRiskTotal > 0 ? Math.round((highRiskImmune / highRiskTotal) * 100) : complianceRate;

  const isAr = window.i18n ? window.i18n.isRTL() : false;

  const deptStats = Object.keys(deptMap).map(d => ({
    name: d,
    total: deptMap[d].total,
    immune: deptMap[d].immune,
    pct: Math.round((deptMap[d].immune / deptMap[d].total) * 100)
  })).sort((a, b) => b.total - a.total);

    const deptGroupStats = Object.keys(deptGroupMap).map(k => {
    const item = deptGroupMap[k];
    const unvacCount = item.unvacList ? item.unvacList.length : (item.total - item.immune);
    const pct = item.total > 0 ? Number((item.immune / item.total * 100).toFixed(1)) : 0;
    return {
      key: k,
      code: item.code,
      name: isAr ? item.nameAr : item.nameEn,
      nameEn: item.nameEn,
      nameAr: item.nameAr,
      total: item.total,
      immune: item.immune,
      unvac: unvacCount,
      pct: pct,
      icon: item.icon,
      list: item.list,
      immuneList: item.immuneList,
      unvacList: item.unvacList
    };
  });

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlyCounts = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

  injuryReports.forEach(inj => {
    const rawDate = inj.incidentDate || inj.part1?.dateTime || inj.reportDate || '';
    if (rawDate) {
      const parts = String(rawDate).split(' ')[0].split(/[-/.]/);
      let mIdx = -1;
      if (parts.length === 3) {
        if (parts[0].length === 4) mIdx = parseInt(parts[1], 10) - 1;
        else if (parts[2].length === 4) mIdx = parseInt(parts[1], 10) - 1;
      }
      if (mIdx >= 0 && mIdx < 12) monthlyCounts[mIdx]++;
    }
  });

  // Save varicella data to window object for interactive follow-up lists
  window.varicellaMetricsData = {
    doses2Count: var2DosesCount, doses2Pct: getPct(var2DosesCount), doses2List: var2DosesList,
    posIgGCount: varPosIgGCount, posIgGPct: getPct(varPosIgGCount), posIgGList: varPosIgGList,
    natImmCount: varNatImmCount, natImmPct: getPct(varNatImmCount), natImmList: varNatImmList,
    ongoingCount: varOngoingCount, ongoingPct: getPct(varOngoingCount), ongoingList: varOngoingList,
    total: total
  };

  window.hbsabMetricsData = {
    immuneList: hbsImmuneList,
    vaccinatingList: hbsVaccinatingList,
    resistanceList: hbsResistanceList,
    ongoingList: hbsOngoingList,
    noNeedList: hbsNoNeedList
  };

  window.labScreeningMetricsData = {
    hcvPosList, hcvNegList, hcvOngoingList,
    hivPosList, hivNegList, hivOngoingList,
    ppdPosList, ppdNegList, ppdOngoingList
  };

  window.flu2425MetricsData = {
    avhDateCount: fluAvhDateCount, avhDatePct: getPct(fluAvhDateCount), avhDateList: fluAvhDateList,
    kupatCount: fluKupatCount, kupatPct: getPct(fluKupatCount), kupatList: fluKupatList,
    refusedCount: fluRefusedCount, refusedPct: getPct(fluRefusedCount), refusedList: fluRefusedList,
    unvaccinatedCount: fluUnvaccinatedCount, unvaccinatedPct: getPct(fluUnvaccinatedCount), unvaccinatedList: fluUnvaccinatedList,
    total: total
  };

  window.mohCellStaffStore = window.mohCellStaffStore || {};

  // Core Vaccines Store:
  window.mohCellStaffStore['core_all_unvac'] = { title: 'Core Vaccines — All Unvaccinated Staff (' + coreUniqueUnvacList.length + ')', list: coreUniqueUnvacList };
  window.mohCellStaffStore['core_all_contra'] = { title: 'Core Vaccines — Staff with Contraindications (' + coreUniqueContraList.length + ')', list: coreUniqueContraList };
  window.mohCellStaffStore['core_all_refused'] = { title: 'Core Vaccines — Staff with Documented Refusal (' + coreUniqueRefusedList.length + ')', list: coreUniqueRefusedList };

  window.mohCellStaffStore['core_ipv_vac'] = { title: 'IPV Vaccine — Documented Vaccination (' + coreIpvVacList.length + ')', list: coreIpvVacList };
  window.mohCellStaffStore['core_ipv_not'] = { title: 'IPV Vaccine — Unvaccinated Staff (' + coreIpvNotList.length + ')', list: coreIpvNotList };
  window.mohCellStaffStore['core_ipv_refused'] = { title: 'IPV Vaccine — Refused (' + coreIpvRefusedList.length + ')', list: coreIpvRefusedList };
  window.mohCellStaffStore['core_ipv_contra'] = { title: 'IPV Vaccine — Contraindicated (' + coreIpvContraList.length + ')', list: coreIpvContraList };

  window.mohCellStaffStore['core_tdap_vac'] = { title: 'Tdap Vaccine — Documented Vaccination (' + coreTdapVacList.length + ')', list: coreTdapVacList };
  window.mohCellStaffStore['core_tdap_not'] = { title: 'Tdap Vaccine — Unvaccinated Staff (' + coreTdapNotList.length + ')', list: coreTdapNotList };
  window.mohCellStaffStore['core_tdap_refused'] = { title: 'Tdap Vaccine — Refused (' + coreTdapRefusedList.length + ')', list: coreTdapRefusedList };
  window.mohCellStaffStore['core_tdap_contra'] = { title: 'Tdap Vaccine — Contraindicated (' + coreTdapContraList.length + ')', list: coreTdapContraList };

  window.mohCellStaffStore['core_mmr1_vac'] = { title: 'MMR Dose 1 — Documented Vaccination (' + coreMmr1VacList.length + ')', list: coreMmr1VacList };
  window.mohCellStaffStore['core_mmr1_not'] = { title: 'MMR Dose 1 — Unvaccinated Staff (' + coreMmr1NotList.length + ')', list: coreMmr1NotList };
  window.mohCellStaffStore['core_mmr1_refused'] = { title: 'MMR Dose 1 — Refused (' + coreMmr1RefusedList.length + ')', list: coreMmr1RefusedList };
  window.mohCellStaffStore['core_mmr1_contra'] = { title: 'MMR Dose 1 — Contraindicated (' + coreMmr1ContraList.length + ')', list: coreMmr1ContraList };

  window.mohCellStaffStore['core_mmr2_vac'] = { title: 'MMR Dose 2 — Documented Vaccination (' + coreMmr2VacList.length + ')', list: coreMmr2VacList };
  window.mohCellStaffStore['core_mmr2_not'] = { title: 'MMR Dose 2 — Unvaccinated Staff (' + coreMmr2NotList.length + ')', list: coreMmr2NotList };
  window.mohCellStaffStore['core_mmr2_refused'] = { title: 'MMR Dose 2 — Refused (' + coreMmr2RefusedList.length + ')', list: coreMmr2RefusedList };
  window.mohCellStaffStore['core_mmr2_contra'] = { title: 'MMR Dose 2 — Contraindicated (' + coreMmr2ContraList.length + ')', list: coreMmr2ContraList };

  window.mohCellStaffStore['core_cp_vac'] = { title: 'Chickenpox / Varicella — Documented Vaccination/Immunity (' + coreCpVacList.length + ')', list: coreCpVacList };
  window.mohCellStaffStore['core_cp_not'] = { title: 'Chickenpox / Varicella — Unvaccinated Staff (' + coreCpNotList.length + ')', list: coreCpNotList };
  window.mohCellStaffStore['core_cp_refused'] = { title: 'Chickenpox / Varicella — Refused (' + coreCpRefusedList.length + ')', list: coreCpRefusedList };
  window.mohCellStaffStore['core_cp_contra'] = { title: 'Chickenpox / Varicella — Contraindicated (' + coreCpContraList.length + ')', list: coreCpContraList };

  // Special Vaccines Store:
  window.mohCellStaffStore['special_all_target'] = { title: 'Special Vaccines — All Target Staff (' + specialTargetList.length + ')', list: specialTargetList };
  window.mohCellStaffStore['special_all_unvac'] = { title: 'Special Vaccines — All Unvaccinated Staff (' + specialUniqueUnvacList.length + ')', list: specialUniqueUnvacList };
  window.mohCellStaffStore['special_all_contra'] = { title: 'Special Vaccines — Staff with Contraindications (' + specialUniqueContraList.length + ')', list: specialUniqueContraList };
  window.mohCellStaffStore['special_all_refused'] = { title: 'Special Vaccines — Staff with Documented Refusal (' + specialUniqueRefusedList.length + ')', list: specialUniqueRefusedList };

  window.mohCellStaffStore['special_men_vac'] = { title: 'Meningococcal A, C — Documented Vaccination (' + specialMenVacList.length + ')', list: specialMenVacList };
  window.mohCellStaffStore['special_men_not'] = { title: 'Meningococcal A, C — Unvaccinated Staff (' + specialMenNotList.length + ')', list: specialMenNotList };
  window.mohCellStaffStore['special_men_refused'] = { title: 'Meningococcal A, C — Refused (' + specialMenRefusedList.length + ')', list: specialMenRefusedList };
  window.mohCellStaffStore['special_men_contra'] = { title: 'Meningococcal A, C — Contraindicated (' + specialMenContraList.length + ')', list: specialMenContraList };

  window.mohCellStaffStore['special_ha1_vac'] = { title: 'Hepatitis A Series 1 — Documented Vaccination (' + specialHa1VacList.length + ')', list: specialHa1VacList };
  window.mohCellStaffStore['special_ha1_not'] = { title: 'Hepatitis A Series 1 — Unvaccinated Staff (' + specialHa1NotList.length + ')', list: specialHa1NotList };
  window.mohCellStaffStore['special_ha1_refused'] = { title: 'Hepatitis A Series 1 — Refused (' + specialHa1RefusedList.length + ')', list: specialHa1RefusedList };
  window.mohCellStaffStore['special_ha1_contra'] = { title: 'Hepatitis A Series 1 — Contraindicated (' + specialHa1ContraList.length + ')', list: specialHa1ContraList };

  window.mohCellStaffStore['special_ha2_vac'] = { title: 'Hepatitis A Series 2 — Documented Vaccination (' + specialHa2VacList.length + ')', list: specialHa2VacList };
  window.mohCellStaffStore['special_ha2_not'] = { title: 'Hepatitis A Series 2 — Unvaccinated Staff (' + specialHa2NotList.length + ')', list: specialHa2NotList };
  window.mohCellStaffStore['special_ha2_refused'] = { title: 'Hepatitis A Series 2 — Refused (' + specialHa2RefusedList.length + ')', list: specialHa2RefusedList };
  window.mohCellStaffStore['special_ha2_contra'] = { title: 'Hepatitis A Series 2 — Contraindicated (' + specialHa2ContraList.length + ')', list: specialHa2ContraList };

  window.mohCellStaffStore['special_typ_vac'] = { title: 'Typhoid — Documented Vaccination (' + specialTypVacList.length + ')', list: specialTypVacList };
  window.mohCellStaffStore['special_typ_not'] = { title: 'Typhoid — Unvaccinated Staff (' + specialTypNotList.length + ')', list: specialTypNotList };
  window.mohCellStaffStore['special_typ_refused'] = { title: 'Typhoid — Refused (' + specialTypRefusedList.length + ')', list: specialTypRefusedList };
  window.mohCellStaffStore['special_typ_contra'] = { title: 'Typhoid — Contraindicated (' + specialTypContraList.length + ')', list: specialTypContraList };

  window.mohCellStaffStore['special_pne_vac'] = { title: 'Pneumovax 23 — Documented Vaccination (' + specialPneVacList.length + ')', list: specialPneVacList };
  window.mohCellStaffStore['special_pne_not'] = { title: 'Pneumovax 23 — Unvaccinated Staff (' + specialPneNotList.length + ')', list: specialPneNotList };
  window.mohCellStaffStore['special_pne_refused'] = { title: 'Pneumovax 23 — Refused (' + specialPneRefusedList.length + ')', list: specialPneRefusedList };
  window.mohCellStaffStore['special_pne_contra'] = { title: 'Pneumovax 23 — Contraindicated (' + specialPneContraList.length + ')', list: specialPneContraList };

  // 5 Hospital Department Groups Stores
  Object.keys(deptGroupMap).forEach(k => {
    const grp = deptGroupMap[k];
    window.mohCellStaffStore[`dept_group_${grp.code}`] = {
      title: `${grp.nameEn}  -  All Monitored Staff (${grp.list.length})`,
      list: grp.list
    };
    window.mohCellStaffStore[`dept_group_${grp.code}_immune`] = {
      title: `${grp.nameEn}  -  Core Vaccine Immune Staff (${grp.immuneList.length})`,
      list: grp.immuneList
    };
    window.mohCellStaffStore[`dept_group_${grp.code}_unvac`] = {
      title: `${grp.nameEn}  -  Core Vaccine Unvaccinated Staff (${grp.unvacList.length})`,
      list: grp.unvacList
    };
  });
  window.mohCellStaffStore['dept_group_all'] = {
    title: `All Hospital Monitored Staff (${nonGazaEmployees.length})`,
    list: nonGazaEmployees
  };
    const allDeptImmuneList = Object.values(deptGroupMap).flatMap(g => g.immuneList || []);
  window.mohCellStaffStore['dept_group_all_immune'] = {
    title: `All Hospital Immune Staff (${allDeptImmuneList.length})`,
    list: allDeptImmuneList
  };
  const allDeptUnvacList = Object.values(deptGroupMap).flatMap(g => g.unvacList || []);
  window.mohCellStaffStore['dept_group_all_unvac'] = {
    title: `All Hospital Core Vaccine Unvaccinated Staff (${allDeptUnvacList.length})`,
    list: allDeptUnvacList
  };

  if (typeof window !== 'undefined') {
    if (!window.mohCellStaffStore) window.mohCellStaffStore = {};
    window.mohCellStaffStore['gender_male'] = {
      title: `Male Staff Members - الموظفون الذكور (${maleCount})`,
      list: maleList
    };
    window.mohCellStaffStore['gender_female'] = {
      title: `Female Staff Members - الموظفات الإناث (${femaleCount})`,
      list: femaleList
    };
  }

  const result = {
    gender: {
      male: maleCount,
      malePct: getPct(maleCount),
      maleList: maleList,
      female: femaleCount,
      femalePct: getPct(femaleCount),
      femaleList: femaleList,
      total: total
    },
    total,
    complianceRate,
    highRiskComplianceRate,
    activeIncidents: injuryReports.length,
    flu2425: window.flu2425MetricsData,
    staffGroup: {
      basicPlan, basicPct: getPct(basicPlan),
      minPlan, minPct: getPct(minPlan),
      extProgram, extPct: getPct(extProgram),
      total
    },
    treatingDepts: {
      invasiveCount: invasiveDept,
      invasivePct: getPct(invasiveDept),
      babiesUnder1: babiesUnder1,
      babiesPct: getPct(babiesUnder1),
      oncologyDept: oncologyDept,
      oncologyPct: getPct(oncologyDept),
      otherDept: otherDept,
      otherPct: getPct(otherDept),
      total: total
    },
    hbsab: {
      hbsImmune, immunePct: getPct(hbsImmune),
      hbsVaccinating, vaccinatingPct: getPct(hbsVaccinating),
      hbsResistance, resistancePct: getPct(hbsResistance),
      hbsOngoing, ongoingPct: getPct(hbsOngoing),
      hbsNoNeed, noNeedPct: getPct(hbsNoNeed),
      hbsGaza, gazaPct: getPct(hbsGaza),
      total, pct: complianceRate
    },
    labScreening: {
      hcvPos, hcvPosPct: getPct(hcvPos), hcvNeg, hcvNegPct: getPct(hcvNeg), hcvOngoing, hcvOngoingPct: getPct(hcvOngoing),
      hivPos, hivPosPct: getPct(hivPos), hivNeg, hivNegPct: getPct(hivNeg), hivOngoing, hivOngoingPct: getPct(hivOngoing),
      ppdPos, ppdPosPct: getPct(ppdPos), ppdNeg, ppdNegPct: getPct(ppdNeg), ppdOngoing, ppdOngoingPct: getPct(ppdOngoing)
    },
    varicella: window.varicellaMetricsData,
    coreVac: {
      unvaccinatedListCount: uniqueCoreUnvacCount,
      unvaccinatedList: coreUniqueUnvacList,
      contraList: coreUniqueContraList,
      refusedList: coreUniqueRefusedList,
      ipv: { vac: ipvVac, refused: ipvRefused, contra: ipvContra, not: ipvNot, total, pct: getPct(ipvVac), refusedPct: getPct(ipvRefused), contraPct: getPct(ipvContra), notPct: getPct(ipvNot) },
      tdap: { vac: tdapVac, refused: tdapRefused, contra: tdapContra, not: tdapNot, total, pct: getPct(tdapVac), refusedPct: getPct(tdapRefused), contraPct: getPct(tdapContra), notPct: getPct(tdapNot) },
      mmr1: { vac: mmr1Vac, refused: mmr1Refused, contra: mmr1Contra, not: mmr1Not, total, pct: getPct(mmr1Vac), refusedPct: getPct(mmr1Refused), contraPct: getPct(mmr1Contra), notPct: getPct(mmr1Not) },
      mmr2: { vac: mmr2Vac, refused: mmr2Refused, contra: mmr2Contra, not: mmr2Not, total, pct: getPct(mmr2Vac), refusedPct: getPct(mmr2Refused), contraPct: getPct(mmr2Contra), notPct: getPct(mmr2Not) },
      cp: { vac: cpVac, refused: cpRefused, contra: cpContra, not: cpNot, total, pct: getPct(cpVac), refusedPct: getPct(cpRefused), contraPct: getPct(cpContra), notPct: getPct(cpNot) }
    },
    specialVac: {
      total: specialTotal,
      unvaccinatedListCount: uniqueSpecialUnvacCount,
      unvaccinatedList: specialUniqueUnvacList,
      targetList: specialTargetList,
      contraList: specialUniqueContraList,
      refusedList: specialUniqueRefusedList,
      men: { vac: menVac, refused: menRefused, contra: menContra, not: menNot, total: specialTotal, pct: getSpecialPct(menVac), refusedPct: getSpecialPct(menRefused), contraPct: getSpecialPct(menContra), notPct: getSpecialPct(menNot) },
      hepA1: { vac: hepA1Vac, refused: hepA1Refused, contra: hepA1Contra, not: hepA1Not, total: specialTotal, pct: getSpecialPct(hepA1Vac), refusedPct: getSpecialPct(hepA1Refused), contraPct: getSpecialPct(hepA1Contra), notPct: getSpecialPct(hepA1Not) },
      hepA2: { vac: hepA2Vac, refused: hepA2Refused, contra: hepA2Contra, not: hepA2Not, total: specialTotal, pct: getSpecialPct(hepA2Vac), refusedPct: getSpecialPct(hepA2Refused), contraPct: getSpecialPct(hepA2Contra), notPct: getSpecialPct(hepA2Not) },
      typ: { vac: typVac, refused: typRefused, contra: typContra, not: typNot, total: specialTotal, pct: getSpecialPct(typVac), refusedPct: getSpecialPct(typRefused), contraPct: getSpecialPct(typContra), notPct: getSpecialPct(typNot) },
      pne: { vac: pneVac, refused: pneRefused, contra: pneContra, not: pneNot, total: specialTotal, pct: getSpecialPct(pneVac), refusedPct: getSpecialPct(pneRefused), contraPct: getSpecialPct(pneContra), notPct: getSpecialPct(pneNot) }
    },
    deptStats,
    deptGroupStats,
    monthlyIncidents: { labels: months, counts: monthlyCounts, data: monthlyCounts }
  };

  if (typeof window !== 'undefined') {
    window._cachedAVHMetrics = result;
    window._cachedAVHMetricsEmpLen = empLen;
    window._cachedAVHMetricsInjLen = injLen;
    window._cachedAVHMetricsVersion = (window._employeesCacheVersion || 1);
  }

  return result;
}
if (typeof window !== "undefined") {
  window.computeAVHExcelReportData = computeAVHExcelReportData;
}

// --------------------------------------------------------------------------
// 🚨 CLINICAL APPOINTMENTS & FOLLOW-UP ALARM FOR DASHBOARD
// --------------------------------------------------------------------------
function buildDashboardAppointmentAlarmHTML(isAr) {
  if (typeof window.getClinicalAppointmentSummary !== 'function') return '';
  const summary = window.getClinicalAppointmentSummary();
  if (!summary || (!summary.overdueCount && !summary.todayCount)) return '';

  const isDismissed = sessionStorage.getItem('avh_alarm_dismissed') === 'true';
  if (isDismissed) return '';

  // Trigger soft medical chime if not already chimed in this view
  if (!window._alarmChimedThisSession) {
    window._alarmChimedThisSession = true;
    if (typeof window.playClinicalAlarmChime === 'function') {
      setTimeout(() => window.playClinicalAlarmChime(), 400);
    }
  }

  const urgentItems = [...summary.overdue, ...summary.today];

  return `
    <!-- 🚨 CLINICAL APPOINTMENTS & FOLLOW-UP ALARM BANNER -->
    <div id="clinicalDashboardAlarmBanner" class="card no-print" style="margin-bottom: 20px; background: linear-gradient(135deg, #FFF5F5 0%, #FEF2F2 100%); border: 2px solid #DC2626; border-radius: 12px; padding: 18px 24px; box-shadow: 0 10px 25px -5px rgba(220, 38, 38, 0.2); position: relative;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 16px;">
        <div style="display: flex; gap: 14px; align-items: flex-start; flex: 1; min-width: 290px;">
          <!-- Alert Bell Icon -->
          <div style="font-size: 2.2rem; line-height: 1; background: #FEE2E2; border: 2px solid #FCA5A5; border-radius: 50%; width: 54px; height: 54px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
            🚨
          </div>
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
              <h3 style="margin: 0; font-size: 1.25rem; font-weight: 800; color: #991B1B;">
                ${isAr ? 'إنذار سريري: مواعيد وفحوصات معلقة تتطلب المتابعة!' : 'Clinical Alarm: Pending Appointments & Tests Due!'}
              </h3>
              <span style="background: #DC2626; color: white; padding: 3px 10px; border-radius: 20px; font-size: 0.76rem; font-weight: 800; text-transform: uppercase;">
                ${isAr ? 'تنبيه عاجل' : 'Urgent Alert'}
              </span>
            </div>

            <p style="margin: 6px 0 10px 0; font-size: 0.92rem; color: #7F1D1D; font-weight: 600;">
              ${isAr 
                ? `يوجد في العيادة <strong>${summary.overdueCount}</strong> موعد/فحص متأخر يحتاج تدخلاً فورياً، بالإضافة إلى <strong>${summary.todayCount}</strong> موعد مستحق اليوم.`
                : `There are <strong>${summary.overdueCount}</strong> overdue follow-up tests requiring immediate clinic action, plus <strong>${summary.todayCount}</strong> due today.`}
            </p>

            <!-- Quick Urgent Staff Preview Chips -->
            <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
              <span style="font-size: 0.78rem; font-weight: 700; color: #991B1B;">${isAr ? 'الكوادر المستحقة:' : 'Pending Staff:'}</span>
              ${urgentItems.slice(0, 4).map(u => `
                <span style="background: white; border: 1.5px solid #FCA5A5; color: #991B1B; padding: 4px 10px; border-radius: 6px; font-size: 0.78rem; font-weight: 800; display: inline-flex; align-items: center; gap: 5px;">
                  <span>${u.status === 'overdue' ? '⚠️' : '🔵'}</span>
                  <span>${u.empName}</span>
                  <span style="opacity: 0.75; font-size: 0.72rem;">(${isAr ? (u.titleAr || u.titleEn) : (u.titleEn || u.titleAr)})</span>
                </span>
              `).join('')}
              ${urgentItems.length > 4 ? `
                <span style="background: #FEE2E2; border: 1px solid #FCA5A5; color: #991B1B; padding: 4px 8px; border-radius: 6px; font-size: 0.76rem; font-weight: 800;">
                  +${urgentItems.length - 4} ${isAr ? 'مواعيد أخرى...' : 'more pending...'}
                </span>
              ` : ''}
            </div>
          </div>
        </div>

        <!-- Action Buttons -->
        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
          <button type="button" class="btn btn-danger" style="background: #DC2626; border-color: #DC2626; color: white; font-weight: 800; padding: 9px 16px; border-radius: 8px; box-shadow: 0 4px 12px rgba(220, 38, 38, 0.25);" onclick="goToCalendarFromAlarm('overdue')">
            📅 ${isAr ? 'فتح التقويم ومتابعة المتأخرات' : 'Open Calendar & Follow-up'}
          </button>
          <button type="button" class="btn btn-outline" style="background: white; border-color: #CBD5E1; color: #64748B; font-weight: 700; padding: 9px 12px; border-radius: 8px;" onclick="dismissDashboardAlarm()">
            ✕ ${isAr ? 'إخفاء' : 'Dismiss'}
          </button>
        </div>
      </div>
    </div>
  `;
}
window.buildDashboardAppointmentAlarmHTML = buildDashboardAppointmentAlarmHTML;

window.goToCalendarFromAlarm = function(filter) {
  if (typeof window.setCalendarFilter === 'function') {
    window.setCalendarFilter(filter || 'all');
  }
  if (typeof window.switchNav === 'function') {
    window.switchNav('followup-calendar');
  }
};

window.dismissDashboardAlarm = function() {
  sessionStorage.setItem('avh_alarm_dismissed', 'true');
  const banner = document.getElementById('clinicalDashboardAlarmBanner');
  if (banner) banner.style.display = 'none';
};

function renderDashboardOverview(container) {
  if (!container) container = document.getElementById('mainAppArea');
  if (!container) return;

  try {
    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
    const injuryReports = (typeof InjuryDataService !== 'undefined' && InjuryDataService._cache) ? InjuryDataService._cache : (JSON.parse(localStorage.getItem('avh_injuries')) || []);
    if (typeof InjuryDataService !== 'undefined' && !InjuryDataService._cache && typeof InjuryDataService.getAllInjuries === 'function') {
      InjuryDataService.getAllInjuries().then(() => { if (container) renderDashboardOverview(container); }).catch(() => {});
    }
    const t = key => window.i18n ? window.i18n.t(key) : key;

    const metrics = computeAVHExcelReportData(employees, injuryReports, true);

    const subTabToolbarHTML = `
      ${buildDashboardAppointmentAlarmHTML(isAr)}

      <!-- DASHBOARD SUB-MENU TOOLBAR -->
      <div class="sub-tabs-container no-print" style="margin-bottom: 20px; background: white; padding: 10px 16px; border-radius: 8px; border: 1px solid var(--border-color); box-shadow: var(--shadow-sm); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
          <button class="sub-tab-btn ${currentDashboardSubTab === 'avh' ? 'active' : ''}" onclick="switchDashboardSubTab('avh')" style="padding: 8px 16px; font-weight: bold; border-radius: 6px; ${currentDashboardSubTab === 'avh' ? 'background: #1A5F7A; color: white; border-color: #113F52;' : ''}">
            🏥 ${isAr ? '1. تقرير مستشفى المُطلع (AVH Dynamic Executive Report)' : '1. AVH Dynamic Executive Report'}
          </button>
          <button class="sub-tab-btn ${currentDashboardSubTab === 'moh' ? 'active' : ''}" onclick="switchDashboardSubTab('moh')" style="padding: 8px 16px; font-weight: bold; border-radius: 6px; ${currentDashboardSubTab === 'moh' ? 'background: #065F46; color: white; border-color: #047857;' : ''}">
            📋 ${isAr ? '2. تقرير وزارة الصحة الرسمي (MOH Official Report)' : '2. MOH Official Statutory Report'}
          </button>
                              <button class="sub-tab-btn ${currentDashboardSubTab === 'body_fluid_injury' ? 'active' : ''}" onclick="if(typeof switchInjurySubReport==='function') switchInjurySubReport('both'); switchDashboardSubTab('body_fluid_injury');" style="padding: 8px 16px; font-weight: bold; border-radius: 6px; ${currentDashboardSubTab === 'body_fluid_injury' ? 'background: #C2410C; color: white; border-color: #9A3412;' : ''}">
            📋 ${isAr ? '3. تقرير حوادث وخز الإبر وسوائل الجسم وزمن الاستجابة' : '3. Injury Report For HCWs Involving Body Fluid & Response Time'}
          </button>
        </div>
        <div style="font-size: 0.85rem; font-weight: bold; color: #1A5F7A;">
          📊 Live Data Sync: <strong style="color: #10B981;">${metrics.total} Staff Records Calculated Live</strong>
        </div>
      </div>
    `;

    if (currentDashboardSubTab === 'moh') {
      renderMOHReportView(container, subTabToolbarHTML, employees, injuryReports, metrics, isAr);
    } else if (currentDashboardSubTab === 'body_fluid_injury' || currentDashboardSubTab === 'injury_processing') {
      renderInjuryResponseTimeReportView(container, subTabToolbarHTML, employees, injuryReports, metrics, isAr);
    } else {
      renderAVHReportView(container, subTabToolbarHTML, employees, injuryReports, metrics, isAr, t);
    }
  } catch (err) {
    console.error("Error rendering dashboard overview:", err);
    container.innerHTML = `
      <div style="padding: 24px; text-align: center; background: #FEF2F2; border: 1px solid #FCA5A5; border-radius: 8px; margin: 20px; color: #991B1B;">
        <h3 style="margin-top: 0;">⚠️ Dashboard Loading Error</h3>
        <p>An error occurred while computing live dashboard metrics. Please refresh the page.</p>
        <pre style="font-size: 0.8rem; text-align: left; background: #FFF; padding: 12px; border-radius: 4px; border: 1px solid #FECACA; max-height: 150px; overflow: auto;">${err.stack || err}</pre>
        <button onclick="location.reload()" style="padding: 8px 16px; background: #DC2626; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer; margin-top: 12px;">🔄 Reload Portal</button>
      </div>
    `;
  }
}

// --------------------------------------------------------------------------
// 🏥 1. AVH DYNAMIC EXECUTIVE REPORT VIEW (WITH PERCENTAGES FOR ALL)
// --------------------------------------------------------------------------
function renderAVHReportView(container, toolbarHTML, employees, injuryReports, metrics, isAr, t) {
  const topDepts = metrics.deptStats.slice(0, 12);

  container.innerHTML = `
    ${toolbarHTML}

    <!-- AVH EXECUTIVE REPORT HEADER BANNER -->
    <div style="background: linear-gradient(135deg, #113F52 0%, #1A5F7A 100%); color: white; padding: 20px 24px; border-radius: 10px; margin-bottom: 24px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
      <div>
        <div style="font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; opacity: 0.9; font-weight: 700;">
          Augusta Victoria Hospital | Infectious Disease Unit
        </div>
        <h2 style="font-size: 1.35rem; font-weight: 800; margin: 4px 0 0 0;">
          🏥 ${isAr ? 'تقرير مستشفى الأوغستا فكتوريا التنفيذي (Live AVH Excel Report)' : '1. AVH Dynamic Executive Report'}
        </h2>
      </div>
      <div class="no-print" style="display: flex; gap: 8px;">
        <button class="btn btn-outline" style="background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.3); font-weight: bold; font-size: 0.82rem;" onclick="window.print()">🖨️ ${isAr ? 'طباعة كامل تقرير المطلع' : 'Print Full AVH Report'}</button>
      </div>
    </div>

    <!-- DYNAMIC KPI SUMMARY CARDS -->
    <div class="kpi-grid" style="margin-bottom: 24px;">
      <div class="kpi-card green">
        <div>
          <div class="kpi-val" style="color: #059669;">${metrics.complianceRate}%</div>
          <div class="kpi-label">${isAr ? 'نسبة المناعة الكاملة (المحسوبة حياً)' : 'Live Calculated Immunity Rate'}</div>
        </div>
        <div style="font-size: 2rem; color: var(--accent-green);">🛡️</div>
      </div>
      <div class="kpi-card">
        <div>
          <div class="kpi-val" style="color: #0284C7;">${metrics.total}</div>
          <div class="kpi-label">${isAr ? 'إجمالي الموظفين المسجلين بالنظام' : 'Total Monitored Staff Records'}</div>
        </div>
        <div style="font-size: 2rem; color: var(--primary-blue);">👨‍⚕️</div>
      </div>
      <div class="kpi-card amber">
        <div>
          <div class="kpi-val" style="color: #D97706;">${metrics.activeIncidents}</div>
          <div class="kpi-label">${isAr ? 'إجمالي بلاغات الإصابات المسجلة' : 'Recorded Exposure Incidents'}</div>
        </div>
        <div style="font-size: 2rem; color: #D69E2E;">⚠️</div>
      </div>
      <div class="kpi-card green">
        <div>
          <div class="kpi-val" style="color: #0d9488;">${metrics.highRiskComplianceRate}%</div>
          <div class="kpi-label">${isAr ? 'مناعة الأقسام عالية الخطورة' : 'High-Risk Units Immunity Rate'}</div>
        </div>
        <div style="font-size: 2rem; color: var(--accent-teal);">🏥</div>
      </div>
    </div>

    <!-- 📊 6 OFFICIAL AVH EXCEL SPREADSHEET CALCULATED STATISTICAL TABLES WITH PERCENTAGES -->
    
    <!-- TABLES GRID 1: STAFF GROUP, HIGH-RISK TREATING DEPTS & GENDER BREAKDOWN -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 24px; margin-bottom: 24px;">
      
      <!-- CARD 1: STAFF GROUP BREAKDOWN -->
      <div class="card" id="cardStaffGroup" style="border-top: 4px solid #0284C7; position: relative;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #0369A1; font-weight: 800; font-size: 0.95rem; margin-bottom: 10px;">
          <span>📋 Staff Group Breakdown (خطة الفئات الوظيفية)</span>
          <button class="btn btn-outline no-print" style="padding: 3px 10px; font-size: 0.78rem; border-color: #0284C7; color: #0284C7; font-weight: bold; background: white;" onclick="printSingleCard('cardStaffGroup', 'Staff Group Breakdown')">
            🖨️ Print
          </button>
        </div>
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-bottom: 14px;">
          <thead>
            <tr style="background: #F1F5F9; color: #0369A1;">
              <th style="padding: 6px; border: 1px solid #CBD5E1;">Category Plan</th>
              <th style="padding: 6px; border: 1px solid #CBD5E1; text-align: center;">Headcount</th>
              <th style="padding: 6px; border: 1px solid #CBD5E1; text-align: center;">Percentage %</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Basic Plan</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${metrics.staffGroup.basicPlan}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${metrics.staffGroup.basicPct}%</td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Minimum Plan</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${metrics.staffGroup.minPlan}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${metrics.staffGroup.minPct}%</td>
            </tr>
            <tr>
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Extended Program</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${metrics.staffGroup.extProgram}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${metrics.staffGroup.extPct}%</td>
            </tr>
            <tr style="background: #E0F2FE; font-weight: 900; color: #0369A1;">
              <td style="padding: 8px; border: 1px solid #BAE6FD;">Total Monitored Staff</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD; font-size: 1rem;">${metrics.staffGroup.total}</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD; font-size: 1rem;">100%</td>
            </tr>
          </tbody>
        </table>
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px;">
          <canvas id="staffGroupChart" height="170"></canvas>
        </div>
      </div>

      <!-- CARD 2: TREATING DEPARTMENTS BREAKDOWN -->
      <div class="card" id="cardTreatingDepts" style="border-top: 4px solid #059669; position: relative;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #047857; font-weight: 800; font-size: 0.95rem; margin-bottom: 10px;">
          <span>🏥 High-Risk Treating Units (الأقسام ذات الخطورة)</span>
          <button class="btn btn-outline no-print" style="padding: 3px 10px; font-size: 0.78rem; border-color: #059669; color: #059669; font-weight: bold; background: white;" onclick="printSingleCard('cardTreatingDepts', 'High-Risk Treating Units Breakdown')">
            🖨️ Print
          </button>
        </div>
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-bottom: 14px;">
          <thead>
            <tr style="background: #F1F5F9; color: #047857;">
              <th style="padding: 6px; border: 1px solid #CBD5E1;">Department Category</th>
              <th style="padding: 6px; border: 1px solid #CBD5E1; text-align: center;">Headcount</th>
              <th style="padding: 6px; border: 1px solid #CBD5E1; text-align: center;">Percentage %</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Employees in oncology, hematooncology</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.treatingDepts.oncologyDept}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.treatingDepts.oncologyPct}%</td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Babies under 1 years (NICU/Pediatrics)</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.treatingDepts.babiesUnder1}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.treatingDepts.babiesPct}%</td>
            </tr>
            <tr>
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">General Hospital Staff / Other Units</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.treatingDepts.otherDept}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.treatingDepts.otherPct}%</td>
            </tr>
            <tr style="background: #D1FAE5; font-weight: 900; color: #047857;">
              <td style="padding: 8px; border: 1px solid #A7F3D0;">Total Monitored Staff</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0; font-size: 1rem;">${metrics.treatingDepts.total}</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0; font-size: 1rem;">100%</td>
            </tr>
            <tr style="background: #F0FDF4; font-weight: 800; color: #065F46; border-top: 2px solid #A7F3D0;">
              <td style="padding: 8px; border: 1px solid #E2E8F0; font-style: italic;">Healthcare workers performing invasive procedures (Apapasach)*</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #E2E8F0; font-size: 0.95rem; color: #059669; font-weight: bold;">${metrics.treatingDepts.invasiveCount}</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #E2E8F0; font-size: 0.95rem; color: #059669; font-weight: bold;">${metrics.treatingDepts.invasivePct}%</td>
            </tr>
          </tbody>
        </table>
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px;">
          <canvas id="treatingDeptChart" height="170"></canvas>
        </div>
      </div>

      <!-- CARD 1C: GENDER DEMOGRAPHIC BREAKDOWN -->
      <div class="card" id="cardStaffGender" style="border-top: 4px solid #DB2777; position: relative;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #9D174D; font-weight: 800; font-size: 0.95rem; margin-bottom: 10px;">
          <span>🚻 Staff Gender Breakdown (توزيع الموظفين حسب الجنس)</span>
          <button class="btn btn-outline no-print" style="padding: 3px 10px; font-size: 0.78rem; border-color: #DB2777; color: #DB2777; font-weight: bold; background: white;" onclick="printSingleCard('cardStaffGender', 'Staff Gender Breakdown')">
            🖨️ Print
          </button>
        </div>
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-bottom: 14px;">
          <thead>
            <tr style="background: #FDF2F8; color: #9D174D;">
              <th style="padding: 6px; border: 1px solid #FBCFE8;">Gender Category</th>
              <th style="padding: 6px; border: 1px solid #FBCFE8; text-align: center;">Headcount</th>
              <th style="padding: 6px; border: 1px solid #FBCFE8; text-align: center;">Percentage %</th>
              <th style="padding: 6px; border: 1px solid #FBCFE8; text-align: center;" class="no-print">Interactive List</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">👨 Male (ذكور)</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${(metrics.gender && metrics.gender.male) || 0}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">${(metrics.gender && metrics.gender.malePct) || 0}%</td>
              <td style="padding: 6px 8px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
                <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; border-color: #0284C7; color: #0284C7; font-weight: bold;" onclick="openMOHCellStaffModal('gender_male')">📋 View List (${(metrics.gender && metrics.gender.male) || 0})</button>
              </td>
            </tr>
            <tr style="background: #FDF2F8;">
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0; color: #DB2777;">👩 Female (إناث)</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #DB2777;">${(metrics.gender && metrics.gender.female) || 0}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #DB2777;">${(metrics.gender && metrics.gender.femalePct) || 0}%</td>
              <td style="padding: 6px 8px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
                <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; border-color: #DB2777; color: #DB2777; font-weight: bold;" onclick="openMOHCellStaffModal('gender_female')">📋 View List (${(metrics.gender && metrics.gender.female) || 0})</button>
              </td>
            </tr>
            <tr style="background: #FCE7F3; font-weight: 900; color: #831843;">
              <td style="padding: 8px; border: 1px solid #FBCFE8;">Total Monitored Staff</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #FBCFE8; font-size: 1rem;">${(metrics.gender && metrics.gender.total) || metrics.total}</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #FBCFE8; font-size: 1rem;">100%</td>
              <td style="padding: 8px; border: 1px solid #FBCFE8;" class="no-print"></td>
            </tr>
          </tbody>
        </table>
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px;">
          <canvas id="staffGenderChart" height="170"></canvas>
        </div>
      </div>
    </div>

    <!-- TABLES GRID 2: HBsAb RESULT & LAB SCREENING -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 24px; margin-bottom: 24px;">
      
      <!-- CARD 3: HBsAb RESULT BREAKDOWN -->
      <div class="card" id="cardHBsAb" style="border-top: 4px solid #D97706; position: relative;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #B45309; font-weight: 800; font-size: 0.95rem; margin-bottom: 10px;">
          <span>🩸 HBsAb Serology Status (نتيجة مناعة الكبد ب)</span>
          <button class="btn btn-outline no-print" style="padding: 3px 10px; font-size: 0.78rem; border-color: #D97706; color: #D97706; font-weight: bold; background: white;" onclick="printSingleCard('cardHBsAb', 'HBsAb Serology Status Result')">
            🖨️ Print
          </button>
        </div>
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9.5pt; margin-bottom: 14px;">
          <thead>
            <tr style="background: #F1F5F9; color: #B45309;">
              <th style="padding: 6px; border: 1px solid #CBD5E1;">Serology Status</th>
              <th style="padding: 6px; border: 1px solid #CBD5E1; text-align: center;">Headcount</th>
              <th style="padding: 6px; border: 1px solid #CBD5E1; text-align: center;">Percentage %</th>
              <th style="padding: 6px; border: 1px solid #CBD5E1; text-align: center;" class="no-print">Interactive Follow-up List</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Immune (anti-HBs ≥10 mIU/mL)</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.hbsab.hbsImmune}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">${metrics.hbsab.immunePct}%</td>
              <td style="padding: 6px 8px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
                <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; border-color: #059669; color: #059669; font-weight: bold;" onclick="renderHBsAbCategoryList('immune')">📋 View List (${metrics.hbsab.hbsImmune})</button>
              </td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Vaccination in progress</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #D97706;">${metrics.hbsab.hbsVaccinating}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #D97706;">${metrics.hbsab.vaccinatingPct}%</td>
              <td style="padding: 6px 8px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
                <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; border-color: #D97706; color: #D97706; font-weight: bold;" onclick="renderHBsAbCategoryList('vaccinating')">📋 View List (${metrics.hbsab.hbsVaccinating})</button>
              </td>
            </tr>
            <tr>
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Vaccine non-responder</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #DC2626;">${metrics.hbsab.hbsResistance}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #DC2626;">${metrics.hbsab.resistancePct}%</td>
              <td style="padding: 6px 8px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
                <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; border-color: #DC2626; color: #DC2626; font-weight: bold;" onclick="renderHBsAbCategoryList('resistance')">📋 View List (${metrics.hbsab.hbsResistance})</button>
              </td>
            </tr>
            <tr style="background: #FFFBEB;">
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0; color: #B45309;">Immunity status unknown (no anti-HBs result)</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #B45309;">${metrics.hbsab.hbsOngoing}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #B45309;">${metrics.hbsab.ongoingPct}%</td>
              <td style="padding: 6px 8px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
                <button class="btn btn-warning" style="padding: 2px 8px; font-size: 0.75rem; background: #D97706; color: white; border: none; font-weight: bold;" onclick="renderHBsAbCategoryList('ongoing')">📋 Follow-up List (${metrics.hbsab.hbsOngoing})</button>
              </td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="padding: 6px 8px; font-weight: bold; border: 1px solid #E2E8F0;">Vaccination not indicated under MOH guidelines</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #64748B;">${metrics.hbsab.hbsNoNeed}</td>
              <td style="padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #E2E8F0; color: #64748B;">${metrics.hbsab.noNeedPct}%</td>
              <td style="padding: 6px 8px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
                <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; border-color: #64748B; color: #64748B; font-weight: bold;" onclick="renderHBsAbCategoryList('noNeed')">📋 View List (${metrics.hbsab.hbsNoNeed})</button>
              </td>
            </tr>
            <tr style="background: #FEF3C7; font-weight: 900; color: #92400E;">
              <td style="padding: 8px; border: 1px solid #FDE68A;">Total Monitored & Compliance %</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #FDE68A; font-size: 1rem;">${metrics.hbsab.total}</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #FDE68A; font-size: 1rem;">${metrics.hbsab.pct}%</td>
              <td style="padding: 8px; border: 1px solid #FDE68A;" class="no-print"></td>
            </tr>
          </tbody>
        </table>
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px; margin-bottom: 12px;">
          <canvas id="hbsabChart" height="170"></canvas>
        </div>
        <div id="hbsabCategoryListContainer" style="background: #F1F5F9; border: 1px solid #CBD5E1; border-radius: 8px; padding: 12px;" class="no-print"></div>
      </div>

      <!-- CARD 4: HCV, HIV & PPD SCREENING RESULTS -->
      <div class="card" id="cardLabScreening" style="border-top: 4px solid #7C3AED; position: relative;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #6D28D9; font-weight: 800; font-size: 0.95rem; margin-bottom: 10px;">
          <span>🔬 HCV, HIV & PPD Results (الفحوصات)</span>
          <button class="btn btn-outline no-print" style="padding: 3px 10px; font-size: 0.78rem; border-color: #7C3AED; color: #7C3AED; font-weight: bold; background: white;" onclick="printSingleCard('cardLabScreening', 'HCV, HIV & PPD Screening Results')">
            🖨️ Print
          </button>
        </div>
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt; margin-bottom: 14px;">
          <thead>
            <tr style="background: #F3E8FF; color: #6D28D9;">
              <th style="padding: 6px; border: 1px solid #DDD6FE;">Test Parameter</th>
              <th style="padding: 6px; border: 1px solid #DDD6FE; text-align: center;">HCV Result</th>
              <th style="padding: 6px; border: 1px solid #DDD6FE; text-align: center;">HIV Result</th>
              <th style="padding: 6px; border: 1px solid #DDD6FE; text-align: center;">PPD Result</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 6px; font-weight: bold; border: 1px solid #E2E8F0; color: #DC2626;">Positive Result</td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #DC2626;">${metrics.labScreening.hcvPos} (${metrics.labScreening.hcvPosPct}%)</div>
                <button class="btn btn-outline no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; border-color: #DC2626; color: #DC2626; font-weight: bold;" onclick="renderLabScreeningCategoryList('hcv', 'pos')">📋 View List (${metrics.labScreening.hcvPos})</button>
              </td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #DC2626;">${metrics.labScreening.hivPos} (${metrics.labScreening.hivPosPct}%)</div>
                <button class="btn btn-outline no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; border-color: #DC2626; color: #DC2626; font-weight: bold;" onclick="renderLabScreeningCategoryList('hiv', 'pos')">📋 View List (${metrics.labScreening.hivPos})</button>
              </td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #DC2626;">${metrics.labScreening.ppdPos} (${metrics.labScreening.ppdPosPct}%)</div>
                <button class="btn btn-outline no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; border-color: #DC2626; color: #DC2626; font-weight: bold;" onclick="renderLabScreeningCategoryList('ppd', 'pos')">📋 View List (${metrics.labScreening.ppdPos})</button>
              </td>
            </tr>
            <tr style="background: #F8FAFC;">
              <td style="padding: 6px; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">Negative Result</td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #059669;">${metrics.labScreening.hcvNeg} (${metrics.labScreening.hcvNegPct}%)</div>
                <button class="btn btn-outline no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; border-color: #059669; color: #059669; font-weight: bold;" onclick="renderLabScreeningCategoryList('hcv', 'neg')">📋 View List (${metrics.labScreening.hcvNeg})</button>
              </td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #059669;">${metrics.labScreening.hivNeg} (${metrics.labScreening.hivNegPct}%)</div>
                <button class="btn btn-outline no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; border-color: #059669; color: #059669; font-weight: bold;" onclick="renderLabScreeningCategoryList('hiv', 'neg')">📋 View List (${metrics.labScreening.hivNeg})</button>
              </td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #059669;">${metrics.labScreening.ppdNeg} (${metrics.labScreening.ppdNegPct}%)</div>
                <button class="btn btn-outline no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; border-color: #059669; color: #059669; font-weight: bold;" onclick="renderLabScreeningCategoryList('ppd', 'neg')">📋 View List (${metrics.labScreening.ppdNeg})</button>
              </td>
            </tr>
            <tr style="background: #FFFBEB;">
              <td style="padding: 6px; font-weight: bold; border: 1px solid #E2E8F0; color: #D97706;">Ongoing / Pending</td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #D97706;">${metrics.labScreening.hcvOngoing} (${metrics.labScreening.hcvOngoingPct}%)</div>
                <button class="btn btn-warning no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; background: #D97706; color: white; border: none; font-weight: bold;" onclick="renderLabScreeningCategoryList('hcv', 'ongoing')">📋 Follow-up List (${metrics.labScreening.hcvOngoing})</button>
              </td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #D97706;">${metrics.labScreening.hivOngoing} (${metrics.labScreening.hivOngoingPct}%)</div>
                <button class="btn btn-warning no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; background: #D97706; color: white; border: none; font-weight: bold;" onclick="renderLabScreeningCategoryList('hiv', 'ongoing')">📋 Follow-up List (${metrics.labScreening.hivOngoing})</button>
              </td>
              <td style="padding: 6px; text-align: center; border: 1px solid #E2E8F0;">
                <div style="font-weight: bold; color: #D97706;">${metrics.labScreening.ppdOngoing} (${metrics.labScreening.ppdOngoingPct}%)</div>
                <button class="btn btn-warning no-print" style="margin-top: 4px; padding: 1px 6px; font-size: 0.7rem; background: #D97706; color: white; border: none; font-weight: bold;" onclick="renderLabScreeningCategoryList('ppd', 'ongoing')">📋 Follow-up List (${metrics.labScreening.ppdOngoing})</button>
              </td>
            </tr>
            <tr style="background: #F3E8FF; font-weight: 900; color: #6D28D9;">
              <td style="padding: 7px; border: 1px solid #DDD6FE;">Total Monitored</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #DDD6FE;">${metrics.total} (100%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #DDD6FE;">${metrics.total} (100%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #DDD6FE;">${metrics.total} (100%)</td>
            </tr>
          </tbody>
        </table>
        <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px; margin-bottom: 12px;">
          <canvas id="labScreeningChart" height="170"></canvas>
        </div>
        <div id="labScreeningCategoryListContainer" style="background: #F1F5F9; border: 1px solid #CBD5E1; border-radius: 8px; padding: 12px;" class="no-print"></div>
      </div>
    </div>

    <!-- CARD 4B: SEPARATE VARICELLA (CHICKENPOX) IMMUNITY STATUS & FOLLOW-UP CARD -->
    <div class="card" id="cardVaricella" style="border-top: 4px solid #059669; position: relative; margin-bottom: 24px;">
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #047857; font-weight: 800; font-size: 1rem; margin-bottom: 12px; border-bottom: 2px solid #ECFDF5; padding-bottom: 8px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span>🦠 Varicella (Chickenpox) Immunity Status & Follow-up</span>
          <span style="font-size: 0.75rem; background: #DEF7EC; color: #03543F; padding: 2px 8px; border-radius: 12px; font-weight: bold;">Separated Report & Graph</span>
        </div>
        <button class="btn btn-outline no-print" style="padding: 4px 12px; font-size: 0.8rem; border-color: #059669; color: #059669; font-weight: bold; background: white;" onclick="printSingleCard('cardVaricella', 'Varicella Immunity Status Report')">
          🖨️ Print Report
        </button>
      </div>

      <!-- 4 CATEGORY SUMMARY BADGES -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 16px;">
        <div style="background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #065F46; font-weight: bold;">💉 Vaccinated (2 Doses)</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #059669; margin: 2px 0;">${metrics.varicella.doses2Count}</div>
          <div style="font-size: 0.75rem; color: #047857; font-weight: 700;">${metrics.varicella.doses2Pct}% of total</div>
        </div>
        <div style="background: #F3E8FF; border: 1px solid #DDD6FE; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #5B21B6; font-weight: bold;">🧪 Positive IgG (Serology)</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #7C3AED; margin: 2px 0;">${metrics.varicella.posIgGCount}</div>
          <div style="font-size: 0.75rem; color: #6D28D9; font-weight: 700;">${metrics.varicella.posIgGPct}% of total</div>
        </div>
        <div style="background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #1E40AF; font-weight: bold;">🛡️ Natural Immunity</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #0284C7; margin: 2px 0;">${metrics.varicella.natImmCount}</div>
          <div style="font-size: 0.75rem; color: #1D4ED8; font-weight: 700;">${metrics.varicella.natImmPct}% of total</div>
        </div>
        <div style="background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #92400E; font-weight: bold;">⏳ Ongoing / Pending</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #D97706; margin: 2px 0;">${metrics.varicella.ongoingCount}</div>
          <div style="font-size: 0.75rem; color: #B45309; font-weight: 700;">${metrics.varicella.ongoingPct}% of total</div>
        </div>
      </div>

      <!-- MAIN VARICELLA BREAKDOWN TABLE -->
      <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt; margin-bottom: 16px; border: 1.5px solid #059669;">
        <thead>
          <tr style="background: #059669; color: white;">
            <th style="padding: 7px; border: 1px solid #047857; text-align: left;">Immunity Category (فئة حصانة الجدري)</th>
            <th style="padding: 7px; border: 1px solid #047857; text-align: left;">Calculation Source / Criteria</th>
            <th style="padding: 7px; border: 1px solid #047857; text-align: center;">Headcount</th>
            <th style="padding: 7px; border: 1px solid #047857; text-align: center;">Percentage %</th>
            <th style="padding: 7px; border: 1px solid #047857; text-align: center;" class="no-print">Interactive Follow-up List</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">💉 Vaccinated (2 Doses)</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Documented 2 vaccine doses/dates in record</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669;">${metrics.varicella.doses2Count}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669;">${metrics.varicella.doses2Pct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.75rem; border-color: #059669; color: #059669; font-weight: bold;" onclick="renderVaricellaCategoryList('doses2')">📋 View List (${metrics.varicella.doses2Count})</button>
            </td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #7C3AED;">🧪 Positive Serology (Positive IgG)</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Lab result showing positive/reactive Varicella IgG</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #7C3AED;">${metrics.varicella.posIgGCount}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #7C3AED;">${metrics.varicella.posIgGPct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.75rem; border-color: #7C3AED; color: #7C3AED; font-weight: bold;" onclick="renderVaricellaCategoryList('posIgG')">📋 View List (${metrics.varicella.posIgGCount})</button>
            </td>
          </tr>
          <tr>
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #0284C7;">🛡️ Natural Immunity Declaration</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Declaration of past chickenpox illness</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #0284C7;">${metrics.varicella.natImmCount}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #0284C7;">${metrics.varicella.natImmPct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.75rem; border-color: #0284C7; color: #0284C7; font-weight: bold;" onclick="renderVaricellaCategoryList('natImm')">📋 View List (${metrics.varicella.natImmCount})</button>
            </td>
          </tr>
          <tr style="background: #FFFBEB;">
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #D97706;">⏳ Ongoing / Pending (Follow-up Needed)</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Blank / incomplete status awaiting vaccine or IgG testing</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706;">${metrics.varicella.ongoingCount}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706;">${metrics.varicella.ongoingPct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-warning" style="padding: 3px 8px; font-size: 0.75rem; background: #D97706; color: white; border: none; font-weight: bold;" onclick="renderVaricellaCategoryList('ongoing')">📋 Follow-up List (${metrics.varicella.ongoingCount})</button>
            </td>
          </tr>
          <tr style="background: #ECFDF5; font-weight: 900; color: #065F46;">
            <td style="padding: 8px; border: 1px solid #A7F3D0;" colspan="2">Total Monitored Hospital Staff</td>
            <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0;">${metrics.total}</td>
            <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0;">100%</td>
            <td style="padding: 8px; border: 1px solid #A7F3D0;" class="no-print"></td>
          </tr>
        </tbody>
      </table>

      <!-- VARICELLA CHART CONTAINER WITH TYPE TOGGLE & COMPACT HEIGHT -->
      <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px 14px; margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <div style="font-size: 0.85rem; font-weight: bold; color: #047857;">📊 Varicella Immunity Categories Breakdown (%)</div>
          <div style="display: flex; gap: 4px;" class="no-print">
            <button type="button" id="btn_varicella_pie" class="btn" style="padding: 3px 10px; font-size: 0.72rem; font-weight: bold; border-radius: 4px; border: 1px solid #059669; background: #059669; color: white; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,0.1);" onclick="toggleVaricellaChartType('doughnut')">
              🥧 Pie/Doughnut Chart
            </button>
            <button type="button" id="btn_varicella_bar" class="btn" style="padding: 3px 10px; font-size: 0.72rem; font-weight: bold; border-radius: 4px; border: 1px solid #059669; background: white; color: #059669; cursor: pointer; box-shadow: 0 1px 3px rgba(0,0,0,0.05);" onclick="toggleVaricellaChartType('bar')">
              📊 Bar Chart
            </button>
          </div>
        </div>
        <div style="height: 140px; position: relative; width: 100%;">
          <canvas id="varicellaChart" height="140"></canvas>
        </div>
      </div>

      <!-- INTERACTIVE CATEGORY EMPLOYEE LIST FOR FOLLOW-UP -->
      <div id="varicellaCategoryListContainer" style="background: #F1F5F9; border: 1px solid #CBD5E1; border-radius: 8px; padding: 12px;" class="no-print">
        <!-- Rendered dynamically by renderVaricellaCategoryList -->
      </div>
    </div>

        <!-- CARD 5: CORE VACCINE COMPLIANCE SUMMARY TABLE -->
    <div class="card" id="cardCoreVac" style="margin-bottom: 24px; border-top: 4px solid #0284C7; position: relative;">
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #0369A1; font-weight: 800;">
        <span>&#128137; Core Vaccine Compliance Summary (\u0627\u0644\u062a\u0637\u0639\u064a\u0645\u0627\u062a \u0627\u0644\u0623\u0633\u0627\u0633\u064a\u0629)</span>
        <div style="display: flex; gap: 8px;">
          <button class="btn btn-warning no-print" style="padding: 4px 12px; font-size: 0.8rem; background: #D97706; color: white; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; box-shadow: 0 2px 6px rgba(217,119,6,0.2);" onclick="openMOHCellStaffModal('core_all_contra')">
            &#128203; ${metrics.coreVac.contraList ? metrics.coreVac.contraList.length : (metrics.coreVac.ipv.contra || 0)} ${isAr ? "\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0648\u0638\u0641\u064a\u0646 \u0630\u0648\u064a \u0627\u0644\u0645\u0648\u0627\u0646\u0639 \u0627\u0644\u0637\u0628\u064a\u0629" : "Contraindicated Staff List"}
          </button>
          <button class="btn btn-danger no-print" style="padding: 4px 12px; font-size: 0.8rem; background: #DC2626; color: white; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; box-shadow: 0 2px 6px rgba(220,38,38,0.2);" onclick="openMOHCellStaffModal('core_all_unvac')">
            &#128203; ${metrics.coreVac.unvaccinatedListCount || 0} ${isAr ? "\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0648\u0638\u0641\u064a\u0646 \u063a\u064a\u0631 \u0627\u0644\u0645\u0644\u0642\u062d\u064a\u0646" : "Unvaccinated Staff List"}
          </button>
          <button class="btn btn-outline no-print" style="padding: 4px 12px; font-size: 0.8rem; border-color: #0284C7; color: #0284C7; font-weight: bold; background: white;" onclick="printSingleCard('cardCoreVac', 'Core Vaccine Compliance Summary')">
            &#128424;&#65039; Print Card
          </button>
        </div>
      </div>
      <div class="table-responsive" style="margin-bottom: 16px;">
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt; border: 1.5px solid #0284C7;">
          <thead>
            <tr style="background: #E0F2FE; color: #0369A1;">
              <th style="padding: 8px; border: 1px solid #BAE6FD; text-align: left;">Vaccine Category Status</th>
              <th style="padding: 8px; border: 1px solid #BAE6FD; text-align: center;">IPV Vaccine (&gt;18Y)</th>
              <th style="padding: 8px; border: 1px solid #BAE6FD; text-align: center;">Tdap Vaccine (&gt;7Y)</th>
              <th style="padding: 8px; border: 1px solid #BAE6FD; text-align: center;">MMR 1st Dose (&gt;1Y)</th>
              <th style="padding: 8px; border: 1px solid #BAE6FD; text-align: center;">MMR 2nd Dose (&gt;1Y)</th>
              <th style="padding: 8px; border: 1px solid #BAE6FD; text-align: center;">Chickenpox / Varicella</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0;">Number of employees with documented vaccination</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('core_ipv_vac')" title="Click to view IPV vaccinated staff">${metrics.coreVac.ipv.vac} (${metrics.coreVac.ipv.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('core_tdap_vac')" title="Click to view Tdap vaccinated staff">${metrics.coreVac.tdap.vac} (${metrics.coreVac.tdap.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('core_mmr1_vac')" title="Click to view MMR 1 vaccinated staff">${metrics.coreVac.mmr1.vac} (${metrics.coreVac.mmr1.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('core_mmr2_vac')" title="Click to view MMR 2 vaccinated staff">${metrics.coreVac.mmr2.vac} (${metrics.coreVac.mmr2.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('core_cp_vac')" title="Click to view Varicella immune staff">${metrics.coreVac.cp.vac} (${metrics.coreVac.cp.pct}%) &#128269;</td>
            </tr>
            <tr style="background: #F8FAFC; cursor: pointer;" title="Click to view full list of staff with documented vaccination refusals" onclick="openMOHCellStaffModal('core_all_refused')">
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #475569;">Number of employees with documented refusal &#128203;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_ipv_refused')">${metrics.coreVac.ipv.refused} (${metrics.coreVac.ipv.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_tdap_refused')">${metrics.coreVac.tdap.refused} (${metrics.coreVac.tdap.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_mmr1_refused')">${metrics.coreVac.mmr1.refused} (${metrics.coreVac.mmr1.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_mmr2_refused')">${metrics.coreVac.mmr2.refused} (${metrics.coreVac.mmr2.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_cp_refused')">${metrics.coreVac.cp.refused} (${metrics.coreVac.cp.refusedPct}%)</td>
            </tr>
            <tr style="background: #FFFBEB; cursor: pointer;" title="Click row to view full list of staff with medical contraindications" onclick="openMOHCellStaffModal('core_all_contra')">
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #92400E;">Number of employees with documented contraindication &#128203;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_ipv_contra')" title="Click to view IPV contraindicated staff">${metrics.coreVac.ipv.contra} (${metrics.coreVac.ipv.contraPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_tdap_contra')" title="Click to view Tdap contraindicated staff">${metrics.coreVac.tdap.contra} (${metrics.coreVac.tdap.contraPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_mmr1_contra')" title="Click to view MMR 1 contraindicated staff">${metrics.coreVac.mmr1.contra} (${metrics.coreVac.mmr1.contraPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_mmr2_contra')" title="Click to view MMR 2 contraindicated staff">${metrics.coreVac.mmr2.contra} (${metrics.coreVac.mmr2.contraPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_cp_contra')" title="Click to view Varicella contraindicated staff">${metrics.coreVac.cp.contra} (${metrics.coreVac.cp.contraPct}%) &#128269;</td>
            </tr>
            <tr style="background: #FEF2F2; cursor: pointer;" title="Click to view full list of unvaccinated staff" onclick="openMOHCellStaffModal('core_all_unvac')">
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #991B1B;">Number of employees unvaccinated or without documented vaccination status &#128203;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_ipv_not')" title="Click to view unvaccinated staff">${metrics.coreVac.ipv.not} (${metrics.coreVac.ipv.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_tdap_not')" title="Click to view unvaccinated staff">${metrics.coreVac.tdap.not} (${metrics.coreVac.tdap.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_mmr1_not')" title="Click to view unvaccinated staff">${metrics.coreVac.mmr1.not} (${metrics.coreVac.mmr1.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_mmr2_not')" title="Click to view unvaccinated staff">${metrics.coreVac.mmr2.not} (${metrics.coreVac.mmr2.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('core_cp_not')" title="Click to view unvaccinated staff">${metrics.coreVac.cp.not} (${metrics.coreVac.cp.notPct}%) &#128269;</td>
            </tr>
            <tr style="background: #E0F2FE; font-weight: 900; color: #0369A1;">
              <td style="padding: 8px; border: 1px solid #BAE6FD;">Total & Compliance Rate</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD;">${metrics.total} (${metrics.coreVac.ipv.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD;">${metrics.total} (${metrics.coreVac.tdap.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD;">${metrics.total} (${metrics.coreVac.mmr1.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD;">${metrics.total} (${metrics.coreVac.mmr2.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD;">${metrics.total} (${metrics.coreVac.cp.pct}%)</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 12px;">
        <canvas id="coreVacChart" height="200"></canvas>
      </div>
    </div>

        <!-- CARD 6: SPECIAL VACCINE COMPLIANCE SUMMARY TABLE -->
    <div class="card" id="cardSpecialVac" style="margin-bottom: 24px; border-top: 4px solid #166534; position: relative;">
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #166534; font-weight: 800;">
        <div>
          <span>&#128737;&#65039; Special Vaccine Compliance Summary (\u0627\u0644\u062a\u0637\u0639\u064a\u0645\u0627\u062a \u0627\u0644\u062e\u0627\u0635\u0629)</span>
          <div style="font-size: 0.78rem; color: #047857; font-weight: 600; margin-top: 2px;">
            Target Denominator: <strong>${metrics.specialVac.total} Special Staff</strong> (Excluding Basic Plan | Anatomical Pathology, Clinical Lab, Lab Medicine, Molecular Lab, Apheresis/BMT Lab & Hematomolecular Pathology)
          </div>
        </div>
        <div style="display: flex; gap: 8px;">
          <button class="btn btn-warning no-print" style="padding: 4px 12px; font-size: 0.8rem; background: #D97706; color: white; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; box-shadow: 0 2px 6px rgba(217,119,6,0.2);" onclick="openMOHCellStaffModal('special_all_contra')">
            &#128203; ${(metrics.specialVac.contraList && metrics.specialVac.contraList.length) || 0} ${isAr ? "\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0648\u0638\u0641\u064a\u0646 \u0630\u0648\u064a \u0627\u0644\u0645\u0648\u0627\u0646\u0639 \u0627\u0644\u0637\u0628\u064a\u0629" : "Contraindicated Staff List"}
          </button>
          <button class="btn btn-danger no-print" style="padding: 4px 12px; font-size: 0.8rem; background: #DC2626; color: white; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; box-shadow: 0 2px 6px rgba(220,38,38,0.2);" onclick="openMOHCellStaffModal('special_all_unvac')">
            &#128203; ${metrics.specialVac.unvaccinatedListCount || 0} ${isAr ? "\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0645\u0648\u0638\u0641\u064a\u0646 \u063a\u064a\u0631 \u0627\u0644\u0645\u0644\u0642\u062d\u064a\u0646" : "Unvaccinated Special Staff List"}
          </button>
          <button class="btn btn-outline no-print" style="padding: 4px 12px; font-size: 0.8rem; border-color: #166534; color: #166534; font-weight: bold; background: white;" onclick="printSingleCard('cardSpecialVac', 'Special Vaccine Compliance Summary')">
            &#128424;&#65039; Print Card
          </button>
        </div>
      </div>
      <div class="table-responsive" style="margin-bottom: 16px;">
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt; border: 1.5px solid #166534;">
          <thead>
            <tr style="background: #DCFCE7; color: #166534;">
              <th style="padding: 8px; border: 1px solid #A7F3D0; text-align: left;">Vaccine Category Status</th>
              <th style="padding: 8px; border: 1px solid #A7F3D0; text-align: center;">Meningiococcal A, C</th>
              <th style="padding: 8px; border: 1px solid #A7F3D0; text-align: center;">hep A SERIES 1</th>
              <th style="padding: 8px; border: 1px solid #A7F3D0; text-align: center;">hep A SERIES 2</th>
              <th style="padding: 8px; border: 1px solid #A7F3D0; text-align: center;">typhoid</th>
              <th style="padding: 8px; border: 1px solid #A7F3D0; text-align: center;">Pneumovax</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0;">Number of employees with documented vaccination</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('special_men_vac')" title="Click to view Meningococcal vaccinated staff">${metrics.specialVac.men.vac} (${metrics.specialVac.men.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('special_ha1_vac')" title="Click to view Hep A1 vaccinated staff">${metrics.specialVac.hepA1.vac} (${metrics.specialVac.hepA1.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('special_ha2_vac')" title="Click to view Hep A2 vaccinated staff">${metrics.specialVac.hepA2.vac} (${metrics.specialVac.hepA2.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('special_typ_vac')" title="Click to view Typhoid vaccinated staff">${metrics.specialVac.typ.vac} (${metrics.specialVac.typ.pct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="openMOHCellStaffModal('special_pne_vac')" title="Click to view Pneumovax vaccinated staff">${metrics.specialVac.pne.vac} (${metrics.specialVac.pne.pct}%) &#128269;</td>
            </tr>
            <tr style="background: #F8FAFC; cursor: pointer;" title="Click to view full list of staff with documented vaccination refusals" onclick="openMOHCellStaffModal('special_all_refused')">
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #475569;">Number of employees with documented refusal &#128203;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_men_refused')">${metrics.specialVac.men.refused} (${metrics.specialVac.men.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_ha1_refused')">${metrics.specialVac.hepA1.refused} (${metrics.specialVac.hepA1.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_ha2_refused')">${metrics.specialVac.hepA2.refused} (${metrics.specialVac.hepA2.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_typ_refused')">${metrics.specialVac.typ.refused} (${metrics.specialVac.typ.refusedPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #64748B; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_pne_refused')">${metrics.specialVac.pne.refused} (${metrics.specialVac.pne.refusedPct}%)</td>
            </tr>
            <tr style="background: #FFFBEB; cursor: pointer;" title="Click to view full list of staff with medical contraindications" onclick="openMOHCellStaffModal('special_all_contra')">
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #92400E;">Number of employees with documented contraindication &#128203;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #D97706; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_men_contra')">${metrics.specialVac.men.contra} (${metrics.specialVac.men.contraPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #D97706; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_ha1_contra')">${metrics.specialVac.hepA1.contra} (${metrics.specialVac.hepA1.contraPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #D97706; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_ha2_contra')">${metrics.specialVac.hepA2.contra} (${metrics.specialVac.hepA2.contraPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #D97706; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_typ_contra')">${metrics.specialVac.typ.contra} (${metrics.specialVac.typ.contraPct}%)</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; color: #D97706; cursor: pointer;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_pne_contra')">${metrics.specialVac.pne.contra} (${metrics.specialVac.pne.contraPct}%)</td>
            </tr>
            <tr style="background: #FEF2F2; cursor: pointer;" title="Click to view full list of unvaccinated special staff" onclick="openMOHCellStaffModal('special_all_unvac')">
              <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #991B1B;">Number of employees unvaccinated or without documented vaccination status &#128203;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_men_not')" title="Click to view Meningococcal unvaccinated staff">${metrics.specialVac.men.not} (${metrics.specialVac.men.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_ha1_not')" title="Click to view Hep A1 unvaccinated staff">${metrics.specialVac.hepA1.not} (${metrics.specialVac.hepA1.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_ha2_not')" title="Click to view Hep A2 unvaccinated staff">${metrics.specialVac.hepA2.not} (${metrics.specialVac.hepA2.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_typ_not')" title="Click to view Typhoid unvaccinated staff">${metrics.specialVac.typ.not} (${metrics.specialVac.typ.notPct}%) &#128269;</td>
              <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('special_pne_not')" title="Click to view Pneumovax unvaccinated staff">${metrics.specialVac.pne.not} (${metrics.specialVac.pne.notPct}%) &#128269;</td>
            </tr>
            <tr style="background: #DCFCE7; font-weight: 900; color: #166534;">
              <td style="padding: 8px; border: 1px solid #A7F3D0; cursor: pointer;" onclick="openMOHCellStaffModal('special_all_target')" title="Click to view all target special staff">Total & Compliance Rate &#128269;</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0;">${metrics.specialVac.total} (${metrics.specialVac.men.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0;">${metrics.specialVac.total} (${metrics.specialVac.hepA1.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0;">${metrics.specialVac.total} (${metrics.specialVac.hepA2.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0;">${metrics.specialVac.total} (${metrics.specialVac.typ.pct}%)</td>
              <td style="padding: 8px; text-align: center; border: 1px solid #A7F3D0;">${metrics.specialVac.total} (${metrics.specialVac.pne.pct}%)</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 12px;">
        <canvas id="specialVacChart" height="200"></canvas>
      </div>
    </div>

    <!-- CARD 6B: SEASONAL FLU VACCINE 2024-2025 COMPLIANCE & FOLLOW-UP CARD (MOVED BELOW SPECIAL VACCINES) -->
    <div class="card" id="cardFlu2025" style="border-top: 4px solid #0284C7; position: relative; margin-bottom: 24px;">
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; color: #0369A1; font-weight: 800; font-size: 1rem; margin-bottom: 12px; border-bottom: 2px solid #E0F2FE; padding-bottom: 8px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span>💉 ${isAr ? 'تقرير التغطية بتطعيم الإنفلونزا الموسمية (Flu Vaccine 2024-2025)' : 'Seasonal Flu Vaccine 2024-2025 Compliance & Follow-up'}</span>
          <span style="font-size: 0.75rem; background: #E0F2FE; color: #0369A1; padding: 2px 8px; border-radius: 12px; font-weight: bold;">AVH Report 2025</span>
        </div>
        <button class="btn btn-outline no-print" style="padding: 4px 12px; font-size: 0.8rem; border-color: #0284C7; color: #0284C7; font-weight: bold; background: white;" onclick="printSingleCard('cardFlu2025', 'Seasonal Flu Vaccine 2024-2025 Compliance Report')">
          🖨️ ${isAr ? 'طباعة التقرير' : 'Print Report'}
        </button>
      </div>

      <!-- 4 CATEGORY SUMMARY KPI BADGES -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 16px;">
        <div style="background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #065F46; font-weight: bold;">🏥 ${isAr ? 'مطعّم في المستشفى (تاريخ موثق)' : 'Vaccinated at AVH (Date)'}</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #059669; margin: 2px 0;">${metrics.flu2425.avhDateCount}</div>
          <div style="font-size: 0.75rem; color: #047857; font-weight: 700;">${metrics.flu2425.avhDatePct}% ${isAr ? 'من الكادر' : 'of total'}</div>
        </div>

        <div style="background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #1E40AF; font-weight: bold;">⚕️ ${isAr ? 'مطعّم في كوبات حوليم' : 'Vaccinated at Kupat Holim'}</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #1D4ED8; margin: 2px 0;">${metrics.flu2425.kupatCount}</div>
          <div style="font-size: 0.75rem; color: #1E40AF; font-weight: 700;">${metrics.flu2425.kupatPct}% ${isAr ? 'من الكادر' : 'of total'}</div>
        </div>

        <div style="background: #FEF2F2; border: 1px solid #FCA5A5; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #991B1B; font-weight: bold;">🚫 ${isAr ? 'ممتنع/رافض للتطعيم' : 'Refused Vaccine'}</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #DC2626; margin: 2px 0;">${metrics.flu2425.refusedCount}</div>
          <div style="font-size: 0.75rem; color: #991B1B; font-weight: 700;">${metrics.flu2425.refusedPct}% ${isAr ? 'من الكادر' : 'of total'}</div>
        </div>

        <div style="background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 8px; padding: 10px; text-align: center;">
          <div style="font-size: 0.78rem; color: #92400E; font-weight: bold;">⚪ ${isAr ? 'غير مطعّم (فارغ/معلق)' : 'Unvaccinated (Blank)'}</div>
          <div style="font-size: 1.3rem; font-weight: 800; color: #D97706; margin: 2px 0;">${metrics.flu2425.unvaccinatedCount}</div>
          <div style="font-size: 0.75rem; color: #B45309; font-weight: 700;">${metrics.flu2425.unvaccinatedPct}% ${isAr ? 'من الكادر' : 'of total'}</div>
        </div>
      </div>

      <!-- MAIN FLU BREAKDOWN TABLE -->
      <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt; margin-bottom: 16px; border: 1.5px solid #0284C7;">
        <thead>
          <tr style="background: #0284C7; color: white;">
            <th style="padding: 7px; border: 1px solid #0369A1; text-align: left;">Compliance Category (فئة التغطية بتطعيم الإنفلونزا)</th>
            <th style="padding: 7px; border: 1px solid #0369A1; text-align: left;">Data Field Source / Standard Criteria</th>
            <th style="padding: 7px; border: 1px solid #0369A1; text-align: center;">Headcount</th>
            <th style="padding: 7px; border: 1px solid #0369A1; text-align: center;">Percentage %</th>
            <th style="padding: 7px; border: 1px solid #0369A1; text-align: center;" class="no-print">Interactive Staff List</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #059669;">🏥 1. Vaccinated at AVH (Date Documented)</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Documented date / AVH record in Flu 2024-2025 field</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669;">${metrics.flu2425.avhDateCount}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #059669;">${metrics.flu2425.avhDatePct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.75rem; border-color: #059669; color: #059669; font-weight: bold;" onclick="renderFlu2425CategoryList('avh_date')">📋 View List (${metrics.flu2425.avhDateCount})</button>
            </td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #1D4ED8;">⚕️ 2. Vaccinated at Kupat Holim</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Documented as Kupat Holim / External Clinic</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #1D4ED8;">${metrics.flu2425.kupatCount}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #1D4ED8;">${metrics.flu2425.kupatPct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.75rem; border-color: #1D4ED8; color: #1D4ED8; font-weight: bold;" onclick="renderFlu2425CategoryList('kupat_holim')">📋 View List (${metrics.flu2425.kupatCount})</button>
            </td>
          </tr>
          <tr>
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #DC2626;">🚫 3. Refused Vaccine (Documented Refusal)</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Documented refusal / decline form in record</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626;">${metrics.flu2425.refusedCount}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #DC2626;">${metrics.flu2425.refusedPct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-outline" style="padding: 3px 8px; font-size: 0.75rem; border-color: #DC2626; color: #DC2626; font-weight: bold;" onclick="renderFlu2425CategoryList('refused')">📋 View List (${metrics.flu2425.refusedCount})</button>
            </td>
          </tr>
          <tr style="background: #FFFBEB;">
            <td style="padding: 7px; font-weight: bold; border: 1px solid #E2E8F0; color: #D97706;">⚪ 4. Unvaccinated (Blank / Pending)</td>
            <td style="padding: 7px; border: 1px solid #E2E8F0; color: #475569; font-size: 0.8rem;">Blank / unrecorded status awaiting vaccination or refusal</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706;">${metrics.flu2425.unvaccinatedCount}</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0; font-weight: bold; color: #D97706;">${metrics.flu2425.unvaccinatedPct}%</td>
            <td style="padding: 7px; text-align: center; border: 1px solid #E2E8F0;" class="no-print">
              <button class="btn btn-warning" style="padding: 3px 8px; font-size: 0.75rem; background: #D97706; color: white; border: none; font-weight: bold;" onclick="renderFlu2425CategoryList('unvaccinated')">📋 Follow-up List (${metrics.flu2425.unvaccinatedCount})</button>
            </td>
          </tr>
          <tr style="background: #E0F2FE; font-weight: 900; color: #0369A1;">
            <td style="padding: 8px; border: 1px solid #BAE6FD;" colspan="2">Total Monitored Hospital Staff</td>
            <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD;">${metrics.total}</td>
            <td style="padding: 8px; text-align: center; border: 1px solid #BAE6FD;">100%</td>
            <td style="padding: 8px; border: 1px solid #BAE6FD;" class="no-print"></td>
          </tr>
        </tbody>
      </table>

      <!-- FLU 2024-2025 CHART CONTAINER -->
      <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px 14px; margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
          <div style="font-size: 0.85rem; font-weight: bold; color: #0369A1;">📊 Seasonal Flu 2024-2025 Breakdown (%)</div>
          <div style="display: flex; gap: 4px;" class="no-print">
            <button type="button" id="btn_flu_pie" class="btn" style="padding: 3px 10px; font-size: 0.72rem; font-weight: bold; border-radius: 4px; border: 1px solid #0284C7; background: #0284C7; color: white; cursor: pointer;" onclick="toggleFluChartType('doughnut')">🥧 Doughnut Chart</button>
            <button type="button" id="btn_flu_bar" class="btn" style="padding: 3px 10px; font-size: 0.72rem; font-weight: bold; border-radius: 4px; border: 1px solid #0284C7; background: white; color: #0284C7; cursor: pointer;" onclick="toggleFluChartType('bar')">📊 Bar Chart</button>
          </div>
        </div>
        <div style="height: 140px; position: relative; width: 100%;">
          <canvas id="flu2425Chart" height="140"></canvas>
        </div>
      </div>

      <!-- INTERACTIVE CATEGORY EMPLOYEE LIST CONTAINER -->
      <div id="flu2425CategoryListContainer" style="display: none; background: #F1F5F9; border: 1px solid #CBD5E1; border-radius: 8px; padding: 12px; margin-top: 14px;" class="no-print">
        <!-- Rendered dynamically by renderFlu2425CategoryList -->
      </div>
    </div>


    <!-- OVERALL DEPARTMENT COMPLIANCE & INCIDENT TREND CHARTS -->
    <div style="margin-top: 28px; margin-bottom: 24px; display: flex; flex-direction: column; gap: 24px;">
      
      <!-- FULL LANDSCAPE DIAGRAM CARD: DEPARTMENT GROUPS & IMMUNITY COMPLIANCE -->
      <div class="card" id="cardDeptChart" style="width: 100%; border-top: 4px solid #1A5F7A; box-shadow: 0 4px 14px rgba(26, 95, 122, 0.12); padding: 20px;">
        
        <!-- CARD HEADER WITH TOGGLE BUTTONS -->
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; margin-bottom: 16px; border-bottom: 2px solid #E2E8F0; flex-wrap: wrap; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 1.25rem;">📊</span>
            <div>
              <div style="font-size: 1.15rem; font-weight: 800; color: #1A5F7A;">
                ${isAr ? "\u0646\u0633\u0628\u0629 \u0645\u0646\u0627\u0639\u0629 \u0627\u0644\u0641\u0626\u0627\u062a \u0648\u0627\u0644\u0623\u0642\u0633\u0627\u0645 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0641\u064a \u0627\u0644\u062a\u0637\u0639\u064a\u0645\u0627\u062a \u0627\u0644\u0623\u0633\u0627\u0633\u064a\u0629 (100% \u0645\u0646 \u0627\u0644\u0643\u0627\u062f\u0631)" : "Hospital Department Groups Core Vaccine Immunity % (100% Staff Coverage)"}
              </div>
              <div style="font-size: 0.8rem; color: #64748B; font-weight: 600;">
                ${isAr ? "\u062a\u063a\u0637\u064a\u0629 \u0627\u0644\u0641\u0626\u0627\u062a \u0627\u0644\u06405 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629 \u0641\u064a \u0627\u0644\u062a\u0637\u0639\u064a\u0645\u0627\u062a \u0627\u0644\u0623\u0633\u0627\u0633\u064a\u0629 (IPV, Tdap, MMR, Varicella) \u0645\u0639 \u0645\u062a\u0627\u0628\u0639\u0629 \u063a\u064a\u0631 \u0627\u0644\u0645\u0644\u0642\u062d\u064a\u0646" : "Covers all 5 primary occupational categories evaluated across Core Vaccines (IPV, Tdap, MMR, Varicella)"}
              </div>
            </div>
          </div>
          
          <div class="no-print" style="display: flex; align-items: center; gap: 8px;">
            <!-- PRINT BUTTON -->
            <button type="button" class="btn btn-outline" style="padding: 6px 16px; font-size: 0.85rem; border-color: #1A5F7A; color: #1A5F7A; font-weight: 800; background: #F4F8FA; cursor: pointer; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);" onclick="printSingleCard('cardDeptChart', 'Hospital Department Groups Core Vaccine Immunity Summary')">
              🖨️ ${isAr ? 'طباعة الرسم البياني (Print Landscape)' : 'Print Full Diagram'}
            </button>
          </div>
        </div>

                <!-- SUMMARY STATISTICAL TABLE OF THE 5 DEPARTMENT GROUPS -->
        <div style="margin-bottom: 20px;">
          <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9.5pt; border: 1.5px solid #1A5F7A;">
            <thead>
              <tr style="background: #1A5F7A; color: white;">
                <th style="padding: 9px 12px; border: 1px solid #113F52; text-align: left;">Hospital Department Group (${isAr ? '\u0627\u0644\u0641\u0626\u0629 \u0627\u0644\u0648\u0638\u064a\u0641\u064a\u0629 \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a\u0629' : 'Staff Category'})</th>
                <th style="padding: 9px 12px; border: 1px solid #113F52; text-align: center;">Monitored Headcount (${isAr ? '\u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0643\u0627\u062f\u0631' : 'Headcount'})</th>
                <th style="padding: 9px 12px; border: 1px solid #113F52; text-align: center;">Immune Staff (${isAr ? '\u0627\u0644\u0643\u0627\u062f\u0631 \u0627\u0644\u0645\u062d\u0645\u064a' : 'Immune'})</th>
                <th style="padding: 9px 12px; border: 1px solid #113F52; text-align: center; background: #991B1B; color: white;">Unvaccinated Staff (${isAr ? '\u063a\u064a\u0631 \u0645\u0644\u0642\u062d\u064a\u0646 \u0623\u0633\u0627\u0633\u064a' : 'Core Unvaccinated'})</th>
                <th style="padding: 9px 12px; border: 1px solid #113F52; text-align: center;">Immunity Rate % (${isAr ? '\u0646\u0633\u0628\u0629 \u0627\u0644\u0645\u0646\u0627\u0639\u0629' : 'Immunity %'})</th>
              </tr>
            </thead>
            <tbody>
              ${metrics.deptGroupStats.map((grp, idx) => {
                const unvacCount = typeof grp.unvac !== 'undefined' ? grp.unvac : (grp.unvacList ? grp.unvacList.length : (grp.total - grp.immune));
                return `
                <tr style="background: ${idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC'}; cursor: pointer;" title="Click row to inspect all ${grp.nameEn} staff" onclick="openMOHCellStaffModal('dept_group_${grp.code}')">
                  <td style="padding: 8px 12px; border: 1px solid #CBD5E1; font-weight: bold; color: #1A5F7A;">
                    ${grp.icon} ${grp.name}
                  </td>
                  <td style="padding: 8px 12px; border: 1px solid #CBD5E1; text-align: center; font-weight: bold; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('dept_group_${grp.code}')" title="Click to view all ${grp.total} staff in this group">
                    ${grp.total} &#128269;
                  </td>
                  <td style="padding: 8px 12px; border: 1px solid #CBD5E1; text-align: center; font-weight: bold; color: #059669; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('dept_group_${grp.code}_immune')" title="Click to view ${grp.immune} immune staff in this group">
                    ${grp.immune} &#128269;
                  </td>
                  <td style="padding: 8px 12px; border: 1px solid #CBD5E1; text-align: center; font-weight: bold; color: ${unvacCount > 0 ? '#DC2626' : '#64748B'}; cursor: pointer; text-decoration: underline; background: ${unvacCount > 0 ? '#FEF2F2' : 'transparent'};" onclick="event.stopPropagation(); openMOHCellStaffModal('dept_group_${grp.code}_unvac')" title="Click to view ${unvacCount} unvaccinated / pending staff in ${grp.nameEn}">
                    ${unvacCount} &#128269;
                  </td>
                  <td style="padding: 8px 12px; border: 1px solid #CBD5E1; text-align: center; font-weight: 800; color: ${grp.pct >= 90 ? '#059669' : (grp.pct >= 75 ? '#D97706' : '#DC2626')};">
                    ${grp.pct}%
                  </td>
                </tr>
              `;}).join('')}
              <tr style="background: #EBF4F7; font-weight: 900; color: #113F52; cursor: pointer;" title="Click to inspect all hospital monitored staff" onclick="openMOHCellStaffModal('dept_group_all')">
                <td style="padding: 10px 12px; border: 1.5px solid #1A5F7A;">Total Hospital Staff Coverage (\u0625\u062c\u0645\u0627\u0644\u064a \u0643\u0627\u062f\u0631 \u0627\u0644\u0645\u0633\u062a\u0634\u0641\u0649 \u0627\u0644\u0634\u0627\u0645\u0644)</td>
                <td style="padding: 10px 12px; border: 1.5px solid #1A5F7A; text-align: center; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('dept_group_all')">${metrics.total} &#128269;</td>
                <td style="padding: 10px 12px; border: 1.5px solid #1A5F7A; text-align: center; color: #059669; cursor: pointer; text-decoration: underline;" onclick="event.stopPropagation(); openMOHCellStaffModal('dept_group_all_immune')">${metrics.deptGroupStats.reduce((a, b) => a + b.immune, 0)} &#128269;</td>
                <td style="padding: 10px 12px; border: 1.5px solid #1A5F7A; text-align: center; color: #DC2626; cursor: pointer; text-decoration: underline; background: #FEE2E2;" onclick="event.stopPropagation(); openMOHCellStaffModal('dept_group_all_unvac')" title="Click to view all ${metrics.deptGroupStats.reduce((a, b) => a + (typeof b.unvac !== 'undefined' ? b.unvac : (b.total - b.immune)), 0)} unvaccinated hospital staff">${metrics.deptGroupStats.reduce((a, b) => a + (typeof b.unvac !== 'undefined' ? b.unvac : (b.total - b.immune)), 0)} &#128269;</td>
                <td style="padding: 10px 12px; border: 1.5px solid #1A5F7A; text-align: center; color: #059669; font-size: 1.05rem; font-weight: 800;">
                  ${metrics.total > 0 ? ((metrics.deptGroupStats.reduce((a, b) => a + b.immune, 0) / metrics.total) * 100).toFixed(1) : 0}%
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- COLUMN DIAGRAM: PERCENTAGE TOTAL OF VACCINATED / TOTAL CATEGORY -->
        <div style="background: #F8FAFC; border: 1.5px solid #CBD5E1; border-radius: 8px; padding: 18px; margin-top: 20px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 8px;">
            <div style="font-weight: 800; font-size: 0.95rem; color: #1A5F7A; display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 1.2rem;">&#128202;</span>
              <span>${isAr ? "\u0627\u0644\u0631\u0633\u0645 \u0627\u0644\u0628\u064a\u0627\u0646\u064a \u0644\u0646\u0633\u0628 \u0627\u0644\u0645\u0646\u0627\u0639\u0629 \u0648\u0627\u0644\u062a\u0637\u0639\u064a\u0645 (\u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0645\u0644\u0642\u062d\u064a\u0646 \u00f7 \u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0641\u0626\u0629 %)" : "Core Vaccine Compliance Column Diagram (% Total Vaccinated / Total Category)"}</span>
            </div>
            <span style="font-size: 0.78rem; font-weight: bold; color: #059669; background: #ECFDF5; border: 1px solid #A7F3D0; padding: 3px 12px; border-radius: 12px;">
              ${isAr ? "\u0634\u0627\u0645\u0644 \u0644\u0643\u0627\u0641\u0629 \u0643\u0648\u0627\u062f\u0631 \u0627\u0644\u0645\u0633\u062a\u0634\u0641\u0649 100%" : "100% Hospital Staff Coverage"}
            </span>
          </div>
          <div style="position: relative; width: 100%; height: 320px;">
            <canvas id="deptChart" height="320"></canvas>
          </div>
        </div>
      </div>

      <!-- FULL LANDSCAPE DIAGRAM CARD: INCIDENT REPORTS TREND -->
      <div class="card" id="cardIncidentChart" style="width: 100%; border-top: 4px solid #DC2626; box-shadow: 0 4px 14px rgba(220, 38, 38, 0.12); padding: 20px;">
        <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; margin-bottom: 16px; border-bottom: 2px solid #E2E8F0;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 1.25rem;">📈</span>
            <div>
              <div style="font-size: 1.15rem; font-weight: 800; color: #991B1B;">
                ${isAr ? 'توزيع حوادث الإصابات والتعرضات حسب أشهر السنة (2026)' : 'Incident Reports Trend by Month (2026 - Monthly Surveillance)'}
              </div>
              <div style="font-size: 0.8rem; color: #64748B; font-weight: 600;">
                ${isAr ? 'مراقبة وتتبع بلاغات الوخز بالإبر وتلوث الدم شهرياً مع إمكانية الطباعة' : 'Monthly occupational exposure & sharps injuries trend analysis with landscape print'}
              </div>
            </div>
          </div>
          <button type="button" class="btn btn-outline no-print" style="padding: 6px 16px; font-size: 0.85rem; border-color: #DC2626; color: #DC2626; font-weight: 800; background: #FEF2F2; cursor: pointer; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05);" onclick="printSingleCard('cardIncidentChart', 'Monthly Incident Reports Surveillance Summary & Run Chart')">
            &#128424;&#65039; ${isAr ? "\u0637\u0628\u0627\u0639\u0629 \u062a\u0642\u0631\u064a\u0631 \u0627\u0644\u0625\u0635\u0627\u0628\u0627\u062a" : "Print Incident Summary"}
          </button>
        </div>
        <!-- MONTHLY SURVEILLANCE DATA TABLE (NO GRAPH) -->
        <div class="table-responsive" style="overflow-x: auto; margin-top: 8px;">
          <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9.5pt; border: 1.5px solid #DC2626; text-align: center;">
            <thead>
              <tr style="background: #DC2626; color: white;">
                <th style="padding: 10px 14px; border: 1px solid #B91C1C; text-align: left;">Incident Surveillance Indicator (${isAr ? "\u0627\u0644\u0645\u0624\u0634\u0631 \u0627\u0644\u0634\u0647\u0631\u064a \u0644\u0644\u0625\u0635\u0627\u0628\u0627\u062a" : "Monthly Surveillance"})</th>
                ${metrics.monthlyIncidents.labels.map(m => `<th style="padding: 10px 8px; border: 1px solid #B91C1C; text-align: center;">${m}</th>`).join('')}
                <th style="padding: 10px 12px; border: 1px solid #B91C1C; text-align: center; background: #991B1B;">Total (2026)</th>
              </tr>
            </thead>
            <tbody>
              <tr style="background: #FFFFFF;">
                <td style="padding: 10px 14px; font-weight: bold; color: #991B1B; text-align: left; border: 1px solid #E2E8F0;">
                  &#9888;&#65039; ${isAr ? "\u0628\u0644\u0627\u063a\u0627\u062a \u0648\u062e\u0632 \u0627\u0644\u0625\u0628\u0631 \u0648\u062a\u0644\u0648\u062b \u0627\u0644\u062f\u0645 \u0627\u0644\u062d\u0627\u062f\u0629" : "Sharps & Blood Exposure Incidents"}
                </td>
                ${(metrics.monthlyIncidents.counts || metrics.monthlyIncidents.data || []).map(cnt => `
                  <td style="padding: 10px 8px; border: 1px solid #E2E8F0; font-weight: bold; color: ${cnt > 0 ? "#DC2626" : "#64748B"}; background: ${cnt > 0 ? "#FEF2F2" : "transparent"}; font-size: ${cnt > 0 ? "1.05rem" : "0.95rem"};">
                    ${cnt}
                  </td>
                `).join('')}
                <td style="padding: 10px 12px; border: 1px solid #E2E8F0; font-weight: 900; font-size: 1.15rem; color: #991B1B; background: #FEE2E2;">
                  ${(metrics.monthlyIncidents.counts || metrics.monthlyIncidents.data || []).reduce((a, b) => a + b, 0)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- RUN CHART: MONTHLY INCIDENT REPORTS (SURVEILLANCE TIME-SERIES) -->
        <div style="background: #FFF5F5; border: 1.5px solid #FECACA; border-radius: 8px; padding: 18px; margin-top: 20px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 8px;">
            <div style="font-weight: 800; font-size: 0.95rem; color: #991B1B; display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 1.2rem;">&#128200;</span>
              <span>${isAr ? "\u0645\u062e\u0637\u0637 \u0627\u0644\u062a\u0633\u0644\u0633\u0644 \u0627\u0644\u0632\u0645\u0646\u064a (Run Chart) \u0644\u0628\u0644\u0627\u063a\u0627\u062a \u0627\u0644\u0625\u0635\u0627\u0628\u0627\u062a \u0627\u0644\u0634\u0647\u0631\u064a\u0629 (2026)" : "Occupational Incident Reports Monthly Run Chart (2026 Surveillance Time-Series)"}</span>
            </div>
            <span style="font-size: 0.78rem; font-weight: bold; color: #991B1B; background: #FEE2E2; border: 1px solid #FCA5A5; padding: 3px 12px; border-radius: 12px;">
              ${isAr ? "\u0645\u062e\u0637\u0637 \u0627\u0644\u062a\u062d\u0644\u064a\u0644 \u0627\u0644\u0634\u0647\u0631\u064a (Monthly QI Run Chart)" : "Monthly QI Surveillance Run Chart"}
            </span>
          </div>
          <div style="position: relative; width: 100%; height: 260px;">
            <canvas id="incidentChart" height="260"></canvas>
          </div>
        </div>
      </div>
    </div>
  `;

  setTimeout(() => {
    initDynamicDashboardCharts(topDepts, metrics);
  }, 100);
}

function getHAIRecordTimestamp(record) {
  if (!record) return 0;

  const raw =
    record.updatedAt ||
    record.lastUpdated ||
    record.updatedDate ||
    record.modifiedAt ||
    record.savedAt ||
    record.eventDate ||
    record.createdAt;

  if (!raw) return 0;

  if (typeof raw === 'number') return raw;

  const str = String(raw).trim();

  const dmy = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (dmy) {
    return new Date(
      Number(dmy[3]),
      Number(dmy[2]) - 1,
      Number(dmy[1])
    ).getTime();
  }

  const parsed = new Date(str).getTime();
  return Number.isNaN(parsed) ? 0 : parsed;
}
window.getHAIRecordTimestamp = getHAIRecordTimestamp;

function getHAIDashboardCardHTML(isAr) {
  const haiVault = (typeof getIPCHAIVault === 'function' ? getIPCHAIVault() : []) || [];
  const survVault = (typeof getIPCSurveillanceVault === 'function' ? getIPCSurveillanceVault() : []) || [];
  const combinedVault = [...haiVault, ...survVault].filter((r, idx, self) => {
    if (!r) return false;
    const key = r.id || r.haiCaseNo || (r.patientCode ? (r.patientCode + '_' + (r.eventDate || '') + '_' + (r.folder || r.haiType || '')) : null) || idx;
    return self.findIndex(x => {
      if (!x) return false;
      const xKey = x.id || x.haiCaseNo || (x.patientCode ? (x.patientCode + '_' + (x.eventDate || '') + '_' + (x.folder || x.haiType || '')) : null) || -1;
      return key === xKey;
    }) === idx;
  });

  const activeCases = combinedVault.filter(r => r && r.status !== 'Closed');
  const cautiCount = combinedVault.filter(r => r && (r.haiType === 'CAUTI' || r.haiType === 'UTI' || r.folder === 'Adult UTI' || r.folder === 'Pediatric UTI' || r.folder === 'SACD UTI' || r.folder === 'LTC UTI' || r.folder === 'CAUTI')).length;
  const clabsiCount = combinedVault.filter(r => r && (r.haiType === 'CLABSI' || r.haiType === 'BSI' || r.folder === 'BSI' || r.folder === 'CLABSI' || r.folder === 'Primary BSI / CLABSI')).length;
  const vaeCount = combinedVault.filter(r => r && (r.haiType === 'VAE' || r.haiType === 'VAP' || r.folder === 'Adult VAE' || r.folder === 'P VAE' || r.folder === 'VAE' || r.folder === 'Pediatric VAE')).length;
  const ssiCount = combinedVault.filter(r => r && (r.haiType === 'SSI' || r.folder === 'SSI')).length;
  const mdroCount = combinedVault.filter(r => r && (r.haiType === 'MDRO' || r.folder === 'MDRO' || (String(r.organism || '').includes('diff') || String(r.organism || '').includes('CRE') || String(r.organism || '').includes('CRAB') || String(r.organism || '').includes('MRSA')))).length;

  const recentForms = [...combinedVault]
    .sort((a, b) => getHAIRecordTimestamp(b) - getHAIRecordTimestamp(a))
    .slice(0, 6);

  return `
    <!-- FULL LANDSCAPE CARD: HAI FOLLOW-UP & SURVEILLANCE LAST UPDATED FORMS -->
    <div class="card" id="cardHAIDashboardSummary" style="width: 100%; border-top: 4px solid #DC2626; box-shadow: 0 4px 14px rgba(220, 38, 38, 0.12); padding: 20px; margin-top: 24px;">
      
      <div class="card-title" style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; margin-bottom: 16px; border-bottom: 2px solid #E2E8F0; flex-wrap: wrap; gap: 12px;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span style="font-size: 1.4rem;">🩸</span>
          <div>
            <div style="font-size: 1.15rem; font-weight: 800; color: #991B1B;">
              ${isAr ? '2. نموذج وسجل متابعة عدوى المستشفيات (HAI Follow-Up & Clinical Surveillance)' : 'Healthcare-Associated Infection (HAI) & Clinical Surveillance Summary'}
            </div>
            <div style="font-size: 0.8rem; color: #64748B; font-weight: 600;">
              Doc Ref: <strong style="color: #991B1B;">AVH-IPC-FM-2026-02</strong> | ${isAr ? 'آخر النماذج المحدثة وسجل المتابعة الميدانية' : 'Last updated clinical forms & recent surveillance submissions'}
            </div>
          </div>
        </div>

        <div class="no-print" style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
          <button type="button" class="btn btn-primary" style="padding: 7px 14px; font-weight: 800; background: #DC2626; border-color: #DC2626; font-size: 0.85rem;" onclick="switchNav('ipc-hai-followup'); setTimeout(() => { if (typeof openHAIFormModal === 'function') openHAIFormModal(-1); }, 150);">
            ➕ ${isAr ? 'تسجيل حالة عدوى جديدة (HAI Form)' : 'Add New HAI Form'}
          </button>
          <button type="button" class="btn btn-outline" style="padding: 7px 14px; font-weight: 800; border-color: #0F766E; color: #0F766E; font-size: 0.85rem;" onclick="switchNav('ipc-hai-followup')">
            🚀 ${isAr ? 'عرض كافة النماذج والأرشيف الكامل' : 'Open Full HAI Vault'} ➔
          </button>
        </div>
      </div>

      <!-- KPI METRICS SUMMARY GRID -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; margin-bottom: 16px;">
        <div style="background: #FEF2F2; border-left: 4px solid #DC2626; padding: 10px 12px; border-radius: 6px;">
          <div style="font-size: 0.72rem; font-weight: bold; color: #991B1B; text-transform: uppercase;">Active HAIs</div>
          <div style="font-size: 1.4rem; font-weight: 800; color: #991B1B;">${activeCases.length}</div>
        </div>
        <div style="background: #F0F9FF; border-left: 4px solid #0284C7; padding: 10px 12px; border-radius: 6px;">
          <div style="font-size: 0.72rem; font-weight: bold; color: #0369A1; text-transform: uppercase;">CAUTI</div>
          <div style="font-size: 1.4rem; font-weight: 800; color: #0284C7;">${cautiCount}</div>
        </div>
        <div style="background: #F3E8FF; border-left: 4px solid #8B5CF6; padding: 10px 12px; border-radius: 6px;">
          <div style="font-size: 0.72rem; font-weight: bold; color: #6D28D9; text-transform: uppercase;">CLABSI</div>
          <div style="font-size: 1.4rem; font-weight: 800; color: #8B5CF6;">${clabsiCount}</div>
        </div>
        <div style="background: #FFF7ED; border-left: 4px solid #EA580C; padding: 10px 12px; border-radius: 6px;">
          <div style="font-size: 0.72rem; font-weight: bold; color: #C2410C; text-transform: uppercase;">VAE / VAP</div>
          <div style="font-size: 1.4rem; font-weight: 800; color: #EA580C;">${vaeCount}</div>
        </div>
        <div style="background: #ECFDF5; border-left: 4px solid #059669; padding: 10px 12px; border-radius: 6px;">
          <div style="font-size: 0.72rem; font-weight: bold; color: #047857; text-transform: uppercase;">SSI</div>
          <div style="font-size: 1.4rem; font-weight: 800; color: #059669;">${ssiCount}</div>
        </div>
        <div style="background: #FEF2F2; border-left: 4px solid #991B1B; padding: 10px 12px; border-radius: 6px;">
          <div style="font-size: 0.72rem; font-weight: bold; color: #991B1B; text-transform: uppercase;">MDRO / C. diff</div>
          <div style="font-size: 1.4rem; font-weight: 800; color: #991B1B;">${mdroCount}</div>
        </div>
      </div>

      <!-- LAST UPDATED HAI FORMS RECENT SUBMISSIONS TABLE -->
      <div style="overflow-x: auto;">
        <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 0.86rem; border: 1px solid #CBD5E1;">
          <thead>
            <tr style="background: #991B1B; color: white;">
              <th style="padding: 7px 10px;">${isAr ? 'فئة العدوى' : 'HAI Category'}</th>
              <th style="padding: 7px 10px;">${isAr ? 'كود المريض' : 'Patient Code'}</th>
              <th style="padding: 7px 10px;">${isAr ? 'اسم المريض' : 'Patient Name'}</th>
              <th style="padding: 7px 10px;">${isAr ? 'القسم والغرفة' : 'Unit & Room'}</th>
              <th style="padding: 7px 10px;">${isAr ? 'تاريخ العدوى' : 'Event Date'}</th>
              <th style="padding: 7px 10px;">${isAr ? 'المسبب الميكروبي' : 'Organism'}</th>
              <th style="padding: 7px 10px;">${isAr ? 'الحالة' : 'Status'}</th>
            </tr>
          </thead>
          <tbody>
            ${recentForms.length === 0 ? `
              <tr>
                <td colspan="7" style="text-align: center; padding: 18px; color: #64748B;">
                  📋 ${isAr ? 'لا توجد نماذج متابعة عدوى مسجلة مؤخراً.' : 'No recent HAI follow-up form submissions found.'}
                </td>
              </tr>
            ` : recentForms.map(r => `
              <tr style="cursor: pointer;" onclick="switchNav('ipc-hai-followup')">
                <td style="padding: 6px 10px;">
                  <span style="background: #991B1B; color: white; padding: 2px 7px; border-radius: 10px; font-weight: bold; font-size: 0.76rem;">${r.haiType || r.folder || 'HAI'}</span>
                  ${r.infectionType ? `<div style="font-size: 0.72rem; font-weight: 800; color: #0F766E; margin-top: 3px;">⚙️ ${r.infectionType}</div>` : ''}
                  <div style="font-size: 0.72rem; font-weight: 800; color: ${(r.haiPoa && (r.haiPoa.includes('POA') || r.haiPoa.includes('Present on Admission'))) || r.infectionType === 'Present on Admission (POA)' || r.infectionType === 'POA' ? '#D97706' : '#059669'}; margin-top: 2px;">🏥 ${r.haiPoa || (r.infectionType === 'Present on Admission (POA)' || r.infectionType === 'POA' ? 'Present on Admission (POA)' : 'Healthcare-Associated Infection (HAI)')}</div>
                </td>
                <td style="padding: 6px 10px; font-family: monospace; font-weight: bold; color: #0284C7;">${r.patientCode || r.patientId || '-'}</td>
                <td style="padding: 6px 10px; font-weight: bold;">${r.patientName || '-'}</td>
                <td style="padding: 6px 10px;">${r.unit || '-'} ${r.roomBed ? '(' + r.roomBed + ')' : ''}</td>
                <td style="padding: 6px 10px; font-weight: bold;">${r.eventDate || r.updatedDate || '-'}</td>
                <td style="padding: 6px 10px; color: #991B1B; font-weight: bold;">${r.organism || '-'}</td>
                <td style="padding: 6px 10px;"><span style="background: #FEF08A; color: #854D0E; font-weight: bold; padding: 2px 6px; border-radius: 4px; font-size: 0.76rem;">${r.status || 'Active'}</span></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

    </div>
  `;
}
window.getHAIDashboardCardHTML = getHAIDashboardCardHTML;

// --------------------------------------------------------------------------
// 🇵🇸 2. MINISTRY OF HEALTH (MOH) STATUTORY OFFICIAL REPORT VIEW
// --------------------------------------------------------------------------
function renderMOHReportView(container, toolbarHTML, employees, injuryReports, metrics, isAr) {
  // Exclude Gaza Project Staff & Archived/Former Staff from all MOH Report calculations (100% aligned with Executive Dashboard)
  const nonGazaEmployees = employees.filter(e => {
    if (typeof isArchivedStaff === 'function' && isArchivedStaff(e)) return false;
    if (typeof isActiveStaff === 'function' && !isActiveStaff(e)) return false;
    if (typeof isGazaStaff === 'function') return !isGazaStaff(e);
    const dept = String(e.department || (e.demographic ? e.demographic.department : '') || '').toLowerCase();
    const org = String(e.organization || (e.demographic ? e.demographic.organization : '') || '').toLowerCase();
    return !dept.includes('gaza') && !org.includes('gaza');
  });

  const totalHCW = nonGazaEmployees.length || metrics.total;

  // 1. Categorize non-Gaza staff into Minimum, Basic, Expanded programs (100% aligned with Executive Dashboard metrics)
  const minList = nonGazaEmployees.filter(e => {
    const demo = e.demographic || {};
    const grp = String(e.staffGroup || demo.staffGroup || '').toLowerCase();
    return grp.includes('minimum');
  });

  const expList = nonGazaEmployees.filter(e => {
    const demo = e.demographic || {};
    const grp = String(e.staffGroup || demo.staffGroup || '').toLowerCase();
    return grp.includes('extended') || grp.includes('expanded');
  });

  const minSet = new Set(minList);
  const expSet = new Set(expList);
  const basicList = nonGazaEmployees.filter(e => !minSet.has(e) && !expSet.has(e));

  // Special population groups (excluding Gaza by default)
  const invasiveList = nonGazaEmployees.filter(e => typeof isInvasiveProcedureStaff === 'function' ? isInvasiveProcedureStaff(e) : true);
  const babiesList = nonGazaEmployees.filter(e => {
    const demo = e.demographic || {};
    const dt = String(demo.deptTreating || e.deptTreating || '').trim().toLowerCase();
    return dt === 'babies under 1 years';
  });
  const immunoList = nonGazaEmployees.filter(e => {
    const demo = e.demographic || {};
    const dt = String(demo.deptTreating || e.deptTreating || '').trim().toLowerCase();
    return dt === 'employees in oncology, hematooncology' || (typeof isOncologyStaff === 'function' && isOncologyStaff(e));
  });

  const minCount = minList.length;
  const basicCount = basicList.length;
  const expCount = expList.length;

  const isDefaultHospitalMOH = false;
  const invasiveCount = invasiveList.length;
  const babiesCount = babiesList.length;
  const immunoCount = immunoList.length;

  // Vaccine immunity & status checking helpers
  function getVacStatus(valStr) {
    const s = String(valStr || '').trim().toLowerCase();
    if (!s || s === 'none' || s === 'n/a' || s === 'neg' || s === 'no' || s === 'unvaccinated' || s === '0' || s === 'false') return 'unvac';
    if (s.includes('refus')) return 'refused';
    if (s.includes('contra') || s.includes('defer') || s.includes('exemp')) return 'contra';
    return 'vac';
  }

  function getTdapVal(e) {
    const vac = e.vaccines || {};
    return vac.tdapDate || (vac.Tdap ? (vac.Tdap.d5 || vac.Tdap.d1) : '') || vac.tdap || vac.tdapDose1 || '';
  }

  function getIpvVal(e) {
    const vac = e.vaccines || {};
    return vac.ipvDate || (vac.IPV ? (vac.IPV.d5 || vac.IPV.d1) : '') || vac.ipv || vac.ipvDose1 || '';
  }

  function getVacStatsForVal(group, getValFn) {
    let vac = 0, ref = 0, contra = 0, unvac = 0;
    group.forEach(e => {
      const val = getValFn(e);
      const st = getVacStatus(val);
      if (st === 'vac') vac++;
      else if (st === 'refused') ref++;
      else if (st === 'contra') contra++;
      else unvac++;
    });
    return { vac, ref, contra, unvac, total: group.length };
  }

  function getMMRStats(group) {
    let vac = 0, ref = 0, contra = 0, unvac = 0;
    group.forEach(e => {
      const v = e.vaccines || {};
      const lab = e.labResults || {};
      const m1 = String(v.mmrDose1 || (v.MMR ? v.MMR.d1 : '') || '').trim();
      const m2 = String(v.mmrDose2 || (v.MMR ? v.MMR.d2 : '') || '').trim();
      const igg = String(lab.mmrIgG || v.mmrIgG || '').toLowerCase();
      const dob = String(e.dob || (e.demographic ? e.demographic.dob : '') || '');
      const isBornBefore1957 = dob.includes('195') || dob.includes('194') || dob.includes('193');
      const combined = `${m1} ${m2} ${igg}`.toLowerCase();

      if (combined.includes('refus')) ref++;
      else if (combined.includes('contra') || combined.includes('defer') || combined.includes('exemp')) contra++;
      else if (isBornBefore1957 || (m1 && m2 && m2 !== 'n/a' && m2 !== 'none') || m1 || igg.includes('pos') || igg.includes('react') || igg.includes('immune')) vac++;
      else unvac++;
    });
    return { vac, ref, contra, unvac, total: group.length };
  }

  function getVZVStats(group) {
    let vac = 0, ref = 0, contra = 0, unvac = 0;
    group.forEach(e => {
      const v = e.vaccines || {};
      const lab = e.labResults || {};
      const cp = String(v.chickenpoxStatus || v.chickenpox || '').toLowerCase();
      const d1 = String(v.chickenpoxDose1 || '').trim();
      const d2 = String(v.chickenpoxDose2 || '').trim();
      const igg = String(lab.varicellaIgG || v.varicellaIgG || '').toLowerCase();
      const combined = `${cp} ${d1} ${d2} ${igg}`.toLowerCase();

      if (combined.includes('refus')) ref++;
      else if (combined.includes('contra') || combined.includes('defer') || combined.includes('exemp')) contra++;
      else if (cp.includes('2 dose') || cp.includes('natural') || cp.includes('history') || cp.includes('positive') || d1 || d2 || igg.includes('pos') || igg.includes('react') || igg.includes('immune')) vac++;
      else unvac++;
    });
    return { vac, ref, contra, unvac, total: group.length };
  }

  function isHBVProtected(e) {
    const lab = e.labResults || {};
    let titer = '';
    if (lab.hbsabResult !== undefined && lab.hbsabResult !== null) titer = toSafeLabString(lab.hbsabResult);
    else if (e.hepbTiter !== undefined && e.hepbTiter !== null) titer = toSafeLabString(e.hepbTiter);
    titer = titer.toLowerCase().trim();
    const immStatus = String(e.immunityStatus || '').toLowerCase();
    const numMatch = titer.match(/([<>])?\s*([0-9]+(?:\.[0-9]+)?)/);
    const hasLessThan = titer.includes('<');
    const parsed = numMatch ? parseFloat(numMatch[2]) : null;
    if (hasLessThan || (parsed !== null && parsed < 10)) return false;
    return titer.includes('immune') || titer.includes('>') || titer.includes('pos') || titer.includes('no need') || titer.includes('moh') || titer.includes('routine') || titer.includes('decl') || titer.includes('waiv') || titer.includes('exemp') || immStatus.includes('immune') || (parsed !== null && parsed >= 10);
  }

  function getPPDStats(group) {
    let neg = 0, pos = 0, ref = 0, contra = 0, unvac = 0;
    group.forEach(e => {
      const lab = e.labResults || {};
      const res1 = String(lab.ppdStep1Result || e.ppdStep1Result || '').toLowerCase();
      const res2 = String(lab.ppdStep2Result || e.ppdStep2Result || '').toLowerCase();
      const resGen = String(lab.ppdResult || e.ppdResult || lab.PPD || e.PPD || '').toLowerCase();
      const combined = `${res1} ${res2} ${resGen}`;
      if (res1.includes('pos') || res2.includes('pos') || resGen.includes('pos') || combined.includes('react')) pos++;
      else if (res1.includes('neg') || res2.includes('neg') || resGen.includes('neg') || combined.includes('non')) neg++;
      else if (combined.includes('refus')) ref++;
      else if (combined.includes('contra')) contra++;
      else unvac++;
    });
    return { neg, pos, ref, contra, unvac, total: group.length };
  }

  const tdapStats = {
    min: getVacStatsForVal(minList, getTdapVal),
    basic: getVacStatsForVal(basicList, getTdapVal),
    exp: getVacStatsForVal(expList, getTdapVal),
    babies: getVacStatsForVal(babiesList, getTdapVal)
  };

  const mmrStats = {
    min: getMMRStats(minList),
    basic: getMMRStats(basicList),
    exp: getMMRStats(expList),
    highRisk: getMMRStats([...new Set([...babiesList, ...immunoList])])
  };
  const vzvStats = {
    min: getVZVStats(minList),
    basic: getVZVStats(basicList),
    exp: getVZVStats(expList),
    highRisk: getVZVStats([...new Set([...babiesList, ...immunoList])])
  };

  const polioStats = {
    min: getVacStatsForVal(minList, getIpvVal),
    basic: getVacStatsForVal(basicList, getIpvVal),
    exp: getVacStatsForVal(expList, getIpvVal)
  };

  const expInvasive = expList.filter(e => typeof isInvasiveProcedureStaff === 'function' ? isInvasiveProcedureStaff(e) : false);
  const expNoInvasive = expList.filter(e => !expInvasive.includes(e));

  function getHBVCategoryStats(group) {
    let vac = 0, ref = 0, contra = 0, unvac = 0, carrier = 0, nonResp = 0;
    group.forEach(e => {
      const v = e.vaccines || {};
      const lab = e.labResults || {};
      const hb = toSafeLabString(getFirstDefinedLabValue(v.hepbDose3, v.hepbDose2, v.hepbDose1, lab.hbsabResult)).toLowerCase();
      const carrierStr = String(lab.hbsagResult || lab.antiHbcResult || '').toLowerCase();
      if (carrierStr.includes('pos') || carrierStr.includes('react') || carrierStr.includes('carrier')) carrier++;
      if (hb.includes('non-resp') || hb.includes('non responder')) nonResp++;
      if (hb.includes('refus')) ref++;
      else if (hb.includes('contra') || hb.includes('defer') || hb.includes('exemp')) contra++;
      else if (isHBVProtected(e) || hb.includes('3 dose') || hb.includes('complete') || hb.includes('pos') || hb.includes('react') || hb.includes('immune')) vac++;
      else unvac++;
    });
    return { vac, immune: vac, nonResp, carrier, ref, contra, unvac, total: group.length };
  }

  const hbvBasic = getHBVCategoryStats(basicList);
  const hbvExpNoInvasive = getHBVCategoryStats(expNoInvasive);
  const hbvExpInvasive = getHBVCategoryStats(expInvasive);

  const unimmudCount = hbvExpInvasive.nonResp + hbvExpInvasive.contra + hbvExpInvasive.unvac;
  const unimmudTestedCount = Math.max(0, unimmudCount - hbvExpInvasive.unvac);
  const hcvSerologyCount = nonGazaEmployees.filter(e => {
    const lab = e.labResults || {};
    const hcv = String(lab.hcvResult || lab.HCV || '').toLowerCase();
    return hcv.includes('neg') || hcv.includes('pos') || hcv.includes('non');
  }).length || expInvasive.length;

  const ppdStats = {
    basic: getPPDStats(basicList),
    exp: getPPDStats(expList)
  };

  function getPPDNegList(group) {
    return group.filter(e => {
      const lab = e.labResults || {};
      const res1 = String(lab.ppdStep1Result || e.ppdStep1Result || '').toLowerCase();
      const res2 = String(lab.ppdStep2Result || e.ppdStep2Result || '').toLowerCase();
      const resGen = String(lab.ppdResult || e.ppdResult || lab.PPD || e.PPD || '').toLowerCase();
      const isPos = res1.includes('pos') || res2.includes('pos') || resGen.includes('pos') || res1.includes('react') || res2.includes('react');
      return !isPos && (res1.includes('neg') || res2.includes('neg') || resGen.includes('neg') || res1.includes('non') || res2.includes('non'));
    });
  }

  window.mohEditMode = window.mohEditMode || false;
  window.mohCellStaffStore = window.mohCellStaffStore || {};

  window.toggleMOHMode = function(isEdit) {
    window.mohEditMode = isEdit;
    if (typeof renderDashboardOverview === 'function') renderDashboardOverview();
  };

  function renderEditableMOHCell(key, defaultValue, extraStyle = '', staffList = null, titleName = '') {
    const overrides = JSON.parse(localStorage.getItem('avh_moh_overrides') || '{}');
    const val = (overrides[key] !== undefined) ? overrides[key] : defaultValue;

    if (staffList) {
      window.mohCellStaffStore[key] = {
        title: titleName || key,
        list: staffList
      };
    }

    const isEdit = window.mohEditMode === true;

    if (isEdit) {
      return `
        <input type="text" 
               id="moh_override_${key}" 
               value="${val}" 
               onchange="updateMOHOverride('${key}', this.value)" 
               oninput="updateMOHOverride('${key}', this.value)" 
               style="width: 100%; text-align: center; font-weight: bold; border: 1.5px solid #0284C7; border-radius: 4px; padding: 3px 4px; background: #FFFBEB; font-family: inherit; font-size: inherit; color: #0F172A; ${extraStyle}" 
               class="moh-editable-input">
      `;
    } else {
      const hasList = staffList && staffList.length > 0;
      const clickable = hasList ? `cursor: pointer; text-decoration: underline; text-decoration-color: #0284C7;` : '';
      const clickAttr = hasList ? `onclick="openMOHCellStaffModal('${key}')" title="Click to inspect ${staffList.length} matching staff members"` : '';

      return `
        <span id="moh_override_${key}_view" 
              class="moh-cell-view ${hasList ? 'moh-cell-drillable' : ''}" 
              ${clickAttr}
              style="display: inline-block; width: 100%; padding: 4px 6px; font-weight: bold; color: #0F172A; text-align: center; border-radius: 4px; transition: all 0.15s ease; ${clickable} ${extraStyle}">
          ${val} ${hasList ? `<span class="no-print" style="font-size: 0.7rem; color: #0284C7; font-weight: normal; margin-left: 2px;">🔍</span>` : ''}
        </span>
        <input type="hidden" id="moh_override_${key}" value="${val}" class="moh-editable-input">
      `;
    }
  }

  window.openMOHCellStaffModal = function(key) {
    const store = window.mohCellStaffStore[key];
    if (!store || !store.list || store.list.length === 0) {
      alert('No specific employee records linked to this summary count.');
      return;
    }

    const modalId = 'mohCellStaffModalContainer';
    let container = document.getElementById(modalId);
    if (!container) {
      container = document.createElement('div');
      container.id = modalId;
      document.body.appendChild(container);
    }

    window.mohCellStaffModalQuery = '';

    const renderModalContent = () => {
      const q = (window.mohCellStaffModalQuery || '').toLowerCase().trim();
      const filtered = store.list.filter(e => {
        const demo = e.demographic || {};
        const name = String(e.name || demo.fullName || '').toLowerCase();
        const id = String(e.empNo || demo.personNo || e.idNo || '').toLowerCase();
        const dept = String(demo.orgName || e.organizationName || demo.organizationName || e.orgName || e.department || demo.department || demo.deptTreating || '').toLowerCase();
        const title = String(e.jobTitle || demo.positionName || demo.jobTitle || e.staffGroup || '').toLowerCase();
        return name.includes(q) || id.includes(q) || dept.includes(q) || title.includes(q);
      });

      let tbodyContent = '';
      if (filtered.length === 0) {
        tbodyContent = `<tr><td colspan="6" style="padding: 24px; text-align: center; color: #64748B; font-weight: bold;">No staff records match your search filter.</td></tr>`;
      } else {
        tbodyContent = filtered.map((emp, i) => {
          const demo = emp.demographic || {};
          const pNo = emp.empNo || demo.personNo || emp.idNo || demo.idNo || '';
          return `
            <tr style="background: ${i % 2 === 0 ? '#FFFFFF' : '#F8FAFC'};">
              <td style="padding: 7px 8px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${i + 1}</td>
              <td style="padding: 7px 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #0F172A;">${emp.name || demo.fullName || 'Unnamed Staff'}</td>
              <td style="padding: 7px 8px; border: 1px solid #E2E8F0; text-align: center; font-family: monospace; font-weight: bold; color: #0284C7;">${pNo}</td>
              <td style="padding: 7px 8px; border: 1px solid #E2E8F0; color: #475569;">${demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || demo.deptTreating || 'Augusta Victoria Hospital'}</td>
              <td style="padding: 7px 8px; border: 1px solid #E2E8F0; color: #475569;">${emp.jobTitle || demo.positionName || demo.jobTitle || emp.staffGroup || 'Staff'}</td>
              <td style="padding: 7px 8px; border: 1px solid #E2E8F0; text-align: center;">
                <button class="btn btn-primary" style="padding: 4px 10px; font-size: 0.75rem; background: #0284C7; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;" onclick="document.getElementById('${modalId}').innerHTML=''; openQuickUpdateModal('${pNo}')">⚡ Edit Record</button>
              </td>
            </tr>
          `;
        }).join('');
      }

      const existingTbody = document.getElementById('mohModalTbody');
      const existingCounter = document.getElementById('mohModalCounter');
      if (existingTbody && existingCounter) {
        existingTbody.innerHTML = tbodyContent;
        existingCounter.textContent = `Showing ${filtered.length} of ${store.list.length}`;
        return;
      }

      container.innerHTML = `
        <div style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px); z-index: 99999; display: flex; align-items: center; justify-content: center; padding: 20px;">
          <div style="background: white; width: 100%; max-width: 920px; max-height: 88vh; border-radius: 12px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); display: flex; flex-direction: column; overflow: hidden; border: 1px solid #CBD5E1;">
            
            <div style="background: linear-gradient(135deg, #1E3A8A 0%, #0369A1 100%); color: white; padding: 16px 22px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px;">
                  <span>📋 MOH Audit Drilldown</span>
                  <span style="background: #0284C7; font-size: 0.8rem; padding: 2px 8px; border-radius: 12px; font-weight: normal;">${store.list.length} Staff</span>
                </div>
                <div style="font-size: 0.88rem; color: #BAE6FD; margin-top: 3px; font-weight: bold;">
                  ${store.title}
                </div>
              </div>
              <button onclick="document.getElementById('${modalId}').innerHTML=''" style="background: rgba(255,255,255,0.2); border: none; color: white; font-size: 1.2rem; cursor: pointer; padding: 4px 12px; border-radius: 6px; font-weight: bold;">✕</button>
            </div>

            <div style="padding: 12px 22px; background: #F8FAFC; border-bottom: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap;">
              <input type="text" 
                     id="mohModalSearchInput"
                     placeholder="🔍 Search staff by name, ID, or department..." 
                     value="${window.mohCellStaffModalQuery || ''}" 
                     onkeyup="window.mohCellStaffModalQuery = this.value; window.renderMOHCellStaffModalContent();" 
                     style="flex: 1; min-width: 250px; padding: 8px 14px; border: 1.5px solid #CBD5E1; border-radius: 6px; font-size: 0.88rem; outline: none;">
              
              <div style="display: flex; gap: 8px; align-items: center;">
                <span id="mohModalCounter" style="font-size: 0.85rem; font-weight: bold; color: #475569;">Showing ${filtered.length} of ${store.list.length}</span>
                <button class="btn btn-outline" style="padding: 5px 12px; font-size: 0.8rem; background: white;" onclick="window.printMOHCellStaffModalList('${key}')">🖨️ Print List</button>
              </div>
            </div>

            <div style="flex: 1; overflow-y: auto; padding: 16px 22px;">
              <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 8.5pt;">
                <thead>
                  <tr style="background: #F1F5F9; color: #334155; position: sticky; top: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                    <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: center; width: 40px;">#</th>
                    <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: left;">Staff Full Name</th>
                    <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: center;">Person # / ID</th>
                    <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: left;">Organization Name</th>
                    <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: left;">Job Title / Sector</th>
                    <th style="padding: 8px; border: 1px solid #CBD5E1; text-align: center; width: 100px;">Action</th>
                  </tr>
                </thead>
                <tbody id="mohModalTbody">
                  ${tbodyContent}
                </tbody>
              </table>
            </div>

            <div style="background: #F8FAFC; border-top: 1px solid #E2E8F0; padding: 12px 22px; display: flex; justify-content: flex-end;">
              <button onclick="document.getElementById('${modalId}').innerHTML=''" style="padding: 7px 18px; font-size: 0.85rem; font-weight: bold; background: #475569; color: white; border: none; border-radius: 6px; cursor: pointer;">Close</button>
            </div>
          </div>
        </div>
      `;
    };

    window.renderMOHCellStaffModalContent = renderModalContent;
    renderModalContent();
  };

  window.printMOHCellStaffModalList = function(key) {
    const store = window.mohCellStaffStore[key];
    if (!store || !store.list) return;

    const printWin = window.open('', '_blank', 'width=900,height=700');
    if (!printWin) {
      alert('Pop-up window was blocked by your browser. Please allow pop-ups for this site to print lists.');
      return;
    }
    printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>MOH Audit Sub-List — ${store.title}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; color: #1E293B; }
            h3 { color: #1E3A8A; margin-bottom: 4px; }
            h2 { color: #0284C7; border-bottom: 2px solid #0284C7; padding-bottom: 8px; margin-top: 0; }
            table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 9pt; }
            th, td { border: 1px solid #CBD5E1; padding: 6px; text-align: left; }
            th { background: #F1F5F9; font-weight: bold; }
            @media print {
              .no-print { display: none !important; }
              body { padding: 0; }
            }
          </style>
        </head>
        <body>
          <div class="no-print" style="margin-bottom: 15px; display: flex; justify-content: flex-end; gap: 8px;">
            <button onclick="window.print()" style="padding: 6px 14px; background: #0284C7; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">🖨️ Print Now / طباعة الآن</button>
            <button onclick="window.close()" style="padding: 6px 14px; background: #64748B; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">✕ Close / إغلاق</button>
          </div>
          <div style="text-align: center; margin-bottom: 16px;">
            <h3>Augusta Victoria Hospital | Occupational Health & MOH Audit</h3>
            <h2>Category: ${store.title}</h2>
            <p>Total Staff in List: <strong>${store.list.length}</strong> | Date: <strong>${new Date().toLocaleDateString()}</strong></p>
          </div>
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Staff Full Name</th>
                <th>Person # / ID</th>
                <th>Organization Name</th>
                <th>Job Title / Sector</th>
              </tr>
            </thead>
            <tbody>
              ${store.list.map((emp, i) => {
                const demo = emp.demographic || {};
                return `
                  <tr>
                    <td>${i + 1}</td>
                    <td><strong>${emp.name || demo.fullName || ''}</strong></td>
                    <td>${emp.empNo || demo.personNo || emp.idNo || ''}</td>
                    <td>${demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || demo.deptTreating || 'Augusta Victoria Hospital'}</td>
                    <td>${emp.jobTitle || demo.positionName || demo.jobTitle || emp.staffGroup || ''}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
          <script>
            window.onafterprint = function() { window.close(); };
            setTimeout(function() {
              try { window.focus(); window.print(); } catch(e) {}
            }, 300);
          </script>
        </body>
      </html>
    `);
    printWin.document.close();
    printWin.focus();
    setTimeout(() => {
      try { printWin.focus(); printWin.print(); } catch(e) {}
    }, 400);
  };

  const getTdapList = list => list.filter(e => getTdapVal(e));
  const getMMRList = list => list.filter(e => {
    const v = e.vaccines || {};
    const lab = e.labResults || {};
    const m1 = String(v.mmrDose1 || (v.MMR ? v.MMR.d1 : '') || '').trim();
    const m2 = String(v.mmrDose2 || (v.MMR ? v.MMR.d2 : '') || '').trim();
    const igg = String(lab.mmrIgG || v.mmrIgG || '').toLowerCase();
    const dob = String(e.dob || (e.demographic ? e.demographic.dob : '') || '');
    const isBornBefore1957 = dob.includes('195') || dob.includes('194') || dob.includes('193');
    return isBornBefore1957 || (m1 && m2 && m2 !== 'n/a' && m2 !== 'none') || m1 || igg.includes('pos') || igg.includes('react') || igg.includes('immune');
  });

  const getVZVList = list => list.filter(e => {
    const v = e.vaccines || {};
    const lab = e.labResults || {};
    const cp = String(v.chickenpoxStatus || v.chickenpox || '').toLowerCase();
    const d1 = String(v.chickenpoxDose1 || '').trim();
    const d2 = String(v.chickenpoxDose2 || '').trim();
    const igg = String(lab.varicellaIgG || v.varicellaIgG || '').toLowerCase();
    return cp.includes('2 dose') || cp.includes('natural') || cp.includes('history') || cp.includes('positive') || d1 || d2 || igg.includes('pos') || igg.includes('react') || igg.includes('immune');
  });

  const getPolioList = list => list.filter(e => getIpvVal(e));
  const getHBVList = list => list.filter(e => isHBVProtected(e));

  const totalTdapProtected = getTdapList(nonGazaEmployees).length;
  const tdapPct = Math.round((totalTdapProtected / Math.max(1, totalHCW)) * 1000) / 10;

  const totalMMRProtected = getMMRList(nonGazaEmployees).length;
  const mmrPct = Math.round((totalMMRProtected / Math.max(1, totalHCW)) * 1000) / 10;

  const totalVZVProtected = getVZVList(nonGazaEmployees).length;
  const vzvPct = Math.round((totalVZVProtected / Math.max(1, totalHCW)) * 1000) / 10;

  const totalPolioProtected = getPolioList(nonGazaEmployees).length;
  const polioPct = Math.round((totalPolioProtected / Math.max(1, totalHCW)) * 1000) / 10;

  const totalHBVInvasiveProtected = getHBVList(expInvasive).length;
  const hbvInvasivePct = Math.round((totalHBVInvasiveProtected / Math.max(1, expInvasive.length)) * 1000) / 10;

  window.updateMOHOverride = function(key, val) {
    const overrides = JSON.parse(localStorage.getItem('avh_moh_overrides') || '{}');
    overrides[key] = val;
    localStorage.setItem('avh_moh_overrides', JSON.stringify(overrides));
  };

  window.saveMOHReportSnapshot = function() {
    const overrides = JSON.parse(localStorage.getItem('avh_moh_overrides') || '{}');
    const instName = overrides['moh_header_institution'] || 'Augusta Victoria Hospital';
    const dateRange = overrides['moh_header_date'] || '1/1/2025-31/1/2025';
    const period = overrides['moh_header_period'] || '1 year';

    const d = new Date();
    const timeStr = d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const snapshot = {
      id: 'moh_' + Date.now(),
      institution: instName,
      date: dateRange,
      period: period,
      timestamp: timeStr,
      overrides: JSON.parse(JSON.stringify(overrides)),
      staffCount: totalHCW,
      tdapPct: tdapPct,
      mmrPct: mmrPct,
      vzvPct: vzvPct,
      polioPct: polioPct
    };

    const savedReports = JSON.parse(localStorage.getItem('avh_saved_moh_reports') || '[]');
    savedReports.unshift(snapshot);
    localStorage.setItem('avh_saved_moh_reports', JSON.stringify(savedReports));

    alert(isAr ? '✅ تم حفظ نسخة من التقرير في الأرشيف بنجاح!' : '✅ MOH Report Snapshot saved successfully to Dashboard Archive!');
    renderDashboardOverview();
  };

  window.loadMOHReportSnapshot = function(index) {
    const savedReports = JSON.parse(localStorage.getItem('avh_saved_moh_reports') || '[]');
    const snapshot = savedReports[index];
    if (!snapshot) return;

    if (snapshot.overrides) {
      localStorage.setItem('avh_moh_overrides', JSON.stringify(snapshot.overrides));
    }
    closeSavedMOHReportsModal();
    renderDashboardOverview();
  };

  window.openSavedMOHReportsModal = function() {
    const savedReports = JSON.parse(localStorage.getItem('avh_saved_moh_reports') || '[]');
    let listHtml = '';
    if (savedReports.length === 0) {
      listHtml = `<div style="text-align: center; color: #64748B; padding: 30px; font-weight: bold;">${isAr ? 'لا توجد تقارير محفوظة بعد في الأرشيف' : 'No saved report snapshots found in archive.'}</div>`;
    } else {
      listHtml = savedReports.map((rpt, idx) => `
        <div style="background: #F8FAFC; border: 1.5px solid #CBD5E1; padding: 14px 18px; border-radius: 10px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; box-shadow: 0 2px 4px rgba(0,0,0,0.03);">
          <div>
            <div style="font-weight: 800; font-size: 1.05rem; color: #0F172A; display: flex; align-items: center; gap: 8px;">
              <span>📅 ${rpt.date || '1/1/2025 - 31/1/2025'}</span>
              <span style="background: #E0F2FE; color: #0369A1; font-size: 0.75rem; padding: 2px 8px; border-radius: 12px; font-weight: bold;">${rpt.period || '1 year'}</span>
            </div>
            <div style="font-size: 0.84rem; color: #475569; margin-top: 4px;">
              🏥 <strong>${rpt.institution || 'Augusta Victoria Hospital'}</strong> • Saved: <span style="color: #0284C7; font-weight: bold;">${rpt.timestamp}</span>
            </div>
            <div style="font-size: 0.78rem; color: #166534; margin-top: 4px; font-weight: 600;">
              Compliance: Tdap ${rpt.tdapPct || 99}% | MMR ${rpt.mmrPct || 99.2}% | VZV ${rpt.vzvPct || 98}% | Polio ${rpt.polioPct || 99}%
            </div>
          </div>
          <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center;">
            <button class="btn btn-primary" style="padding: 6px 14px; font-size: 0.82rem; background: #0284C7; color: white; border: none; font-weight: bold; border-radius: 6px; cursor: pointer;" onclick="loadMOHReportSnapshot(${idx})">
              👁️ ${isAr ? 'عرض باللوحة' : 'Load Report'}
            </button>
            <button class="btn btn-success" style="padding: 6px 14px; font-size: 0.82rem; background: #16A34A; color: white; border: none; font-weight: bold; border-radius: 6px; cursor: pointer;" onclick="exportMOHSnapshotToExcel(${idx})">
              📊 ${isAr ? 'إكسل' : 'Excel'}
            </button>
            <button class="btn btn-outline" style="padding: 6px 10px; font-size: 0.82rem; border-color: #DC2626; color: #DC2626; font-weight: bold; border-radius: 6px; cursor: pointer; background: white;" onclick="deleteMOHReportSnapshot(${idx})">
              🗑️ ${isAr ? 'حذف' : 'Delete'}
            </button>
          </div>
        </div>
      `).join('');
    }

    const modalHtml = `
      <div id="savedMOHReportsModal" style="position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(4px); z-index: 9999; display: flex; align-items: center; justify-content: center; padding: 20px;">
        <div style="background: white; width: 100%; max-width: 720px; max-height: 80vh; border-radius: 12px; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.2); display: flex; flex-direction: column; overflow: hidden; border: 1px solid #CBD5E1;">
          <div style="background: #0284C7; color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <div style="font-size: 1.1rem; font-weight: bold;">📚 ${isAr ? 'أرشيف تقارير وزارة الصحة المحفوظة' : 'Saved MOH Report Snapshots Library'}</div>
            <button onclick="closeSavedMOHReportsModal()" style="background: none; border: none; color: white; font-size: 1.2rem; cursor: pointer;">✕</button>
          </div>
          <div style="flex: 1; overflow-y: auto; padding: 20px;">
            ${listHtml}
          </div>
          <div style="background: #F8FAFC; border-top: 1px solid #CBD5E1; padding: 12px 20px; text-align: right;">
            <button class="btn btn-outline" style="padding: 6px 16px; font-weight: bold;" onclick="closeSavedMOHReportsModal()">
              ${isAr ? 'إغلاق' : 'Close'}
            </button>
          </div>
        </div>
      </div>
    `;

    const oldModal = document.getElementById('savedMOHReportsModal');
    if (oldModal) oldModal.remove();
    document.body.insertAdjacentHTML('beforeend', modalHtml);
  };

  window.closeSavedMOHReportsModal = function() {
    const modal = document.getElementById('savedMOHReportsModal');
    if (modal) modal.remove();
  };

  window.deleteMOHReportSnapshot = function(index) {
    const savedReports = JSON.parse(localStorage.getItem('avh_saved_moh_reports') || '[]');
    savedReports.splice(index, 1);
    localStorage.setItem('avh_saved_moh_reports', JSON.stringify(savedReports));
    openSavedMOHReportsModal();
    renderDashboardOverview();
  };

  window.printFormalMOHReport = function() {
    const printArea = document.getElementById('mohReportPrintArea');
    if (!printArea) {
      window.print();
      return;
    }

    const overrides = JSON.parse(localStorage.getItem('avh_moh_overrides') || '{}');
    const instName = overrides['moh_header_institution'] || 'Augusta Victoria Hospital';
    const dateRange = overrides['moh_header_date'] || '1/1/2025-31/1/2025';
    const period = overrides['moh_header_period'] || '1 year';

    const clone = printArea.cloneNode(true);
    const inputs = printArea.querySelectorAll('input.moh-editable-input');
    inputs.forEach(inp => {
      const id = inp.id;
      const key = id.replace('moh_override_', '');
      const viewSpanInClone = clone.querySelector('#moh_override_' + key + '_view');
      if (viewSpanInClone) {
        viewSpanInClone.textContent = inp.value;
      }
    });

    const elementsToRemove = clone.querySelectorAll('.no-print, button, input.moh-editable-input');
    elementsToRemove.forEach(el => el.remove());

    const printWin = window.open('', '_blank', 'width=1000,height=800');
    if (!printWin) {
      alert('The print window was blocked by your browser. Please allow popups and try again.');
      return;
    }
    printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>MOH Official Annual Immunity Report — ${instName}</title>
          <style>
            @page { size: A4 portrait; margin: 10mm 12mm; }
            body { font-family: Arial, sans-serif; color: #0F172A; margin: 0; padding: 15px; background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .formal-header { text-align: center; border-bottom: 2px solid #1E3A8A; padding-bottom: 10px; margin-bottom: 16px; }
            .formal-header img { height: 70px; width: auto; display: block; margin: 0 auto 6px auto; object-fit: contain; }
            .formal-header h1 { font-size: 1.3rem; color: #1E3A8A; margin: 0 0 3px 0; text-transform: uppercase; letter-spacing: 0.5px; }
            .formal-header h2 { font-size: 1.0rem; color: #0284C7; margin: 0 0 4px 0; font-weight: 700; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 8.5pt; page-break-inside: avoid; }
            th, td { border: 1px solid #70A7C4; padding: 5px 8px; text-align: left; }
            th { background: #5C94B5 !important; color: white !important; font-weight: bold; text-align: center; }
          </style>
        </head>
        <body>
          <div class="formal-header">
            <img src="assets/avh_logo.png" alt="Augusta Victoria Hospital Logo" />
            <h1>Augusta Victoria Hospital — Jerusalem</h1>
            <h2>Infectious Disease Unit</h2>
            <div style="font-size: 0.95rem; font-weight: bold; color: #0F172A; margin-top: 4px;">Ministry of Health (MOH) Official Annual Immunity Report</div>
          </div>

          ${clone.innerHTML}

          <` + `script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
                window.close();
              }, 400);
            };
          </` + `script>
        </body>
      </html>
    `);
  };

  window.exportMOHReportToExcel = function(snapshotOverrides = null) {
    const overrides = snapshotOverrides || JSON.parse(localStorage.getItem('avh_moh_overrides') || '{}');

    const instName = overrides['moh_header_institution'] || 'Augusta Victoria Hospital';
    const dateRange = overrides['moh_header_date'] || '1/1/2025-31/1/2025';
    const period = overrides['moh_header_period'] || '1 year';

    const getVal = (key, defVal) => (overrides[key] !== undefined) ? overrides[key] : defVal;

    const rows = [
      ["Augusta Victoria Hospital - Ministry of Health (MOH) Annual Immunity Report"],
      ["Name of Institution:", instName],
      ["Date:", dateRange],
      ["Reporting Period:", period],
      ["Generated Timestamp:", new Date().toLocaleString()],
      [],
      ["1. DISTRIBUTION OF HEALTHCARE WORKERS BY VACCINATION PROGRAM"],
      ["Program Type", "Staff Count", "Program Description"],
      ["Minimum Program", getVal('sec1_min', minCount), "Healthcare workers with no contact with patients or their secretions."],
      ["Basic Program", getVal('sec1_basic', basicCount), "Healthcare workers with contact with patients or their secretions."],
      ["Expanded Program", getVal('sec1_exp', expCount), "Healthcare workers at high risk of contact with blood or body fluids (including HCW who perform invasive procedures (apapasach))."],
      ["Total", getVal('sec1_total', totalHCW), ""],
      [],
      ["2. SPECIAL POPULATIONS & INVASIVE PROCEDURES"],
      ["Category", "Staff Count"],
      ["Healthcare workers performing invasive procedures (Apapasach)", getVal('sec2_invasive', invasiveCount)],
      ["Healthcare workers providing direct care for premature/infants (<1Y)", getVal('sec2_babies', babiesCount)],
      ["Healthcare workers providing direct care for severely immunocompromised patients", getVal('sec2_immuno', immunoCount)],
      [],
      ["3. TDAP VACCINATION & IMMUNITY"],
      ["Vaccination Program", "Minimum", "Basic", "Expanded", "Direct care for premature/infants (<1Y)"],
      ["Documented Tdap vaccine in last 10 years", getVal('tdap_min_vac', tdapStats.min.vac), getVal('tdap_basic_vac', tdapStats.basic.vac), getVal('tdap_exp_vac', tdapStats.exp.vac), getVal('tdap_babies_vac', tdapStats.babies.vac)],
      ["Documented refusal", getVal('tdap_min_ref', tdapStats.min.ref), getVal('tdap_basic_ref', tdapStats.basic.ref), getVal('tdap_exp_ref', tdapStats.exp.ref), getVal('tdap_babies_ref', tdapStats.babies.ref)],
      ["Documented contraindication", getVal('tdap_min_contra', tdapStats.min.contra), getVal('tdap_basic_contra', tdapStats.basic.contra), getVal('tdap_exp_contra', tdapStats.exp.contra), getVal('tdap_babies_contra', tdapStats.babies.contra)],
      ["Unvaccinated or without status", getVal('tdap_min_unvac', tdapStats.min.unvac), getVal('tdap_basic_unvac', tdapStats.basic.unvac), getVal('tdap_exp_unvac', tdapStats.exp.unvac), getVal('tdap_babies_unvac', tdapStats.babies.unvac)],
      ["Total", getVal('tdap_min_total', tdapStats.min.total), getVal('tdap_basic_total', tdapStats.basic.total), getVal('tdap_exp_total', tdapStats.exp.total), getVal('tdap_babies_total', tdapStats.babies.total)],
      [],
      ["4. MMR IMMUNITY (MEASLES, MUMPS, RUBELLA)"],
      ["Vaccination Program", "Minimum", "Basic", "Expanded", "High Risk Units"],
      ["Documented immunity (2 doses / born < 1957 / positive IgG)", getVal('mmr_min_immune', mmrStats.min.vac), getVal('mmr_basic_immune', mmrStats.basic.vac), getVal('mmr_exp_immune', mmrStats.exp.vac), getVal('mmr_highRisk_immune', mmrStats.highRisk.vac)],
      ["Documented refusal", getVal('mmr_min_ref', mmrStats.min.ref), getVal('mmr_basic_ref', mmrStats.basic.ref), getVal('mmr_exp_ref', mmrStats.exp.ref), getVal('mmr_highRisk_ref', mmrStats.highRisk.ref)],
      ["Documented contraindication", getVal('mmr_min_contra', mmrStats.min.contra), getVal('mmr_basic_contra', mmrStats.basic.contra), getVal('mmr_exp_contra', mmrStats.exp.contra), getVal('mmr_highRisk_contra', mmrStats.highRisk.contra)],
      ["Unvaccinated or without status", getVal('mmr_min_unvac', mmrStats.min.unvac), getVal('mmr_basic_unvac', mmrStats.basic.unvac), getVal('mmr_exp_unvac', mmrStats.exp.unvac), getVal('mmr_highRisk_unvac', mmrStats.highRisk.unvac)],
      ["Total", getVal('mmr_min_total', mmrStats.min.total), getVal('mmr_basic_total', mmrStats.basic.total), getVal('mmr_exp_total', mmrStats.exp.total), getVal('mmr_highRisk_total', mmrStats.highRisk.total)],
      [],
      ["5. VARICELLA (CHICKENPOX) IMMUNITY"],
      ["Vaccination Program", "Minimum", "Basic", "Expanded", "High Risk Units"],
      ["Documented immunity (2 doses / natural history / positive IgG)", getVal('vzv_min_immune', vzvStats.min.vac), getVal('vzv_basic_immune', vzvStats.basic.vac), getVal('vzv_exp_immune', vzvStats.exp.vac), getVal('vzv_highRisk_immune', vzvStats.highRisk.vac)],
      ["Documented refusal", getVal('vzv_min_ref', vzvStats.min.ref), getVal('vzv_basic_ref', vzvStats.basic.ref), getVal('vzv_exp_ref', vzvStats.exp.ref), getVal('vzv_highRisk_ref', vzvStats.highRisk.ref)],
      ["Documented contraindication", getVal('vzv_min_contra', vzvStats.min.contra), getVal('vzv_basic_contra', vzvStats.basic.contra), getVal('vzv_exp_contra', vzvStats.exp.contra), getVal('vzv_highRisk_contra', vzvStats.highRisk.contra)],
      ["Unvaccinated or without status", getVal('vzv_min_unvac', vzvStats.min.unvac), getVal('vzv_basic_unvac', vzvStats.basic.unvac), getVal('vzv_exp_unvac', vzvStats.exp.unvac), getVal('vzv_highRisk_unvac', vzvStats.highRisk.unvac)],
      ["Total", getVal('vzv_min_total', vzvStats.min.total), getVal('vzv_basic_total', vzvStats.basic.total), getVal('vzv_exp_total', vzvStats.exp.total), getVal('vzv_highRisk_total', vzvStats.highRisk.total)],
      [],
      ["6. POLIO VACCINATION"],
      ["Vaccination Program", "Basic", "Expanded"],
      ["Documented vaccination", getVal('polio_basic_vac', polioStats.basic.vac), getVal('polio_exp_vac', polioStats.exp.vac)],
      ["Documented refusal", getVal('polio_basic_ref', polioStats.basic.ref), getVal('polio_exp_ref', polioStats.exp.ref)],
      ["Documented contraindication", getVal('polio_basic_contra', polioStats.basic.contra), getVal('polio_exp_contra', polioStats.exp.contra)],
      ["Unvaccinated or without status", getVal('polio_basic_unvac', polioStats.basic.unvac), getVal('polio_exp_unvac', polioStats.exp.unvac)],
      ["Total", getVal('polio_basic_total', polioStats.basic.total), getVal('polio_exp_total', polioStats.exp.total)],
      [],
      ["7. IMMUNITY TO HBV & HCV"],
      ["Vaccination Program", "Basic", "Expanded (No Invasive)", "Expanded (Invasive Procedures)"],
      ["Documented immunity", getVal('hbv_basic_immune', hbvBasic.immune), getVal('hbv_expNoInv_immune', hbvExpNoInvasive.immune), getVal('hbv_expInv_immune', hbvExpInvasive.immune)],
      ["Non-responders after 6 doses", "N/A", getVal('hbv_expNoInv_nonResp', hbvExpNoInvasive.nonResp), getVal('hbv_expInv_nonResp', hbvExpInvasive.nonResp)],
      ["HBV carriers", getVal('hbv_basic_carrier', hbvBasic.carrier), getVal('hbv_expNoInv_carrier', hbvExpNoInvasive.carrier), getVal('hbv_expInv_carrier', hbvExpInvasive.carrier)],
      ["Documented refusal", getVal('hbv_basic_ref', hbvBasic.ref), getVal('hbv_expNoInv_ref', hbvExpNoInvasive.ref), getVal('hbv_expInv_ref', hbvExpInvasive.ref)],
      ["Documented contraindication", getVal('hbv_basic_contra', hbvBasic.contra), getVal('hbv_expNoInv_contra', hbvExpNoInvasive.contra), getVal('hbv_expInv_contra', hbvExpInvasive.contra)],
      ["Unvaccinated or without status", getVal('hbv_basic_unvac', hbvBasic.unvac), getVal('hbv_expNoInv_unvac', hbvExpNoInvasive.unvac), getVal('hbv_expInv_unvac', hbvExpInvasive.unvac)],
      ["Total", getVal('hbv_basic_total', hbvBasic.total), getVal('hbv_expNoInv_total', hbvExpNoInvasive.total), getVal('hbv_expInv_total', hbvExpInvasive.total)],
      ["Unimmunized employees", getVal('unimmud_basic', ''), getVal('unimmud_expNoInv', ''), getVal('unimmud_expInv', unimmudCount)],
      ["Unimmunized employees tested for carrier status", getVal('unimmudTested_basic', ''), getVal('unimmudTested_expNoInv', ''), getVal('unimmudTested_expInv', unimmudTestedCount)],
      ["Anti-HCV serology tested", getVal('hcvSerology_basic', ''), getVal('hcvSerology_expNoInv', ''), getVal('hcvSerology_expInv', hcvSerologyCount)],
      [],
      ["8. TUBERCULIN TESTING (PPD)"],
      ["Vaccination Program", "Basic", "Expanded"],
      ["Current negative test", getVal('ppd_basic_neg', ppdStats.basic.neg), getVal('ppd_exp_neg', ppdStats.exp.neg)],
      ["History of positive test", getVal('ppd_basic_pos', ppdStats.basic.pos), getVal('ppd_exp_pos', ppdStats.exp.pos)],
      ["Documented refusal", getVal('ppd_basic_ref', ppdStats.basic.ref), getVal('ppd_exp_ref', ppdStats.exp.ref)],
      ["Documented contraindication", getVal('ppd_basic_contra', ppdStats.basic.contra), getVal('ppd_exp_contra', ppdStats.exp.contra)],
      ["Unvaccinated or without status", getVal('ppd_basic_unvac', ppdStats.basic.unvac), getVal('ppd_exp_unvac', ppdStats.exp.unvac)],
      ["Total", getVal('ppd_basic_total', ppdStats.basic.total), getVal('ppd_exp_total', ppdStats.exp.total)]
    ];

    const safeDateStr = String(dateRange).replace(/[/\\?%*:|"<>]/g, '-');
    const fileName = `MOH_Annual_Immunity_Report_${safeDateStr}.xlsx`;

    if (typeof XLSX !== 'undefined') {
      const ws = XLSX.utils.aoa_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "MOH Report");
      XLSX.writeFile(wb, fileName);
    } else {
      const csvLines = rows.map(r => r.map(cell => `"${String(cell !== undefined && cell !== null ? cell : '').replace(/"/g, '""')}"`).join(","));
      const csvContent = "\uFEFF" + csvLines.join("\r\n");
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", fileName.replace('.xlsx', '.csv'));
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  window.exportMOHSnapshotToExcel = function(index) {
    const savedReports = JSON.parse(localStorage.getItem('avh_saved_moh_reports') || '[]');
    const rpt = savedReports[index];
    if (rpt && rpt.overrides) {
      exportMOHReportToExcel(rpt.overrides);
    }
  };

  const savedReportsCount = (JSON.parse(localStorage.getItem('avh_saved_moh_reports') || '[]')).length;

  const saveEditBtnHTML = window.mohEditMode ? `
    <button type="button" class="btn btn-success" style="background: #16A34A; color: white; border: none; font-weight: bold; padding: 6px 14px; font-size: 0.85rem; border-radius: 6px; cursor: pointer;" onclick="saveMOHOverrides()">
      💾 ${isAr ? 'حفظ التعديلات' : 'Save Table Changes'}
    </button>
  ` : '';

  container.innerHTML = `
    ${toolbarHTML}

    <!-- EXECUTIVE COMPLIANCE KPI SUMMARY RIBBON -->
    <div class="no-print" style="display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap;">
      <div style="flex: 1; min-width: 140px; background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 8px; padding: 10px 14px;">
        <div style="font-size: 0.78rem; font-weight: bold; color: #166534;">Tdap Protection</div>
        <div style="font-size: 1.25rem; font-weight: 900; color: #15803D;">${tdapPct}%</div>
        <div style="font-size: 0.72rem; color: #166534;">${totalTdapProtected} / ${totalHCW} HCW</div>
      </div>
      <div style="flex: 1; min-width: 140px; background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 8px; padding: 10px 14px;">
        <div style="font-size: 0.78rem; font-weight: bold; color: #166534;">MMR Immunity</div>
        <div style="font-size: 1.25rem; font-weight: 900; color: #15803D;">${mmrPct}%</div>
        <div style="font-size: 0.72rem; color: #166534;">${totalMMRProtected} / ${totalHCW} HCW</div>
      </div>
      <div style="flex: 1; min-width: 140px; background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 8px; padding: 10px 14px;">
        <div style="font-size: 0.78rem; font-weight: bold; color: #166534;">VZV Immunity</div>
        <div style="font-size: 1.25rem; font-weight: 900; color: #15803D;">${vzvPct}%</div>
        <div style="font-size: 0.72rem; color: #166534;">${totalVZVProtected} / ${totalHCW} HCW</div>
      </div>
      <div style="flex: 1; min-width: 140px; background: #F0FDF4; border: 1.5px solid #86EFAC; border-radius: 8px; padding: 10px 14px;">
        <div style="font-size: 0.78rem; font-weight: bold; color: #166534;">Polio Protection</div>
        <div style="font-size: 1.25rem; font-weight: 900; color: #15803D;">${polioPct}%</div>
        <div style="font-size: 0.72rem; color: #166534;">${totalPolioProtected} / ${totalHCW} HCW</div>
      </div>
      <div style="flex: 1; min-width: 160px; background: #EFF6FF; border: 1.5px solid #93C5FD; border-radius: 8px; padding: 10px 14px;">
        <div style="font-size: 0.78rem; font-weight: bold; color: #1E40AF;">HBV Invasive (Apapasach)</div>
        <div style="font-size: 1.25rem; font-weight: 900; color: #1D4ED8;">${hbvInvasivePct}%</div>
        <div style="font-size: 0.72rem; color: #1E40AF;">${totalHBVInvasiveProtected} / ${expInvasive.length} Staff</div>
      </div>
    </div>

    <!-- PRINTABLE OFFICIAL MOH STATUTORY REPORT CONTAINER -->
    <div style="background: white; padding: 28px 36px; border-radius: 8px; border: 2px solid #70A7C4; box-shadow: 0 4px 14px rgba(0,0,0,0.06); font-family: Arial, sans-serif; color: #1E293B;" id="mohReportPrintArea">
      
      <!-- MOH ACTION BUTTONS (NO PRINT) -->
      <div class="no-print" style="display: flex; justify-content: space-between; align-items: center; gap: 10px; margin-bottom: 20px; background: #EBF3F8; padding: 10px 14px; border-radius: 6px; border: 1px solid #70A7C4; flex-wrap: wrap;">
        <div style="font-size: 1.1rem; font-weight: bold; color: #1E3A8A; display: flex; align-items: center; gap: 8px;">
          <span>📋 Ministry of Health (MOH) Annual Immunity Report</span>
        </div>

        <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
          <!-- MODE SWITCH -->
          <div style="display: flex; gap: 4px; background: white; border: 1px solid #70A7C4; padding: 3px; border-radius: 6px;">
            <button type="button" style="padding: 4px 10px; font-size: 0.8rem; font-weight: bold; border-radius: 4px; cursor: pointer; ${!window.mohEditMode ? 'background: #0284C7; color: white; border: none;' : 'background: transparent; color: #475569; border: none;'}" onclick="toggleMOHMode(false)">
              👁️ ${isAr ? 'تفتيش السجلات (تفاعلي)' : 'Audit & Drilldown'}
            </button>
            <button type="button" style="padding: 4px 10px; font-size: 0.8rem; font-weight: bold; border-radius: 4px; cursor: pointer; ${window.mohEditMode ? 'background: #D97706; color: white; border: none;' : 'background: transparent; color: #475569; border: none;'}" onclick="toggleMOHMode(true)">
              ✏️ ${isAr ? 'تعديل الأرقام' : 'Direct Edit'}
            </button>
          </div>

          ${saveEditBtnHTML}

          <button type="button" class="btn btn-primary" style="background: #0284C7; color: white; border: none; font-weight: bold; padding: 6px 14px; font-size: 0.85rem; border-radius: 6px; cursor: pointer;" onclick="saveMOHReportSnapshot()">
            💾 ${isAr ? 'حفظ التقرير باللوحة' : 'Save Report to Dashboard'}
          </button>
          <button type="button" class="btn btn-outline" style="border-color: #0284C7; color: #0284C7; font-weight: bold; padding: 6px 14px; font-size: 0.85rem; border-radius: 6px; cursor: pointer; background: white;" onclick="openSavedMOHReportsModal()">
            📚 ${isAr ? 'التقارير المحفوظة' : 'Saved Reports'} (${savedReportsCount})
          </button>
          <button type="button" class="btn btn-outline" style="border-color: #DC2626; color: #DC2626; font-weight: bold; padding: 6px 12px; font-size: 0.85rem; border-radius: 6px; cursor: pointer; background: white;" onclick="resetMOHOverrides()">
            🔄 ${isAr ? 'إعادة ضبط' : 'Reset Defaults'}
          </button>
          <button type="button" class="btn btn-success" style="background: #0F766E; color: white; border: none; font-weight: bold; padding: 6px 16px; font-size: 0.85rem; border-radius: 6px; cursor: pointer;" onclick="printFormalMOHReport()">
            🖨️ ${isAr ? 'طباعة التقرير الرسمي' : 'Print Formal MOH Report'}
          </button>
          <button type="button" class="btn btn-outline" style="border-color: #0284C7; color: #0284C7; font-weight: bold; padding: 6px 16px; font-size: 0.85rem; border-radius: 6px; cursor: pointer; background: white;" onclick="exportMOHReportToExcel()">
            📥 ${isAr ? 'تصدير للإكسل' : 'Export to Excel'}
          </button>
        </div>
      </div>
      <!-- OFFICIAL MOH REPORT HEADER METADATA TABLE -->
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9.5pt; margin-bottom: 20px; background: white;">
        <tr>
          <td style="padding: 6px 12px; border: 1px solid #70A7C4; background: #8EBAD1; font-weight: bold; width: 25%; color: #0F172A;">Name of Institution:</td>
          <td style="padding: 6px 12px; border: 1px solid #70A7C4; text-align: center; font-weight: bold; width: 75%; font-size: 10.5pt; color: #0F172A;">
            ${renderEditableMOHCell('moh_header_institution', 'Augusta Victoria Hospital', 'font-weight: bold; font-size: 10.5pt;')}
          </td>
        </tr>
        <tr>
          <td style="padding: 6px 12px; border: 1px solid #70A7C4; background: #8EBAD1; font-weight: bold; color: #0F172A;">Date:</td>
          <td style="padding: 6px 12px; border: 1px solid #70A7C4; text-align: center; font-weight: bold; font-size: 10pt; color: #0284C7;">
            ${renderEditableMOHCell('moh_header_date', '1/1/2025-31/1/2025', 'font-weight: bold; color: #0284C7; font-size: 10pt;')}
          </td>
        </tr>
        <tr>
          <td style="padding: 6px 12px; border: 1px solid #70A7C4; background: #8EBAD1; font-weight: bold; color: #0F172A;">Reporting period:</td>
          <td style="padding: 6px 12px; border: 1px solid #70A7C4; text-align: center; font-weight: bold;">
            ${renderEditableMOHCell('moh_header_period', '1 year', 'font-weight: bold;')}
          </td>
        </tr>
      </table>

      <!-- 1. DISTRIBUTION OF HEALTHCARE WORKERS BY VACCINATION PROGRAM -->
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9.5pt; margin-bottom: 20px;">
        <tr style="background: #EBF3F8;">
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; width: 22%;">Minimum program</td>
          <td style="padding: 3px 6px; border: 1px solid #70A7C4; width: 12%; text-align: center; font-weight: bold;">
            ${renderEditableMOHCell('sec1_min', minCount, 'font-weight: bold;', minList, 'Section 1: Minimum Program Staff')}
          </td>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4;">Healthcare workers with no contact with patients or their secretions.</td>
        </tr>
        <tr>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4;">Basic program</td>
          <td style="padding: 3px 6px; border: 1px solid #70A7C4; text-align: center; font-weight: bold;">
            ${renderEditableMOHCell('sec1_basic', basicCount, 'font-weight: bold;', basicList, 'Section 1: Basic Program Staff')}
          </td>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4;">Healthcare workers with contact with patients or their secretions.</td>
        </tr>
        <tr style="background: #EBF3F8;">
          <td style="padding: 6px 10px; border: 1px solid #70A7C4;">Expanded program</td>
          <td style="padding: 3px 6px; border: 1px solid #70A7C4; text-align: center; font-weight: bold;">
            ${renderEditableMOHCell('sec1_exp', expCount, 'font-weight: bold;', expList, 'Section 1: Expanded Program Staff')}
          </td>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4;">Healthcare workers at high risk of contact with blood or body fluids (including HCW who perform invasive procedures (apapasach)).</td>
        </tr>
        <tr style="background: #8EBAD1; font-weight: bold;">
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; text-align: right;">Total:</td>
          <td style="padding: 3px 6px; border: 1px solid #70A7C4; text-align: center; font-size: 10pt;">
            ${renderEditableMOHCell('sec1_total', totalHCW, 'font-weight: bold; font-size: 10pt;', nonGazaEmployees, 'Section 1: All Hospital Staff')}
          </td>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4;"></td>
        </tr>
      </table>

      <!-- 2. SPECIAL POPULATIONS & INVASIVE PROCEDURES -->
      <div style="font-weight: bold; color: #B91C1C; margin-bottom: 6px; font-size: 10pt;">
        Number of healthcare workers working with special populations or performing invasive procedures:
      </div>
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9pt; margin-bottom: 24px;">
        <tr>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; width: 22%; font-weight: bold;">Healthcare workers performing invasive procedures* (Apapasach)</td>
          <td style="padding: 3px 6px; border: 1px solid #70A7C4; width: 12%; text-align: center; font-weight: bold;">
            ${renderEditableMOHCell('sec2_invasive', invasiveCount, 'font-weight: bold;', expInvasive, 'Section 2: Invasive Procedures Staff (Apapasach)')}
          </td>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; color: #B91C1C;">*Invasive procedures with risk of exposing patients to blood borne pathogens from an infected healthcare worker.<br><em>It is necessary to provide a detailed individual report of immune status for HBV and HCV.</em></td>
        </tr>
        <tr style="background: #EBF3F8;">
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; font-weight: bold;">Healthcare workers working with babies ≤1 year:</td>
          <td style="padding: 3px 6px; border: 1px solid #70A7C4; text-align: center; font-weight: bold;">
            ${renderEditableMOHCell('sec2_babies', babiesCount, 'font-weight: bold;', babiesList, 'Section 2: Staff Treating Babies <= 1 Year')}
          </td>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; color: #B91C1C;">Employees in departments/units/clinics treating babies up to age 1 year.<br><em>It is necessary to provide a detailed individual report of vaccination status for Tdap, MMR and VZV.</em></td>
        </tr>
        <tr>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; font-weight: bold;">Healthcare workers working with immunocompromised patients:</td>
          <td style="padding: 3px 6px; border: 1px solid #70A7C4; text-align: center; font-weight: bold;">
            ${renderEditableMOHCell('sec2_immuno', immunoCount, 'font-weight: bold;', immunoList, 'Section 2: Staff Treating Immunocompromised Patients')}
          </td>
          <td style="padding: 6px 10px; border: 1px solid #70A7C4; color: #B91C1C;">Employees in oncology, hemato-oncology, bone marrow transplantation and solid organ transplantation departments/units/clinics.<br><em>It is necessary to provide a detailed individual report of vaccination status for MMR and VZV.</em></td>
        </tr>
      </table>

      <!-- 3. IMMUNITY TO PERTUSSIS (Tdap) -->
      <div style="background: #8EBAD1; padding: 6px 12px; font-weight: bold; border: 1px solid #70A7C4; border-bottom: none; font-family: Arial, sans-serif; font-size: 9.5pt; display: flex; justify-content: space-between;">
        <span>Immunity to Pertussis</span>
        <span style="font-weight: normal; font-size: 8.5pt; color: #1E293B;">One dose of Tdap given after age 18 years</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9pt; margin-bottom: 24px;">
        <thead>
          <tr style="background: #5C94B5; color: white; text-align: center; font-weight: bold;">
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 40%; text-align: left;">Vaccination program</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Minimum</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Basic</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Expanded</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">HCW working with babies ≤1y</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented vaccination</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_min_vac', tdapStats.min.vac, 'font-weight: bold;', getTdapList(minList), 'Tdap Vaccination — Minimum Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_basic_vac', tdapStats.basic.vac, 'font-weight: bold;', getTdapList(basicList), 'Tdap Vaccination — Basic Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_exp_vac', tdapStats.exp.vac, 'font-weight: bold;', getTdapList(expList), 'Tdap Vaccination — Expanded Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_babies_vac', tdapStats.babies.vac, 'font-weight: bold;', getTdapList(babiesList), 'Tdap Vaccination — Babies <= 1y Staff')}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented refusal</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_min_ref', tdapStats.min.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_basic_ref', tdapStats.basic.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_exp_ref', tdapStats.exp.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_babies_ref', tdapStats.babies.ref)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented contraindication</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_min_contra', tdapStats.min.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_basic_contra', tdapStats.basic.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_exp_contra', tdapStats.exp.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_babies_contra', tdapStats.babies.contra)}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees unvaccinated or without documented vaccination status</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_min_unvac', tdapStats.min.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_basic_unvac', tdapStats.basic.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_exp_unvac', tdapStats.exp.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_babies_unvac', tdapStats.babies.unvac)}</td>
          </tr>
          <tr style="background: #EBF3F8; font-weight: bold;">
            <td style="padding: 6px 8px; border: 1px solid #70A7C4;">Total</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_min_total', tdapStats.min.total, 'font-weight: bold;', minList, 'Tdap Minimum Staff Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_basic_total', tdapStats.basic.total, 'font-weight: bold;', basicList, 'Tdap Basic Staff Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_exp_total', tdapStats.exp.total, 'font-weight: bold;', expList, 'Tdap Expanded Staff Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('tdap_babies_total', tdapStats.babies.total, 'font-weight: bold;', babiesList, 'Tdap Babies Staff Total')}</td>
          </tr>
        </tbody>
      </table>

      <!-- 4. IMMUNITY TO MMR -->
      <div style="background: #8EBAD1; padding: 6px 12px; font-weight: bold; border: 1px solid #70A7C4; border-bottom: none; font-family: Arial, sans-serif; font-size: 9pt; display: flex; justify-content: space-between;">
        <span>Immunity to MMR</span>
        <span style="font-weight: normal; font-size: 8pt; color: #1E293B;">One of 4 options: Born before 1/1/1957 | Two documented doses MMR | Documented positive serology | Documented clinical/lab confirmation</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9pt; margin-bottom: 24px;">
        <thead>
          <tr style="background: #5C94B5; color: white; text-align: center; font-weight: bold;">
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 40%; text-align: left;">Vaccination program</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Minimum</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Basic</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Expanded</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">HCW working with babies or immunocompromised</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented vaccination / immunity</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_min_vac', mmrStats.min.vac, 'font-weight: bold;', getMMRList(minList), 'MMR Immunity — Minimum Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_basic_vac', mmrStats.basic.vac, 'font-weight: bold;', getMMRList(basicList), 'MMR Immunity — Basic Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_exp_vac', mmrStats.exp.vac, 'font-weight: bold;', getMMRList(expList), 'MMR Immunity — Expanded Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_highRisk_vac', mmrStats.highRisk.vac, 'font-weight: bold;', getMMRList([...new Set([...babiesList, ...immunoList])]), 'MMR Immunity — High Risk Staff')}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented refusal</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_min_ref', mmrStats.min.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_basic_ref', mmrStats.basic.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_exp_ref', mmrStats.exp.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_highRisk_ref', mmrStats.highRisk.ref)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented contraindication</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_min_contra', mmrStats.min.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_basic_contra', mmrStats.basic.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_exp_contra', mmrStats.exp.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_highRisk_contra', mmrStats.highRisk.contra)}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees unvaccinated or without documented vaccination status</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_min_unvac', mmrStats.min.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_basic_unvac', mmrStats.basic.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_exp_unvac', mmrStats.exp.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_highRisk_unvac', mmrStats.highRisk.unvac)}</td>
          </tr>
          <tr style="background: #EBF3F8; font-weight: bold;">
            <td style="padding: 6px 8px; border: 1px solid #70A7C4;">Total</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_min_total', mmrStats.min.total, 'font-weight: bold;', minList, 'MMR Minimum Program Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_basic_total', mmrStats.basic.total, 'font-weight: bold;', basicList, 'MMR Basic Program Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_exp_total', mmrStats.exp.total, 'font-weight: bold;', expList, 'MMR Expanded Program Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('mmr_highRisk_total', mmrStats.highRisk.total, 'font-weight: bold;', [...new Set([...babiesList, ...immunoList])], 'MMR High Risk Total')}</td>
          </tr>
        </tbody>
      </table>

      <!-- 5. IMMUNITY TO VZV -->
      <div style="background: #8EBAD1; padding: 6px 12px; font-weight: bold; border: 1px solid #70A7C4; border-bottom: none; font-family: Arial, sans-serif; font-size: 9pt; display: flex; justify-content: space-between;">
        <span>Immunity to VZV</span>
        <span style="font-weight: normal; font-size: 8pt; color: #1E293B;">One of 3 options: Declaration of past illness (chickenpox/zoster) | Documented positive serology | Two documented doses VZV</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9pt; margin-bottom: 24px;">
        <thead>
          <tr style="background: #5C94B5; color: white; text-align: center; font-weight: bold;">
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 40%; text-align: left;">Vaccination program</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Minimum</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Basic</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">Expanded</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 15%;">HCW working with babies or immunocompromised</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented vaccination / immunity</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_min_vac', vzvStats.min.vac, 'font-weight: bold;', getVZVList(minList), 'VZV Immunity — Minimum Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_basic_vac', vzvStats.basic.vac, 'font-weight: bold;', getVZVList(basicList), 'VZV Immunity — Basic Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_exp_vac', vzvStats.exp.vac, 'font-weight: bold;', getVZVList(expList), 'VZV Immunity — Expanded Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_highRisk_vac', vzvStats.highRisk.vac, 'font-weight: bold;', getVZVList([...new Set([...babiesList, ...immunoList])]), 'VZV Immunity — High Risk Staff')}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented refusal</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_min_ref', vzvStats.min.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_basic_ref', vzvStats.basic.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_exp_ref', vzvStats.exp.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_highRisk_ref', vzvStats.highRisk.ref)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented contraindication</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_min_contra', vzvStats.min.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_basic_contra', vzvStats.basic.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_exp_contra', vzvStats.exp.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_highRisk_contra', vzvStats.highRisk.contra)}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees unvaccinated or without documented vaccination status</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_min_unvac', vzvStats.min.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_basic_unvac', vzvStats.basic.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_exp_unvac', vzvStats.exp.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_highRisk_unvac', vzvStats.highRisk.unvac)}</td>
          </tr>
          <tr style="background: #EBF3F8; font-weight: bold;">
            <td style="padding: 6px 8px; border: 1px solid #70A7C4;">Total</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_min_total', vzvStats.min.total, 'font-weight: bold;', minList, 'VZV Minimum Program Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_basic_total', vzvStats.basic.total, 'font-weight: bold;', basicList, 'VZV Basic Program Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_exp_total', vzvStats.exp.total, 'font-weight: bold;', expList, 'VZV Expanded Program Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('vzv_highRisk_total', vzvStats.highRisk.total, 'font-weight: bold;', [...new Set([...babiesList, ...immunoList])], 'VZV High Risk Total')}</td>
          </tr>
        </tbody>
      </table>

      <!-- 6. IMMUNITY TO POLIO -->
      <div style="background: #8EBAD1; padding: 6px 12px; font-weight: bold; border: 1px solid #70A7C4; border-bottom: none; font-family: Arial, sans-serif; font-size: 9pt; display: flex; justify-content: space-between;">
        <span>Immunity to Polio</span>
        <span style="font-weight: normal; font-size: 8pt; color: #1E293B;">One dose of polio vaccine (IPV or OPV) given after age 18 years documented or worker's declaration</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9pt; margin-bottom: 24px;">
        <thead>
          <tr style="background: #5C94B5; color: white; text-align: center; font-weight: bold;">
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 50%; text-align: left;">Vaccination program</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 25%;">Basic</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 25%;">Expanded</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented vaccination</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_basic_vac', polioStats.basic.vac, 'font-weight: bold;', getPolioList(basicList), 'Polio Vaccination — Basic Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_exp_vac', polioStats.exp.vac, 'font-weight: bold;', getPolioList(expList), 'Polio Vaccination — Expanded Program')}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented refusal</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_basic_ref', polioStats.basic.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_exp_ref', polioStats.exp.ref)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented contraindication</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_basic_contra', polioStats.basic.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_exp_contra', polioStats.exp.contra)}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees unvaccinated or without documented vaccination status</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_basic_unvac', polioStats.basic.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_exp_unvac', polioStats.exp.unvac)}</td>
          </tr>
          <tr style="background: #EBF3F8; font-weight: bold;">
            <td style="padding: 6px 8px; border: 1px solid #70A7C4;">Total</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_basic_total', polioStats.basic.total, 'font-weight: bold;', basicList, 'Polio Basic Program Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('polio_exp_total', polioStats.exp.total, 'font-weight: bold;', expList, 'Polio Expanded Program Total')}</td>
          </tr>
        </tbody>
      </table>

      <!-- 7. IMMUNITY TO HBV & HCV -->
      <div style="background: #8EBAD1; padding: 6px 12px; font-weight: bold; border: 1px solid #70A7C4; border-bottom: none; font-family: Arial, sans-serif; font-size: 9pt; display: flex; justify-content: space-between;">
        <span>Immunity to HBV</span>
        <span style="font-weight: normal; font-size: 7.5pt; color: #1E293B;">One of 4 options: 3 doses HBV | Routine childhood declaration (born Israel >= 1.1.1992) | Anti-HBs >= 100 mIU/ml | Post-infection immunity</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 8.5pt; margin-bottom: 24px;">
        <thead>
          <tr style="background: #5C94B5; color: white; text-align: center; font-weight: bold;">
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 46%; text-align: left;">Vaccination program</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 18%;">Basic</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 18%;">Expanded - No invasive procedures</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 18%;">Expanded - Invasive procedures (apapasach)</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented immunity</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_basic_immune', hbvBasic.immune, 'font-weight: bold;', getHBVList(basicList), 'HBV Immunity — Basic Program')}</td>
            <td style="background: #000; color: white; border: 1px solid #70A7C4;"></td>
            <td style="background: #000; color: white; border: 1px solid #70A7C4;"></td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented 3 doses of HBV vaccine and documented post-vaccination titer ≥ 10 mIU/ml (or ≥ 100 mIU/ml) without regard to number of vaccine doses</td>
            <td style="background: #000; color: white; border: 1px solid #70A7C4;"></td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expNoInv_immune', hbvExpNoInvasive.immune, 'font-weight: bold;', getHBVList(expNoInvasive), 'HBV Immunity — Expanded (No Invasive)')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expInv_immune', hbvExpInvasive.immune, 'font-weight: bold;', getHBVList(expInvasive), 'HBV Immunity — Expanded (Invasive Procedures)')}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees documented as non-responders after 6 HBV doses</td>
            <td style="background: #000; color: white; border: 1px solid #70A7C4;"></td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expNoInv_nonResp', hbvExpNoInvasive.nonResp)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expInv_nonResp', hbvExpInvasive.nonResp)}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees who are HBV carriers</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_basic_carrier', hbvBasic.carrier)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expNoInv_carrier', hbvExpNoInvasive.carrier)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expInv_carrier', hbvExpInvasive.carrier)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented refusal</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_basic_ref', hbvBasic.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expNoInv_ref', hbvExpNoInvasive.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expInv_ref', hbvExpInvasive.ref)}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented contraindication</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_basic_contra', hbvBasic.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expNoInv_contra', hbvExpNoInvasive.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expInv_contra', hbvExpInvasive.contra)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees unvaccinated or without documented vaccination status</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_basic_unvac', hbvBasic.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expNoInv_unvac', hbvExpNoInvasive.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expInv_unvac', hbvExpInvasive.unvac)}</td>
          </tr>
          <tr style="background: #EBF3F8; font-weight: bold;">
            <td style="padding: 6px 8px; border: 1px solid #70A7C4;">Total</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_basic_total', hbvBasic.total, 'font-weight: bold;', basicList, 'HBV Basic Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expNoInv_total', hbvExpNoInvasive.total, 'font-weight: bold;', expNoInvasive, 'HBV Expanded (No Invasive) Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hbv_expInv_total', hbvExpInvasive.total, 'font-weight: bold;', expInvasive, 'HBV Expanded (Invasive Procedures) Total')}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of unimmunized employees (including non-responders or with contraindication)</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('unimmud_basic', '')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('unimmud_expNoInv', '')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('unimmud_expInv', unimmudCount, 'font-weight: bold;')}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of unimmunized employees (including non-responders or with contraindication) with documented testing for carrier status (HBsAg + anti-HBc)</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('unimmudTested_basic', '')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('unimmudTested_expNoInv', '')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('unimmudTested_expInv', unimmudTestedCount, 'font-weight: bold;')}</td>
          </tr>
          <tr style="background: #FFEAD7;">
            <td style="padding: 6px 8px; border: 1px solid #70A7C4; font-weight: bold;">HCV serology: Number of employees with documented anti-HCV serology</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hcvSerology_basic', '')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hcvSerology_expNoInv', '')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('hcvSerology_expInv', hcvSerologyCount, 'color: #9A3412; font-size: 10pt; font-weight: bold;')}</td>
          </tr>
        </tbody>
      </table>

      <!-- 8. TUBERCULIN TESTING -->
      <div style="background: #8EBAD1; padding: 6px 12px; font-weight: bold; border: 1px solid #70A7C4; border-bottom: none; font-family: Arial, sans-serif; font-size: 9pt; display: flex; justify-content: space-between;">
        <span>Up to date tuberculin testing according to MOH circular 02/1997</span>
      </div>
      <table style="width: 100%; border-collapse: collapse; border: 1.5px solid #70A7C4; font-family: Arial, sans-serif; font-size: 9pt; margin-bottom: 24px;">
        <thead>
          <tr style="background: #5C94B5; color: white; text-align: center; font-weight: bold;">
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 50%; text-align: left;">Vaccination program</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 25%;">Basic</th>
            <th style="padding: 6px; border: 1px solid #70A7C4; width: 25%;">Expanded</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with current negative test</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_basic_neg', ppdStats.basic.neg, 'font-weight: bold;', getPPDNegList(basicList), 'PPD Negative — Basic Program')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_exp_neg', ppdStats.exp.neg, 'font-weight: bold;', getPPDNegList(expList), 'PPD Negative — Expanded Program')}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with history of positive test</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_basic_pos', ppdStats.basic.pos)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_exp_pos', ppdStats.exp.pos)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented refusal</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_basic_ref', ppdStats.basic.ref)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_exp_ref', ppdStats.exp.ref)}</td>
          </tr>
          <tr style="background: #F8FAFC;">
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees with documented contraindication</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_basic_contra', ppdStats.basic.contra)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_exp_contra', ppdStats.exp.contra)}</td>
          </tr>
          <tr>
            <td style="padding: 5px 8px; border: 1px solid #70A7C4;">Number of employees unvaccinated or without documented vaccination status</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_basic_unvac', ppdStats.basic.unvac)}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_exp_unvac', ppdStats.exp.unvac)}</td>
          </tr>
          <tr style="background: #EBF3F8; font-weight: bold;">
            <td style="padding: 6px 8px; border: 1px solid #70A7C4;">Total</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_basic_total', ppdStats.basic.total, 'font-weight: bold;', basicList, 'PPD Basic Total')}</td>
            <td style="padding: 3px; border: 1px solid #70A7C4; text-align: center;">${renderEditableMOHCell('ppd_exp_total', ppdStats.exp.total, 'font-weight: bold;', expList, 'PPD Expanded Total')}</td>
          </tr>
        </tbody>
      </table>
    </div>
  `;
}

// --------------------------------------------------------------------------
// 🎨 CHART INITIALIZATION FOR ALL TABLES (WITH TOOLTIP PERCENTAGES)
// --------------------------------------------------------------------------
function initDynamicDashboardCharts(topDepts, metrics) {
  if (typeof Chart === 'undefined' || !metrics) return;
  const isAr = (typeof window !== 'undefined' && window.i18n && typeof window.i18n.isRTL === 'function')
    ? window.i18n.isRTL()
    : (typeof document !== 'undefined' && document.documentElement.dir === 'rtl');

  // ⚡ PERFORMANCE BOOST: Disable multi-frame animation loops for instant 5ms chart rendering
  if (Chart.defaults) {
    Chart.defaults.animation = false;
  }

  const tooltipWithPct = {
    callbacks: {
      label: function(context) {
        const label = context.dataset.label || context.label || '';
        const val = context.parsed.y !== undefined ? context.parsed.y : context.parsed;
        const totalArr = context.dataset.data;
        const sum = totalArr.reduce((a, b) => (typeof a === 'number' && typeof b === 'number' ? a + b : 0), 0);
        const pct = sum > 0 ? Math.round((val / sum) * 100) : val;
        return `${label}: ${val} (${pct}%)`;
      }
    }
  };

  // Register data labels plugin so values & percentages appear directly on all diagrams
  if (typeof Chart !== 'undefined' && !Chart.registry.plugins.get('alwaysShowDataLabels')) {
    Chart.register({
      id: 'alwaysShowDataLabels',
      afterDatasetsDraw(chart) {
        try {
          const { ctx } = chart;
          const isHorizontal = chart.options && chart.options.indexAxis === 'y';
          chart.data.datasets.forEach((dataset, datasetIndex) => {
            if (dataset.skipDataLabels || dataset.borderDash) return;
            const meta = chart.getDatasetMeta(datasetIndex);
            if (meta && !meta.hidden && meta.data) {
              meta.data.forEach((element, index) => {
                const val = dataset.data[index];

                if (val !== undefined && val !== null) {
                  ctx.save();
                  ctx.font = 'bold 11px Inter, sans-serif';
                  ctx.fillStyle = '#1E293B';

                  const totalArr = dataset.data;
                  const sum = totalArr.reduce((a, b) => (typeof a === 'number' && typeof b === 'number' ? a + b : 0), 0);
                  const pct = sum > 0 ? Math.round((val / sum) * 100) : val;

                  let text = `${val}`;
                  if (typeof dataset.dataLabelFormatter === 'function') {
                    text = dataset.dataLabelFormatter(val, index);
                  } else if (dataset.yAxisID === 'yComp' || dataset.isPercentage) {
                    text = `${val}%`;
                  } else if (dataset.yAxisID === 'yCount') {
                    text = `${val}`;
                  } else if (chart.config.type === 'doughnut' || chart.config.type === 'pie') {
                    text = `${val} (${pct}%)`;
                  } else if (dataset.pctData && dataset.headcountData) {
                    const p = dataset.pctData[index];
                    const h = dataset.headcountData[index];
                    text = `${p}% (${h})`;
                  } else if (chart.options.isPercentageChart || (chart.options.scales && chart.options.scales.y && chart.options.scales.y.max >= 100) || (chart.options.scales && chart.options.scales.x && chart.options.scales.x.max >= 100)) {
                    text = `${val}%`;
                  }

                  const pos = (element && typeof element.tooltipPosition === 'function') 
                    ? element.tooltipPosition() 
                    : (element ? { x: element.x, y: element.y } : null);

                  if (pos && typeof pos.x === 'number' && typeof pos.y === 'number' && !isNaN(pos.x) && !isNaN(pos.y)) {
                    // Callout Box Pill for Relevant Element Counts on Dual Axis Charts
                    if (dataset.calloutBadge || dataset.yAxisID === 'yCount') {
                      ctx.font = 'bold 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                      const textMetrics = ctx.measureText(text);
                      const badgeW = Math.max(20, textMetrics.width + 10);
                      const badgeH = 18;

                      let badgeX = pos.x - badgeW / 2;
                      let badgeY = pos.y - badgeH - 5;

                      // If near top of a 100% bar (like Figure 4), offset badge to right so it never collides with bar % label
                      const barVal = (chart.data.datasets[0] && chart.data.datasets[0].data) ? chart.data.datasets[0].data[index] : null;
                      if (dataset.labelOffsetRight || (barVal >= 80 && val >= 4)) {
                        badgeX = pos.x + 8;
                        badgeY = pos.y - badgeH / 2;
                      }

                      ctx.fillStyle = '#FFFFFF';
                      ctx.strokeStyle = dataset.borderColor || '#DC2626';
                      ctx.lineWidth = 1.5;
                      if (typeof ctx.roundRect === 'function') {
                        ctx.beginPath();
                        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 4);
                        ctx.fill();
                        ctx.stroke();
                      } else {
                        ctx.fillRect(badgeX, badgeY, badgeW, badgeH);
                        ctx.strokeRect(badgeX, badgeY, badgeW, badgeH);
                      }
                      ctx.fillStyle = dataset.dataLabelColor || '#DC2626';
                      ctx.textAlign = 'center';
                      ctx.textBaseline = 'middle';
                      ctx.fillText(text, badgeX + badgeW / 2, badgeY + badgeH / 2);
                      ctx.restore();
                      return;
                    }

                    // Smart Position determination
                    let labelPos = dataset.dataLabelPosition;
                    if (!labelPos) {
                      if (chart.config.type === 'line' && chart.data.datasets.length > 1) {
                        labelPos = (datasetIndex % 2 === 0) ? 'top' : 'bottom';
                      } else {
                        labelPos = isHorizontal ? 'right' : 'top';
                      }
                    }

                    // Font & Color matching the line dataset
                    const labelColor = dataset.dataLabelColor 
                      || ((chart.config.type === 'line' || dataset.type === 'line') && dataset.borderColor && typeof dataset.borderColor === 'string' ? dataset.borderColor : '#1E293B');
                    ctx.font = 'bold 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

                    let targetX = pos.x;
                    let targetY = pos.y;

                    if (labelPos === 'bottom') {
                      ctx.textAlign = 'center';
                      ctx.textBaseline = 'top';
                      targetY = pos.y + 7;
                    } else if (labelPos === 'left') {
                      ctx.textAlign = 'right';
                      ctx.textBaseline = 'middle';
                      targetX = pos.x - 7;
                    } else if (labelPos === 'right') {
                      ctx.textAlign = 'left';
                      ctx.textBaseline = 'middle';
                      targetX = pos.x + 7;
                    } else {
                      // 'top' (default)
                      ctx.textAlign = 'center';
                      ctx.textBaseline = 'bottom';
                      targetY = Math.max(12, pos.y - 6);
                    }

                    // White halo stroke for maximum clarity over lines and grid
                    ctx.strokeStyle = '#FFFFFF';
                    ctx.lineWidth = 3.5;
                    ctx.lineJoin = 'round';
                    ctx.strokeText(text, targetX, targetY);

                    ctx.fillStyle = labelColor;
                    ctx.fillText(text, targetX, targetY);
                  }
                  ctx.restore();
                }
              });

              // Standalone pass for #N/A badges on compliance bar datasets where data[index] === null
              if (dataset.yAxisID === 'yComp' || dataset.showNA) {
                dataset.data.forEach((nullVal, nullIdx) => {
                  if (nullVal === null) {
                    ctx.save();
                    const xScale = chart.scales.x;
                    const x = xScale ? xScale.getPixelForTick(nullIdx) : null;
                    if (x !== null && !isNaN(x)) {
                      const bottomY = chart.chartArea ? chart.chartArea.bottom : 220;
                      const badgeW = 42;
                      const badgeH = 18;
                      const badgeX = x - badgeW / 2;
                      const badgeY = bottomY - 32;

                      ctx.fillStyle = '#F8FAFC';
                      ctx.strokeStyle = '#94A3B8';
                      ctx.lineWidth = 1;
                      if (typeof ctx.roundRect === 'function') {
                        ctx.beginPath();
                        ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 4);
                        ctx.fill();
                        ctx.stroke();
                      } else {
                        ctx.fillRect(badgeX, badgeY, badgeW, badgeH);
                        ctx.strokeRect(badgeX, badgeY, badgeW, badgeH);
                      }
                      ctx.font = 'bold 10px Inter, sans-serif';
                      ctx.fillStyle = '#475569';
                      ctx.textAlign = 'center';
                      ctx.textBaseline = 'middle';
                      ctx.fillText('#N/A', x, badgeY + badgeH / 2);
                    }
                    ctx.restore();
                  }
                });
              }
            }
          });
        } catch (err) {
          // Fail silently without breaking chart rendering
        }
      }
    });
  }

  const destroyExistingChart = (canvasEl) => {
    if (!canvasEl || typeof Chart === 'undefined') return;
    const existingChart = Chart.getChart(canvasEl);
    if (existingChart) existingChart.destroy();
  };

  // Chart 1: Staff Group Breakdown (Doughnut)
  const sgCtx = document.getElementById('staffGroupChart');
  if (sgCtx) {
    destroyExistingChart(sgCtx);
    new Chart(sgCtx, {
      type: 'doughnut',
      data: {
        labels: [
          `Basic Plan (${metrics.staffGroup.basicPct}%)`,
          `Minimum Plan (${metrics.staffGroup.minPct}%)`,
          `Extended Program (${metrics.staffGroup.extPct}%)`
        ],
        datasets: [{
          data: [metrics.staffGroup.basicPlan, metrics.staffGroup.minPlan, metrics.staffGroup.extProgram],
          backgroundColor: ['#0284C7', '#38BDF8', '#0369A1']
        }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' }, tooltip: tooltipWithPct } }
    });
  }

  // Chart 2: High Risk Treating Depts (Pie)
  const tdCtx = document.getElementById('treatingDeptChart');
  if (tdCtx) {
    destroyExistingChart(tdCtx);
    new Chart(tdCtx, {
      type: 'pie',
      data: {
        labels: [
          `Oncology/Hemato (${metrics.treatingDepts.oncologyPct}%)`,
          `Babies under 1 Yr (${metrics.treatingDepts.babiesPct}%)`,
          `General Staff (${metrics.treatingDepts.otherPct}%)`
        ],
        datasets: [{
          data: [metrics.treatingDepts.oncologyDept, metrics.treatingDepts.babiesUnder1, metrics.treatingDepts.otherDept],
          backgroundColor: ['#7C3AED', '#F59E0B', '#64748B']
        }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' }, tooltip: tooltipWithPct } }
    });
  }

  // Chart 1C: Staff Gender Breakdown (Doughnut)
  const sgGenderCtx = document.getElementById('staffGenderChart');
  if (sgGenderCtx && metrics.gender) {
    destroyExistingChart(sgGenderCtx);
    new Chart(sgGenderCtx, {
      type: 'doughnut',
      data: {
        labels: [
          `Male - ذكور (${metrics.gender.malePct}%)`,
          `Female - إناث (${metrics.gender.femalePct}%)`
        ],
        datasets: [{
          data: [metrics.gender.male, metrics.gender.female],
          backgroundColor: ['#0284C7', '#DB2777']
        }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' }, tooltip: tooltipWithPct } }
    });
  }

  // Chart 3: HBsAb Serology Status (Doughnut)
  const hbsCtx = document.getElementById('hbsabChart');
  if (hbsCtx) {
    destroyExistingChart(hbsCtx);
    new Chart(hbsCtx, {
      type: 'doughnut',
      data: {
        labels: [
          `Immune (anti-HBs ≥10 mIU/mL) (${metrics.hbsab.immunePct}%)`,
          `Vaccination in progress (${metrics.hbsab.vaccinatingPct}%)`,
          `Vaccine non-responder (${metrics.hbsab.resistancePct}%)`,
          `Immunity status unknown (${metrics.hbsab.ongoingPct}%)`,
          `Vaccination not indicated under MOH guidelines (${metrics.hbsab.noNeedPct}%)`
        ],
        datasets: [{
          data: [metrics.hbsab.hbsImmune, metrics.hbsab.hbsVaccinating, metrics.hbsab.hbsResistance, metrics.hbsab.hbsOngoing, metrics.hbsab.hbsNoNeed],
          backgroundColor: ['#10B981', '#F59E0B', '#EF4444', '#D97706', '#94A3B8']
        }]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' }, tooltip: tooltipWithPct } }
    });
  }

  // Chart 4: Lab Screening Results (HCV, HIV, PPD: Positive, Negative, Ongoing)
  const labCtx = document.getElementById('labScreeningChart');
  if (labCtx) {
    destroyExistingChart(labCtx);
    const maxVal = Math.max(
      metrics.labScreening.hcvPos, metrics.labScreening.hcvNeg, metrics.labScreening.hcvOngoing,
      metrics.labScreening.hivPos, metrics.labScreening.hivNeg, metrics.labScreening.hivOngoing,
      metrics.labScreening.ppdPos, metrics.labScreening.ppdNeg, metrics.labScreening.ppdOngoing,
      metrics.total || 0
    );
    const labYMax = Math.ceil((maxVal > 0 ? maxVal : 500) * 1.22);
    new Chart(labCtx, {
      type: 'bar',
      data: {
        labels: ['HCV Result', 'HIV Result', 'PPD Result'],
        datasets: [
          { label: 'Positive Result', data: [metrics.labScreening.hcvPos, metrics.labScreening.hivPos, metrics.labScreening.ppdPos], backgroundColor: '#EF4444' },
          { label: 'Negative Result', data: [metrics.labScreening.hcvNeg, metrics.labScreening.hivNeg, metrics.labScreening.ppdNeg], backgroundColor: '#10B981' },
          { label: 'Ongoing / Pending', data: [metrics.labScreening.hcvOngoing, metrics.labScreening.hivOngoing, metrics.labScreening.ppdOngoing], backgroundColor: '#F59E0B' }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
          padding: { top: 24, bottom: 4 }
        },
        scales: {
          y: {
            beginAtZero: true,
            grace: '20%',
            suggestedMax: labYMax,
            ticks: { precision: 0 }
          }
        },
        plugins: {
          legend: { position: 'bottom' },
          tooltip: tooltipWithPct
        }
      }
    });
  }

  // Chart 4B: Varicella (Chickenpox) Immunity Status Chart (Default Pie/Doughnut or Bar with Scaled Bounds)
  if (typeof renderVaricellaChart === 'function') {
    renderVaricellaChart(window.currentVaricellaChartType || 'doughnut', metrics.varicella);
  }

  // Auto-render default Ongoing / Pending list for Varicella follow-up
  if (typeof renderVaricellaCategoryList === 'function') {
    renderVaricellaCategoryList('ongoing');
  }

  // Chart 5: Core Vaccine Compliance (Bar)
  const cvCtx = document.getElementById('coreVacChart');
  if (cvCtx) {
    destroyExistingChart(cvCtx);
    new Chart(cvCtx, {
      type: 'bar',
      data: {
        labels: [
          `IPV (${metrics.coreVac.ipv.pct}%)`,
          `Tdap (${metrics.coreVac.tdap.pct}%)`,
          `MMR 1 (${metrics.coreVac.mmr1.pct}%)`,
          `MMR 2 (${metrics.coreVac.mmr2.pct}%)`,
          `Chickenpox (${metrics.coreVac.cp.pct}%)`
        ],
        datasets: [{
          label: 'Compliance Rate %',
          data: [metrics.coreVac.ipv.pct, metrics.coreVac.tdap.pct, metrics.coreVac.mmr1.pct, metrics.coreVac.mmr2.pct, metrics.coreVac.cp.pct],
          backgroundColor: '#0284C7',
          borderRadius: 6
        }]
      },
      options: { responsive: true, maintainAspectRatio: false, scales: { y: { max: 100, min: 0 } }, plugins: { legend: { position: 'bottom' }, tooltip: tooltipWithPct } }
    });
  }

  // Chart 6: Special Vaccine Compliance (Bar)
  const svCtx = document.getElementById('specialVacChart');
  if (svCtx) {
    destroyExistingChart(svCtx);
    new Chart(svCtx, {
      type: 'bar',
      data: {
        labels: [
          `Meningococcal (${metrics.specialVac.men.pct}%)`,
          `Hep A 1 (${metrics.specialVac.hepA1.pct}%)`,
          `Hep A 2 (${metrics.specialVac.hepA2.pct}%)`,
          `Typhoid (${metrics.specialVac.typ.pct}%)`,
          `Pneumovax (${metrics.specialVac.pne.pct}%)`
        ],
        datasets: [{
          label: `Special Target Staff Compliance Rate % (${metrics.specialVac.total} Laboratory & Pathology Staff)`,
          data: [metrics.specialVac.men.pct, metrics.specialVac.hepA1.pct, metrics.specialVac.hepA2.pct, metrics.specialVac.typ.pct, metrics.specialVac.pne.pct],
          backgroundColor: '#059669',
          borderRadius: 6
        }]
      },
      options: { responsive: true, maintainAspectRatio: false, scales: { y: { max: 100, min: 0 } }, plugins: { legend: { position: 'bottom' }, tooltip: tooltipWithPct } }
    });
  }

  // Chart 7: Overall Department Compliance (Full Landscape Vertical Column Diagram with 5 Department Groups + Total Coverage)
  const deptCtx = document.getElementById('deptChart');
  if (deptCtx) {
    try {
      destroyExistingChart(deptCtx);
      if (window.myDeptChartInstance) {
        window.myDeptChartInstance.destroy();
        window.myDeptChartInstance = null;
      }
      const activeData = [...((metrics && metrics.deptGroupStats) || [])];

    // Append 6th column: Total Hospital Coverage
    if (metrics.total > 0) {
      const totImm = activeData.reduce((a, b) => a + b.immune, 0);
      const totStaff = metrics.total;
      const totPct = Number(((totImm / totStaff) * 100).toFixed(1));
      activeData.push({
        code: 'all',
        name: isAr ? '\u0625\u062c\u0645\u0627\u0644\u064a \u0643\u0627\u062f\u0631 \u0627\u0644\u0645\u0633\u062a\u0634\u0641\u0649' : 'Total Hospital Staff',
        nameEn: 'Total Hospital Staff',
        nameAr: '\u0625\u062c\u0645\u0627\u0644\u064a \u0643\u0627\u062f\u0631 \u0627\u0644\u0645\u0633\u062a\u0634\u0641\u0649',
        total: totStaff,
        immune: totImm,
        pct: totPct
      });
    }

    // Crisp 2-line category labels for vertical column diagram
    const deptLabels = activeData.map(d => {
      if (isAr) {
        if (d.code === 'doctors') return ['\u0627\u0644\u0623\u0637\u0628\u0627\u0621', '\u0648\u0627\u0644\u0623\u062e\u0635\u0627\u0626\u064a\u0648\u0646'];
        if (d.code === 'nursing') return ['\u0643\u0627\u062f\u0631', '\u0627\u0644\u062a\u0645\u0631\u064a\u0636'];
        if (d.code === 'allied') return ['\u0627\u0644\u0645\u0647\u0646 \u0627\u0644\u0637\u0628\u064a\u0629', '\u0627\u0644\u0645\u0633\u0627\u0646\u062f\u0629'];
        if (d.code === 'general') return ['\u0627\u0644\u062e\u062f\u0645\u0627\u062a \u0627\u0644\u0639\u0627\u0645\u0629', '\u0648\u0627\u0644\u0635\u064a\u0627\u0646\u0629'];
        if (d.code === 'admin') return ['\u0627\u0644\u0625\u062f\u0627\u0631\u0629', '\u0648\u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a'];
        if (d.code === 'all') return ['\u0625\u062c\u0645\u0627\u0644\u064a \u0643\u0627\u062f\u0631', '\u0627\u0644\u0645\u0633\u062a\u0634\u0641\u0649'];
      } else {
        if (d.code === 'doctors') return ['Medical Doctors', '& Specialists'];
        if (d.code === 'nursing') return ['Nursing', 'Staff'];
        if (d.code === 'allied') return ['Allied Health', 'Professionals'];
        if (d.code === 'general') return ['General Services', '& Support'];
        if (d.code === 'admin') return ['Administration', '& Operations'];
        if (d.code === 'all') return ['Total Hospital', 'Staff'];
      }
      return d.name || '';
    });

    const deptData = activeData.map(d => d.pct);
    const deptHeadcounts = activeData.map(d => `${d.immune}/${d.total} vaccinated`);
    const bgColors = ['#0284C7', '#059669', '#7C3AED', '#D97706', '#475569', '#1A5F7A'];
    const borderColors = ['#0369A1', '#047857', '#6D28D9', '#B45309', '#334155', '#113F52'];

    if (window.myDeptChartInstance) {
      window.myDeptChartInstance.destroy();
    }

    window.myDeptChartInstance = new Chart(deptCtx, {
      type: 'bar',
      data: {
        labels: deptLabels,
        datasets: [{
          label: isAr ? '\u0646\u0633\u0628\u0629 \u0627\u0644\u062a\u0637\u0639\u064a\u0645 \u0648\u0627\u0644\u0645\u0646\u0627\u0639\u0629 (\u0627\u0644\u0645\u0644\u0642\u062d\u064a\u0646 \u00f7 \u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0641\u0626\u0629) %' : 'Vaccinated Compliance Rate % (Vaccinated \u00f7 Total Category)',
          data: deptData,
          backgroundColor: bgColors.slice(0, activeData.length),
          borderColor: borderColors.slice(0, activeData.length),
          borderWidth: 1.5,
          borderRadius: { topLeft: 8, topRight: 8, bottomLeft: 0, bottomRight: 0 },
          borderSkipped: 'bottom',
          barPercentage: 0.52,
          categoryPercentage: 0.75
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        isPercentageChart: true,
        onClick: function(evt, elements) {
          if (elements && elements.length > 0) {
            const index = elements[0].index;
            const grp = activeData[index];
            if (grp && grp.code) {
              if (grp.code === 'all') {
                openMOHCellStaffModal('dept_group_all');
              } else {
                openMOHCellStaffModal('dept_group_' + grp.code);
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: {
              font: { size: 12, weight: 'bold' },
              color: '#1E293B',
              autoSkip: false
            }
          },
          y: {
            max: 110,
            min: 0,
            ticks: {
              stepSize: 20,
              callback: function(v) { return v <= 100 ? v + '%' : ''; },
              font: { weight: 'bold', size: 11 },
              color: '#475569'
            },
            grid: { color: '#E2E8F0' }
          }
        },
        plugins: {
          legend: { 
            position: 'top', 
            labels: { font: { weight: 'bold', size: 12 }, boxWidth: 16 } 
          },
          tooltip: {
            callbacks: {
              title: function(items) {
                if (!items || !items.length) return '';
                const idx = items[0].dataIndex;
                const grp = activeData[idx];
                return grp ? (isAr ? (grp.nameAr || grp.name) : (grp.nameEn || grp.name)) : '';
              },
              label: function(context) {
                const idx = context.dataIndex;
                const grp = activeData[idx];
                if (grp) {
                  return isAr 
                    ? ` \u0646\u0633\u0628\u0629 \u0627\u0644\u062a\u0637\u0639\u064a\u0645: ${grp.pct}% (${grp.immune}/${grp.total} \u0645\u0648\u0638\u0641 \u0645\u062d\u0635\u0646)`
                    : ` Vaccination Rate: ${grp.pct}% (${grp.immune}/${grp.total} vaccinated staff)`;
                }
                return ` ${context.parsed.y}%`;
              }
            }
          }
        }
      }
    });
    } catch (chartErr) {
      console.error('Error rendering deptChart:', chartErr);
    }
  }

  // Chart 8: Incidents Trend (Full Portal Diagram with Points & Print Support - QI Run Chart)
  const incidentCtx = document.getElementById('incidentChart');
  if (incidentCtx) {
    try {
      destroyExistingChart(incidentCtx);
      const incCounts = (metrics.monthlyIncidents.counts || metrics.monthlyIncidents.data || [0,0,0,0,0,0,0,0,0,0,0,0]);
      const incLabels = metrics.monthlyIncidents.labels || ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const totInc = incCounts.reduce((a, b) => a + b, 0);
      const meanVal = Number((totInc / Math.max(1, incCounts.length)).toFixed(2));
      const centerLine = incCounts.map(() => meanVal);
      const maxY = Math.max(3, ...incCounts) + 1;

      new Chart(incidentCtx, {
        type: 'line',
        data: {
          labels: incLabels,
          datasets: [
            {
              label: isAr ? '\u0628\u0644\u0627\u063a\u0627\u062a \u062d\u0648\u0627\u062f\u062b \u0627\u0644\u0648\u062e\u0632 \u0648\u062a\u0644\u0648\u062b \u0627\u0644\u062f\u0645' : 'Blood & Sharps Exposure Incidents',
              data: incCounts,
              borderColor: '#DC2626',
              backgroundColor: 'rgba(220, 38, 38, 0.10)',
              borderWidth: 2.8,
              pointRadius: 6,
              pointHoverRadius: 9,
              pointBackgroundColor: '#DC2626',
              pointBorderColor: '#FFFFFF',
              pointBorderWidth: 2,
              fill: true,
              tension: 0.25
            },
            {
              label: isAr ? `\u062e\u0637 \u0627\u0644\u0648\u0633\u0637 (Centerline Mean = ${meanVal})` : `Centerline (Mean Baseline = ${meanVal})`,
              data: centerLine,
              borderColor: '#64748B',
              borderWidth: 1.8,
              borderDash: [6, 4],
              pointRadius: 0,
              pointHoverRadius: 0,
              fill: false,
              tension: 0,
              skipDataLabels: true
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              grid: { color: '#F1F5F9' },
              ticks: {
                font: { size: 12, weight: 'bold' },
                color: '#1E293B',
                autoSkip: false
              }
            },
            y: {
              min: 0,
              suggestedMax: maxY,
              beginAtZero: true,
              ticks: { precision: 0, stepSize: 1, font: { weight: 'bold', size: 11 }, color: '#475569' },
              grid: { color: '#E2E8F0' }
            }
          },
          plugins: {
            legend: { 
              position: 'top', 
              labels: { font: { weight: 'bold', size: 12 }, boxWidth: 20 } 
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  return ` ${context.dataset.label}: ${context.parsed.y} incidents`;
                }
              }
            }
          }
        }
      });
    } catch (incErr) {
      console.error('Error rendering incidentChart run chart:', incErr);
    }
  }

    // Chart 4C: Seasonal Flu Vaccine 2024-2025 Compliance Chart
  if (typeof renderFlu2425Chart === 'function') {
    renderFlu2425Chart(metrics, window.currentFluChartType || 'doughnut');
  }

  // Keep Seasonal Flu Category List collapsed by default on initial dashboard render
  const fluContainer = document.getElementById('flu2425CategoryListContainer');
  if (fluContainer) {
    fluContainer.style.display = 'none';
    delete fluContainer.dataset.activeCategory;
  }
}

// --------------------------------------------------------------------------
// 🦠 VARICELLA CATEGORY INTERACTIVE FOLLOW-UP LIST RENDERER & PRINTER
// --------------------------------------------------------------------------
function renderVaricellaCategoryList(categoryKey) {
  const container = document.getElementById('varicellaCategoryListContainer');
  if (!container || !window.varicellaMetricsData) return;

  const data = window.varicellaMetricsData;
  let catName = '';
  let list = [];
  let badgeColor = '#059669';

  if (categoryKey === 'doses2') {
    catName = '💉 Vaccinated (2 Doses)';
    list = data.doses2List || [];
    badgeColor = '#059669';
  } else if (categoryKey === 'posIgG') {
    catName = '🧪 Positive Serology (Positive IgG)';
    list = data.posIgGList || [];
    badgeColor = '#7C3AED';
  } else if (categoryKey === 'natImm') {
    catName = '🛡️ Natural Immunity Declaration';
    list = data.natImmList || [];
    badgeColor = '#0284C7';
  } else {
    catName = '⏳ Ongoing / Pending (Action & Follow-up Needed)';
    list = data.ongoingList || [];
    badgeColor = '#D97706';
  }

  container.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #CBD5E1; padding-bottom: 6px;">
      <div style="font-size: 0.9rem; font-weight: 800; color: ${badgeColor};">
        📋 Follow-Up Staff List: ${catName} (${list.length} Staff)
      </div>
      <div style="display: flex; gap: 6px;">
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: #ECFDF5; color: #047857; font-weight: bold; border: 1px solid #059669;" onclick="if(typeof filterByVaricellaCategory === 'function') filterByVaricellaCategory('${categoryKey}')">🔍 Filter Master Table</button>
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: white;" onclick="window.printVaricellaList('${categoryKey}')">🖨️ Print List</button>
      </div>
    </div>
    <div style="max-height: 280px; overflow-y: auto; background: white; border: 1px solid #E2E8F0; border-radius: 6px;">
      <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 8.5pt;">
        <thead>
          <tr style="background: #F8FAFC; color: #475569; position: sticky; top: 0;">
            <th style="padding: 6px; border: 1px solid #E2E8F0; width: 40px; text-align: center;">#</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Staff Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">Person # / ID</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Organization Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Job Title / Group</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">Varicella Detail</th>
          </tr>
        </thead>
        <tbody>
          ${list.length === 0 ? `
            <tr><td colspan="6" style="padding: 12px; text-align: center; color: #64748B;">No employees found in this category.</td></tr>
          ` : list.map((emp, idx) => {
            const demo = emp.demographic || {};
            const vac = emp.vaccines || {};
            const lab = emp.labResults || {};
            const detail = vac.chickenpoxStatus || vac.chickenpoxDose2 || lab.varicellaIgG || vac.varicellaIgG || 'Blank / Pending';
            return `
              <tr style="background: ${idx % 2 === 0 ? '#FFFFFF' : '#F9FAFB'};">
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${idx + 1}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; font-weight: bold; color: #1E293B;">${emp.name || demo.fullName || 'Unnamed'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-family: monospace; font-weight: bold; color: #0284C7;">${emp.empNo || demo.personNo || emp.idNo || demo.idNo || 'N/A'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || 'Augusta Victoria Hospital'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${emp.staffGroup || demo.jobTitle || 'Staff'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold; color: ${badgeColor};">${detail}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}
window.renderVaricellaCategoryList = renderVaricellaCategoryList;

function printVaricellaList(categoryKey) {
  const data = window.varicellaMetricsData;
  if (!data) return;
  
  let catName = 'Immunity status unknown (no anti-HBs result) Staff List';
  let list = data.ongoingList || [];

  if (categoryKey === 'doses2') { catName = 'Vaccinated (2 Doses) Staff List'; list = data.doses2List || []; }
  else if (categoryKey === 'posIgG') { catName = 'Positive Serology (Positive IgG) Staff List'; list = data.posIgGList || []; }
  else if (categoryKey === 'natImm') { catName = 'Natural Immunity Declaration Staff List'; list = data.natImmList || []; }

  const printWin = window.open('', '_blank', 'width=950,height=750');
  if (!printWin) {
    const container = document.getElementById('varicellaCategoryListContainer');
    if (container && window.AVHPrintController) {
      window.AVHPrintController.printContainer(container, { mode: 'landscape' });
      return;
    }
    alert('The print window was blocked by your browser. Please allow popups and try again.');
    return;
  }
  printWin.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Varicella Follow-up Report — ${catName}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; color: #1E293B; background: white; }
          h2 { color: #059669; border-bottom: 2px solid #059669; padding-bottom: 8px; }
          table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 9pt; }
          th, td { border: 1px solid #CBD5E1; padding: 6px; text-align: left; }
          th { background: #F1F5F9; font-weight: bold; }
          .no-print { margin-bottom: 15px; display: flex; justify-content: flex-end; gap: 8px; }
          .btn-print { padding: 6px 14px; background: #059669; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; }
          .btn-close { padding: 6px 14px; background: #64748B; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; }
          @media print {
            .no-print { display: none !important; }
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div class="no-print">
          <button class="btn-print" onclick="window.print()">🖨️ Print Now / طباعة الآن</button>
          <button class="btn-close" onclick="window.close()">✕ Close / إغلاق</button>
        </div>
        <div style="text-align: center; margin-bottom: 16px;">
          <h3>Augusta Victoria Hospital | Infectious Disease Unit</h3>
          <h2>Varicella (Chickenpox) Surveillance Report: ${catName}</h2>
          <p>Total Staff in List: <strong>${list.length}</strong> | Date: <strong>${new Date().toLocaleDateString()}</strong></p>
        </div>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Staff Name</th>
              <th>Person # / ID</th>
              <th>Organization Name</th>
              <th>Job Title</th>
              <th>Varicella Detail / Status</th>
            </tr>
          </thead>
          <tbody>
            ${list.map((emp, i) => {
              const demo = emp.demographic || {};
              const vac = emp.vaccines || {};
              const lab = emp.labResults || {};
              const detail = vac.chickenpoxStatus || vac.chickenpoxDose2 || lab.varicellaIgG || 'Blank / Pending';
              return `
                <tr>
                  <td>${i + 1}</td>
                  <td><strong>${emp.name || demo.fullName || ''}</strong></td>
                  <td>${emp.empNo || demo.personNo || ''}</td>
                  <td>${demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || 'Augusta Victoria Hospital'}</td>
                  <td>${emp.staffGroup || demo.jobTitle || ''}</td>
                  <td>${detail}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
        <script>
          window.onafterprint = function() { window.close(); };
          setTimeout(function() {
            try { window.focus(); window.print(); } catch(e) {}
          }, 300);
        </script>
      </body>
    </html>
  `);
  printWin.document.close();
  printWin.focus();
  setTimeout(() => {
    try { printWin.focus(); printWin.print(); } catch(e) {}
  }, 400);
}
window.printVaricellaList = printVaricellaList;

// --------------------------------------------------------------------------
// 🦠 DYNAMIC VARICELLA CHART RENDERER (PIE/DOUGHNUT VS SCALED BAR CHART)
// --------------------------------------------------------------------------
window.currentVaricellaChartType = 'doughnut';

function renderVaricellaChart(chartType, metricsData) {
  const canvas = document.getElementById('varicellaChart');
  if (!canvas || typeof Chart === 'undefined') return;

  const data = metricsData || window.varicellaMetricsData;
  if (!data) return;

  if (window.varicellaChartInstance) {
    window.varicellaChartInstance.destroy();
  }

  const activeType = chartType || window.currentVaricellaChartType || 'doughnut';
  window.currentVaricellaChartType = activeType;

  const btnPie = document.getElementById('btn_varicella_pie');
  const btnBar = document.getElementById('btn_varicella_bar');
  if (btnPie && btnBar) {
    if (activeType === 'doughnut' || activeType === 'pie') {
      btnPie.style.background = '#059669'; btnPie.style.color = 'white';
      btnBar.style.background = 'white'; btnBar.style.color = '#059669';
    } else {
      btnBar.style.background = '#059669'; btnBar.style.color = 'white';
      btnPie.style.background = 'white'; btnPie.style.color = '#059669';
    }
  }

  const ctx = canvas.getContext('2d');
  const isPie = (activeType === 'doughnut' || activeType === 'pie');

  const pcts = [
    parseFloat(data.doses2Pct) || 0,
    parseFloat(data.posIgGPct) || 0,
    parseFloat(data.natImmPct) || 0,
    parseFloat(data.ongoingPct) || 0
  ];

  const counts = [
    data.doses2Count || 0,
    data.posIgGCount || 0,
    data.natImmCount || 0,
    data.ongoingCount || 0
  ];

  const labels = [
    `Vaccinated 2 Doses`,
    `Positive IgG`,
    `Natural Immunity`,
    `Ongoing / Pending`
  ];
  const colors = ['#059669', '#7C3AED', '#0284C7', '#D97706'];

  if (isPie) {
    window.varicellaChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels.map((l, i) => `${l} (${pcts[i]}%)`),
        datasets: [{
          data: counts,
          backgroundColor: colors,
          borderWidth: 2,
          borderColor: '#ffffff',
          pctData: pcts,
          headcountData: counts
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { font: { size: 10, weight: 'bold' }, boxWidth: 12 }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const idx = context.dataIndex;
                return ` ${labels[idx]}: ${pcts[idx]}% (${counts[idx]} staff)`;
              }
            }
          }
        }
      }
    });
  } else {
    // BAR CHART PLOTTED IN PERCENTAGE (%) WITH PERCENTAGE Y-AXIS & CALLOUTS
    const maxPct = Math.max(...pcts);
    const suggestedMax = Math.min(100, Math.ceil((maxPct * 1.15) / 10) * 10 || 100);

    window.varicellaChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Immunity Percentage %',
          data: pcts, // Plotted in percentage (%)!
          backgroundColor: colors,
          borderRadius: 6,
          barThickness: 28,
          pctData: pcts,
          headcountData: counts
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        isPercentageChart: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: function(context) {
                const idx = context.dataIndex;
                return ` ${labels[idx]}: ${pcts[idx]}% (${counts[idx]} staff)`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            min: 0,
            max: suggestedMax,
            ticks: {
              callback: function(v) { return v + '%'; },
              font: { size: 10, weight: 'bold' }
            },
            grid: { color: '#E2E8F0' }
          },
          x: {
            ticks: { font: { size: 9, weight: 'bold' } }
          }
        }
      }
    });
  }
}
window.renderVaricellaChart = renderVaricellaChart;

function toggleVaricellaChartType(type) {
  window.currentVaricellaChartType = type;
  renderVaricellaChart(type);
}
window.toggleVaricellaChartType = toggleVaricellaChartType;

// --------------------------------------------------------------------------
// 🩸 HBsAb CATEGORY INTERACTIVE FOLLOW-UP LIST RENDERER & PRINTER
// --------------------------------------------------------------------------
function renderHBsAbCategoryList(categoryKey) {
  const container = document.getElementById('hbsabCategoryListContainer');
  if (!container || !window.hbsabMetricsData) return;

  const data = window.hbsabMetricsData;
  let catName = '';
  let list = [];
  let badgeColor = '#D97706';

  if (categoryKey === 'immune') {
    catName = 'Immune (anti-HBs ≥10 mIU/mL)';
    list = data.immuneList || [];
    badgeColor = '#059669';
  } else if (categoryKey === 'vaccinating') {
    catName = 'Vaccination in progress';
    list = data.vaccinatingList || [];
    badgeColor = '#D97706';
  } else if (categoryKey === 'resistance') {
    catName = 'Vaccine non-responder';
    list = data.resistanceList || [];
    badgeColor = '#DC2626';
  } else if (categoryKey === 'noNeed') {
    catName = 'Vaccination not indicated under MOH guidelines';
    list = data.noNeedList || [];
    badgeColor = '#64748B';
  } else {
    catName = 'Immunity status unknown (no anti-HBs result)';
    list = data.ongoingList || [];
    badgeColor = '#B45309';
  }

  container.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #CBD5E1; padding-bottom: 6px;">
      <div style="font-size: 0.9rem; font-weight: 800; color: ${badgeColor};">
        📋 Follow-Up Staff List: ${catName} (${list.length} Staff)
      </div>
      <div style="display: flex; gap: 6px;">
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: #DC2626; color: white; font-weight: bold; border: none;" onclick="if(typeof openUnvaccinatedFollowupReport === 'function') openUnvaccinatedFollowupReport('${categoryKey === 'vaccinating' ? 'HBSAB_IN_PROGRESS' : 'HEPB'}')">📋 Action Report</button>
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: #FFFBEB; color: #B45309; font-weight: bold; border: 1px solid #D97706;" onclick="if(typeof filterByHBsAbCategory === 'function') filterByHBsAbCategory('${categoryKey}')">🔍 Filter Master Table</button>
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: white;" onclick="window.printHBsAbList('${categoryKey}')">🖨️ Print List</button>
      </div>
    </div>
    <div style="max-height: 280px; overflow-y: auto; background: white; border: 1px solid #E2E8F0; border-radius: 6px;">
      <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 8.5pt;">
        <thead>
          <tr style="background: #F8FAFC; color: #475569; position: sticky; top: 0;">
            <th style="padding: 6px; border: 1px solid #E2E8F0; width: 40px; text-align: center;">#</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Staff Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">Person # / ID</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Organization Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Job Title / Group</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">HBsAb Titer / Status</th>
          </tr>
        </thead>
        <tbody>
          ${list.length === 0 ? `
            <tr><td colspan="6" style="padding: 12px; text-align: center; color: #64748B;">No employees found in this category.</td></tr>
          ` : list.map((emp, idx) => {
            const demo = emp.demographic || {};
            const lab = emp.labResults || {};
            const detail = emp.hepbTiter || lab.hbsabResult || emp.immunityStatus || 'Blank / Pending';
            return `
              <tr style="background: ${idx % 2 === 0 ? '#FFFFFF' : '#F9FAFC'};">
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${idx + 1}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; font-weight: bold; color: #1E293B;">${emp.name || demo.fullName || 'Unnamed'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-family: monospace; font-weight: bold; color: #0284C7;">${emp.empNo || demo.personNo || emp.idNo || demo.idNo || 'N/A'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || 'Augusta Victoria Hospital'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${emp.staffGroup || demo.jobTitle || 'Staff'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold; color: ${badgeColor};">${detail}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}
window.renderHBsAbCategoryList = renderHBsAbCategoryList;

function printHBsAbList(categoryKey) {
  const data = window.hbsabMetricsData;
  if (!data) return;
  
  let catName = 'Immunity status unknown (no anti-HBs result) Staff List';
  let list = data.ongoingList || [];

  if (categoryKey === 'immune') { catName = 'Immune (anti-HBs ≥10 mIU/mL) Staff List'; list = data.immuneList || []; }
  else if (categoryKey === 'vaccinating') { catName = 'Vaccination in progress Staff List'; list = data.vaccinatingList || []; }
  else if (categoryKey === 'resistance') { catName = 'Vaccine non-responder Staff List'; list = data.resistanceList || []; }
  else if (categoryKey === 'noNeed') { catName = 'Vaccination not indicated under MOH guidelines Staff List'; list = data.noNeedList || []; }

  const printWin = window.open('', '_blank', 'width=950,height=750');
  if (!printWin) {
    const container = document.getElementById('hbsabCategoryListContainer');
    if (container && window.AVHPrintController) {
      window.AVHPrintController.printContainer(container, { mode: 'landscape' });
      return;
    }
    alert('The print window was blocked by your browser. Please allow popups and try again.');
    return;
  }
  printWin.document.write(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>HBsAb Serology Follow-up Report — ${catName}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; color: #1E293B; background: white; }
          h2 { color: #B45309; border-bottom: 2px solid #D97706; padding-bottom: 8px; }
          table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 9pt; }
          th, td { border: 1px solid #CBD5E1; padding: 6px; text-align: left; }
          th { background: #F1F5F9; font-weight: bold; }
          .no-print { margin-bottom: 15px; display: flex; justify-content: flex-end; gap: 8px; }
          .btn-print { padding: 6px 14px; background: #D97706; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; }
          .btn-close { padding: 6px 14px; background: #64748B; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; }
          @media print {
            .no-print { display: none !important; }
            body { padding: 0; }
          }
        </style>
      </head>
      <body>
        <div class="no-print">
          <button class="btn-print" onclick="window.print()">🖨️ Print Now / طباعة الآن</button>
          <button class="btn-close" onclick="window.close()">✕ Close / إغلاق</button>
        </div>
        <div style="text-align: center; margin-bottom: 16px;">
          <h3>Augusta Victoria Hospital | Infectious Disease Unit</h3>
          <h2>HBsAb Serology Surveillance Report: ${catName}</h2>
          <p>Total Staff in List: <strong>${list.length}</strong> | Date: <strong>${new Date().toLocaleDateString()}</strong></p>
        </div>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>Staff Name</th>
              <th>Person # / ID</th>
              <th>Organization Name</th>
              <th>Job Title</th>
              <th>HBsAb Titer / Status</th>
            </tr>
          </thead>
          <tbody>
            ${list.map((emp, i) => {
              const demo = emp.demographic || {};
              const lab = emp.labResults || {};
              const detail = emp.hepbTiter || lab.hbsabResult || emp.immunityStatus || 'Blank / Pending';
              return `
                <tr>
                  <td>${i + 1}</td>
                  <td><strong>${emp.name || demo.fullName || ''}</strong></td>
                  <td>${emp.empNo || demo.personNo || ''}</td>
                  <td>${demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || 'Augusta Victoria Hospital'}</td>
                  <td>${emp.staffGroup || demo.jobTitle || ''}</td>
                  <td>${detail}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>
        <script>
          window.onafterprint = function() { window.close(); };
          setTimeout(function() {
            try { window.focus(); window.print(); } catch(e) {}
          }, 300);
        </script>
      </body>
    </html>
  `);
  printWin.document.close();
  printWin.focus();
  setTimeout(() => {
    try { printWin.focus(); printWin.print(); } catch(e) {}
  }, 400);
}
window.printHBsAbList = printHBsAbList;

// --------------------------------------------------------------------------
// 🔬 HCV, HIV & PPD SCREENING INTERACTIVE FOLLOW-UP LIST RENDERER & PRINTER
// --------------------------------------------------------------------------
function renderLabScreeningCategoryList(testType, resultCat) {
  const container = document.getElementById('labScreeningCategoryListContainer');
  if (!container || !window.labScreeningMetricsData) return;

  const data = window.labScreeningMetricsData;
  let testName = testType.toUpperCase();
  let resultName = resultCat === 'pos' ? 'Positive Result' : (resultCat === 'neg' ? 'Negative Result' : 'Ongoing / Pending');
  let list = [];
  let badgeColor = resultCat === 'pos' ? '#DC2626' : (resultCat === 'neg' ? '#059669' : '#D97706');

  const listKey = `${testType.toLowerCase()}${resultCat.charAt(0).toUpperCase() + resultCat.slice(1)}List`;
  list = data[listKey] || [];

  container.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #CBD5E1; padding-bottom: 6px;">
      <div style="font-size: 0.9rem; font-weight: 800; color: ${badgeColor};">
        📋 Follow-Up Staff List: ${testName} ${resultName} (${list.length} Staff)
      </div>
      <div style="display: flex; gap: 6px;">
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: #F3E8FF; color: #6D28D9; font-weight: bold; border: 1px solid #7C3AED;" onclick="if(typeof filterByLabScreeningCategory === 'function') filterByLabScreeningCategory('${testType}', '${resultCat}')">🔍 Filter Master Table</button>
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: white;" onclick="window.printLabScreeningList('${testType}', '${resultCat}')">🖨️ Print List</button>
      </div>
    </div>
    <div style="max-height: 280px; overflow-y: auto; background: white; border: 1px solid #E2E8F0; border-radius: 6px;">
      <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 8.5pt;">
        <thead>
          <tr style="background: #F8FAFC; color: #475569; position: sticky; top: 0;">
            <th style="padding: 6px; border: 1px solid #E2E8F0; width: 40px; text-align: center;">#</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Staff Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">Person # / ID</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Organization Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Job Title / Group</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">${testName} Result Detail</th>
          </tr>
        </thead>
        <tbody>
          ${list.length === 0 ? `
            <tr><td colspan="6" style="padding: 12px; text-align: center; color: #64748B;">No employees found in this category.</td></tr>
          ` : list.map((emp, idx) => {
            const demo = emp.demographic || {};
            const lab = emp.labResults || {};
            let detail = 'Blank / Pending';
            if (testType === 'hcv') detail = lab.hcvResult || lab.HCV || 'Negative';
            else if (testType === 'hiv') detail = lab.hivResult || lab.HIV || 'Negative';
            else if (testType === 'ppd') {
              const s1 = String(lab.ppdStep1Result || emp.ppdStep1Result || '').trim();
              const s2 = String(lab.ppdStep2Result || emp.ppdStep2Result || '').trim();
              const ind1 = String(lab.ppdStep1Induration || emp.ppdStep1Induration || '').trim();
              const ind2 = String(lab.ppdStep2Induration || emp.ppdStep2Induration || '').trim();
              const isPos = s1.toLowerCase().includes('pos') || s2.toLowerCase().includes('pos') || String(lab.ppdResult || emp.ppdResult || '').toLowerCase().includes('pos');
              if (isPos) {
                if (s1.toLowerCase().includes('pos') && s2.toLowerCase().includes('pos')) {
                  detail = `Positive (1st: Positive [${ind1 || 'P'}], 2nd: Positive [${ind2 || 'P'}])`;
                } else if (s2.toLowerCase().includes('pos')) {
                  detail = `Positive (1st: ${s1 || 'Negative'} [${ind1 || '-'}], 2nd: Positive [${ind2 || '-'}])`;
                } else {
                  detail = `Positive (1st: Positive [${ind1 || '-'}], 2nd: ${s2 || 'Pending'} [${ind2 || '-'}])`;
                }
              } else if (s1.toLowerCase().includes('neg') || s2.toLowerCase().includes('neg')) {
                detail = `Negative (1st: ${ind1 || '0mm'}, 2nd: ${ind2 || '0mm'})`;
              } else {
                detail = lab.ppdResult || lab.PPD || 'Blank / Pending';
              }
            }
            return `
              <tr style="background: ${idx % 2 === 0 ? '#FFFFFF' : '#F9FAFC'};">
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${idx + 1}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; font-weight: bold; color: #1E293B;">${emp.name || demo.fullName || 'Unnamed'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-family: monospace; font-weight: bold; color: #0284C7;">${emp.empNo || demo.personNo || emp.idNo || demo.idNo || 'N/A'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || 'Augusta Victoria Hospital'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${emp.staffGroup || demo.jobTitle || 'Staff'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold; color: ${badgeColor};">${detail}</td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}
window.renderLabScreeningCategoryList = renderLabScreeningCategoryList;

function printLabScreeningList(testType, resultCat) {
  const data = window.labScreeningMetricsData;
  if (!data) return;
  
  const testName = testType.toUpperCase();
  const resultName = resultCat === 'pos' ? 'Positive Result' : (resultCat === 'neg' ? 'Negative Result' : 'Ongoing / Pending');
  const listKey = testType.toLowerCase() + (resultCat.charAt(0).toUpperCase() + resultCat.slice(1)) + 'List';
  const list = data[listKey] || [];

  let rowsHtml = '';
  list.forEach((emp, i) => {
    const demo = emp.demographic || {};
    const lab = emp.labResults || {};
    let detail = 'Blank / Pending';
    if (testType === 'hcv') detail = lab.hcvResult || lab.HCV || 'Negative';
    else if (testType === 'hiv') detail = lab.hivResult || lab.HIV || 'Negative';
    else if (testType === 'ppd') {
      const s1 = String(lab.ppdStep1Result || emp.ppdStep1Result || '').trim();
      const s2 = String(lab.ppdStep2Result || emp.ppdStep2Result || '').trim();
      const ind1 = String(lab.ppdStep1Induration || emp.ppdStep1Induration || '').trim();
      const ind2 = String(lab.ppdStep2Induration || emp.ppdStep2Induration || '').trim();
      const isPos = s1.toLowerCase().includes('pos') || s2.toLowerCase().includes('pos') || String(lab.ppdResult || emp.ppdResult || '').toLowerCase().includes('pos');
      if (isPos) {
        if (s1.toLowerCase().includes('pos') && s2.toLowerCase().includes('pos')) {
          detail = 'Positive (1st: Positive [' + (ind1 || 'P') + '], 2nd: Positive [' + (ind2 || 'P') + '])';
        } else if (s2.toLowerCase().includes('pos')) {
          detail = 'Positive (1st: ' + (s1 || 'Negative') + ' [' + (ind1 || '-') + '], 2nd: Positive [' + (ind2 || '-') + '])';
        } else {
          detail = 'Positive (1st: Positive [' + (ind1 || '-') + '], 2nd: ' + (s2 || 'Pending') + ' [' + (ind2 || '-') + '])';
        }
      } else if (s1.toLowerCase().includes('neg') || s2.toLowerCase().includes('neg')) {
        detail = 'Negative (1st: ' + (ind1 || '0mm') + ', 2nd: ' + (ind2 || '0mm') + ')';
      } else {
        detail = lab.ppdResult || lab.PPD || 'Blank / Pending';
      }
    }
    
    const orgName = demo.orgName || emp.organizationName || demo.organizationName || emp.orgName || emp.department || demo.department || 'Augusta Victoria Hospital';
    rowsHtml += '<tr><td>' + (i + 1) + '</td><td><strong>' + (emp.name || demo.fullName || '') + '</strong></td><td>' + (emp.empNo || demo.personNo || '') + '</td><td>' + orgName + '</td><td>' + (emp.staffGroup || demo.jobTitle || '') + '</td><td>' + detail + '</td></tr>';
  });

  const printWin = window.open('', '_blank', 'width=950,height=750');
  if (!printWin) {
    const container = document.getElementById('labScreeningCategoryListContainer');
    if (container && window.AVHPrintController) {
      window.AVHPrintController.printContainer(container, { mode: 'landscape' });
      return;
    }
    alert('The print window was blocked by your browser. Please allow popups and try again.');
    return;
  }
  printWin.document.write(
    '<!DOCTYPE html><html><head><title>Screening Report — ' + testName + ' ' + resultName + '</title>' +
    '<style>body{font-family:Arial,sans-serif;padding:20px;color:#1E293B;background:white;}h2{color:#6D28D9;border-bottom:2px solid #7C3AED;padding-bottom:8px;}table{width:100%;border-collapse:collapse;margin-top:12px;font-size:9pt;}th,td{border:1px solid #CBD5E1;padding:6px;text-align:left;}th{background:#F1F5F9;font-weight:bold;}' +
    '.no-print{margin-bottom:15px;display:flex;justify-content:flex-end;gap:8px;}.btn-print{padding:6px 14px;background:#7C3AED;color:white;border:none;border-radius:4px;font-weight:bold;cursor:pointer;}.btn-close{padding:6px 14px;background:#64748B;color:white;border:none;border-radius:4px;font-weight:bold;cursor:pointer;}' +
    '@media print{.no-print{display:none !important;}body{padding:0;}}</style>' +
    '</head><body>' +
    '<div class="no-print"><button class="btn-print" onclick="window.print()">🖨️ Print Now / طباعة الآن</button><button class="btn-close" onclick="window.close()">✕ Close / إغلاق</button></div>' +
    '<div style="text-align:center;margin-bottom:16px;"><h3>Augusta Victoria Hospital | Infectious Disease Unit</h3>' +
    '<h2>Screening Surveillance Report: ' + testName + ' (' + resultName + ')</h2>' +
    '<p>Total Staff in List: <strong>' + list.length + '</strong> | Date: <strong>' + new Date().toLocaleDateString() + '</strong></p></div>' +
    '<table><thead><tr><th>#</th><th>Staff Name</th><th>Person # / ID</th><th>Organization Name</th><th>Job Title</th><th>' + testName + ' Result Detail</th></tr></thead>' +
    '<tbody>' + rowsHtml + '</tbody></table>' +
    '<script>window.onafterprint = function() { window.close(); }; setTimeout(function() { try { window.focus(); window.print(); } catch(e){} }, 300);<' + '/script>' +
    '</body></html>'
  );
  printWin.document.close();
  printWin.focus();
  setTimeout(() => {
    try { printWin.focus(); printWin.print(); } catch(e) {}
  }, 400);
}
window.printLabScreeningList = printLabScreeningList;

/* ==========================================================================
   SEASONAL FLU VACCINE 2024-2025 COMPLIANCE REPORT ENGINE
   ========================================================================== */

function evalFlu2425Status(emp) {
  if (!emp) return 'unvaccinated';

  const cf = emp.covidFlu || {};
  const vac = emp.vaccines || {};
  const demo = emp.demographic || {};

  const rawVal = String(
    cf.flu2425 || cf.flu20242025 || cf.flu2425Date || cf.fluDate ||
    vac['Flu vaccine']?.d5 || vac['Flu vaccine']?.d1 || vac.flu2425 ||
    emp.flu2425 || emp['flu vaccine 2024-2025'] || ''
  ).trim();

  if (!rawVal || rawVal.toLowerCase() === 'blank' || rawVal.toLowerCase() === 'pending' || rawVal === '0') {
    return 'unvaccinated';
  }

  const lower = rawVal.toLowerCase();

  // 3. Refuse Vaccine
  if (lower.includes('refus') || lower.includes('رافض') || lower.includes('ممتنع') || lower.includes('declin') || lower.includes('reject')) {
    return 'refused';
  }

  // 2. Vaccinated at Kupat Holim
  if (lower.includes('kupa') || lower.includes('kob') || lower.includes('كوبات') || lower.includes('كليت') || lower.includes('كلاليت') || lower.includes('مكابي') || lower.includes('موهيدت') || lower.includes('لاوميت') || lower.includes('external') || lower.includes('خارجي')) {
    return 'kupat_holim';
  }

  // 1. Vaccine at AVH (appear as date or AVH)
  return 'avh_date';
}
window.evalFlu2425Status = evalFlu2425Status;

window.currentFluChartType = 'doughnut';

function renderFlu2425Chart(metrics, forceType = null) {
  const canvas = document.getElementById('flu2425Chart');
  if (!canvas) return;

  const chartType = forceType || window.currentFluChartType || 'doughnut';
  window.currentFluChartType = chartType;

  if (window.flu2425ChartInstance) {
    window.flu2425ChartInstance.destroy();
  }

  const fluData = (metrics && metrics.flu2425) ? metrics.flu2425 : window.flu2425MetricsData;
  if (!fluData) return;

  const ctx = canvas.getContext('2d');
  const labels = ['AVH Date', 'Kupat Holim', 'Refused', 'Unvaccinated (Blank)'];
  const counts = [fluData.avhDateCount, fluData.kupatCount, fluData.refusedCount, fluData.unvaccinatedCount];
  const pcts = [fluData.avhDatePct, fluData.kupatPct, fluData.refusedPct, fluData.unvaccinatedPct];

  const colors = ['#059669', '#1D4ED8', '#DC2626', '#D97706'];

  if (chartType === 'bar') {
    window.flu2425ChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Headcount',
          data: counts,
          backgroundColor: colors,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: function(context) {
                const idx = context.dataIndex;
                return `${labels[idx]}: ${counts[idx]} staff (${pcts[idx]}%)`;
              }
            }
          }
        },
        scales: {
          y: { beginAtZero: true, grid: { color: '#F1F5F9' } },
          x: { grid: { display: false } }
        }
      }
    });
  } else {
    window.flu2425ChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels.map((l, i) => `${l} (${pcts[i]}%)`),
        datasets: [{
          data: counts,
          backgroundColor: colors,
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'right', labels: { boxWidth: 12, font: { size: 11, weight: 'bold' } } }
        }
      }
    });
  }
}
window.renderFlu2425Chart = renderFlu2425Chart;

function toggleFluChartType(type) {
  window.currentFluChartType = type;
  const metrics = window.currentDashboardMetrics || {};
  renderFlu2425Chart(metrics, type);
  
  const pieBtn = document.getElementById('btn_flu_pie');
  const barBtn = document.getElementById('btn_flu_bar');
  if (pieBtn && barBtn) {
    if (type === 'doughnut') {
      pieBtn.style.background = '#0284C7'; pieBtn.style.color = 'white';
      barBtn.style.background = 'white'; barBtn.style.color = '#0284C7';
    } else {
      barBtn.style.background = '#0284C7'; barBtn.style.color = 'white';
      pieBtn.style.background = 'white'; pieBtn.style.color = '#0284C7';
    }
  }
}
window.toggleFluChartType = toggleFluChartType;

function renderFlu2425CategoryList(category) {
  const container = document.getElementById('flu2425CategoryListContainer');
  if (!container || !window.flu2425MetricsData) return;

  // Toggle collapse if clicking the same category that is currently open
  if (container.style.display !== 'none' && container.dataset.activeCategory === category) {
    container.style.display = 'none';
    delete container.dataset.activeCategory;
    return;
  }
  container.dataset.activeCategory = category;
  container.style.display = 'block';

  const data = window.flu2425MetricsData;
  let title = '';
  let list = [];
  let badgeColor = '#0284C7';

  if (category === 'avh_date') {
    title = '🏥 Vaccinated at AVH (Date Documented)';
    list = data.avhDateList;
    badgeColor = '#059669';
  } else if (category === 'kupat_holim') {
    title = '⚕️ Vaccinated at Kupat Holim (External Clinic)';
    list = data.kupatList;
    badgeColor = '#1D4ED8';
  } else if (category === 'refused') {
    title = '🚫 Refused Vaccine (Documented Refusal)';
    list = data.refusedList;
    badgeColor = '#DC2626';
  } else {
    title = '⚪ Unvaccinated (Blank / Pending)';
    list = data.unvaccinatedList;
    badgeColor = '#D97706';
  }

  container.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid #CBD5E1; padding-bottom: 6px;">
      <div style="font-size: 0.9rem; font-weight: 800; color: ${badgeColor};">
        📋 Seasonal Flu 2024-2025 Staff List: ${title} (${list.length} Staff)
      </div>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: white;" onclick="printFlu2425CategoryList('${category}')">🖨️ Print List</button>
        <button class="btn btn-outline" style="padding: 2px 8px; font-size: 0.75rem; background: white; color: #DC2626; border-color: #DC2626; font-weight: bold; cursor: pointer;" onclick="collapseFlu2425CategoryList()">✖ Collapse / طي</button>
      </div>
    </div>
    <div style="max-height: 280px; overflow-y: auto; background: white; border: 1px solid #E2E8F0; border-radius: 6px;">
      <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 8.5pt;">
        <thead>
          <tr style="background: #F8FAFC; color: #475569; position: sticky; top: 0;">
            <th style="padding: 6px; border: 1px solid #E2E8F0; width: 40px; text-align: center;">#</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Staff Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">Person # / ID</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Organization Name</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: left;">Job Title</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">Flu 2024-2025 Record Detail</th>
            <th style="padding: 6px; border: 1px solid #E2E8F0; text-align: center;">Action</th>
          </tr>
        </thead>
        <tbody>
          ${list.length === 0 ? `
            <tr><td colspan="7" style="padding: 12px; text-align: center; color: #64748B;">No employees found in this category.</td></tr>
          ` : list.map((emp, idx) => {
            const demo = emp.demographic || {};
            const cf = emp.covidFlu || {};
            const vac = emp.vaccines || {};
            const rawVal = cf.flu2425 || cf.fluDate || vac['Flu vaccine']?.d5 || emp.flu2425 || 'Blank';
            const empNo = emp.empNo || demo.personNo || emp.idNo || demo.idNo || 'N/A';
            const orgName = demo.orgName || emp.orgName || 'Augusta Victoria Hospital';
            const jobTitle = emp.jobTitle || demo.positionName || demo.jobTitle || 'Staff Member';
            return `
              <tr style="background: ${idx % 2 === 0 ? '#FFFFFF' : '#F9FAFC'};">
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${idx + 1}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; font-weight: bold; color: #1E293B;">${emp.name || demo.fullName || 'Unnamed'}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-family: monospace; font-weight: bold; color: #0284C7;">${empNo}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${orgName}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; color: #475569;">${jobTitle}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold; color: ${badgeColor};">${rawVal}</td>
                <td style="padding: 5px; border: 1px solid #E2E8F0; text-align: center;">
                  <button class="btn btn-primary" style="padding: 2px 6px; font-size: 0.7rem; background: #0284C7; border: none; color: white; font-weight: bold; border-radius: 4px;" onclick="openQuickUpdateModal('${empNo}')">⚡ Edit</button>
                </td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}
window.renderFlu2425CategoryList = renderFlu2425CategoryList;

function collapseFlu2425CategoryList() {
  const container = document.getElementById('flu2425CategoryListContainer');
  if (container) {
    container.style.display = 'none';
    delete container.dataset.activeCategory;
  }
}
window.collapseFlu2425CategoryList = collapseFlu2425CategoryList;

function printFlu2425CategoryList(category) {
  const data = window.flu2425MetricsData;
  if (!data) return;

  let title = '';
  let list = [];
  if (category === 'avh_date') { title = 'Vaccinated at AVH (Date Documented)'; list = data.avhDateList; }
  else if (category === 'kupat_holim') { title = 'Vaccinated at Kupat Holim'; list = data.kupatList; }
  else if (category === 'refused') { title = 'Refused Vaccine'; list = data.refusedList; }
  else { title = 'Unvaccinated (Blank / Pending)'; list = data.unvaccinatedList; }

  let rowsHtml = '';
  list.forEach((emp, i) => {
    const demo = emp.demographic || {};
    const cf = emp.covidFlu || {};
    const vac = emp.vaccines || {};
    const rawVal = cf.flu2425 || cf.fluDate || vac['Flu vaccine']?.d5 || emp.flu2425 || 'Blank';
    const orgName = demo.orgName || emp.orgName || 'Augusta Victoria Hospital';
    const jobTitle = emp.jobTitle || demo.positionName || demo.jobTitle || 'Staff Member';
    rowsHtml += '<tr><td>' + (i + 1) + '</td><td><strong>' + (emp.name || demo.fullName || '') + '</strong></td><td>' + (emp.empNo || demo.personNo || '') + '</td><td>' + orgName + '</td><td>' + jobTitle + '</td><td>' + rawVal + '</td></tr>';
  });

  const printWin = window.open('', '_blank', 'width=950,height=750');
  if (!printWin) {
    const container = document.getElementById('flu2425CategoryListContainer');
    if (container && window.AVHPrintController) {
      window.AVHPrintController.printContainer(container, { mode: 'landscape' });
      return;
    }
    alert('The print window was blocked by your browser. Please allow popups and try again.');
    return;
  }
  printWin.document.write(
    '<!DOCTYPE html><html><head><title>Flu 2024-2025 Report — ' + title + '</title>' +
    '<style>body{font-family:Arial,sans-serif;padding:20px;color:#1E293B;background:white;}h2{color:#0284C7;border-bottom:2px solid #0369A1;padding-bottom:8px;}table{width:100%;border-collapse:collapse;margin-top:12px;font-size:9pt;}th,td{border:1px solid #CBD5E1;padding:6px;text-align:left;}th{background:#F1F5F9;font-weight:bold;}' +
    '.no-print{margin-bottom:15px;display:flex;justify-content:flex-end;gap:8px;}.btn-print{padding:6px 14px;background:#0284C7;color:white;border:none;border-radius:4px;font-weight:bold;cursor:pointer;}.btn-close{padding:6px 14px;background:#64748B;color:white;border:none;border-radius:4px;font-weight:bold;cursor:pointer;}' +
    '@media print{.no-print{display:none !important;}body{padding:0;}}</style>' +
    '</head><body>' +
    '<div class="no-print"><button class="btn-print" onclick="window.print()">🖨️ Print Now / طباعة الآن</button><button class="btn-close" onclick="window.close()">✕ Close / إغلاق</button></div>' +
    '<div style="text-align:center;margin-bottom:16px;"><h3>Augusta Victoria Hospital | Infectious Disease Unit</h3>' +
    '<h2>Seasonal Flu Vaccine 2024-2025 Report: ' + title + '</h2>' +
    '<p>Total Staff in List: <strong>' + list.length + '</strong> | Date: <strong>' + new Date().toLocaleDateString() + '</strong></p></div>' +
    '<table><thead><tr><th>#</th><th>Staff Name</th><th>Person # / ID</th><th>Organization Name</th><th>Job Title</th><th>Flu 2024-2025 Detail</th></tr></thead>' +
    '<tbody>' + rowsHtml + '</tbody></table>' +
    '<script>window.onafterprint = function() { window.close(); }; setTimeout(function() { try { window.focus(); window.print(); } catch(e){} }, 300);<' + '/script>' +
    '</body></html>'
  );
  printWin.document.close();
  printWin.focus();
  setTimeout(() => {
    try { printWin.focus(); printWin.print(); } catch(e) {}
  }, 400);
}
window.printFlu2425CategoryList = printFlu2425CategoryList;

// --------------------------------------------------------------------------
// 🔄 LIVE AUTOMATIC RE-CALCULATION & REAL-TIME EVENT LISTENERS
// --------------------------------------------------------------------------
window.addEventListener('staffDataUpdated', function() {
  window._cachedAVHMetrics = null;
  window._cachedAVHMetricsVersion = null;
  const container = document.getElementById('mainAppArea');
  if (container && typeof renderDashboardOverview === 'function') {
    if (typeof activeNavTab !== 'undefined' && activeNavTab === 'dashboard') {
      renderDashboardOverview(container);
    }
  }
});

window.addEventListener('avh_data_updated', function() {
  window._cachedAVHMetrics = null;
  window._cachedAVHMetricsVersion = null;
  const container = document.getElementById('mainAppArea');
  if (container && typeof renderDashboardOverview === 'function') {
    if (typeof activeNavTab !== 'undefined' && activeNavTab === 'dashboard') {
      renderDashboardOverview(container);
    }
  }
});
