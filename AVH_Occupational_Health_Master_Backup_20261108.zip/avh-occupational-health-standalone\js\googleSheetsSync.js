/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - GOOGLE SHEETS LIVE SYNC ENGINE
   Connects All 12 Web Forms & Dashboard Modules to Google Sheets Real-Time
   ========================================================================== */

(function() {
  const STORAGE_KEY_URL = 'avh_google_sheets_url';
  const STORAGE_KEY_LAST_SYNC = 'avh_google_sheets_last_sync';

  // Google Apps Script template code to paste in Google Sheets
  // Google Apps Script template code to paste in Google Sheets
  const APPS_SCRIPT_TEMPLATE = `// AUGUSTA VICTORIA HOSPITAL - GOOGLE SHEETS BACKEND SCRIPT
// Paste this code into: Google Sheets -> Extensions -> Apps Script
// Then click "Deploy" -> "New deployment" -> Select "Web app"
// Set "Execute as: Me" and "Who has access: Anyone"

function doPost(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var contents = JSON.parse(e.postData.contents || '{}');
    var sheetName = contents.sheetName || 'Master_Staff_Onboarding';
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
    }

    var action = contents.action || 'save';

    var defaultHeaders = [
      'National Identifier', 'Person Number', 'Full Name', 'Arabic Full Name', 'Date Of Birth', 'Age',
      'National Identifier Type', 'Organization Name', 'Position Name', 'Position Arabic', 'Start Date',
      'Assignment Effective Date', 'Staff Group', 'Administrative Department', 'Departments/Units/Clinics Treating',
      'Employment Status', 'Pregnancy Status', 'Allergies Details', 'Fever Today', 'Immune Deficient', 'Steroids Use',
      'Pre-Vaccination Screening Summary', 'HBsAb Result', 'HBsAb Result Date', 'Date of 1st Engrix Dose',
      'Date of 2nd Engrix Dose', 'Date of 3rd Engrix Dose', 'Engrix Booster Dose', 'HBsAg Result', 'HBsAg Result Date',
      'HCV Result', 'HIV Result', 'PPD 1st Step Result', 'PPD 1st Step Induration (mm)', 'PPD 2nd Step Result',
      'PPD 2nd Step Induration (mm)', 'IPV Vaccine (>18 Yrs)', 'Tdap Vaccine (>7 Yrs)', 'MMR 1st Dose (>1 Yr)',
      'MMR 2nd Dose (>1 Yr)', 'Chickenpox Infected or Vaccinated', 'Chickenpox 2nd Dose or IgG Level',
      'Varicella Zoster IgG', 'Varicella Zoster IgG Date', 'Mumps IgG Titer', 'Mumps IgG Titer Date',
      'Measles IgG Titer', 'Measles IgG Titer Date', 'Rubella IgG Titer', 'Rubella IgG Titer Date',
      'Meningococcal A, C', 'Hep A Series 1', 'Hep A Series 2', 'Typhoid', 'Pneumovax', 'Flu Season 2025/2026 Date',
      'Covid-19 Vaccine Date', 'Covid-19 Vaccine Date & Brand', 'Post Exposure Prophylaxis (PEP) Status', 'Updated_At'
    ];

    if (sheet.getLastRow() === 0) {
      var headersToUse = contents.headers || defaultHeaders;
      sheet.appendRow(headersToUse);
      sheet.getRange(1, 1, 1, headersToUse.length)
           .setFontWeight("bold")
           .setBackground("#1A5F7A")
           .setFontColor("#FFFFFF");
    }

    var values = sheet.getDataRange().getValues();
    var headers = values[0] || defaultHeaders;

    if (action === 'delete') {
      var targetId = String(contents.id || contents.empNo || '').trim().toLowerCase();
      var idColIndex = -1;
      for (var k = 0; k < headers.length; k++) {
        var hStr = String(headers[k]).toLowerCase();
        if (hStr.includes('person number') || hStr === 'empno') {
          idColIndex = k;
          break;
        }
      }
      if (idColIndex === -1) {
        for (var k = 0; k < headers.length; k++) {
          var hStr = String(headers[k]).toLowerCase();
          if (hStr.includes('national identifier') || hStr === 'id') {
            idColIndex = k;
            break;
          }
        }
      }
      if (idColIndex !== -1 && targetId) {
        for (var i = values.length - 1; i >= 1; i--) {
          var rowVal = String(values[i][idColIndex]).trim().toLowerCase();
          if (rowVal === targetId) {
            sheet.deleteRow(i + 1);
          }
        }
      }
      return ContentService.createTextOutput(JSON.stringify({
        status: 'success',
        message: 'Record deleted successfully from Google Sheets',
        timestamp: new Date().toISOString()
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // Save / Upsert Single Record or Row or Batch (Header-Mapped, Idempotent, Explicit Clearing & Stale Write Rejection)
    if (contents.row || contents.employee) {
      var rowObj = contents.row || mapEmployeeToSheetHeaders(contents.employee, headers);
      var targetId = String(contents.id || contents.empNo || rowObj['Person Number'] || rowObj['National Identifier'] || '').trim();

      var idColIndex = -1;
      for (var k = 0; k < headers.length; k++) {
        var hStr = String(headers[k]).toLowerCase();
        if (hStr.includes('person number') || hStr === 'empno') {
          idColIndex = k;
          break;
        }
      }
      if (idColIndex === -1) {
        for (var k = 0; k < headers.length; k++) {
          var hStr = String(headers[k]).toLowerCase();
          if (hStr.includes('national identifier') || hStr === 'id') {
            idColIndex = k;
            break;
          }
        }
      }

      var matchRowIndex = -1;
      if (idColIndex !== -1 && targetId) {
        for (var i = 1; i < values.length; i++) {
          if (String(values[i][idColIndex]).trim().toLowerCase() === targetId.toLowerCase()) {
            matchRowIndex = i + 1;
            break;
          }
        }
      }

      // Check Stale Writes if Updated_At is present
      if (matchRowIndex > 0 && contents.employee && contents.employee.updated_at) {
        var updatedAtColIdx = -1;
        for (var k = 0; k < headers.length; k++) {
          if (String(headers[k]).toLowerCase() === 'updated_at') {
            updatedAtColIdx = k;
            break;
          }
        }
        if (updatedAtColIdx !== -1) {
          var existingTimestampStr = String(values[matchRowIndex - 1][updatedAtColIdx] || '').trim();
          if (existingTimestampStr) {
            var existingTime = new Date(existingTimestampStr).getTime();
            var incomingTime = new Date(contents.employee.updated_at).getTime();
            if (!isNaN(existingTime) && !isNaN(incomingTime) && incomingTime < existingTime) {
              return ContentService.createTextOutput(JSON.stringify({
                status: 'error',
                message: 'Stale write rejected: Google Sheets has a newer revision of this employee record',
                empNo: targetId,
                timestamp: new Date().toISOString()
              })).setMimeType(ContentService.MimeType.JSON);
            }
          }
        }
      }

      if (matchRowIndex > 0) {
        var existingRowVals = values[matchRowIndex - 1];
        var mergedRowValues = [];
        for (var j = 0; j < headers.length; j++) {
          var hKey = headers[j];
          var newVal = rowObj[hKey];
          var oldVal = existingRowVals[j];
          // Respect explicit clearing (allow empty string ""), only fallback if undefined
          if (newVal !== undefined && newVal !== null) {
            mergedRowValues.push(newVal);
          } else {
            mergedRowValues.push(oldVal !== undefined && oldVal !== null ? oldVal : '');
          }
        }
        sheet.getRange(matchRowIndex, 1, 1, mergedRowValues.length).setValues([mergedRowValues]);
      } else {
        var rowValues = [];
        for (var j = 0; j < headers.length; j++) {
          var hKey = headers[j];
          rowValues.push(rowObj[hKey] !== undefined && rowObj[hKey] !== null ? rowObj[hKey] : '');
        }
        sheet.appendRow(rowValues);
      }
    } else if (contents.rows && Array.isArray(contents.rows) && contents.rows.length > 0) {
      var idColIndex = -1;
      for (var k = 0; k < headers.length; k++) {
        var hStr = String(headers[k]).toLowerCase();
        if (hStr.includes('person number') || hStr === 'empno') {
          idColIndex = k;
          break;
        }
      }
      if (idColIndex === -1) {
        for (var k = 0; k < headers.length; k++) {
          var hStr = String(headers[k]).toLowerCase();
          if (hStr.includes('national identifier') || hStr === 'id') {
            idColIndex = k;
            break;
          }
        }
      }
      for (var r = 0; r < contents.rows.length; r++) {
        var rVals = contents.rows[r];
        var rTargetId = idColIndex !== -1 ? String(rVals[idColIndex] || '').trim().toLowerCase() : '';
        var matchIdx = -1;
        if (rTargetId && idColIndex !== -1) {
          for (var i = 1; i < values.length; i++) {
            if (String(values[i][idColIndex]).trim().toLowerCase() === rTargetId) {
              matchIdx = i + 1;
              break;
            }
          }
        }
        if (matchIdx > 0) {
          var existingRowVals = values[matchIdx - 1];
          var mergedRowValues = [];
          for (var j = 0; j < headers.length; j++) {
            var newVal = rVals[j];
            var oldVal = existingRowVals[j];
            if (newVal !== undefined && newVal !== null) {
              mergedRowValues.push(newVal);
            } else {
              mergedRowValues.push(oldVal !== undefined && oldVal !== null ? oldVal : '');
            }
          }
          sheet.getRange(matchIdx, 1, 1, mergedRowValues.length).setValues([mergedRowValues]);
        } else {
          sheet.appendRow(rVals);
        }
      }
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      message: 'Record saved successfully to Google Sheets',
      timestamp: new Date().toISOString(),
      id: contents.id || contents.empNo || '',
      empNo: contents.empNo || contents.id || '',
      updated_at: contents.employee ? contents.employee.updated_at : new Date().toISOString()
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function mapEmployeeToSheetHeaders(emp, headers) {
  if (!emp) return {};
  var d = emp.demographic || {};
  var h = emp.healthStatus || {};
  var lab = emp.labResults || {};
  var vac = emp.vaccines || {};
  var sp = emp.specialVaccines || {};
  var cf = emp.covidFlu || {};
  var pep = emp.pep || {};
  var cl = emp.preVaccinationChecklist || emp.checklist || {};

  var qSummary = [];
  for (var i = 1; i <= 11; i++) {
    if (cl['q' + i] === 'Yes') qSummary.push('Q' + i + ': Yes');
  }

  var map = {
    'National Identifier': d.nationalId || emp.idNo || '',
    'Person Number': d.personNumber || emp.empNo || emp.id || '',
    'Full Name': d.fullName || emp.name || '',
    'Arabic Full Name': d.arabicFullName || '',
    'Date Of Birth': d.dob || emp.dob || '',
    'Age': d.age || emp.age || '',
    'National Identifier Type': d.idType || 'Palestinian ID',
    'Organization Name': d.orgName || 'Augusta Victoria Hospital',
    'Position Name': d.positionName || emp.jobTitle || '',
    'Position Arabic': d.positionArabic || '',
    'Start Date': d.startDate || '',
    'Assignment Effective Date': d.assignmentEffectiveDate || '',
    'Staff Group': d.staffGroup || emp.staffGroup || 'Medical / Nursing',
    'Administrative Department': d.department || emp.department || '',
    'Departments/Units/Clinics Treating': d.deptTreating || emp.deptTreating || emp.unit || '',
    'Employment Status': emp.employmentStatus || d.employmentStatus || emp.workStatus || 'Active Staff',
    'Pregnancy Status': h.pregnancyStatus || '',
    'Allergies Details': h.allergies || '',
    'Fever Today': h.feverToday ? 'Yes' : 'No',
    'Immune Deficient': h.immunodeficient ? 'Yes' : 'No',
    'Steroids Use': h.steroids ? 'Yes' : 'No',
    'Pre-Vaccination Screening Summary': qSummary.join(', ') || 'No Screen Flags',
    'HBsAb Result': lab.hbsabResult || emp.hepbTiter || '',
    'HBsAb Result Date': lab.hbsabDate || '',
    'Date of 1st Engrix Dose': lab.engrixDose1 || '',
    'Date of 2nd Engrix Dose': lab.engrixDose2 || '',
    'Date of 3rd Engrix Dose': lab.engrixDose3 || '',
    'Engrix Booster Dose': lab.engrixBooster || '',
    'HBsAg Result': lab.hbsagResult || (lab.HBsAg ? lab.HBsAg.result : '') || '',
    'HBsAg Result Date': lab.hbsagDate || (lab.HBsAg ? lab.HBsAg.date : '') || lab.hbsabDate || '',
    'HCV Result': lab.hcvResult || '',
    'HIV Result': lab.hivResult || '',
    'PPD 1st Step Result': lab.ppdStep1Result || '',
    'PPD 1st Step Induration (mm)': lab.ppdStep1Induration || '',
    'PPD 2nd Step Result': lab.ppdStep2Result || '',
    'PPD 2nd Step Induration (mm)': lab.ppdStep2Induration || '',
    'IPV Vaccine (>18 Yrs)': vac.ipvDate || '',
    'Tdap Vaccine (>7 Yrs)': vac.tdapDate || '',
    'MMR 1st Dose (>1 Yr)': vac.mmrDose1 || '',
    'MMR 2nd Dose (>1 Yr)': vac.mmrDose2 || '',
    'Chickenpox Infected or Vaccinated': vac.chickenpoxStatus || '',
    'Chickenpox 2nd Dose or IgG Level': vac.chickenpoxDose2 || '',
    'Varicella Zoster IgG': vac.varicellaIgG || '',
    'Varicella Zoster IgG Date': vac.varicellaIgGDate || '',
    'Mumps IgG Titer': lab.mumpsIgGTiter || (lab.Mumps_IgG ? lab.Mumps_IgG.result : '') || '',
    'Mumps IgG Titer Date': lab.mumpsIgGTiterDate || (lab.Mumps_IgG ? lab.Mumps_IgG.date : '') || emp.mumpsIgGTiterDate || '',
    'Measles IgG Titer': lab.measlesIgGTiter || (lab.Measles_IgG ? lab.Measles_IgG.result : '') || '',
    'Measles IgG Titer Date': lab.measlesIgGTiterDate || (lab.Measles_IgG ? lab.Measles_IgG.date : '') || emp.measlesIgGTiterDate || '',
    'Rubella IgG Titer': lab.rubellaIgGTiter || (lab.Rubella_IgG ? lab.Rubella_IgG.result : '') || '',
    'Rubella IgG Titer Date': lab.rubellaIgGTiterDate || (lab.Rubella_IgG ? lab.Rubella_IgG.date : '') || emp.rubellaIgGTiterDate || '',
    'Meningococcal A, C': sp.meningococcal || '',
    'Hep A Series 1': sp.hepA1 || '',
    'Hep A Series 2': sp.hepA2 || '',
    'Typhoid': sp.typhoid || '',
    'Pneumovax': sp.pneumovax || '',
    'Flu Season 2025/2026 Date': cf.fluDate || '',
    'Covid-19 Vaccine Date': cf.covidDate || '',
    'Covid-19 Vaccine Date & Brand': (cf.covidDate ? (cf.covidDate + ' ') : '') + (cf.covidBrandDate || ''),
    'Post Exposure Prophylaxis (PEP) Status': pep.status || '',
    'Updated_At': emp.updated_at || new Date().toISOString()
  };

  return map;
}

function doGet(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var action = (e && e.parameter && e.parameter.action) ? e.parameter.action : 'readAll';
    var targetSheet = (e && e.parameter && e.parameter.sheetName) ? e.parameter.sheetName : 'Master_Staff_Onboarding';

    if (action === 'readSheet' || action === 'readAll') {
      var sheet = ss.getSheetByName(targetSheet);
      if (!sheet) {
        return ContentService.createTextOutput(JSON.stringify({ status: 'success', data: [] })).setMimeType(ContentService.MimeType.JSON);
      }
      var values = sheet.getDataRange().getValues();
      if (values.length <= 1) {
        return ContentService.createTextOutput(JSON.stringify({ status: 'success', data: [] })).setMimeType(ContentService.MimeType.JSON);
      }
      var headers = values[0];
      var rows = [];
      for (var i = 1; i < values.length; i++) {
        var rowObj = {};
        for (var j = 0; j < headers.length; j++) {
          rowObj[headers[j]] = values[i][j];
        }
        rows.push(rowObj);
      }
      return ContentService.createTextOutput(JSON.stringify({
        status: 'success',
        sheetName: targetSheet,
        totalRows: rows.length,
        data: rows
      })).setMimeType(ContentService.MimeType.JSON);
    }

    return ContentService.createTextOutput("Augusta Victoria Hospital Google Sheets API Endpoint is Active.");

  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}
`;

  const DEFAULT_URL = 'https://script.google.com/macros/s/AKfycbxaQ0qVKVdviZtJmAphOPvmrvyeDP9ERNPu8BU5cmd1lJ1A6SXOcmVu7u0n8HWA9l-B/exec';

  // Ensure default URL is saved in localStorage
  if (!localStorage.getItem(STORAGE_KEY_URL)) {
    localStorage.setItem(STORAGE_KEY_URL, DEFAULT_URL);
  }

  window.googleSheetsSync = {
    getUrl: function() {
      const url = localStorage.getItem(STORAGE_KEY_URL) || DEFAULT_URL;
      console.log("ACTIVE GOOGLE APP SCRIPT URL:", url);
      return url;
    },

    setUrl: function(url) {
      if (url && url.trim()) {
        localStorage.setItem(STORAGE_KEY_URL, url.trim());
      }
    },

    getLastSync: function() {
      return localStorage.getItem(STORAGE_KEY_LAST_SYNC) || 'Never';
    },

    getAppsScriptCode: function() {
      return APPS_SCRIPT_TEMPLATE;
    },

    isConnected: function() {
      return !!this.getUrl();
    },

    fetchSheetData: async function(sheetName) {
      const url = this.getUrl();
      if (!url) return [];
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);
      try {
        const fetchUrl = url + (url.includes('?') ? '&' : '?') + 'action=readSheet&sheetName=' + encodeURIComponent(sheetName || 'Master_Staff_Onboarding');
        const response = await fetch(fetchUrl, { signal: controller.signal });
        clearTimeout(timeoutId);
        if (!response.ok) return [];
        const result = await response.json();
        if (result && result.status === 'success' && Array.isArray(result.data)) {
          return result.data;
        }
        return [];
      } catch (e) {
        clearTimeout(timeoutId);
        console.warn('Error reading from Google Sheets API:', e);
        return [];
      }
    },

    saveEmployeeToGoogleSheets: async function(empData) {
      const url = this.getUrl();
      if (!url) throw new Error("Google Sheets Web App URL is missing");

      const d = empData.demographic || {};
      const empId = (empData.empNo || d.personNumber || empData.id || empData.idNo || d.nationalId || '').toString().trim();

      const payload = {
        action: 'save',
        sheetName: 'Master_Staff_Onboarding',
        id: empId,
        empNo: empId,
        employee: empData
      };

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
        }

        let json = null;
        try {
          json = await response.json();
        } catch(e) {}

        if (json && (json.status === 'error' || json.success === false)) {
          throw new Error(json.message || 'Google Sheets API error response');
        }

        const nowStr = new Date().toLocaleString();
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, nowStr);
        return { success: true, status: 'success', timestamp: nowStr, data: json };
      } catch (err) {
        console.error("Error saving to Google Sheets:", err);
        throw err;
      }
    },

    deleteEmployeeFromGoogleSheets: async function(empId) {
      const url = this.getUrl();
      if (!url) throw new Error("Google Sheets Web App URL is missing");

      const payload = {
        action: 'delete',
        sheetName: 'Master_Staff_Onboarding',
        id: String(empId).trim()
      };

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          try {
            const json = await response.json();
            if (json && json.status === 'error') {
              throw new Error(json.message || 'Google Sheets API error');
            }
          } catch(e) {}
        }
        const nowStr = new Date().toLocaleString();
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, nowStr);
        return { success: true, timestamp: nowStr };
      } catch (err) {
        console.error("Error deleting from Google Sheets:", err);
        throw err;
      }
    },

    syncAllDataFromGoogleSheets: async function() {
      const records = await this.fetchSheetData('Master_Staff_Onboarding');
      if (records && records.length > 0) {
        const employees = records.map(r => ({
          id: r['Person Number'] || r['National Identifier'] || 'EMP-' + Math.floor(1000 + Math.random() * 9000),
          empNo: r['Person Number'] || '',
          idNo: r['National Identifier'] || '',
          name: r['Full Name'] || '',
          department: r['Departments/Units/Clinics Treating'] || '',
          jobTitle: r['Position Name'] || '',
          immunityStatus: r['Immunity Status'] || '',
          hepbTiter: r['HBsAb Result'] || '',
          lastVaccineDate: r['Date of 3rd Engrix Dose'] || '',

          demographic: {
            nationalId: r['National Identifier'] || '',
            personNumber: r['Person Number'] || '',
            fullName: r['Full Name'] || '',
            arabicFullName: r['Arabic Full Name'] || '',
            dob: r['Date Of Birth'] || '',
            age: r['Age'] || '',
            idType: r['National Identifier Type'] || 'Palestinian ID',
            orgName: r['Organization Name'] || 'Augusta Victoria Hospital',
            positionName: r['Position Name'] || '',
            positionArabic: r['Position Arabic'] || '',
            startDate: r['Start Date'] || '',
            assignmentEffectiveDate: r['Assignment Effective Date'] || '',
            staffGroup: r['Staff Group'] || 'Medical / Nursing',
            deptTreating: r['Departments/Units/Clinics Treating'] || ''
          },

          healthStatus: {
            pregnancyStatus: r['Pregnancy Status'] || '',
            allergies: r['Allergies Details'] || '',
            feverToday: r['Fever Today'] === 'Yes',
            immunodeficient: r['Immune Deficient'] === 'Yes',
            steroids: r['Steroids Use'] === 'Yes'
          },

          labResults: {
            hbsabResult: r['HBsAb Result'] || '',
            hbsabDate: r['HBsAb Result Date'] || '',
            engrixDose1: r['Date of 1st Engrix Dose'] || '',
            engrixDose2: r['Date of 2nd Engrix Dose'] || '',
            engrixDose3: r['Date of 3rd Engrix Dose'] || '',
            engrixBooster: r['Engrix Booster Dose'] || '',
            hbsagResult: r['HBsAg Result'] || '',
            hbsagDate: r['HBsAg Result Date'] || r['HBsAb Result Date'] || '',
            hcvResult: r['HCV Result'] || '',
            hivResult: r['HIV Result'] || '',
            ppdStep1Result: r['PPD 1st Step Result'] || '',
            ppdStep1Induration: r['PPD 1st Step Induration (mm)'] || '',
            ppdStep2Result: r['PPD 2nd Step Result'] || '',
            ppdStep2Induration: r['PPD 2nd Step Induration (mm)'] || ''
          },

          vaccines: {
            ipvDate: r['IPV Vaccine (>18 Yrs)'] || '',
            tdapDate: r['Tdap Vaccine (>7 Yrs)'] || '',
            mmrDose1: r['MMR 1st Dose (>1 Yr)'] || '',
            mmrDose2: r['MMR 2nd Dose (>1 Yr)'] || '',
            chickenpoxStatus: r['Chickenpox Infected or Vaccinated'] || '',
            chickenpoxDose2: r['Chickenpox 2nd Dose or IgG Level'] || '',
            varicellaIgG: r['Varicella Zoster IgG'] || '',
            varicellaIgGDate: r['Varicella Zoster IgG Date'] || '',
            mumpsIgGTiter: r['Mumps IgG Titer'] || '',
            mumpsIgGTiterDate: r['Mumps IgG Titer Date'] || '',
            measlesIgGTiter: r['Measles IgG Titer'] || '',
            measlesIgGTiterDate: r['Measles IgG Titer Date'] || '',
            rubellaIgGTiter: r['Rubella IgG Titer'] || '',
            rubellaIgGTiterDate: r['Rubella IgG Titer Date'] || ''
          },

          specialVaccines: {
            meningococcal: r['Meningococcal A, C'] || r['Meningiococcal A, C'] || '',
            hepA1: r['Hep A Series 1'] || r['hep A SERIES 1'] || '',
            hepA2: r['Hep A Series 2'] || r['hep A SERIES2'] || '',
            typhoid: r['Typhoid'] || r['typhoid'] || r['typhoid '] || '',
            pneumovax: r['Pnemovax'] || r['Pnemovax '] || r['Pneumovax'] || r['Pneumovax '] || ''
          },

          covidFlu: {
            fluDate: r['Flu Season 2025/2026 Date'] || '',
            covidBrandDate: r['Covid-19 Vaccine Date & Brand'] || ''
          },

          pep: {
            status: r['Post Exposure Prophylaxis (PEP) Status'] || ''
          }
        }));

        return employees;
      }
      return null;
    },

    sendToSheets: async function(sheetName, headers, row) {
      const url = this.getUrl();
      if (!url) {
        console.warn('Google Sheets URL not configured. Data saved locally.');
        return { success: false, reason: 'unconfigured' };
      }

      const payload = {
        sheetName: sheetName,
        headers: headers,
        row: row,
        timestamp: new Date().toISOString()
      };

      try {
        await fetch(url, {
          method: 'POST',
          mode: 'no-cors',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });

        const nowStr = new Date().toLocaleString();
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, nowStr);
        return { success: true, timestamp: nowStr };
      } catch (error) {
        console.error('Error syncing to Google Sheets:', error);
        return { success: false, error: error.message };
      }
    },

    sendBatchToSheets: async function(sheetName, headers, rows) {
      const url = this.getUrl();
      if (!url || !rows || rows.length === 0) return { success: false };

      const payload = {
        sheetName: sheetName,
        headers: headers,
        rows: rows,
        timestamp: new Date().toISOString()
      };

      try {
        await fetch(url, {
          method: 'POST',
          mode: 'no-cors',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });

        const nowStr = new Date().toLocaleString();
        localStorage.setItem(STORAGE_KEY_LAST_SYNC, nowStr);
        return { success: true, timestamp: nowStr };
      } catch (error) {
        console.error('Error syncing batch to Google Sheets:', error);
        return { success: false, error: error.message };
      }
    },

    // 1. Staff Master Sync
    syncStaffRecord: function(employee) {
      const headers = ['Employee ID', 'Full Name', 'ID No', 'Department', 'Job Title', 'Immunity Status', 'Hepatitis B Titer (mIU/mL)', 'Last Vaccine Date', 'Sync Date'];
      const row = [
        employee.id || '',
        employee.name || '',
        employee.idNo || '',
        employee.department || '',
        employee.jobTitle || '',
        employee.immunityStatus || '',
        employee.hepbTiter || 'N/A',
        employee.lastVaccineDate || 'N/A',
        new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Staff_Master', headers, row);
    },

    // 1b. Unified 7-Section Staff Onboarding Sync
    syncMasterStaffOnboarding: function(emp) {
      const d = emp.demographic || {};
      const h = emp.healthStatus || {};
      const lab = emp.labResults || {};
      const vac = emp.vaccines || {};
      const sp = emp.specialVaccines || {};
      const cf = emp.covidFlu || {};
      const pep = emp.pep || {};

      const headers = [
        // Sec 1: Demographic (Image 1)
        'National Identifier', 'Person Number', 'Full Name', 'Arabic Full Name', 'Date Of Birth', 'Age', 'National Identifier Type', 'Organization Name', 'Position Name', 'Position Arabic', 'Start Date', 'Assignment Effective Date', 'Staff Group', 'Departments/Units/Clinics Treating',
        // Sec 2: Health Status
        'Pregnancy Status', 'Allergies Details', 'Fever Today', 'Immune Deficient', 'Steroids Use',
        // Sec 3: Lab Results (Image 2)
        'HBsAb Result', 'HBsAb Result Date', 'Date of 1st Engrix Dose', 'Date of 2nd Engrix Dose', 'Date of 3rd Engrix Dose', 'Engrix Booster Dose', 'HBsAg Result', 'HBsAg Result Date', 'HCV Result', 'HIV Result', 'PPD 1st Step Result', 'PPD 1st Step Induration (mm)', 'PPD 2nd Step Result', 'PPD 2nd Step Induration (mm)', 'Mumps IgG Titer', 'Mumps IgG Titer Date', 'Measles IgG Titer', 'Measles IgG Titer Date', 'Rubella IgG Titer', 'Rubella IgG Titer Date',
        // Sec 4: Hospital & Historical Vaccines (Image 3)
        'IPV Vaccine (>18 Yrs)', 'Tdap Vaccine (>7 Yrs)', 'MMR 1st Dose (>1 Yr)', 'MMR 2nd Dose (>1 Yr)', 'Chickenpox Infected or Vaccinated', 'Chickenpox 2nd Dose or IgG Level', 'Varicella Zoster IgG', 'Varicella Zoster IgG Date',
        // Sec 5: Special Vaccination (Image 4)
        'Meningococcal A, C', 'Hep A Series 1', 'Hep A Series 2', 'Typhoid', 'Pneumovax',
        // Sec 6: Covid-19 & Flu
        'Flu Season 2025/2026 Date', 'Covid-19 Vaccine Date & Brand',
        // Sec 7: PEP
        'Post Exposure Prophylaxis (PEP) Status', 'Sync Date'
      ];

      const row = [
        // Sec 1
        d.nationalId || emp.idNo || '',
        d.personNumber || emp.empNo || emp.id || '',
        d.fullName || emp.name || '',
        d.arabicFullName || '',
        d.dob || emp.dob || '',
        typeof formatAgeToOneDecimal === 'function' ? formatAgeToOneDecimal(d.age || emp.age || '') : (d.age || emp.age || ''),
        d.idType || 'Palestinian ID',
        d.orgName || 'Augusta Victoria Hospital',
        d.positionName || emp.jobTitle || '',
        d.positionArabic || '',
        d.startDate || '',
        d.assignmentEffectiveDate || '',
        d.staffGroup || 'Medical / Nursing',
        d.deptTreating || emp.deptTreating || '',
        // Sec 2
        h.pregnancyStatus || 'N/A',
        h.allergies || 'None',
        h.feverToday ? 'Yes' : 'No',
        h.immunodeficient ? 'Yes' : 'No',
        h.steroids ? 'Yes' : 'No',
        // Sec 3
        lab.hbsabResult || 'Positive (>10 mIU/mL)',
        lab.hbsabDate || '',
        lab.engrixDose1 || '',
        lab.engrixDose2 || '',
        lab.engrixDose3 || '',
        lab.engrixBooster || '',
        lab.hbsagResult || 'Negative',
        lab.hbsagDate || lab.hbsabDate || '',
        lab.hcvResult || 'Negative',
        lab.hivResult || 'Negative',
        lab.ppdStep1Result || 'Negative',
        lab.ppdStep1Induration || '0 mm',
        lab.ppdStep2Result || 'Negative',
        lab.ppdStep2Induration || '0 mm',
        lab.mumpsIgGTiter || (lab.Mumps_IgG ? lab.Mumps_IgG.result : '') || '',
        lab.mumpsIgGTiterDate || (lab.Mumps_IgG ? lab.Mumps_IgG.date : '') || emp.mumpsIgGTiterDate || '',
        lab.measlesIgGTiter || (lab.Measles_IgG ? lab.Measles_IgG.result : '') || '',
        lab.measlesIgGTiterDate || (lab.Measles_IgG ? lab.Measles_IgG.date : '') || emp.measlesIgGTiterDate || '',
        lab.rubellaIgGTiter || (lab.Rubella_IgG ? lab.Rubella_IgG.result : '') || '',
        lab.rubellaIgGTiterDate || (lab.Rubella_IgG ? lab.Rubella_IgG.date : '') || emp.rubellaIgGTiterDate || '',
        // Sec 4
        vac.ipvDate || '',
        vac.tdapDate || '',
        vac.mmrDose1 || '',
        vac.mmrDose2 || '',
        vac.chickenpoxStatus || 'Vaccinated',
        vac.chickenpoxDose2 || 'IgG Positive',
        vac.varicellaIgG || 'Positive',
        vac.varicellaIgGDate || '',
        // Sec 5
        sp.meningococcal || '',
        sp.hepA1 || '',
        sp.hepA2 || '',
        sp.typhoid || '',
        sp.pneumovax || '',
        // Sec 6
        cf.fluDate || '',
        cf.covidBrandDate || '',
        // Sec 7
        pep.status || 'No Incident Reported',
        new Date().toLocaleDateString()
      ];

      // 1. Send to Master_Staff_Onboarding
      const p1 = this.sendToSheets('Master_Staff_Onboarding', headers, row);
      this.syncExemptionForm(emp, { startDate: d.startDate });

      // 4. Backup sync to Pre_Vaccination_Checklists
      this.syncChecklistForm(emp, {
        fever: h.feverToday,
        allergies: !!h.allergies && h.allergies !== 'None',
        allergyDetails: h.allergies,
        pregnant: h.pregnancyStatus && h.pregnancyStatus !== 'Not Pregnant / N/A',
        immunodeficient: h.immunodeficient,
        steroids: h.steroids
      });

      // 5. Backup sync to Vaccination_Test_History
      this.syncHistoryForm(emp, {
        hepBDoses: (lab.engrixDose1 ? '1st:' + lab.engrixDose1 : '') + (lab.engrixDose2 ? ', 2nd:' + lab.engrixDose2 : '') + (lab.engrixDose3 ? ', 3rd:' + lab.engrixDose3 : ''),
        mmrStatus: (vac.mmrDose1 ? '1st:' + vac.mmrDose1 : '') + (vac.mmrDose2 ? ', 2nd:' + vac.mmrDose2 : ''),
        varicellaIgG: vac.varicellaIgG || 'Positive',
        ppdResult: (lab.ppdStep1Result || 'Negative') + ' (' + (lab.ppdStep1Induration || '0 mm') + ')',
        tdapDate: vac.tdapDate || ''
      });

      // 6. Backup sync to Covid_Flu_Vaccines
      this.syncCovidFluForm(emp, {
        fluDate: cf.fluDate,
        covidDose1: cf.covidBrandDate,
        covidDose2: cf.covidBrandDate,
        booster: cf.covidBrandDate
      });

      // 7. Backup sync to Special_Vaccinations
      this.syncSpecialForm(emp, {
        meningococcal: sp.meningococcal,
        hepA: sp.hepA1,
        typhoid: sp.typhoid,
        pneumococcal: sp.pneumovax
      });

      // 8. Backup sync to Post_Exposure_Prophylaxis
      this.syncPepForm(emp, {
        incidentDate: new Date().toLocaleDateString(),
        sourceStatus: pep.status || 'Baseline Inspection',
        pepStarted: false,
        followUpStatus: pep.status || 'Cleared'
      });

      return p1;
    },

    // 2. Fee Exemption Form Sync (Form HR-02)
    syncExemptionForm: function(emp, exemptionData) {
      const headers = ['Form Code', 'Employee ID', 'Employee Name', 'Department', 'Employment Start Date', 'Requested Tests', 'Approval Date', 'Recorded Date'];
      const testsSelected = Object.keys(exemptionData.tests || {}).filter(k => exemptionData.tests[k]).join(', ');
      const row = [
        'HR-02',
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        exemptionData.startDate || 'N/A',
        testsSelected || 'Standard Panel (HBsAg, HBsAb, HCV, HIV, PPD)',
        exemptionData.approvalDate || new Date().toLocaleDateString(),
        new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Fee_Exemptions', headers, row);
    },

    // 3. Pre-Vaccination Checklist Sync
    syncChecklistForm: function(emp, checklistData) {
      const headers = ['Checklist ID', 'Employee ID', 'Employee Name', 'Department', 'Fever Today', 'Allergies', 'Pregnant/Planning', 'Immune Deficient', 'Steroids', 'Date Completed'];
      const row = [
        'CHK-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        checklistData.fever ? 'Yes' : 'No',
        checklistData.allergies ? 'Yes (' + (checklistData.allergyDetails || 'Specified') + ')' : 'No',
        checklistData.pregnant ? 'Yes' : 'No',
        checklistData.immunodeficient ? 'Yes' : 'No',
        checklistData.steroids ? 'Yes' : 'No',
        checklistData.date || new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Pre_Vaccination_Checklists', headers, row);
    },

    // 4. Vaccination and Test History Sync
    syncHistoryForm: function(emp, historyData) {
      const headers = ['Log ID', 'Employee ID', 'Employee Name', 'Department', 'Hep B Doses', 'MMR Status', 'Varicella IgG', 'Mantoux PPD (mm)', 'Quantiferon Result', 'Tdap Date', 'Last Updated'];
      const row = [
        'HIS-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        historyData.hepBDoses || '',
        historyData.mmrStatus || '',
        historyData.varicellaIgG || '',
        historyData.ppdResult || '',
        historyData.quantiferon || '',
        historyData.tdapDate || '',
        new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Vaccination_Test_History', headers, row);
    },

    // 5. Old Vaccination Records Sync
    syncOldVacForm: function(emp, oldVacData) {
      const headers = ['Record ID', 'Employee ID', 'Employee Name', 'Department', 'Childhood Vaccines', 'External Hep B Date', 'Verified By', 'Sync Date'];
      const row = [
        'OLD-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        oldVacData.childhood || '',
        oldVacData.externalHepB || '',
        oldVacData.verifiedBy || '',
        new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Old_Vaccination_Records', headers, row);
    },

    // 6. Declaration about Chickenpox Sync
    syncChickenpoxForm: function(emp, chickenpoxData) {
      const headers = ['Declaration ID', 'Employee ID', 'Employee Name', 'Department', 'History of Chickenpox', 'Approximate Year', 'Varicella Lab IgG', 'Signed Date'];
      const row = [
        'VAR-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        chickenpoxData.hadChickenpox ? 'Yes' : 'No',
        chickenpoxData.approxYear || '',
        chickenpoxData.labIgG || '',
        chickenpoxData.date || new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Chickenpox_Declarations', headers, row);
    },

    // 7. Covid-19 & Flu Vaccine Sync
    syncCovidFluForm: function(emp, covidFluData) {
      const headers = ['Log ID', 'Employee ID', 'Employee Name', 'Department', 'Flu Season Date', 'Covid Vaccine Date', 'Vaccine Lot No', 'Administered Date'];
      const row = [
        'COV-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        covidFluData.fluDate || '',
        covidFluData.covidDate || '',
        covidFluData.lotNo || '',
        new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Covid_Flu_Vaccines', headers, row);
    },

    // 8. Special Vaccination Sync
    syncSpecialForm: function(emp, specialData) {
      const headers = ['Special ID', 'Employee ID', 'Employee Name', 'Department', 'Unit / Ward', 'Meningococcal Date', 'Typhoid Date', 'Rabies/Other Date', 'Sync Date'];
      const row = [
        'SPC-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        specialData.unit || emp.department,
        specialData.meningococcal || '',
        specialData.typhoid || '',
        specialData.other || '',
        new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Special_Vaccinations', headers, row);
    },

    // 9. Post Exposure Prophylaxis (PEP) Sync
    syncPepForm: function(emp, pepData) {
      const headers = ['PEP Log ID', 'Employee ID', 'Employee Name', 'Department', 'Incident Date', 'Exposure Source', 'Starter Pack Initiated', 'Baseline HIV/HBV/HCV', 'Follow-up Date'];
      const row = [
        'PEP-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        pepData.incidentDate || new Date().toLocaleDateString(),
        pepData.source || '',
        pepData.starterPack ? 'Yes' : 'No',
        pepData.baselineBloodwork || '',
        pepData.followUpDate || '',
      ];
      return this.sendToSheets('Post_Exposure_Prophylaxis', headers, row);
    },
    syncPEPForm: function(emp, pepData) {
      return this.syncPepForm(emp, pepData);
    },

    // 10. Vaccine Refusal Declaration Sync
    syncRefusalForm: function(emp, refusalData) {
      const headers = ['Refusal ID', 'Employee ID', 'Employee Name', 'Department', 'Refused Vaccines', 'Reason for Refusal', 'Waiver Signed', 'Date Signed'];
      const row = [
        'REF-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        refusalData.refusedVaccines || '',
        refusalData.reason || '',
        'Yes',
        refusalData.date || new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Vaccine_Refusal_Declarations', headers, row);
    },

    // 11. Infection Control Approval Card Sync
    syncInfectionControlForm: function(emp, icData) {
      const headers = ['Approval ID', 'Employee ID', 'Employee Name', 'Department', 'Clearance Issued', 'Approved By Specialist', 'Approval Date'];
      const row = [
        'ICA-' + Date.now().toString().slice(-6),
        emp.empNo || emp.id,
        emp.name,
        emp.department,
        'Fully Cleared for Healthcare Duties',
        icData.specialist || 'Dr. Salma Nusseibeh',
        icData.date || new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Infection_Control_Approvals', headers, row);
    },

    // 12. Occupational Injury Incident Report Sync (Form SQE 02.01)
    syncInjuryReport: function(report) {
      const headers = ['Report ID', 'Incident Date', 'Employee Name', 'Department', 'Job Title', 'Exposure Type', 'Body Part', 'PEP Initiated', 'Status', 'Recorded Date'];
      const row = [
        report.id || 'INJ-' + Date.now().toString().slice(-6),
        report.incidentDate || '',
        report.employeeName || '',
        report.department || '',
        report.jobTitle || '',
        report.exposureType || '',
        report.bodyPart || '',
        report.pepInitiated ? 'Yes' : 'No',
        report.status || 'Under Investigation',
        new Date().toLocaleDateString()
      ];
      return this.sendToSheets('Injury_Incident_Reports', headers, row);
    },

    // Sync all existing data across all 12 modules in batch
    syncAllData: async function(onProgress) {
      const url = this.getUrl();
      if (!url) {
        alert('Please configure your Google Sheets Web App URL first!');
        return false;
      }

      const employees = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
      const injuries = JSON.parse(localStorage.getItem('avh_injuries')) || [];

      let total = (employees.length * 3) + injuries.length;
      let completed = 0;

      // 1. Sync Staff Master & 7-Section Onboarding
      for (let emp of employees) {
        await this.syncMasterStaffOnboarding(emp);
        completed++;
        if (onProgress) onProgress(completed, total, 'Syncing 7-Section Staff Onboarding: ' + (emp.name || emp.id));

        await this.syncStaffRecord(emp);
        completed++;

        await this.syncHistoryForm(emp, emp.history || {});
        completed++;
        if (onProgress) onProgress(completed, total, 'Syncing Immunization History: ' + (emp.name || emp.id));
      }

      // 2. Sync Injury Reports
      for (let inj of injuries) {
        await this.syncInjuryReport(inj);
        completed++;
        if (onProgress) onProgress(completed, total, 'Syncing SQE 02.01 Injury Report: ' + inj.id);
      }

      const nowStr = new Date().toLocaleString();
      localStorage.setItem(STORAGE_KEY_LAST_SYNC, nowStr);
      return true;
    }
  };
})();
