/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - UNIFIED VACCINATION SERVICE & ADAPTER
   Authoritative Data Model for COVID-19 & Influenza Seasonal Vaccination
   ========================================================================== */

(function() {
  /**
   * Exact requested labels:
   * 1. COVID -19 first dose
   * 2. COVID -19 second dose
   * 3. COVID -19 third dose
   * 4. COVID -19 booster dose
   * 5. flu vaccine year (-----)
   */

  function formatDateClean(val) {
    if (val === null || val === undefined) return '';
    const str = String(val).trim();
    if (!str) return '';
    if (typeof window.standardizeDateStr === 'function') {
      return window.standardizeDateStr(str, false);
    }
    return str;
  }

  function getVaccineLabel(record) {
    if (!record) return '';
    const type = (record.type || '').toLowerCase();
    const doseType = (record.doseType || '').toLowerCase();

    if (type === 'covid') {
      if (doseType === 'first' || doseType === '1st' || doseType === 'dose 1' || doseType === '1') {
        return 'COVID -19 first dose';
      }
      if (doseType === 'second' || doseType === '2nd' || doseType === 'dose 2' || doseType === '2') {
        return 'COVID -19 second dose';
      }
      if (doseType === 'third' || doseType === '3rd' || doseType === 'dose 3' || doseType === '3') {
        return 'COVID -19 third dose';
      }
      if (doseType === 'booster' || doseType === 'booster 1' || doseType === 'dose 4' || doseType === '4' || doseType === 'bivalent') {
        return 'COVID -19 booster dose';
      }
      if (record.vacName && record.vacName.trim()) {
        return record.vacName.trim();
      }
      return 'COVID -19 booster dose';
    }

    if (type === 'flu') {
      let yr = record.fluYear || record.season || record.year || '';
      if (!yr && record.vacName) {
        const match = record.vacName.match(/(?:year|flu|season)?\s*\(?(\d{4}(?:[/-]\d{2,4})?)\)?/i);
        if (match) yr = match[1];
      }
      if (!yr) {
        const d = formatDateClean(record.date);
        if (d && /\d{4}/.test(d)) {
          yr = d.match(/(\d{4})/)[1];
        }
      }
      if (!yr) yr = '2025/2026';
      return `flu vaccine year (${yr})`;
    }

    if (record.vacName && record.vacName.trim()) {
      return record.vacName.trim();
    }
    return 'Vaccine Record';
  }

  function parseVaccineLabel(labelStr) {
    if (!labelStr) return { type: 'covid', doseType: 'first', fluYear: '' };
    const str = String(labelStr).trim().toLowerCase();

    if (str.includes('flu')) {
      let fluYear = '';
      const yearMatch = str.match(/\(?(\d{4}(?:[/-]\d{2,4})?)\)?/);
      if (yearMatch) {
        fluYear = yearMatch[1];
      } else {
        fluYear = '2025/2026';
      }
      return { type: 'flu', doseType: 'annual', fluYear: fluYear };
    }

    if (str.includes('first') || str.includes('1st') || str.includes('dose 1') || str.includes('dose1')) {
      return { type: 'covid', doseType: 'first', fluYear: '' };
    }
    if (str.includes('second') || str.includes('2nd') || str.includes('dose 2') || str.includes('dose2')) {
      return { type: 'covid', doseType: 'second', fluYear: '' };
    }
    if (str.includes('third') || str.includes('3rd') || str.includes('dose 3') || str.includes('dose3')) {
      return { type: 'covid', doseType: 'third', fluYear: '' };
    }
    if (str.includes('booster') || str.includes('dose 4') || str.includes('bivalent') || str.includes('4th')) {
      return { type: 'covid', doseType: 'booster', fluYear: '' };
    }

    // Default fallback based on covid keywords
    if (str.includes('covid')) {
      return { type: 'covid', doseType: 'booster', fluYear: '' };
    }

    return { type: 'other', doseType: 'custom', fluYear: '' };
  }

  function normalizeSingleRecord(rawObj, defaultId = null) {
    if (!rawObj || typeof rawObj !== 'object') return null;
    const vacName = rawObj.vacName || rawObj.name || rawObj.vaccine || '';
    const parsed = parseVaccineLabel(vacName);

    const type = rawObj.type || parsed.type;
    const doseType = rawObj.doseType || parsed.doseType;
    const fluYear = rawObj.fluYear || rawObj.season || parsed.fluYear;
    const mfr = (rawObj.manufacturer !== undefined ? rawObj.manufacturer : (rawObj.mfr !== undefined ? rawObj.mfr : (rawObj.type !== undefined && rawObj.type !== 'covid' && rawObj.type !== 'flu' ? rawObj.type : '')))||"";
    const date = formatDateClean(rawObj.date || rawObj.covidDate || rawObj.fluDate || rawObj.covidBrandDate || '');
    const lot = (rawObj.batch !== undefined ? rawObj.batch : (rawObj.lot !== undefined ? rawObj.lot : '')) || "";

    const id = rawObj.id || defaultId || ('rec_' + Math.random().toString(36).substr(2, 9));

    const rec = {
      id,
      type,
      doseType,
      fluYear,
      mfr: String(mfr).trim(),
      date: date,
      lot: String(lot).trim(),
      vacName: String(vacName).trim()
    };

    rec.label = getVaccineLabel(rec);
    return rec;
  }

  function sortVaccineRecords(records) {
    if (!Array.isArray(records)) return [];

    function getDoseRank(r) {
      if (!r) return 999;
      const type = (r.type || '').toLowerCase();
      const doseType = (r.doseType || '').toLowerCase();

      if (type === 'covid') {
        if (doseType === 'first' || doseType === '1st' || doseType === 'dose 1' || doseType === '1') return 10;
        if (doseType === 'second' || doseType === '2nd' || doseType === 'dose 2' || doseType === '2') return 20;
        if (doseType === 'third' || doseType === '3rd' || doseType === 'dose 3' || doseType === '3') return 30;
        if (doseType === 'booster' || doseType.includes('booster') || doseType === 'dose 4' || doseType === '4') return 40;
        return 45;
      }
      if (type === 'flu') {
        return 100;
      }
      return 200;
    }

    function getFluScore(r) {
      if (!r) return 0;
      let yrStr = r.fluYear || r.season || r.year || '';
      if (!yrStr && r.vacName) {
        const match = String(r.vacName).match(/\(?(\d{4}(?:[/-]\d{2,4})?)\)?/i);
        if (match) yrStr = match[1];
      }
      if (!yrStr && r.date) {
        const m = String(r.date).match(/(\d{4})/);
        if (m) yrStr = m[1];
      }
      const mYear = String(yrStr).match(/(\d{4})/);
      let val = mYear ? parseInt(mYear[1], 10) : 0;
      if (String(yrStr).includes('/')) val += 0.5;
      return val;
    }

    return [...records].sort((a, b) => {
      const rankA = getDoseRank(a);
      const rankB = getDoseRank(b);

      if (rankA !== rankB) {
        return rankA - rankB; // Covid first (first, second, third, booster), then flu
      }

      if (rankA < 100) {
        const dA = a.date ? String(a.date) : '';
        const dB = b.date ? String(b.date) : '';
        return dA.localeCompare(dB);
      }

      const scoreA = getFluScore(a);
      const scoreB = getFluScore(b);
      if (scoreA !== scoreB) {
        return scoreB - scoreA; // Descending (2025/2026 before 2024/2025 before 2023/2024)
      }
      const dA = a.date ? String(a.date) : '';
      const dB = b.date ? String(b.date) : '';
      return dB.localeCompare(dA);
    });
  }

  function getCanonicalVaccineRecords(emp) {
    if (!emp) return [];

    let rawList = [];
    if (Array.isArray(emp.covidFluRecords)) {
      rawList = emp.covidFluRecords.map((r, i) => normalizeSingleRecord(r, `rec_${i}`)).filter(Boolean);
    } else if (emp.covidFlu && Array.isArray(emp.covidFlu.covidFluRecords)) {
      rawList = emp.covidFlu.covidFluRecords.map((r, i) => normalizeSingleRecord(r, `rec_${i}`)).filter(Boolean);
    } else {
      // Migrate from legacy structures
      const recordsMap = new Map();
      const addRecord = (rec) => {
        if (!rec) return;
        const key = `${rec.type}_${rec.doseType}_${rec.fluYear || ''}_${rec.date || ''}`.toLowerCase();
        if (recordsMap.has(key)) {
          const existing = recordsMap.get(key);
          if (!existing.date && rec.date) existing.date = rec.date;
          if (!existing.mfr && rec.mfr) existing.mfr = rec.mfr;
          if (!existing.lot && rec.lot) existing.lot = rec.lot;
          existing.label = getVaccineLabel(existing);
        } else {
          recordsMap.set(key, rec);
        }
      };

      const cf = emp.covidFlu || {};
      const vac = emp.vaccines || {};
      const covVac = vac['Covid - 19'] || vac['Covid-19'] || vac['COVID - 19'] || {};
      const legacyDoses = cf.additionalCovidFluDoses || emp.covidFluLogs || [];

      if (Array.isArray(legacyDoses) && legacyDoses.length > 0) {
        legacyDoses.forEach((d, idx) => {
          const rec = normalizeSingleRecord(d, `leg_${idx}`);
          if (rec && (rec.date || rec.mfr || rec.lot || rec.vacName)) {
            addRecord(rec);
          }
        });
      }

      const cov1Dt = formatDateClean(emp.covidDose1Date || cf.covidDose1Date || covVac.d1);
      const cov1Lot = emp.covidDose1Batch || cf.covidDose1Batch || covVac.p1 || emp.patch1 || emp.batch1 || '';
      const cov1Mfr = cf.covidDose1Mfr || emp.covidBrand1 || (emp.covidBrandDate && !cov1Dt ? emp.covidBrandDate : '');
      if (cov1Dt || cov1Lot || cov1Mfr) {
        addRecord(normalizeSingleRecord({ type: 'covid', doseType: 'first', date: cov1Dt, mfr: cov1Mfr, lot: cov1Lot }, 'cov_1'));
      }

      const cov2Dt = formatDateClean(emp.covidDose2Date || cf.covidDose2Date || covVac.d2);
      const cov2Lot = emp.covidDose2Batch || cf.covidDose2Batch || covVac.p2 || emp.patch2 || emp.batch2 || '';
      const cov2Mfr = cf.covidDose2Mfr || emp.covidBrand2 || '';
      if (cov2Dt || cov2Lot || cov2Mfr) {
        addRecord(normalizeSingleRecord({ type: 'covid', doseType: 'second', date: cov2Dt, mfr: cov2Mfr, lot: cov2Lot }, 'cov_2'));
      }

      const cov3Dt = formatDateClean(emp.covidDose3Date || cf.covidDose3Date || covVac.d3);
      const cov3Lot = emp.covidDose3Batch || cf.covidDose3Batch || covVac.p3 || emp.patch3 || emp.batch3 || '';
      const cov3Mfr = cf.covidDose3Mfr || emp.covidBrand3 || '';
      if (cov3Dt || cov3Lot || cov3Mfr) {
        addRecord(normalizeSingleRecord({ type: 'covid', doseType: 'third', date: cov3Dt, mfr: cov3Mfr, lot: cov3Lot }, 'cov_3'));
      }

      const cov4Dt = formatDateClean(emp.covidDose4Date || cf.covidDose4Date || covVac.d4);
      const cov4Lot = emp.covidDose4Batch || cf.covidDose4Batch || covVac.p4 || emp.patch4 || emp.batch4 || '';
      const cov4Mfr = cf.covidDose4Mfr || emp.covidBrand4 || '';
      if (cov4Dt || cov4Lot || cov4Mfr) {
        addRecord(normalizeSingleRecord({ type: 'covid', doseType: 'booster', date: cov4Dt, mfr: cov4Mfr, lot: cov4Lot }, 'cov_4'));
      }

      const flu2526Dt = formatDateClean(cf.fluDate || cf.flu2526 || emp.fluDate);
      const flu2526Lot = cf.fluBatch || emp.fluBatch || '';
      const flu2526Mfr = cf.fluMfr || emp.fluMfr || '';
      if (flu2526Dt || flu2526Lot || flu2526Mfr) {
        addRecord(normalizeSingleRecord({ type: 'flu', doseType: 'annual', fluYear: '2025/2026', date: flu2526Dt, mfr: flu2526Mfr, lot: flu2526Lot }, 'flu_2526'));
      }

      const flu2425Dt = formatDateClean(cf.flu2425 || emp.flu2425);
      if (flu2425Dt && flu2425Dt !== flu2526Dt) {
        addRecord(normalizeSingleRecord({ type: 'flu', doseType: 'annual', fluYear: '2024/2025', date: flu2425Dt }, 'flu_2425'));
      }

      const flu2324Dt = formatDateClean(cf.flu2324 || emp.flu2324);
      if (flu2324Dt && flu2324Dt !== flu2526Dt && flu2324Dt !== flu2425Dt) {
        addRecord(normalizeSingleRecord({ type: 'flu', doseType: 'annual', fluYear: '2023/2024', date: flu2324Dt }, 'flu_2324'));
      }

      rawList = Array.from(recordsMap.values());
    }

    return sortVaccineRecords(rawList);
  }

  function syncCanonicalRecordsToLegacyFields(emp, records) {
    if (!emp) return emp;
    const cleanRecords = sortVaccineRecords((Array.isArray(records) ? records : []).map((r, i) => normalizeSingleRecord(r, `rec_${i}`)).filter(Boolean));

    emp.covidFluRecords = cleanRecords;
    if (!emp.covidFlu) emp.covidFlu = {};
    emp.covidFlu.covidFluRecords = cleanRecords;

    // Build legacy additionalCovidFluDoses format for backwards compatibility
    emp.covidFlu.additionalCovidFluDoses = cleanRecords.map(r => ({
      vacName: r.label,
      manufacturer: r.mfr,
      date: r.date,
      batch: r.lot
    }));

    emp.covidFluLogs = cleanRecords.map(r => ({
      name: r.label,
      mfr: r.mfr,
      date: r.date,
      lot: r.lot
    }));

    // Reset top-level individual legacy dose fields
    emp.covidDose1Date = ''; emp.covidDose1Batch = '';
    emp.covidDose2Date = ''; emp.covidDose2Batch = '';
    emp.covidDose3Date = ''; emp.covidDose3Batch = '';
    emp.covidDose4Date = ''; emp.covidDose4Batch = '';
    emp.fluDate = ''; emp.flu2425 = ''; emp.flu2324 = ''; emp.fluBatch = ''; emp.fluMfr = '';
    emp.covidDate = ''; emp.covidBrandDate = '';

    emp.covidFlu.covidDose1Date = ''; emp.covidFlu.covidDose1Batch = ''; emp.covidFlu.covidDose1Mfr = '';
    emp.covidFlu.covidDose2Date = ''; emp.covidFlu.covidDose2Batch = ''; emp.covidFlu.covidDose2Mfr = '';
    emp.covidFlu.covidDose3Date = ''; emp.covidFlu.covidDose3Batch = ''; emp.covidFlu.covidDose3Mfr = '';
    emp.covidFlu.covidDose4Date = ''; emp.covidFlu.covidDose4Batch = ''; emp.covidFlu.covidDose4Mfr = '';
    emp.covidFlu.fluDate = ''; emp.covidFlu.flu2425 = ''; emp.covidFlu.flu2324 = ''; emp.covidFlu.fluBatch = ''; emp.covidFlu.fluMfr = '';
    emp.covidFlu.covidDate = ''; emp.covidFlu.covidBrandDate = '';

    cleanRecords.forEach(r => {
      if (r.type === 'covid') {
        if (r.doseType === 'first') {
          emp.covidDose1Date = r.date; emp.covidDose1Batch = r.lot; emp.patch1 = r.lot; emp.batch1 = r.lot;
          emp.covidFlu.covidDose1Date = r.date; emp.covidFlu.covidDose1Batch = r.lot; emp.covidFlu.covidDose1Mfr = r.mfr;
          if (!emp.covidDate) { emp.covidDate = r.date; emp.covidBrandDate = r.mfr; emp.covidFlu.covidDate = r.date; emp.covidFlu.covidBrandDate = r.mfr; }
        } else if (r.doseType === 'second') {
          emp.covidDose2Date = r.date; emp.covidDose2Batch = r.lot; emp.patch2 = r.lot; emp.batch2 = r.lot;
          emp.covidFlu.covidDose2Date = r.date; emp.covidFlu.covidDose2Batch = r.lot; emp.covidFlu.covidDose2Mfr = r.mfr;
        } else if (r.doseType === 'third') {
          emp.covidDose3Date = r.date; emp.covidDose3Batch = r.lot; emp.patch3 = r.lot; emp.batch3 = r.lot;
          emp.covidFlu.covidDose3Date = r.date; emp.covidFlu.covidDose3Batch = r.lot; emp.covidFlu.covidDose3Mfr = r.mfr;
        } else if (r.doseType === 'booster') {
          emp.covidDose4Date = r.date; emp.covidDose4Batch = r.lot; emp.patch4 = r.lot; emp.batch4 = r.lot;
          emp.covidFlu.covidDose4Date = r.date; emp.covidFlu.covidDose4Batch = r.lot; emp.covidFlu.covidDose4Mfr = r.mfr;
        }
      } else if (r.type === 'flu') {
        emp.fluDate = r.date; emp.fluBatch = r.lot; emp.fluMfr = r.mfr;
        emp.covidFlu.fluDate = r.date; emp.covidFlu.fluBatch = r.lot; emp.covidFlu.fluMfr = r.mfr;
        if (r.fluYear === '2024/2025') {
          emp.flu2425 = r.date; emp.covidFlu.flu2425 = r.date;
        } else if (r.fluYear === '2023/2024') {
          emp.flu2324 = r.date; emp.covidFlu.flu2324 = r.date;
        }
      }
    });

    if (!emp.vaccines) emp.vaccines = {};
    if (!emp.vaccines['Covid - 19']) emp.vaccines['Covid - 19'] = {};
    emp.vaccines['Covid - 19'].d1 = emp.covidDose1Date || '';
    emp.vaccines['Covid - 19'].p1 = emp.covidDose1Batch || '';
    emp.vaccines['Covid - 19'].d2 = emp.covidDose2Date || '';
    emp.vaccines['Covid - 19'].p2 = emp.covidDose2Batch || '';
    emp.vaccines['Covid - 19'].d3 = emp.covidDose3Date || '';
    emp.vaccines['Covid - 19'].p3 = emp.covidDose3Batch || '';

    return emp;
  }

  const VaccinationService = {
    getVaccineLabel,
    parseVaccineLabel,
    normalizeSingleRecord,
    sortVaccineRecords,
    getCanonicalVaccineRecords,
    syncCanonicalRecordsToLegacyFields
  };

  if (typeof window !== 'undefined') {
    window.VaccinationService = VaccinationService;
    window.getVaccineLabel = getVaccineLabel;
    window.parseVaccineLabel = parseVaccineLabel;
    window.sortVaccineRecords = sortVaccineRecords;
    window.getCanonicalVaccineRecords = getCanonicalVaccineRecords;
    window.syncCanonicalRecordsToLegacyFields = syncCanonicalRecordsToLegacyFields;
  }
})();
