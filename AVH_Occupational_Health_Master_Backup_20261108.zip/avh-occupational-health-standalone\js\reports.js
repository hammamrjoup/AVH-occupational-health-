/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - VACCINATION REPORTS & EXCEL SYNC CONTROLLER
   ========================================================================== */

let rptCurrentPage = 1;
let rptPageSize = 50;
let rptAllEmployeesList = [];
window.rptAllEmployeesList = rptAllEmployeesList;
let rptFilteredEmployees = [];

function renderVaccinationReports(container) {
  if (!container) return;
  try {
    rptAllEmployeesList = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));

    if (!Array.isArray(rptAllEmployeesList) || rptAllEmployeesList.length === 0) {
      if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
        rptAllEmployeesList = AVH_MASTER_EXCEL_EMPLOYEES;
      } else {
        rptAllEmployeesList = [];
      }
    }
    window.rptAllEmployeesList = rptAllEmployeesList;
    rptFilteredEmployees = rptAllEmployeesList.slice();
    rptCurrentPage = 1;
    console.log("5 MASTER REPORT DATA:", rptAllEmployeesList);

    const isAr = window.i18n ? window.i18n.isRTL() : false;
    const activeStaffList = rptAllEmployeesList.filter(e => e && (typeof isActiveStaff === 'function' ? isActiveStaff(e) : true));
    const totalActiveStaffCount = activeStaffList.length;
    const avhStaffCount = activeStaffList.filter(e => e && (typeof isAVHStaff === 'function' ? isAVHStaff(e) : true)).length;
    const gazaStaffCount = activeStaffList.filter(e => e && (typeof isGazaStaff === 'function' ? isGazaStaff(e) : false)).length;

    let depts = [];
    try {
      depts = typeof getCombinedDepartmentList === 'function' ? getCombinedDepartmentList() : (typeof AVH_DEPARTMENTS !== 'undefined' ? AVH_DEPARTMENTS : []);
      if (!Array.isArray(depts)) depts = [];
    } catch(de) {
      depts = typeof AVH_DEPARTMENTS !== 'undefined' ? AVH_DEPARTMENTS : [];
    }
    const deptOptionsHtml = depts.map(d => `<option value="${String(d).replace(/"/g, '&quot;')}">${String(d)}</option>`).join('');

    container.innerHTML = `
    <div class="card">
      <div class="card-title" style="margin-bottom: 14px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
        <span id="rptHeaderMainTitle">📊 ${isAr ? 'تقارير تطعيم ومناعة الكوادر والتزامن مع Excel' : 'Occupational Health Vaccination & Immunity Reports'} <span style="font-size: 0.88rem; font-weight: normal; color: #475569;">(${totalActiveStaffCount} ${isAr ? 'كادر نشط إجمالي: ' + avhStaffCount + ' مستشفى المطلع + ' + gazaStaffCount + ' مشروع غزة' : 'Total Active Staff: ' + avhStaffCount + ' AVH Hospital + ' + gazaStaffCount + ' Gaza Project'})</span></span>
        <div style="font-size: 0.8rem; font-weight: bold; background: #E0F2FE; color: #0369A1; border: 1px solid #BAE6FD; padding: 4px 12px; border-radius: 20px;">
          <span id="rptCurrentFilterBadge">${isAr ? 'العرض النشط: كادر المستشفى' : 'Active View: AVH Hospital Staff'} (${avhStaffCount})</span>
        </div>
      </div>

      <!-- DATA MANAGEMENT & ACTION TOOLBAR - 3 STRUCTURED FUNCTIONAL GROUPS -->
      <div style="background: #F8FAFC; border: 1.5px solid #E2E8F0; border-radius: 12px; padding: 16px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
        
        <!-- TOOLBAR MAIN HEADER -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #E2E8F0; padding-bottom: 10px; margin-bottom: 14px; flex-wrap: wrap; gap: 8px;">
          <div style="font-weight: 800; font-size: 0.95rem; color: #0F172A; display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 1.15rem;">⚙️</span>
            <span>${isAr ? 'إدارة البيانات والتقارير واستيراد/تصدير Excel' : 'Data Management, Reports & Excel Sync'}</span>
          </div>
          <span style="font-size: 0.76rem; color: #475569; background: #E2E8F0; padding: 3px 10px; border-radius: 20px; font-weight: 600;">
            ${isAr ? 'قاعدة بيانات متزامنة (IndexedDB + Server)' : 'Synchronized DB (IndexedDB + Server)'}
          </span>
        </div>

        <!-- 3 FUNCTIONAL GROUPS GRID -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 14px; align-items: stretch;">
          
          <!-- GROUP 1: EXCEL IMPORT & EXPORT -->
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 10px; padding: 14px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
            <div>
              <div style="display: flex; align-items: center; gap: 6px; font-weight: 800; font-size: 0.9rem; color: #0369A1; margin-bottom: 4px;">
                <span>📂</span>
                <span>${isAr ? '1. استيراد وتصدير Excel' : '1. Excel Import & Export'}</span>
              </div>
              <p style="font-size: 0.78rem; color: #64748B; margin: 0 0 12px 0; line-height: 1.4;">
                ${isAr ? 'استيراد السجلات من ملف إكسل أو تصدير ورقة العمل النشطة بصيغة XLSX.' : 'Import records from an Excel workbook or export the active filtered report table.'}
              </p>
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                <label class="btn btn-outline" style="cursor: pointer; font-size: 0.82rem; background: white; border: 1.5px solid #0284C7; color: #0369A1; font-weight: bold; padding: 7px 12px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; gap: 6px; flex: 1; min-width: 130px; text-align: center;">
                  📂 Import Report.xlsx <input type="file" accept=".xlsx,.xls" style="display:none;" onchange="importExcelReport(event)">
                </label>
                <button class="btn btn-success" style="background: #10B981; color: white; border: none; font-weight: bold; padding: 7px 12px; font-size: 0.82rem; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; flex: 1.2; min-width: 150px; box-shadow: 0 2px 4px rgba(16, 185, 129, 0.2);" onclick="exportToExcelReport()" title="${isAr ? 'تنزيل أحدث ملف إكسل مفرّغ بالكامل' : 'Export and download current sheet'}">
                  📥 ${isAr ? 'تصدير ورقة العمل (Excel .xlsx)' : 'Export Active Sheet (.xlsx Format)'}
                </button>
              </div>
              <div style="font-size: 0.72rem; color: #64748B; background: #F1F5F9; padding: 4px 8px; border-radius: 4px; display: flex; align-items: center; gap: 4px;">
                <span>ℹ️</span>
                <span>${isAr ? 'المتصفح لا يعدّل ملفات القرص تلقائياً؛ اضغط "تصدير" لتنزيل أحدث ملف إكسل.' : 'Browser sandbox requires clicking export to download the updated .xlsx file.'}</span>
              </div>
            </div>
          </div>

          <!-- GROUP 2: BACKUP & DATA ADMINISTRATION -->
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 10px; padding: 14px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
            <div>
              <div style="display: flex; align-items: center; gap: 6px; font-weight: 800; font-size: 0.9rem; color: #1E40AF; margin-bottom: 4px;">
                <span>💾</span>
                <span>${isAr ? '2. النسخ الاحتياطي وإدارة البيانات' : '2. Backup & Data Administration'}</span>
              </div>
              <p style="font-size: 0.78rem; color: #64748B; margin: 0 0 12px 0; line-height: 1.4;">
                ${isAr ? 'حفظ نسخة كاملة من قاعدة بيانات الموظفين (IndexedDB) والخيارات المتقدمة للصيانة.' : 'Export complete database snapshot (JSON) and access advanced maintenance tools.'}
              </p>
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <button class="btn btn-primary" style="background: #2563EB; color: white; border: none; font-weight: bold; padding: 7px 14px; font-size: 0.82rem; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; width: 100%; box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2);" onclick="downloadStaffDatabaseBackup()">
                💾 ${isAr ? 'نسخ احتياطي لقاعدة البيانات (JSON)' : 'Backup Staff DB (JSON)'}
              </button>

              <!-- ADVANCED OPTIONS ACCORDION -->
              <details style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 6px; padding: 6px 10px;">
                <summary style="cursor: pointer; font-size: 0.78rem; font-weight: 700; color: #475569; display: flex; align-items: center; justify-content: space-between; user-select: none;">
                  <span>⚙️ ${isAr ? 'خيارات متقدمة واستعادة' : 'Advanced Options & Recovery'}</span>
                  <span style="font-size: 0.7rem; opacity: 0.7;">▼</span>
                </summary>
                <div style="margin-top: 8px; padding-top: 8px; border-top: 1px dashed #CBD5E1; display: flex; flex-direction: column; gap: 8px;">
                  <button type="button" class="btn btn-outline" style="background: white; border: 1px solid #94A3B8; color: #334155; font-weight: 600; padding: 5px 10px; font-size: 0.78rem; border-radius: 4px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px;" onclick="downloadPreMigrationBackup()" title="Download raw snapshot taken prior to IndexedDB migration">
                    📥 ${isAr ? 'تنزيل نسخة ما قبل الهجرة (Pre-Migration)' : 'Pre-Migration Backup (JSON)'}
                  </button>

                  <!-- DANGER ZONE: CLEAR ALL DATA -->
                  <div style="background: #FEF2F2; border: 1px solid #FECACA; border-radius: 6px; padding: 6px 8px; margin-top: 2px;">
                    <div style="font-size: 0.72rem; font-weight: 800; color: #DC2626; margin-bottom: 4px; display: flex; align-items: center; gap: 4px;">
                      <span>⚠️</span>
                      <span>${isAr ? 'منطقة الخطر (مسح البيانات)' : 'Danger Zone (Data Wipe)'}</span>
                    </div>
                    <button type="button" class="btn btn-danger" style="background: #DC2626; color: white; border: none; font-weight: bold; padding: 6px 10px; font-size: 0.76rem; border-radius: 4px; cursor: pointer; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 1px 3px rgba(220, 38, 38, 0.25);" onclick="clearAllStaffRecords()">
                      🗑️ ${isAr ? 'مسح كافة السجلات' : 'Clear All Data'}
                    </button>
                  </div>
                </div>
              </details>
            </div>
          </div>

          <!-- GROUP 3: FOLLOW-UP & IMMUNITY REPORTS -->
          <div style="background: white; border: 1px solid #CBD5E1; border-radius: 10px; padding: 14px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
            <div>
              <div style="display: flex; align-items: center; gap: 6px; font-weight: 800; font-size: 0.9rem; color: #0F766E; margin-bottom: 4px;">
                <span>📊</span>
                <span>${isAr ? '3. تقارير المتابعة والمناعة' : '3. Follow-Up & Immunity Reports'}</span>
              </div>
              <p style="font-size: 0.78rem; color: #64748B; margin: 0 0 12px 0; line-height: 1.4;">
                ${isAr ? 'متابعة الكوادر غير المستكملين للتطعيم وتفصيل نسب المناعة والتغطية الوزارية (MOH).' : 'Monitor non-immune staff and review Ministry of Health (MOH) breakdown reports.'}
              </p>
            </div>
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <button class="btn btn-danger" style="background: #E11D48; color: white; border: none; font-weight: bold; padding: 7px 14px; font-size: 0.82rem; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; width: 100%; box-shadow: 0 2px 4px rgba(225, 29, 72, 0.2);" onclick="openUnvaccinatedFollowupReport('ALL', typeof rptActiveReportCategory !== 'undefined' ? rptActiveReportCategory : 'ALL')">
                📋 ${isAr ? 'تقرير متابعة غير المطعّمين' : 'Unvaccinated Follow-Up Report'}
              </button>
              <button class="btn btn-primary" style="background: linear-gradient(135deg, #0D9488 0%, #0F766E 100%); color: white; border: none; font-weight: bold; padding: 7px 14px; font-size: 0.82rem; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; width: 100%; box-shadow: 0 2px 4px rgba(13, 148, 136, 0.25);" onclick="openMOHImmunityBreakdownReport('ALL', typeof rptActiveReportCategory !== 'undefined' ? rptActiveReportCategory : 'ALL')">
                🛡️ ${isAr ? 'تقرير مناعة الكوادر والتغطية (MOH)' : 'MOH Immunity Status Breakdown Report'}
              </button>
            </div>
          </div>

        </div>
      </div>

      <!-- DEDICATED MASTER REPORT CATEGORY SUB-TABS GROUPED BY USER SPECIFIED ORDERING -->
      <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 18px; background: #F8FAFC; padding: 14px 16px; border-radius: 12px; border: 1px solid #CBD5E1; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02);">
        
        <!-- GROUP 1: BY PROGRAM / COVERAGE PLAN -->
        <div>
          <div style="font-size: 0.76rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; color: #64748B; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">
            <span>📌 1. ${isAr ? 'حسب خطة التغطية (كادر المستشفى - استثناء غزة)' : 'BY COVERAGE PLAN (Excludes Gaza Project)'}</span>
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button type="button" id="btnRptTabExtended" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('extended')">
              <span>🌟 ${isAr ? '1- برنامج التغطية الشاملة (Extended Program)' : '1- Extended Program'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeExtended">0</span>
            </button>

            <button type="button" id="btnRptTabMinimum" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('minimum')">
              <span>📋 ${isAr ? '2- الخطة الأدنى (Minimum Plan)' : '2- Minimum Plan'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeMinimum">0</span>
            </button>

            <button type="button" id="btnRptTabBasic" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('basic')">
              <span>📄 ${isAr ? '3- الخطة الأساسية (Basic Plan)' : '3- Basic Plan'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeBasic">0</span>
            </button>

            <button type="button" id="btnRptTabSpecial" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('special')">
              <span>🛡️ ${isAr ? '4- كادر التطعيمات الخاصة / المختبرات (Special Vaccine Staff)' : '4- Special Vaccine Staff (Lab Techs)'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeSpecial">0</span>
            </button>
          </div>
        </div>

        <div style="border-top: 1px dashed #CBD5E1;"></div>

        <!-- GROUP 2: BY SPECIALIZED CLINICAL CARE UNITS -->
        <div>
          <div style="font-size: 0.76rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; color: #64748B; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">
            <span>🏥 2. ${isAr ? 'حسب الأقسام التخصصية' : 'By Specialized Clinical Care Units'}</span>
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button type="button" id="btnRptTabOncology" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('oncology')">
              <span>🎗️ ${isAr ? '1- قسم الأورام وأورام الدم (Oncology & Hemato-Oncology)' : '1- Employees in Oncology & Hemato-Oncology'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeOncology">0</span>
            </button>

            <button type="button" id="btnRptTabBabies" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('babies')">
              <span>👶 ${isAr ? '2- الأطفال والرضع (<1 سنة) (Babies & Pediatrics)' : '2- Babies (<1Y) & Pediatrics'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeBabies">0</span>
            </button>

            <button type="button" id="btnRptTabNoCat" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('nocat')">
              <span>⚪ ${isAr ? '3- بدون تصنيف خاص (الأقسام العامة)' : '3- No Category (General Units)'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeNoCat">0</span>
            </button>

            <button type="button" id="btnRptTabInvasive" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('invasive')">
              <span>🔬 ${isAr ? '4- كادر الإجراءات التداخلية (Apapasach)' : '4- Healthcare workers performing invasive procedures (Apapasach)'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeInvasive">0</span>
            </button>
          </div>
        </div>

        <div style="border-top: 1px dashed #CBD5E1;"></div>

        <!-- GROUP 3: BY ORGANIZATION / LOCATION -->
        <div>
          <div style="font-size: 0.76rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; color: #64748B; margin-bottom: 6px; display: flex; align-items: center; gap: 6px;">
            <span>📍 3. ${isAr ? 'حسب المؤسسة والموقع' : 'By Organization / Location'}</span>
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button type="button" id="btnRptTabAVH" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('avh')">
              <span>🏥 ${isAr ? '1- كادر المستشفى (AVH Staff)' : '1- AVH Staff'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeAVH">0</span>
            </button>

            <button type="button" id="btnRptTabGaza" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('gaza')">
              <span>🇵🇸 ${isAr ? '2- كادر مشروع غزة (Gaza Staff)' : '2- Gaza Staff'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeGaza">0</span>
            </button>

            <button type="button" id="btnRptTabAll" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('all')">
              <span>🌐 ${isAr ? 'كافة السجلات النشطة (All Active Staff)' : 'All Active Staff'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeAll">0</span>
            </button>

            <button type="button" id="btnRptTabArchived" class="btn" style="padding: 8px 14px; font-weight: 800; font-size: 0.84rem; border-radius: 8px; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; transition: all 0.2s;" onclick="switchReportCategoryTab('archived')">
              <span>📁 ${isAr ? 'الكادر المؤرشف / المنتهي خدمتهم (Archived Staff)' : 'Archived / Former Staff'}</span>
              <span class="badge" style="background: rgba(0,0,0,0.12); color: inherit; padding: 2px 8px; border-radius: 12px; font-size: 0.76rem;" id="countBadgeArchived">0</span>
            </button>
          </div>
        </div>

      </div>

      <!-- FILTER CONTROLS -->
      <div style="display: flex; flex-wrap: wrap; gap: 16px; margin-bottom: 16px; background: var(--primary-light); padding: 14px; border-radius: 8px;">
        <div style="flex: 1; min-width: 200px;">
          <label style="font-size: 0.8rem; font-weight: bold;">Filter by Department:</label>
          <select id="rptDeptFilter" onchange="filterReportsTable()" style="width: 100%; padding: 6px; margin-top: 4px; font-weight: bold;">
            <option value="ALL">All Departments (${depts.length})</option>
            ${deptOptionsHtml}
          </select>
        </div>

        <div style="flex: 1; min-width: 180px;">
          <label style="font-size: 0.8rem; font-weight: bold;">Staff Group:</label>
          <select id="rptStaffGroupFilter" onchange="filterReportsTable()" style="width: 100%; padding: 6px; margin-top: 4px; font-weight: bold;">
            <option value="ALL">All Staff Groups</option>
            <option value="Basic Plan">Basic Plan</option>
            <option value="Extended Program">Extended Program</option>
            <option value="Minimum Plan">Minimum Plan</option>
          </select>
        </div>

        <div style="flex: 1; min-width: 220px;">
          <label style="font-size: 0.8rem; font-weight: bold;">Departments/Units/Clinics Treating:</label>
          <select id="rptDeptTreatingFilter" onchange="filterReportsTable()" style="width: 100%; padding: 6px; margin-top: 4px; font-weight: bold;">
            <option value="ALL">All Treating Units / Clinics</option>
            <option value="babies under 1 years">babies under 1 years</option>
            <option value="Employees in oncology, hematooncology">Employees in oncology, hematooncology</option>
          </select>
        </div>

        <div style="flex: 1; min-width: 160px;">
          <label style="font-size: 0.8rem; font-weight: bold;">Immunity Status:</label>
          <select id="rptStatusFilter" onchange="filterReportsTable()" style="width: 100%; padding: 6px; margin-top: 4px; font-weight: bold;">
            <option value="ALL">All Statuses</option>
            <option value="Fully Immune">Fully Immune</option>
            <option value="Partially Compliant">Partially Compliant</option>
            <option value="Pending">Pending</option>
            <option value="Booster Due Soon">Booster Due Soon</option>
            <option value="Non-Responder">Non-Responder</option>
            <option value="Contraindicated">Contraindicated</option>
          </select>
        </div>

        <div style="flex: 1; min-width: 200px;">
          <label style="font-size: 0.8rem; font-weight: bold;">Search Staff Member:</label>
          <input type="text" id="rptSearch" placeholder="Search by name, ID, or Emp No..." onkeyup="filterReportsTable()" style="width: 100%; padding: 6px; margin-top: 4px;">
        </div>
      </div>

      <!-- PAGINATION TOP BAR -->
      <div id="rptPaginationTop" style="display: flex; justify-content: space-between; align-items: center; background: #F8FAFC; border: 1px solid #E2E8F0; padding: 10px 16px; border-radius: 8px; margin-bottom: 12px; flex-wrap: wrap; gap: 10px;"></div>

      <!-- QUICK TABLE HORIZONTAL SCROLL TOOLBAR -->
      <div style="display: flex; justify-content: space-between; align-items: center; background: #E0F2FE; border: 1px solid #7DD3FC; padding: 10px 16px; border-radius: 8px; margin-bottom: 14px; flex-wrap: wrap; gap: 10px;">
        <div style="font-size: 0.88rem; font-weight: 700; color: #0369A1; display: flex; align-items: center; gap: 8px;">
          <span>↔️ ${isAr ? 'تصفح كافة الأعمدة الـ 45 يميناً ويساراً:' : 'Scroll All 45 Excel Columns Right & Left:'}</span>
          <span style="font-size: 0.8rem; font-weight: normal; color: #0284C7;">(${isAr ? 'استخدم الأزرار أو اسحب شريط التمرير الملون' : 'Use buttons or drag the scrollbar below / Shift + Mouse Wheel'})</span>
        </div>
        <div style="display: flex; gap: 8px; flex-wrap: wrap;">
          <button type="button" class="btn btn-success" style="background: #10B981; border: none; font-weight: bold; padding: 6px 14px; font-size: 0.85rem; color: white; cursor: pointer; display: flex; align-items: center; gap: 4px;" onclick="addNewStaffRowFromReport()">
            ➕ ${isAr ? 'إضافة صف سجل موظف جديد' : 'Add New Staff Row'}
          </button>
          <button type="button" class="btn btn-outline" style="background: white; border: 2px solid #0284C7; color: #0369A1; font-weight: bold; padding: 6px 14px; font-size: 0.85rem;" onclick="scrollTableHorizontally(-500)">
            ◀️ ${isAr ? 'التمرير لليسار (Scroll Left)' : 'Scroll Left ◀️'}
          </button>
          <button type="button" class="btn btn-outline" style="background: white; border: 2px solid #0284C7; color: #0369A1; font-weight: bold; padding: 6px 14px; font-size: 0.85rem;" onclick="scrollTableHorizontally(500)">
            ${isAr ? 'التمرير لليمين (Scroll Right) ▶️' : '▶️ Scroll Right'}
          </button>
        </div>
      </div>

      <!-- TOP HORIZONTAL SCROLLBAR (MOVED ABOVE TABLE) -->
      <div style="background: #E0F2FE; border: 1px solid #7DD3FC; border-radius: 8px; padding: 6px 12px; margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 0.82rem; font-weight: bold; color: #0369A1; white-space: nowrap;">↔️ ${isAr ? 'شريط التمرير العلوي:' : 'Top Horizontal Scrollbar:'}</span>
        <div id="topScrollWrapper" class="custom-table-scroll" style="overflow-x: auto; flex: 1; height: 18px; background: white; border: 1px solid #93C5FD; border-radius: 4px;" onscroll="syncTopScroll(this)">
          <div id="topScrollDummy" style="width: 4600px; height: 1px;"></div>
        </div>
      </div>

      <!-- MASTER REPORT TABLE (FULL ALL-PARTS 55+ COLUMN AVH STAFF SCHEMA) -->
      <div id="tableScrollWrapper" class="custom-table-scroll" style="overflow-x: auto; max-width: 100%; border: 1px solid var(--border-color); border-radius: 8px; box-shadow: var(--shadow-sm);" onscroll="syncBottomScroll(this)">
        <table class="clinical-table" id="masterReportTable" style="width: 100%; min-width: 4600px; white-space: nowrap; font-size: 0.8rem;">
          <thead style="background: #113F52; color: white;">
            <tr>
              <th style="position: sticky; left: 0; background: #113F52; z-index: 3; text-align: center; border-right: 2px solid #334155; min-width: 270px;">Actions / الإجراءات</th>
              <th style="position: sticky; left: 270px; background: #113F52; z-index: 3;">National ID / الهوية</th>
              <th style="position: sticky; left: 380px; background: #113F52; z-index: 3;">Emp No / الرقم الوظيفي</th>
              <th style="position: sticky; left: 480px; background: #113F52; z-index: 3; border-right: 2px solid #334155;">Staff Full Name / اسم الموظف</th>
              <th>Arabic Full Name</th>
              <th>Date of Birth / تاريخ الميلاد</th>
              <th>Age / العمر</th>
              <th>Gender / الجنس</th>
              <th>ID Type / نوع الهوية</th>
              <th>Organization / القسم</th>
              <th>Position Name / المسمى</th>
              <th>Position Arabic</th>
              <th>Employment Status / حالة العمل</th>
              <th>Start Date / تاريخ المباشرة</th>
              <th>Assignment Effective Date</th>
              <th>Staff Group</th>
              <th>Treating Units / Clinics</th>
              <th>Invasive procedure</th>
              <th>Pregnancy Status / حالة الحمل (Sec 2)</th>
              <th>Allergies / الحساسية (Sec 2)</th>
              <th>HBsAb Result (Sec 3)</th>
              <th>HBsAb Date</th>
              <th>Date of Engrix 1st Dose</th>
              <th>Date of Engrix 2nd Dose</th>
              <th>Date of Engrix 3rd Dose</th>
              <th>Engrix Booster Dose</th>
              <th>HBsAg Result</th>
              <th>HCV Result</th>
              <th>HCV Date</th>
              <th>HIV Result</th>
              <th>HIV Date</th>
              <th>PPD 1st Step Result</th>
              <th>1st Step Induration</th>
              <th>PPD 1st Test Date</th>
              <th>2nd Step Result</th>
              <th>2nd Step Induration</th>
              <th>PPD 2nd Test Date</th>
              <th>IPV Vaccine (>18y) (Sec 4)</th>
              <th>Tdap Vaccine (>7y)</th>
              <th>MMR 1st Dose (>1y)</th>
              <th>MMR 2nd Dose (>1y)</th>
              <th>Chicken pox infected or Vaccinated</th>
              <th>Chicken pox vaccine date dose 1</th>
              <th>Chicken pox Vaccine 2nd dose</th>
              <th>Varicella Zoster, IgG</th>
              <th>Varicella Zoster, IgG date</th>
              <th>Mumps IgG Titer</th>
              <th>Mumps IgG Titer date</th>
              <th>Measles IgG Titer</th>
              <th>Measles IgG Titer date</th>
              <th>Rubella IgG Titer</th>
              <th>Rubella IgG Titer date</th>
              <th>Other Lab Test & Date</th>
              <th>Additional Core Vaccine Doses</th>
              <th>Meningiococcal A, C (Sec 5)</th>
              <th>hep A SERIES 1</th>
              <th>hep A SERIES 2</th>
              <th>typhoid</th>
              <th>Pnemovax</th>
              <th>Note / ملاحظات</th>
              <th>Additional Special Vaccines</th>
              <th>Covid 1st Dose Date (Sec 6)</th>
              <th>PATCH #1</th>
              <th>Covid 2nd Dose Date</th>
              <th>PATCH #2</th>
              <th>Covid 3rd Dose Date</th>
              <th>PATCH #3</th>
              <th>Additional Covid/Flu Doses</th>
              <th>flu vaccine 2023-2024</th>
              <th>flu vaccine 2024-2025</th>
              <th>PEP Serial / Ref No. (Sec 7)</th>
              <th>PEP Injury Report Date</th>
              <th>PEP Protocol</th>
              <th>PEP Indication</th>
              <th>PEP Follow-Up Date</th>
              <th>Immunity Status</th>
            </tr>
            <!-- INTERACTIVE COLUMN FILTER ROW (EXCEL-STYLE MULTI-SELECT CHECKBOX BUTTONS) -->
            <tr style="background: #0F172A; border-bottom: 2px solid #334155;">
              <th style="position: sticky; left: 0; background: #0F172A; z-index: 3; text-align: center; border-right: 2px solid #334155; padding: 4px;">
                <button type="button" class="btn btn-danger" style="padding: 3px 8px; font-size: 0.72rem; font-weight: bold; background: #EF4444; color: white; border: none; border-radius: 4px; cursor: pointer;" onclick="clearAllColumnFilters()">🧹 ${isAr ? 'مسح الفلاتر' : 'Clear All'}</button>
              </th>
              <th style="position: sticky; left: 270px; background: #0F172A; z-index: 3; padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="nationalId" data-label="ID" onclick="toggleExcelFilterMenu(event, 'nationalId', 'Person Number / ID / الهوية')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 ID...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="position: sticky; left: 380px; background: #0F172A; z-index: 3; padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="empNo" data-label="Emp No" onclick="toggleExcelFilterMenu(event, 'empNo', 'Staff ID / رقم الموظف')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Emp No...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="position: sticky; left: 480px; background: #0F172A; z-index: 3; border-right: 2px solid #334155; padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="fullName" data-label="Name" onclick="toggleExcelFilterMenu(event, 'fullName', 'Full Name / الاسم بالعبرية/الإنجليزية')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Name...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="arabicFullName" data-label="Arabic Name" onclick="toggleExcelFilterMenu(event, 'arabicFullName', 'الاسم بالعربية')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Arabic Name...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="dob" data-label="DOB" onclick="toggleExcelFilterMenu(event, 'dob', 'Date of Birth')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 DOB...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="age" data-label="Age" onclick="toggleExcelFilterMenu(event, 'age', 'Age / العمر')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Age...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="gender" data-label="Gender" onclick="toggleExcelFilterMenu(event, 'gender', 'Gender / الجنس')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Gender...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="idType" data-label="ID Type" onclick="toggleExcelFilterMenu(event, 'idType', 'ID Type')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 ID Type...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="orgName" data-label="Org" onclick="toggleExcelFilterMenu(event, 'orgName', 'Organization / القسم')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Org...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="positionName" data-label="Position" onclick="toggleExcelFilterMenu(event, 'positionName', 'Position Name / المسمى')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Position...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="positionArabic" data-label="Position Ar" onclick="toggleExcelFilterMenu(event, 'positionArabic', 'المسمى الوظيفي')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Position Ar...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="employmentStatus" data-label="Status" onclick="toggleExcelFilterMenu(event, 'employmentStatus', 'Employment Status / حالة العمل')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Status...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="startDate" data-label="Start Date" onclick="toggleExcelFilterMenu(event, 'startDate', 'Start Date / تاريخ المباشرة')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Start Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="assignmentEffectiveDate" data-label="Assign Date" onclick="toggleExcelFilterMenu(event, 'assignmentEffectiveDate', 'Assignment Effective Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Assign Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="staffGroup" data-label="Group" onclick="toggleExcelFilterMenu(event, 'staffGroup', 'Staff Group / فئة الموظف')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Group...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="deptTreating" data-label="Treating Units" onclick="toggleExcelFilterMenu(event, 'deptTreating', 'Treating Units / Clinics / الأقسام العلاجية')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Treating Units...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="invasiveProcedure" data-label="Invasive" onclick="toggleExcelFilterMenu(event, 'invasiveProcedure', 'Invasive Procedure / إجراءات تداخلية')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Invasive...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="pregnancyStatus" data-label="Pregnancy" onclick="toggleExcelFilterMenu(event, 'pregnancyStatus', 'Pregnancy / Breast Feeding')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Pregnancy...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="allergies" data-label="Allergies" onclick="toggleExcelFilterMenu(event, 'allergies', 'Allergies')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Allergies...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hbsab" data-label="HBsAb" onclick="toggleExcelFilterMenu(event, 'hbsab', 'HBsAb Level Result')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HBsAb...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hbsabDate" data-label="HBsAb Date" onclick="toggleExcelFilterMenu(event, 'hbsabDate', 'HBsAb Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HBsAb Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="engrix1" data-label="Engrix 1" onclick="toggleExcelFilterMenu(event, 'engrix1', 'Engrix Dose 1 Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Engrix 1...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="engrix2" data-label="Engrix 2" onclick="toggleExcelFilterMenu(event, 'engrix2', 'Engrix Dose 2 Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Engrix 2...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="engrix3" data-label="Engrix 3" onclick="toggleExcelFilterMenu(event, 'engrix3', 'Engrix Dose 3 Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Engrix 3...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="engrixBooster" data-label="Booster" onclick="toggleExcelFilterMenu(event, 'engrixBooster', 'Engrix Booster Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Booster...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hbsag" data-label="HBsAg" onclick="toggleExcelFilterMenu(event, 'hbsag', 'HBsAg Result')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HBsAg...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hcv" data-label="HCV" onclick="toggleExcelFilterMenu(event, 'hcv', 'HCV Ab Result')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HCV...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hcvDate" data-label="HCV Date" onclick="toggleExcelFilterMenu(event, 'hcvDate', 'HCV Ab Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HCV Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hiv" data-label="HIV" onclick="toggleExcelFilterMenu(event, 'hiv', 'HIV Ag/Ab Result')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HIV...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hivDate" data-label="HIV Date" onclick="toggleExcelFilterMenu(event, 'hivDate', 'HIV Ag/Ab Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HIV Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="ppdRes" data-label="PPD" onclick="toggleExcelFilterMenu(event, 'ppdRes', 'PPD Result')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PPD...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="ppd1Ind" data-label="1st Ind" onclick="toggleExcelFilterMenu(event, 'ppd1Ind', '1st Induration mm')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 1st Ind...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="ppd1Date" data-label="PPD1 Date" onclick="toggleExcelFilterMenu(event, 'ppd1Date', 'PPD 1st Step Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PPD1 Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="ppd2Res" data-label="PPD2" onclick="toggleExcelFilterMenu(event, 'ppd2Res', '2nd Step PPD Result')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PPD2...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="ppd2Ind" data-label="2nd Ind" onclick="toggleExcelFilterMenu(event, 'ppd2Ind', '2nd Induration mm')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 2nd Ind...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="ppd2Date" data-label="PPD2 Date" onclick="toggleExcelFilterMenu(event, 'ppd2Date', '2nd Step PPD Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PPD2 Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="ipv" data-label="IPV" onclick="toggleExcelFilterMenu(event, 'ipv', 'IPV Vaccine')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 IPV...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="tdap" data-label="Tdap" onclick="toggleExcelFilterMenu(event, 'tdap', 'Tdap Vaccine')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Tdap...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="mmr1" data-label="MMR1" onclick="toggleExcelFilterMenu(event, 'mmr1', 'MMR 1st Dose')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 MMR1...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="mmr2" data-label="MMR2" onclick="toggleExcelFilterMenu(event, 'mmr2', 'MMR 2nd Dose')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 MMR2...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="chickenpox" data-label="Chickenpox" onclick="toggleExcelFilterMenu(event, 'chickenpox', 'Chicken pox infected or Vaccinated')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Chickenpox...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="chickenpoxDose1" data-label="CP Dose 1" onclick="toggleExcelFilterMenu(event, 'chickenpoxDose1', 'Chicken pox vaccine date dose 1')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 CP Dose 1...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="chickenpox2" data-label="CP Dose 2" onclick="toggleExcelFilterMenu(event, 'chickenpox2', 'Chicken pox Vaccine 2nd dose')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 CP Dose 2...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="varicellaIgg" data-label="Varicella IgG" onclick="toggleExcelFilterMenu(event, 'varicellaIgg', 'Varicella Zoster, IgG')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Varicella IgG...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="varicellaDate" data-label="Varicella Date" onclick="toggleExcelFilterMenu(event, 'varicellaDate', 'Varicella Zoster, IgG date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Varicella Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="mumpsIgg" data-label="Mumps IgG" onclick="toggleExcelFilterMenu(event, 'mumpsIgg', 'Mumps IgG Titer')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Mumps IgG...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="mumpsDate" data-label="Mumps Date" onclick="toggleExcelFilterMenu(event, 'mumpsDate', 'Mumps IgG Titer date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Mumps Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="measlesIgg" data-label="Measles IgG" onclick="toggleExcelFilterMenu(event, 'measlesIgg', 'Measles IgG Titer')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Measles IgG...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="measlesDate" data-label="Measles Date" onclick="toggleExcelFilterMenu(event, 'measlesDate', 'Measles IgG Titer date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Measles Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="rubellaIgg" data-label="Rubella IgG" onclick="toggleExcelFilterMenu(event, 'rubellaIgg', 'Rubella IgG Titer')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Rubella IgG...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="rubellaDate" data-label="Rubella Date" onclick="toggleExcelFilterMenu(event, 'rubellaDate', 'Rubella IgG Titer date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Rubella Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="otherLab" data-label="Other Lab" onclick="toggleExcelFilterMenu(event, 'otherLab', 'Other Lab Result / Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Other Lab...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="extraCore" data-label="Core Extra" onclick="toggleExcelFilterMenu(event, 'extraCore', 'Extra Core Vaccines')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Core Extra...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="meningococcal" data-label="Menactra" onclick="toggleExcelFilterMenu(event, 'meningococcal', 'Meningococcal (Menactra)')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Menactra...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hepA1" data-label="HepA1" onclick="toggleExcelFilterMenu(event, 'hepA1', 'Hepatitis A 1st Dose Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HepA1...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="hepA2" data-label="HepA2" onclick="toggleExcelFilterMenu(event, 'hepA2', 'Hepatitis A 2nd Dose Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 HepA2...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="typhoid" data-label="Typhoid" onclick="toggleExcelFilterMenu(event, 'typhoid', 'Typhoid Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Typhoid...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="pneumovax" data-label="Pneumovax" onclick="toggleExcelFilterMenu(event, 'pneumovax', 'Pneumovax 23 Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Pneumovax...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="note" data-label="Note" onclick="toggleExcelFilterMenu(event, 'note', 'Note / ملاحظات')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Note...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="extraSp" data-label="Special Extra" onclick="toggleExcelFilterMenu(event, 'extraSp', 'Extra Special Vaccines')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Special Extra...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="covidD1" data-label="Covid1" onclick="toggleExcelFilterMenu(event, 'covidD1', 'COVID-19 1st Dose Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Covid1...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="covidP1" data-label="Patch1" onclick="toggleExcelFilterMenu(event, 'covidP1', 'COVID-19 1st Patch/Batch No.')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Patch1...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="covidD2" data-label="Covid2" onclick="toggleExcelFilterMenu(event, 'covidD2', 'COVID-19 2nd Dose Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Covid2...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="covidP2" data-label="Patch2" onclick="toggleExcelFilterMenu(event, 'covidP2', 'COVID-19 2nd Patch/Batch No.')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Patch2...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="covidD3" data-label="Covid3" onclick="toggleExcelFilterMenu(event, 'covidD3', 'COVID-19 Booster 3rd Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Covid3...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="covidP3" data-label="Patch3" onclick="toggleExcelFilterMenu(event, 'covidP3', 'COVID-19 3rd Patch/Batch No.')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Patch3...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="extraCovidFlu" data-label="Covid/Flu Extra" onclick="toggleExcelFilterMenu(event, 'extraCovidFlu', 'Extra Covid/Flu Doses')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Covid/Flu Extra...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="flu2324" data-label="Flu 23-24" onclick="toggleExcelFilterMenu(event, 'flu2324', 'Seasonal Flu 2023-2024 Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Flu 23-24...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="flu2425" data-label="Flu 24-25" onclick="toggleExcelFilterMenu(event, 'flu2425', 'Seasonal Flu 2024-2025 Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Flu 24-25...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="pepSerialNo" data-label="PEP Serial" onclick="toggleExcelFilterMenu(event, 'pepSerialNo', 'PEP Incident Serial / Ref No.')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PEP Serial...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="pepReportDate" data-label="PEP Report Date" onclick="toggleExcelFilterMenu(event, 'pepReportDate', 'PEP Injury Incident Report Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PEP Report Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="pepProtocol" data-label="PEP Protocol" onclick="toggleExcelFilterMenu(event, 'pepProtocol', 'PEP Vaccine / Medication / Protocol')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PEP Protocol...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="pepIndication" data-label="PEP Indication" onclick="toggleExcelFilterMenu(event, 'pepIndication', 'PEP Indication')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PEP Indication...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="pepDate" data-label="PEP Date" onclick="toggleExcelFilterMenu(event, 'pepDate', 'PEP Follow-Up Date')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 PEP Date...</span><span style="font-size:0.62rem;">▼</span></button></th>
              <th style="padding: 4px;"><button type="button" class="excel-col-filter-btn" data-col="immunityStatus" data-label="Immunity" onclick="toggleExcelFilterMenu(event, 'immunityStatus', 'Immunity Status / حالة التطعيم')" style="width: 100%; padding: 3px 6px; font-size: 0.73rem; border-radius: 4px; border: 1px solid #475569; background: #1E293B; color: white; cursor: pointer; display: flex; justify-content: space-between; align-items: center;"><span>🔍 Immunity...</span><span style="font-size:0.62rem;">▼</span></button></th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>

      <!-- PAGINATION BOTTOM BAR -->
      <div id="rptPaginationBottom" style="display: flex; justify-content: space-between; align-items: center; background: #F8FAFC; border: 1px solid #E2E8F0; padding: 10px 16px; border-radius: 8px; margin-top: 14px; flex-wrap: wrap; gap: 10px;"></div>
    </div>
  `;

    try {
      filterReportsTable();
    } catch(err) {
      console.error("filterReportsTable error:", err);
    }
    setTimeout(() => {
      try {
        populateColumnFilterDropdowns(true);
      } catch(e) {}
    }, 50);
  } catch (err) {
    console.error("Error rendering vaccination reports:", err);
    container.innerHTML = `
      <div class="card" style="padding: 24px;">
        <h3 style="color: #DC2626;">⚠️ Error Loading Vaccination Reports</h3>
        <p style="color: #64748B; margin: 10px 0;">An unexpected error occurred: ${err.message}. Click below to retry.</p>
        <button class="btn btn-primary" onclick="renderVaccinationReports(document.getElementById('mainAppArea'))">🔄 Retry Loading Reports</button>
      </div>
    `;
  }
}
window.renderVaccinationReports = renderVaccinationReports;

function editEmployeeFromReportTable(empNo) {
  if (typeof switchNav === 'function') {
    switchNav('staff-entry');
    setTimeout(() => {
      if (typeof selectStaffFromSearch === 'function') {
        selectStaffFromSearch(empNo);
      }
    }, 150);
  }
}

let rptActiveReportCategory = 'avh';

function calculateMOHImmunityStatus(emp) {
  if (!emp) return 'Incomplete Data';
  if (emp._mohStatusCache) return emp._mohStatusCache;

  // 0. Primary Authority: Respect explicit manual immunity override if set by physician / specialist
  const explicitStatus = emp.immunityStatus || (emp.demographic && emp.demographic.immunityStatus);
  if (explicitStatus && explicitStatus !== 'Pending' && explicitStatus !== 'Pending Verification' && explicitStatus !== 'Incomplete Data') {
    emp._mohStatusCache = explicitStatus;
    return explicitStatus;
  }

  const demo = emp.demographic || {};
  const vac = emp.vaccines || {};
  const lab = emp.labResults || emp.lab || {};
  const sp = emp.specialVaccines || {};
  const cf = emp.covidFlu || {};

  const hasTdap = !!(vac.tdapDate || emp.tdapDate || (vac.Tdap && (vac.Tdap.d5 || vac.Tdap.d1)));
  
  const isMMRImmune = typeof isMMRProtected === 'function' ? isMMRProtected(emp) : !!(vac.mmrDose1 || emp.mmrDose1 || (vac.MMR && vac.MMR.d1));

  const cpStatus = String(vac.chickenpoxStatus || emp.chickenpoxStatus || vac.chickenpox || '').toLowerCase();
  const varIgG = String(vac.varicellaIgG || lab.varicellaIgG || emp.varicellaIgG || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '').toLowerCase();
  const isVaricellaImmune = !!(
    vac.chickenpoxDose2 || emp.chickenpoxDose2 || vac.chickenpoxDose1 || emp.chickenpoxDose1 ||
    cpStatus.includes('vaccin') || cpStatus.includes('immune') || cpStatus.includes('natural') || cpStatus.includes('pos') ||
    varIgG.includes('pos') || varIgG.includes('immune') || varIgG.includes('natural')
  );

  const hasPolio = !!(vac.ipvDate || emp.ipvDate || (vac.IPV && (vac.IPV.d5 || vac.IPV.d1)));

  const hasHBVVac = !!(lab.engrixDose3 || lab.engrixDose2 || lab.engrixDose1 || (vac['Hepatitis B'] && vac['Hepatitis B'].d1));
  
  const rawHbsab = String(emp.hepbTiter || lab.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || '').toLowerCase().trim();
  const immStatus = String(emp.immunityStatus || '').toLowerCase().trim();

  const isNonResponder = rawHbsab.includes('non-responder') || rawHbsab.includes('non responder') || 
                         rawHbsab.includes('resistance') || rawHbsab.includes('nonresponder') ||
                         immStatus.includes('non-responder') || immStatus.includes('resistance');

  const numMatch = rawHbsab.match(/([<>])?\s*([0-9]+(?:\.[0-9]+)?)/);
  const hasLessThan = rawHbsab.includes('<');
  const hasGreaterThan = rawHbsab.includes('>') || rawHbsab.includes('positive') || rawHbsab.includes('pos') || rawHbsab.includes('immune') || rawHbsab.includes('react');
  let parsedVal = numMatch ? parseFloat(numMatch[2]) : null;

  const isImmuneGreater10 = !hasLessThan && (hasGreaterThan || (parsedVal !== null && parsedVal >= 10) || (parsedVal === null && immStatus.includes('immune') && !immStatus.includes('non-responder')));

  const hasAntiHBs = isImmuneGreater10 || isNonResponder || !!(rawHbsab && !rawHbsab.includes('blank') && !rawHbsab.includes('pending') && rawHbsab !== '0');
  const hasAntiHBc = isImmuneGreater10 || isNonResponder || !!(lab.antiHbcResult || lab.antiHBc);
  const hasHBsAg = isImmuneGreater10 || isNonResponder || !!(lab.hbsagResult || lab.HBsAg);
  const noNeedHBV = isImmuneGreater10 || isNonResponder;

  const rawHcv = String(lab.hcvResult || lab.HCV || '').toLowerCase();
  const hasAntiHCV = !!(rawHcv && !rawHcv.includes('blank') && !rawHcv.includes('pending'));

  const rawPpd = String(lab.ppdStep1Result || lab.ppdResult || lab.PPD || '').toLowerCase();
  const hasPPD = !!(rawPpd && !rawPpd.includes('blank') && !rawPpd.includes('pending'));

  const hasFlu = !!(cf.flu2425 || cf.flu2324 || cf.fluDate || (vac['Flu vaccine'] && vac['Flu vaccine'].d5));

  const hasTyphoid = !!(sp.typhoid || sp.typhoidDate);
  const hasMeningo = !!(sp.meningococcal || sp.meningococcalDate);
  const hasPneumo = !!(sp.pneumovax || sp.pnemovax || sp.pneumovaxDate);
  const hasHepA = !!(sp.hepA2 || sp.hepA1 || sp.hepADate);

  const isLabStaff = typeof isSpecialVaccineStaff === 'function' ? isSpecialVaccineStaff(emp) : false;

  const isMin = typeof isMinimumStaff === 'function' ? isMinimumStaff(emp) : false;
  const isExt = typeof isExtendedStaff === 'function' ? isExtendedStaff(emp) : false;
  const isBasic = typeof isBasicStaff === 'function' ? isBasicStaff(emp) : false;

  let missing = [];

  if (isLabStaff) {
    if (!hasTdap) missing.push('Tdap');
    if (!isMMRImmune) missing.push('MMR');
    if (!isVaricellaImmune) missing.push('Chickenpox');
    if (!hasPolio) missing.push('Polio');
    if (!noNeedHBV && !hasHBVVac) missing.push('HBV');
    if (!noNeedHBV && !hasAntiHBs) missing.push('Anti-HBs');
    if (!hasAntiHCV) missing.push('Anti-HCV');
    if (!noNeedHBV && !hasAntiHBc) missing.push('Anti-HBc');
    if (!noNeedHBV && !hasHBsAg) missing.push('HBsAg');
    if (!hasPPD) missing.push('PPD');
    if (!hasTyphoid) missing.push('Typhoid');
    if (!hasMeningo) missing.push('Meningo');
    if (!hasPneumo) missing.push('Pneumo');
    if (!hasHepA) missing.push('Hep A');
  } else if (isExt) {
    if (!hasTdap) missing.push('Tdap');
    if (!isMMRImmune) missing.push('MMR');
    if (!isVaricellaImmune) missing.push('Chickenpox');
    if (!hasPolio) missing.push('Polio');
    if (!noNeedHBV && !hasHBVVac) missing.push('HBV');
    if (!noNeedHBV && !hasAntiHBs) missing.push('Anti-HBs');
    if (!hasPPD) missing.push('PPD');
  } else if (isBasic) {
    if (!hasTdap) missing.push('Tdap');
    if (!isMMRImmune) missing.push('MMR');
    if (!isVaricellaImmune) missing.push('Chickenpox');
    if (!hasPolio) missing.push('Polio');
    if (!noNeedHBV && !hasHBVVac) missing.push('HBV');
    if (!noNeedHBV && !hasAntiHBs) missing.push('Anti-HBs');
    if (!hasPPD) missing.push('PPD');
  } else {
    if (!hasTdap) missing.push('Tdap');
    if (!isMMRImmune) missing.push('MMR');
    if (!isVaricellaImmune) missing.push('Chickenpox');
  }

  let finalStatus = 'Pending';
  if (isNonResponder && missing.length === 0) {
    finalStatus = 'Partially Compliant (Non-Responder)';
  } else if (isNonResponder) {
    finalStatus = 'Partially Compliant (Non-Responder, ' + missing.join(', ') + ')';
  } else if (missing.length === 0) {
    finalStatus = 'Fully Immune';
  } else if (missing.length <= 2) {
    finalStatus = 'Partially Compliant (' + missing.join(', ') + ')';
  }

  emp._mohStatusCache = finalStatus;
  return finalStatus;
}
window.calculateMOHImmunityStatus = calculateMOHImmunityStatus;

function isGazaStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const dept = String(emp.department || demo.deptTreating || demo.department || '').toLowerCase().trim();
  const org = String(demo.orgName || '').toLowerCase().trim();
  return dept.includes('gaza') || org.includes('gaza');
}
window.isGazaStaff = isGazaStaff;

function isAVHStaff(emp) {
  return !isGazaStaff(emp);
}
window.isAVHStaff = isAVHStaff;
window.isHospitalCoreStaff = isAVHStaff;

function isExtendedStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const group = String(emp.staffGroup || demo.staffGroup || '').toLowerCase().trim();
  return group.includes('extended');
}
window.isExtendedStaff = isExtendedStaff;

function isMinimumStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const group = String(emp.staffGroup || demo.staffGroup || '').toLowerCase().trim();
  return group.includes('minimum');
}
window.isMinimumStaff = isMinimumStaff;

function isBasicStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const group = String(emp.staffGroup || demo.staffGroup || '').toLowerCase().trim();
  return group.includes('basic') && !group.includes('minimum');
}
window.isBasicStaff = isBasicStaff;

function isBabiesPediatricStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const treating = String(demo.deptTreating || emp.deptTreating || '').trim().toLowerCase();
  return treating === 'babies under 1 years';
}
window.isBabiesPediatricStaff = isBabiesPediatricStaff;

function isOncologyStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const treating = String(demo.deptTreating || emp.deptTreating || '').trim().toLowerCase();
  return treating === 'employees in oncology, hematooncology';
}
window.isOncologyStaff = isOncologyStaff;

function isNoCategoryStaff(emp) {
  return !isOncologyStaff(emp) && !isBabiesPediatricStaff(emp);
}
window.isNoCategoryStaff = isNoCategoryStaff;

const SPECIAL_CLINICAL_LAB_DEPARTMENTS = [
  'anatomical pathology department',
  'anatomical pathology department/tech',
  'clinical laboratory',
  'hematopathology ,cellular therapy and applied genomics department',
  'hematopathology, cellular therapy and applied genomics department',
  'hematopathology,cellular therapy and applied genomics department',
  'laboratory medicine department',
  'molecular laboratory unit',
  'apheresis and bone marrow transplant lab',
  'hematomolecular pathology'
];

function isSpecialVaccineStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const group = String(emp.staffGroup || demo.staffGroup || '').toLowerCase().trim();
  const dept = String(emp.department || demo.department || demo.deptTreating || '').toLowerCase().trim();
  const title = String(emp.jobTitle || demo.positionName || demo.positionArabic || '').toLowerCase().trim();

  // Secretary & administrative office staff excluded unless they are technologists/lab staff
  if ((dept.includes('secretary') || title.includes('secretary') || dept.includes('admin') || title.includes('admin')) && !title.includes('tech') && !title.includes('lab')) {
    return false;
  }

  // Explicit laboratory department or job title match
  if (SPECIAL_CLINICAL_LAB_DEPARTMENTS.includes(dept)) return true;
  if (title.includes('lab') || title.includes('laboratory') || title.includes('pathology') || title.includes('molecular') || title.includes('apheresis') || title.includes('genomics') || title.includes('microbiology')) {
    return true;
  }
  if (dept.includes('pathology') || dept.includes('clinical lab') || dept.includes('laboratory') || dept.includes('hematopathology') || dept.includes('cellular therapy') || dept.includes('applied genomics') || dept.includes('molecular') || dept.includes('apheresis') || dept.includes('bone marrow') || dept.includes('hematomolecular')) {
    return true;
  }

  // Explicit staffGroup match for Special Vaccines / Lab Techs
  if (group.includes('special') || group.includes('lab') || group.includes('4-')) return true;

  return false;
}
window.isSpecialVaccineStaff = isSpecialVaccineStaff;

const INVASIVE_PROCEDURE_DEPARTMENTS = [
  "anesthesia / doctor",
  "anesthesia / tech",
  "chemotherapy day care",
  "clinical laboratory",
  "hematology and bmt department/nursing",
  "hematology and bone morrow transplantation department/ doctors",
  "intensive care unit (doctors)",
  "intensive care unit / nursing",
  "internal medicine",
  "internal medicine department/ nursing",
  "kidney care center for adults",
  "kidney care center for adults( doctors)",
  "kidney care center for adults/nursing",
  "long term skilled nursing department",
  "long term skilled nursing department/ nursing",
  "medical oncology (doctors)",
  "oncology specialists doctors",
  "operation theater",
  "pediatric hematology- oncology / specialists",
  "pediatric hematology-oncology department/ nursing",
  "pediatric hematology-oncology/ doctors",
  "pediatric hemodialysis",
  "pediatric nephrology & pediatric intensive care unit/ nursing",
  "pediatric nephrology and dialysis department/doctors",
  "pediatric nephrology and dialysis department/specialists",
  "radiation oncology specialists",
  "radiology / doctors",
  "radiology / tech",
  "surgery specialist doctors",
  "surgical department / doctors",
  "surgical department / nursing",
  "surgical department / specialists",
  "treatment room and out-patient clinics"
];

function isInvasiveProcedureStaff(emp) {
  if (!emp) return false;
  const demo = emp.demographic || {};
  const inv = String(demo.invasiveProcedure || emp.invasiveProcedure || '').trim().toLowerCase();
  if (inv === 'yes' || inv === 'true' || inv === 'y') return true;
  if (inv === 'no' || inv === 'false' || inv === 'n') return false;
  const dept = String(emp.department || demo.department || '').trim().toLowerCase();
  return INVASIVE_PROCEDURE_DEPARTMENTS.includes(dept);
}
window.isInvasiveProcedureStaff = isInvasiveProcedureStaff;

function getEmployeeSector(emp) {
  if (!emp) return 'Administrative / Support';
  const demo = emp.demographic || {};
  const title = String(emp.jobTitle || demo.positionName || demo.title || '').toLowerCase().trim();
  const dept = String(emp.department || demo.department || demo.deptTreating || '').toLowerCase().trim();
  const text = `${title} ${dept}`;

  if (text.includes('doctor') || text.includes('physician') || text.includes('surgeon') || text.includes('specialist') || text.includes('resident') || text.includes('house officer') || text.includes('consultant') || text.includes('medical officer') || text.includes('pathologist') || text.includes('radiologist') || text.includes('oncologist') || text.includes('pediatrician') || text.includes('nephrologist') || text.includes('intensivist') || text.includes('dentist')) {
    return 'Physician';
  }

  if (text.includes('nurse') || text.includes('nursing') || text.includes('midwife') || text.includes('head nurse') || text.includes('staff nurse') || text.includes('practical nurse') || text.includes('aid nurse') || text.includes('nursery')) {
    return 'Nurse';
  }

  if (text.includes('tech') || text.includes('technologist') || text.includes('laboratory') || text.includes('lab') || text.includes('pharmacy') || text.includes('pharmacist') || text.includes('radiographer') || text.includes('physiotherapy') || text.includes('physiotherapist') || text.includes('dietitian') || text.includes('nutrition') || text.includes('social worker') || text.includes('engineer') || text.includes('phlebotom') || text.includes('therapist') || text.includes('psychologist') || text.includes('paramedic')) {
    return 'Allied health professional';
  }

  return 'Administrative / Support';
}
window.getEmployeeSector = getEmployeeSector;

function switchReportCategoryTab(cat) {
  rptActiveReportCategory = cat;
  rptCurrentPage = 1;
  filterReportsTableImmediate();
  updateReportTabStyles();
}
window.switchReportCategoryTab = switchReportCategoryTab;

function updateReportTabStyles() {
  try {
    const masterList = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
    const safeMasterList = Array.isArray(masterList) ? masterList.filter(e => e && typeof e === 'object') : [];
    const activeMasterList = safeMasterList.filter(e => (typeof isActiveStaff === 'function' ? isActiveStaff(e) : true));
    const hospitalList = activeMasterList.filter(e => isAVHStaff(e));
    const archivedList = safeMasterList.filter(e => (typeof isArchivedStaff === 'function' ? isArchivedStaff(e) : false));

    const counts = {
      extended: hospitalList.filter(e => isExtendedStaff(e)).length,
      minimum: hospitalList.filter(e => isMinimumStaff(e)).length,
      basic: hospitalList.filter(e => isBasicStaff(e)).length,
      special: hospitalList.filter(e => isSpecialVaccineStaff(e)).length,
      oncology: hospitalList.filter(e => isOncologyStaff(e)).length,
      babies: hospitalList.filter(e => isBabiesPediatricStaff(e)).length,
      nocat: hospitalList.filter(e => isNoCategoryStaff(e)).length,
      invasive: hospitalList.filter(e => isInvasiveProcedureStaff(e)).length,
      avh: hospitalList.length,
      gaza: activeMasterList.filter(e => isGazaStaff(e)).length,
      all: activeMasterList.length,
      archived: archivedList.length
    };

    const tabsConfig = [
      { key: 'extended', btnId: 'btnRptTabExtended', badgeId: 'countBadgeExtended', activeBg: 'linear-gradient(135deg, #0D9488 0%, #0F766E 100%)', activeBorder: '2px solid #0F766E', activeShadow: '0 4px 12px rgba(13, 148, 136, 0.3)' },
      { key: 'minimum', btnId: 'btnRptTabMinimum', badgeId: 'countBadgeMinimum', activeBg: 'linear-gradient(135deg, #D97706 0%, #B45309 100%)', activeBorder: '2px solid #B45309', activeShadow: '0 4px 12px rgba(217, 119, 6, 0.3)' },
      { key: 'basic', btnId: 'btnRptTabBasic', badgeId: 'countBadgeBasic', activeBg: 'linear-gradient(135deg, #2563EB 0%, #1D4ED8 100%)', activeBorder: '2px solid #1D4ED8', activeShadow: '0 4px 12px rgba(37, 99, 235, 0.3)' },
      { key: 'special', btnId: 'btnRptTabSpecial', badgeId: 'countBadgeSpecial', activeBg: 'linear-gradient(135deg, #047857 0%, #065F46 100%)', activeBorder: '2px solid #065F46', activeShadow: '0 4px 12px rgba(4, 120, 87, 0.3)' },
      { key: 'oncology', btnId: 'btnRptTabOncology', badgeId: 'countBadgeOncology', activeBg: 'linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)', activeBorder: '2px solid #6D28D9', activeShadow: '0 4px 12px rgba(124, 58, 237, 0.3)' },
      { key: 'babies', btnId: 'btnRptTabBabies', badgeId: 'countBadgeBabies', activeBg: 'linear-gradient(135deg, #4F46E5 0%, #4338CA 100%)', activeBorder: '2px solid #4338CA', activeShadow: '0 4px 12px rgba(79, 70, 229, 0.3)' },
      { key: 'nocat', btnId: 'btnRptTabNoCat', badgeId: 'countBadgeNoCat', activeBg: 'linear-gradient(135deg, #475569 0%, #334155 100%)', activeBorder: '2px solid #334155', activeShadow: '0 4px 12px rgba(71, 85, 105, 0.3)' },
      { key: 'invasive', btnId: 'btnRptTabInvasive', badgeId: 'countBadgeInvasive', activeBg: 'linear-gradient(135deg, #059669 0%, #047857 100%)', activeBorder: '2px solid #047857', activeShadow: '0 4px 12px rgba(5, 150, 105, 0.3)' },
      { key: 'avh', btnId: 'btnRptTabAVH', badgeId: 'countBadgeAVH', activeBg: 'linear-gradient(135deg, #0284C7 0%, #0369A1 100%)', activeBorder: '2px solid #0369A1', activeShadow: '0 4px 12px rgba(2, 132, 199, 0.3)' },
      { key: 'gaza', btnId: 'btnRptTabGaza', badgeId: 'countBadgeGaza', activeBg: 'linear-gradient(135deg, #DC2626 0%, #B91C1C 100%)', activeBorder: '2px solid #B91C1C', activeShadow: '0 4px 12px rgba(220, 38, 38, 0.3)' },
      { key: 'all', btnId: 'btnRptTabAll', badgeId: 'countBadgeAll', activeBg: 'linear-gradient(135deg, #1E293B 0%, #0F172A 100%)', activeBorder: '2px solid #0F172A', activeShadow: '0 4px 12px rgba(15, 23, 42, 0.3)' },
      { key: 'archived', btnId: 'btnRptTabArchived', badgeId: 'countBadgeArchived', activeBg: 'linear-gradient(135deg, #475569 0%, #1E293B 100%)', activeBorder: '2px solid #1E293B', activeShadow: '0 4px 12px rgba(71, 85, 105, 0.3)' }
    ];

    tabsConfig.forEach(cfg => {
      const btn = document.getElementById(cfg.btnId);
      const badge = document.getElementById(cfg.badgeId);
      if (badge) badge.textContent = counts[cfg.key] !== undefined ? counts[cfg.key] : 0;
      if (btn) {
        const isActive = rptActiveReportCategory === cfg.key;
        btn.style.background = isActive ? cfg.activeBg : '#FFFFFF';
        btn.style.color = isActive ? '#FFFFFF' : '#334155';
        btn.style.border = isActive ? cfg.activeBorder : '1px solid #CBD5E1';
        btn.style.boxShadow = isActive ? cfg.activeShadow : '0 1px 3px rgba(0,0,0,0.05)';
        btn.style.transform = isActive ? 'translateY(-1px)' : 'none';
      }
    });

    const badgeEl = document.getElementById('rptCurrentFilterBadge');
    if (badgeEl) {
      const isAr = window.i18n ? window.i18n.isRTL() : false;
      const tabLabels = {
        extended: isAr ? `برنامج التغطية الشاملة (${counts.extended})` : `Extended Program (${counts.extended})`,
        minimum: isAr ? `الخطة الأدنى (${counts.minimum})` : `Minimum Plan (${counts.minimum})`,
        basic: isAr ? `الخطة الأساسية (${counts.basic})` : `Basic Plan (${counts.basic})`,
        special: isAr ? `كادر التطعيمات الخاصة والمختبرات (${counts.special})` : `Special Vaccines Staff (${counts.special})`,
        oncology: isAr ? `قسم الأورام وأورام الدم (${counts.oncology})` : `Oncology & Hemato-Oncology (${counts.oncology})`,
        babies: isAr ? `الأطفال والرضع (${counts.babies})` : `Babies & Pediatrics (${counts.babies})`,
        nocat: isAr ? `الأقسام العامة (${counts.nocat})` : `General Units (${counts.nocat})`,
        invasive: isAr ? `كادر الإجراءات التداخلية (${counts.invasive})` : `Invasive Procedures (${counts.invasive})`,
        avh: isAr ? `كادر مستشفى المطلع (${counts.avh})` : `AVH Hospital Staff (${counts.avh})`,
        gaza: isAr ? `كادر مشروع غزة (${counts.gaza})` : `Gaza Project Staff (${counts.gaza})`,
        all: isAr ? `كافة الكوادر النشطة (${counts.all})` : `All Active Staff (${counts.all})`,
        archived: isAr ? `الكادر المؤرشف (${counts.archived})` : `Archived Staff (${counts.archived})`
      };
      const label = tabLabels[rptActiveReportCategory] || (rptActiveReportCategory.toUpperCase());
      badgeEl.textContent = (isAr ? 'العرض النشط: ' : 'Active View: ') + label;
    }
  } catch (err) {
    console.error("updateReportTabStyles error:", err);
  }
}
window.updateReportTabStyles = updateReportTabStyles;

function extractRowColumnValues(e) {
  const demo = e.demographic || {};
  const lab = e.labResults || e.lab || {};
  const vac = e.vaccines || {};
  const sp = e.specialVaccines || {};
  const cf = e.covidFlu || {};

  const formatDate = (val, strict = true) => (typeof standardizeDateStr === 'function' ? standardizeDateStr(val, strict) : val);
  const effectiveDateVal = demo.assignmentEffectiveDate || demo.startDate || e.startDate || '';

  const canonicalRecs = typeof getCanonicalVaccineRecords === 'function' ? getCanonicalVaccineRecords(e) : [];
  const cov1Rec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'first' || r.doseType === '1st' || r.doseType === '1'));
  const cov2Rec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'second' || r.doseType === '2nd' || r.doseType === '2'));
  const cov3Rec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'third' || r.doseType === '3rd' || r.doseType === '3'));
  const covBoosterRec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'booster' || r.doseType === 'dose 4' || r.doseType === '4'));

  const covidD1 = cov1Rec ? formatDate(cov1Rec.date, true) : formatDate(cf.covidDose1Date || (vac['Covid - 19'] ? vac['Covid - 19'].d1 : ''), true);
  const covidP1 = cov1Rec ? (cov1Rec.lot || cov1Rec.mfr || '') : (cf.covidDose1Batch || (vac['Covid - 19'] ? vac['Covid - 19'].p1 : ''));
  const covidD2 = cov2Rec ? formatDate(cov2Rec.date, true) : formatDate(cf.covidDose2Date || (vac['Covid - 19'] ? vac['Covid - 19'].d2 : ''), true);
  const covidP2 = cov2Rec ? (cov2Rec.lot || cov2Rec.mfr || '') : (cf.covidDose2Batch || (vac['Covid - 19'] ? vac['Covid - 19'].p2 : ''));
  const covidD3 = cov3Rec ? formatDate(cov3Rec.date, true) : formatDate(cf.covidDose3Date || (vac['Covid - 19'] ? vac['Covid - 19'].d3 : ''), true);
  const covidP3 = cov3Rec ? (cov3Rec.lot || cov3Rec.mfr || '') : (cf.covidDose3Batch || (vac['Covid - 19'] ? vac['Covid - 19'].p3 : ''));
  const covidD4 = covBoosterRec ? formatDate(covBoosterRec.date, true) : formatDate(cf.covidDose4Date || '', true);
  const covidP4 = covBoosterRec ? (covBoosterRec.lot || covBoosterRec.mfr || '') : (cf.covidDose4Batch || '');

  const fluRecs = canonicalRecs.filter(r => r.type === 'flu');
  const fluSummary = fluRecs.length > 0
    ? fluRecs.map(r => (typeof getVaccineLabel === 'function' ? getVaccineLabel(r) : r.vacName) + (r.date ? ' [' + formatDate(r.date, true) + ']' : '') + (r.lot ? ' Lot:' + r.lot : '')).join('; ')
    : formatDate(cf.flu2425 || cf.flu2324 || cf.fluDate || '', true);

  const hbsab = lab.hbsabResult || lab.hbsAb || e.hepbTiter || e.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || '';
  const rawHbsabDate = lab.hbsabDate || lab.hbsAbDate || (lab.HBsAb ? lab.HBsAb.date : '') || e.hbsabDate || e.hbvBoosterDate || '';

  const hbsag = lab.hbsagResult || lab.hbsAg || e.hbsagResult || e.hbsAg || (lab.HBsAg ? lab.HBsAg.result : '') || '';
  const rawHbsagDate = lab.hbsagDate || lab.hbsAgDate || (lab.HBsAg ? lab.HBsAg.date : '') || e.hbsagDate || '';

  const hcv = lab.hcvResult || lab.hcv || e.hcvResult || e.hcv || (lab.HCV ? lab.HCV.result : '') || '';
  const rawHcvDate = lab.hcvDate || (lab.HCV ? lab.HCV.date : '') || e.hcvDate || '';

  const hiv = lab.hivResult || lab.hiv || e.hivResult || e.hiv || (lab.HIV ? lab.HIV.result : '') || '';
  const rawHivDate = lab.hivDate || (lab.HIV ? lab.HIV.date : '') || e.hivDate || '';

  const ppdRes = lab.ppdStep1Result || e.ppdStep1Result || lab.ppdResult || e.ppdResult || (lab.PPD ? lab.PPD.result : '') || '';
  const ppd1Ind = lab.ppdStep1Induration || e.ppdStep1Induration || (lab.PPD ? lab.PPD.test1 : '') || '0mm';
  const rawPpd1Date = lab.ppdStep1Date || e.ppdStep1Date || (lab.PPD ? (lab.PPD.date1 || lab.PPD.date) : '') || '';

  const ppd2Res = lab.ppdStep2Result || e.ppdStep2Result || (lab.PPD ? lab.PPD.test2 : '') || '';
  const ppd2Ind = lab.ppdStep2Induration || e.ppdStep2Induration || (lab.PPD ? lab.PPD.test2 : '') || '0mm';
  const rawPpd2Date = lab.ppdStep2Date || e.ppdStep2Date || (lab.PPD ? lab.PPD.date2 : '') || '';

  const varicellaIgg = vac.varicellaIgG || lab.varicellaIgG || e.varicellaIgG || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '';
  const rawVarDate = vac.varicellaIgGDate || lab.varicellaIgGDate || e.varicellaIgGDate || (lab.Varicella_IgG ? lab.Varicella_IgG.date : '') || '';

  const mumpsIgg = lab.mumpsIgG || lab.mumpsIgGTiter || e.mumpsIgG || e.mumpsIgGTiter || (lab.Mumps_IgG ? lab.Mumps_IgG.result : '') || '';
  const mumpsDate = lab.mumpsIgGDate || lab.mumpsIgGTiterDate || e.mumpsIgGDate || e.mumpsIgGTiterDate || (lab.Mumps_IgG ? lab.Mumps_IgG.date : '') || '';

  const measlesIgg = lab.measlesIgG || lab.measlesIgGTiter || e.measlesIgG || e.measlesIgGTiter || (lab.Measles_IgG ? lab.Measles_IgG.result : '') || '';
  const measlesDate = lab.measlesIgGDate || lab.measlesIgGTiterDate || e.measlesIgGDate || e.measlesIgGTiterDate || (lab.Measles_IgG ? lab.Measles_IgG.date : '') || '';

  const rubellaIgg = lab.rubellaIgG || lab.rubellaIgGTiter || e.rubellaIgG || e.rubellaIgGTiter || (lab.Rubella_IgG ? lab.Rubella_IgG.result : '') || '';
  const rubellaDate = lab.rubellaIgGDate || lab.rubellaIgGTiterDate || e.rubellaIgGDate || e.rubellaIgGTiterDate || (lab.Rubella_IgG ? lab.Rubella_IgG.date : '') || '';

  const engrix1 = lab.engrixDose1 || e.engrixDose1 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d1 : '') || '';
  const engrix2 = lab.engrixDose2 || e.engrixDose2 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d2 : '') || '';
  const engrix3 = lab.engrixDose3 || e.engrixDose3 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d3 : '') || '';
  const engrixBooster = lab.engrixBooster || e.engrixBooster || e.hbvBoosterDate || '';

  const extraCore = vac.additionalCoreDoses && vac.additionalCoreDoses.length > 0
    ? vac.additionalCoreDoses.map(d => [d.ipvDate, d.tdapDate, d.mmrDose1, d.chickenpoxStatus].filter(Boolean).map(v => formatDate(v, true)).join(' ')).join(' ')
    : '';

  const extraSp = sp.additionalSpecialDoses && sp.additionalSpecialDoses.length > 0
    ? sp.additionalSpecialDoses.map(d => (d.vacName || '') + ' ' + (d.date || '')).join(' ')
    : '';

  const extraCovidFlu = cf.additionalCovidFluDoses && cf.additionalCovidFluDoses.length > 0
    ? cf.additionalCovidFluDoses.map(d => (d.vacName || '') + ' ' + (d.batch || '') + ' ' + (d.date || '')).join(' ')
    : '';

  const pepRecs = (e.pep && Array.isArray(e.pep.additionalPepRecords) && e.pep.additionalPepRecords.length > 0) ? e.pep.additionalPepRecords : [];
  const pepSerialNo = pepRecs.map(p => p.serialNo || p.incidentId || '').filter(Boolean).join('; ');
  const pepReportDate = pepRecs.map(p => formatDate(p.incidentDate, false)).filter(Boolean).join('; ');
  const pepProtocol = pepRecs.map(p => p.protocol || '').filter(Boolean).join('; ');
  const pepIndication = pepRecs.map(p => p.indication || '').filter(Boolean).join('; ');
  const pepDate = pepRecs.map(p => formatDate(p.date, true)).filter(Boolean).join('; ');

  const gender = demo.gender || e.gender || '';
  const isFemale = (gender && gender.toString().trim().toLowerCase() === 'female');
  let preg = isFemale ? 'Not Pregnant' : 'Not Applicable';
  if (e.healthStatus && e.healthStatus.pregnancyStatus) {
    if (isFemale && (e.healthStatus.pregnancyStatus === 'Pregnant' || e.healthStatus.pregnancyStatus === 'Lactating' || e.healthStatus.pregnancyStatus === 'Not Pregnant')) {
      preg = e.healthStatus.pregnancyStatus;
    } else if (!isFemale) {
      preg = 'Not Applicable';
    }
  }

  const rawAgeVal = demo.age || e.age || '';
  const ageVal = typeof formatAgeToOneDecimal === 'function' ? formatAgeToOneDecimal(rawAgeVal) : rawAgeVal;
  const deptVal = e.department || demo.deptTreating || demo.department || demo.orgName || e.orgName || 'General Medical';
  const treatingVal = demo.deptTreating || e.deptTreating || '';
  const allergiesVal = (e.healthStatus && e.healthStatus.allergies) ? e.healthStatus.allergies : 'None';
  const invVal = demo.invasiveProcedure || e.invasiveProcedure || (typeof isInvasiveProcedureStaff === 'function' && isInvasiveProcedureStaff(e) ? 'Yes' : 'No');

  return {
    nationalId: e.idNo || demo.nationalId || '',
    empNo: e.empNo || demo.personNumber || e.id || '',
    fullName: e.name || demo.fullName || '',
    arabicFullName: demo.arabicFullName || '',
    dob: formatDate(demo.dob || demo.dateOfBirth || e.dob || '', false),
    age: ageVal,
    gender: gender,
    idType: demo.idType || e.idType || '',
    orgName: deptVal,
    positionName: e.jobTitle || demo.positionName || '',
    positionArabic: demo.positionArabic || '',
    employmentStatus: e.employmentStatus || demo.employmentStatus || 'Active',
    startDate: formatDate(demo.startDate || e.startDate || '', false),
    assignmentEffectiveDate: formatDate(demo.assignmentEffectiveDate || '', false),
    staffGroup: demo.staffGroup || e.staffGroup || 'Minimum Plan',
    deptTreating: treatingVal,
    invasiveProcedure: invVal,
    pregnancyStatus: preg,
    allergies: allergiesVal,
    hbsab: hbsab,
    hbsabDate: formatDate(rawHbsabDate, true),
    engrix1: formatDate(engrix1, true),
    engrix2: formatDate(engrix2, true),
    engrix3: formatDate(engrix3, true),
    engrixBooster: formatDate(engrixBooster, true),
    hbsag: hbsag,
    hcv: hcv,
    hcvDate: formatDate(rawHcvDate, true),
    hiv: hiv,
    hivDate: formatDate(rawHivDate, true),
    ppdRes: ppdRes,
    ppd1Ind: ppd1Ind,
    ppd1Date: formatDate(rawPpd1Date, true),
    ppd2Res: ppd2Res,
    ppd2Ind: ppd2Ind,
    ppd2Date: formatDate(rawPpd2Date, true),
    ipv: formatDate(vac.ipvDate || e.ipvDate || (vac.IPV ? vac.IPV.d5 || vac.IPV.d1 : '') || '', true),
    tdap: formatDate(vac.tdapDate || e.tdapDate || (vac.Tdap ? vac.Tdap.d5 || vac.Tdap.d1 : '') || '', true),
    mmr1: formatDate(vac.mmrDose1 || e.mmrDose1 || (vac.MMR ? vac.MMR.d1 : '') || '', true),
    mmr2: formatDate(vac.mmrDose2 || e.mmrDose2 || (vac.MMR ? (vac.MMR.d2 || vac.MMR.d5) : '') || '', true),
    chickenpox: vac.chickenpoxStatus || (vac['Varicella Zoster (Chicken pox)'] ? 'Vaccinated' : '') || '',
    chickenpoxDose1: formatDate(vac.chickenpoxDose1 || e.chickenpoxDose1 || vac.chickenpoxDose1Date || vac.chickenpoxDateDose1 || '', true),
    chickenpox2: formatDate(vac.chickenpoxDose2 || e.chickenpoxDose2 || '', true),
    varicellaIgg: varicellaIgg || e.varicellaIgG || '',
    varicellaDate: formatDate(rawVarDate || e.varicellaIgGDate || '', true),
    mumpsIgg: mumpsIgg || e.mumpsIgG || '',
    mumpsDate: formatDate(mumpsDate || e.mumpsIgGDate || '', true),
    measlesIgg: measlesIgg || e.measlesIgG || '',
    measlesDate: formatDate(measlesDate || e.measlesIgGDate || '', true),
    rubellaIgg: rubellaIgg || e.rubellaIgG || '',
    rubellaDate: formatDate(rubellaDate || e.rubellaIgGDate || '', true),
    otherLab: (lab.otherLabResult || e.otherLabResult || '') + (lab.otherLabDate ? (lab.otherLabResult ? ' Date: ' : '') + formatDate(lab.otherLabDate, true) : ''),
    extraCore: extraCore,
    meningococcal: formatDate(sp.meningococcal || e.meningococcal || '', true),
    hepA1: formatDate(sp.hepA1 || e.hepA1 || '', true),
    hepA2: formatDate(sp.hepA2 || e.hepA2 || '', true),
    typhoid: formatDate(sp.typhoid || e.typhoid || '', true),
    pneumovax: formatDate(sp.pneumovax || sp.pnemovax || e.pneumovax || e.pnemovax || '', true),
    note: e.note || lab.note || '',
    extraSp: extraSp,
    covidD1: covidD1,
    covidP1: covidP1,
    covidD2: covidD2,
    covidP2: covidP2,
    covidD3: covidD3,
    covidP3: covidP3,
    extraCovidFlu: extraCovidFlu,
    flu2324: formatDate(cf.flu2324 || cf.fluDate2324 || '', true),
    flu2425: fluSummary,
    pepSerialNo: pepSerialNo,
    pepReportDate: pepReportDate,
    pepProtocol: pepProtocol,
    pepIndication: pepIndication,
    pepDate: pepDate,
    immunityStatus: (e.immunityStatus && e.immunityStatus !== 'Pending' && e.immunityStatus !== 'Pending Verification' && e.immunityStatus !== 'Incomplete Data')
      ? e.immunityStatus
      : (typeof calculateMOHImmunityStatus === 'function' ? calculateMOHImmunityStatus(e) : (e.immunityStatus || 'Fully Immune'))
  };
}
window.extractRowColumnValues = extractRowColumnValues;

window.activeExcelColFilters = {}; // colKey -> Set of selected values (or '__BLANKS__')

function toggleExcelFilterMenu(event, colKey, colTitle) {
  event.stopPropagation();
  let popover = document.getElementById('excel_filter_popover');
  if (!popover) {
    popover = document.createElement('div');
    popover.id = 'excel_filter_popover';
    popover.className = 'excel-filter-popover';
    popover.style.cssText = 'display:none; position:fixed; z-index:999999; background:white; border:1px solid #CBD5E1; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3); border-radius: 8px; width: 270px; padding: 10px; font-family: system-ui, -apple-system, sans-serif;';
    document.body.appendChild(popover);
  }

  if (popover.style.display === 'block' && popover.getAttribute('data-active-col') === colKey) {
    popover.style.display = 'none';
    return;
  }

  popover.setAttribute('data-active-col', colKey);

  const btn = event.currentTarget;
  const rect = btn.getBoundingClientRect();
  let top = rect.bottom + 4;
  let left = rect.left;

  if (left + 270 > window.innerWidth - 10) {
    left = window.innerWidth - 280;
  }
  if (left < 10) left = 10;
  if (top + 320 > window.innerHeight) {
    top = rect.top - 320;
    if (top < 10) top = 10;
  }

  popover.style.top = top + 'px';
  popover.style.left = left + 'px';

  const employees = rptAllEmployeesList || (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : []);
  const uniqueValuesMap = {};
  let blankCount = 0;

  employees.forEach(e => {
    const vals = extractRowColumnValues(e);
    const rawVal = String(vals[colKey] || '').trim();
    if (rawVal) {
      uniqueValuesMap[rawVal] = (uniqueValuesMap[rawVal] || 0) + 1;
    } else {
      blankCount++;
    }
  });

  const sortedValues = Object.keys(uniqueValuesMap).sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
  const currentSelection = window.activeExcelColFilters[colKey];
  const isFiltered = !!(currentSelection && currentSelection.size > 0);
  const isAr = window.i18n ? window.i18n.isRTL() : false;

  let listHtml = `
    <div style="padding: 5px 8px; border-bottom: 1px dashed #CBD5E1; font-weight: bold; font-size: 0.78rem; background: #F8FAFC;">
      <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: #0F172A; user-select: none;">
        <input type="checkbox" id="excel_chk_select_all" onchange="toggleExcelSelectAll(this)" checked style="accent-color: #10B981; width: 15px; height: 15px;">
        <span>(Select All / تحديد الكل)</span>
      </label>
    </div>
  `;

  if (sortedValues.length === 0 && blankCount === 0) {
    listHtml += `<div style="padding: 10px; font-size: 0.78rem; color: #64748B; text-align: center;">(No values / لا يوجد بيانات)</div>`;
  } else {
    sortedValues.forEach(val => {
      const isChecked = !isFiltered || currentSelection.has(val);
      const safeVal = val.replace(/"/g, '&quot;');
      listHtml += `
        <div class="excel-filter-item" style="padding: 4px 8px; font-size: 0.78rem; border-bottom: 1px solid #F1F5F9;">
          <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: #334155; user-select: none; width: 100%;">
            <input type="checkbox" class="excel-filter-item-chk" value="${safeVal}" ${isChecked ? 'checked' : ''} onchange="updateSelectAllCheckboxState()" style="accent-color: #10B981; width: 14px; height: 14px; flex-shrink: 0;">
            <span title="${safeVal}" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${val} <span style="color: #94A3B8; font-size: 0.72rem;">(${uniqueValuesMap[val]})</span></span>
          </label>
        </div>
      `;
    });

    if (blankCount > 0) {
      const isBlankChecked = !isFiltered || currentSelection.has('__BLANKS__');
      listHtml += `
        <div class="excel-filter-item" style="padding: 4px 8px; font-size: 0.78rem; font-style: italic; background: #FFFBEB;">
          <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: #B45309; user-select: none;">
            <input type="checkbox" class="excel-filter-item-chk" value="__BLANKS__" ${isBlankChecked ? 'checked' : ''} onchange="updateSelectAllCheckboxState()" style="accent-color: #F59E0B; width: 14px; height: 14px; flex-shrink: 0;">
            <span>(Blanks / فارغ) <span style="color: #D97706; font-size: 0.72rem;">(${blankCount})</span></span>
          </label>
        </div>
      `;
    }
  }

  popover.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; border-bottom: 1px solid #E2E8F0; padding-bottom: 6px; margin-bottom: 8px;">
      <strong style="font-size:0.82rem; color:#0F172A; text-overflow:ellipsis; overflow:hidden; white-space:nowrap; max-width:210px;">🔍 ${colTitle || colKey}</strong>
      <button type="button" onclick="closeExcelFilterMenu()" style="border:none; background:none; cursor:pointer; font-size:1.2rem; color:#64748B; padding:0 4px; line-height:1;">&times;</button>
    </div>
    
    <div style="margin-bottom: 8px;">
      <input type="text" id="excel_filter_search" placeholder="🔍 ${isAr ? 'بحث في القائمة...' : 'Search values...'}" oninput="filterExcelCheckboxList(this.value)" style="width:100%; padding: 5px 8px; font-size:0.78rem; border:1px solid #CBD5E1; border-radius:4px; outline:none; box-sizing:border-box;">
    </div>
    
    <div id="excel_filter_checkbox_list" style="max-height: 190px; overflow-y: auto; border: 1px solid #CBD5E1; border-radius: 4px; background:#FAFAFA;">
      ${listHtml}
    </div>
    
    <div style="display:flex; gap:6px; justify-content:space-between; align-items:center; margin-top:10px; border-top:1px solid #E2E8F0; padding-top:8px;">
      <button type="button" class="btn btn-outline" style="padding:4px 8px; font-size:0.74rem; border:1px solid #CBD5E1; background:white; color:#475569; border-radius:4px; cursor:pointer;" onclick="clearCurrentColumnFilter('${colKey}')">🧹 ${isAr ? 'مسح الفلتر' : 'Clear'}</button>
      <div style="display:flex; gap:4px;">
        <button type="button" class="btn btn-outline" style="padding:4px 8px; font-size:0.74rem; border:1px solid #CBD5E1; background:white; color:#475569; border-radius:4px; cursor:pointer;" onclick="closeExcelFilterMenu()">Cancel</button>
        <button type="button" class="btn btn-primary" style="padding:4px 12px; font-size:0.74rem; background:#10B981; border:none; font-weight:bold; color:white; border-radius:4px; cursor:pointer;" onclick="applyExcelFilterMenu('${colKey}')">Apply 🟢</button>
      </div>
    </div>
  `;

  popover.style.display = 'block';
  updateSelectAllCheckboxState();
}
window.toggleExcelFilterMenu = toggleExcelFilterMenu;

function toggleExcelSelectAll(selectAllChk) {
  const isChecked = selectAllChk.checked;
  document.querySelectorAll('#excel_filter_checkbox_list .excel-filter-item-chk').forEach(chk => {
    if (chk.closest('.excel-filter-item').style.display !== 'none') {
      chk.checked = isChecked;
    }
  });
}
window.toggleExcelSelectAll = toggleExcelSelectAll;

function updateSelectAllCheckboxState() {
  const allChks = Array.from(document.querySelectorAll('#excel_filter_checkbox_list .excel-filter-item-chk')).filter(chk => chk.closest('.excel-filter-item').style.display !== 'none');
  const checkedChks = allChks.filter(chk => chk.checked);
  const selectAllChk = document.getElementById('excel_chk_select_all');
  if (selectAllChk) {
    selectAllChk.checked = (allChks.length > 0 && checkedChks.length === allChks.length);
    selectAllChk.indeterminate = (checkedChks.length > 0 && checkedChks.length < allChks.length);
  }
}
window.updateSelectAllCheckboxState = updateSelectAllCheckboxState;

function filterExcelCheckboxList(query) {
  const q = (query || '').toLowerCase().trim();
  document.querySelectorAll('#excel_filter_checkbox_list .excel-filter-item').forEach(item => {
    const txt = item.textContent.toLowerCase();
    item.style.display = (!q || txt.includes(q)) ? 'block' : 'none';
  });
  updateSelectAllCheckboxState();
}
window.filterExcelCheckboxList = filterExcelCheckboxList;

function closeExcelFilterMenu() {
  const popover = document.getElementById('excel_filter_popover');
  if (popover) popover.style.display = 'none';
}
window.closeExcelFilterMenu = closeExcelFilterMenu;

function applyExcelFilterMenu(colKey) {
  const selectedVals = new Set();
  const itemChks = document.querySelectorAll('#excel_filter_checkbox_list .excel-filter-item-chk');
  
  let checkedCount = 0;
  itemChks.forEach(chk => {
    if (chk.checked) {
      selectedVals.add(chk.value);
      checkedCount++;
    }
  });

  if (checkedCount === itemChks.length || checkedCount === 0) {
    delete window.activeExcelColFilters[colKey];
  } else {
    window.activeExcelColFilters[colKey] = selectedVals;
  }

  closeExcelFilterMenu();
  updateExcelFilterButtonsUI();
  filterReportsTable();
}
window.applyExcelFilterMenu = applyExcelFilterMenu;

function clearCurrentColumnFilter(colKey) {
  delete window.activeExcelColFilters[colKey];
  closeExcelFilterMenu();
  updateExcelFilterButtonsUI();
  filterReportsTable();
}
window.clearCurrentColumnFilter = clearCurrentColumnFilter;

function clearAllColumnFilters() {
  window.activeExcelColFilters = {};
  updateExcelFilterButtonsUI();
  filterReportsTable();
}
window.clearAllColumnFilters = clearAllColumnFilters;

function updateExcelFilterButtonsUI() {
  document.querySelectorAll('.excel-col-filter-btn').forEach(btn => {
    const colKey = btn.getAttribute('data-col');
    const label = btn.getAttribute('data-label') || colKey;
    const filterSet = window.activeExcelColFilters[colKey];

    if (filterSet && filterSet.size > 0) {
      btn.style.background = '#059669';
      btn.style.borderColor = '#10B981';
      btn.style.color = 'white';
      btn.style.fontWeight = 'bold';
      btn.innerHTML = `<span class="btn-label" style="text-overflow: ellipsis; overflow: hidden;">⚡ ${label} (${filterSet.size})</span><span class="btn-arrow" style="font-size:0.62rem; margin-left:3px;">▼</span>`;
    } else {
      btn.style.background = '#1E293B';
      btn.style.borderColor = '#475569';
      btn.style.color = 'white';
      btn.style.fontWeight = 'normal';
      btn.innerHTML = `<span class="btn-label" style="text-overflow: ellipsis; overflow: hidden;">🔍 ${label}...</span><span class="btn-arrow" style="font-size:0.62rem; margin-left:3px;">▼</span>`;
    }
  });
}
window.updateExcelFilterButtonsUI = updateExcelFilterButtonsUI;

function populateColumnFilterDropdowns(force = false) {
  updateExcelFilterButtonsUI();
}
window.populateColumnFilterDropdowns = populateColumnFilterDropdowns;

if (!window.excelFilterClickListenerAttached) {
  document.addEventListener('click', function(e) {
    const popover = document.getElementById('excel_filter_popover');
    if (popover && popover.style.display === 'block') {
      if (!popover.contains(e.target) && !e.target.closest('.excel-col-filter-btn')) {
        popover.style.display = 'none';
      }
    }
  });
  window.excelFilterClickListenerAttached = true;
}

let _filterReportsDebounceTimer = null;

function filterReportsTableImmediate() {
  try {
    const dept = document.getElementById('rptDeptFilter') ? document.getElementById('rptDeptFilter').value : 'ALL';
    const staffGroup = document.getElementById('rptStaffGroupFilter') ? document.getElementById('rptStaffGroupFilter').value : 'ALL';
    const deptTreating = document.getElementById('rptDeptTreatingFilter') ? document.getElementById('rptDeptTreatingFilter').value : 'ALL';
    const status = document.getElementById('rptStatusFilter') ? document.getElementById('rptStatusFilter').value : 'ALL';
    const search = document.getElementById('rptSearch') ? document.getElementById('rptSearch').value.toLowerCase().trim() : '';

    rptAllEmployeesList = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
    window.rptAllEmployeesList = rptAllEmployeesList;

    rptFilteredEmployees = rptAllEmployeesList.filter(e => {
      if (!e || typeof e !== 'object') return false;

      // Filter active vs archived staff members
      if (rptActiveReportCategory === 'archived') {
        if (typeof isArchivedStaff === 'function' && !isArchivedStaff(e)) return false;
      } else {
        if (typeof isArchivedStaff === 'function' && isArchivedStaff(e)) return false;
      }

      // Exclude Gaza Project Staff from hospital coverage plans & clinical units unless 'all', 'archived', or 'gaza' tab is selected
      if (rptActiveReportCategory !== 'all' && rptActiveReportCategory !== 'archived' && rptActiveReportCategory !== 'gaza' && isGazaStaff(e)) return false;

      if (rptActiveReportCategory === 'extended' && !isExtendedStaff(e)) return false;
      if (rptActiveReportCategory === 'minimum' && !isMinimumStaff(e)) return false;
      if (rptActiveReportCategory === 'basic' && !isBasicStaff(e)) return false;
      if (rptActiveReportCategory === 'special' && !isSpecialVaccineStaff(e)) return false;
      if (rptActiveReportCategory === 'oncology' && !isOncologyStaff(e)) return false;
      if (rptActiveReportCategory === 'babies' && !isBabiesPediatricStaff(e)) return false;
      if (rptActiveReportCategory === 'nocat' && !isNoCategoryStaff(e)) return false;
      if (rptActiveReportCategory === 'invasive' && !isInvasiveProcedureStaff(e)) return false;
      if (rptActiveReportCategory === 'avh' && !isAVHStaff(e)) return false;
      if (rptActiveReportCategory === 'hospital' && !isAVHStaff(e)) return false;
      if (rptActiveReportCategory === 'gaza' && !isGazaStaff(e)) return false;

      const demo = e.demographic || {};
      const text = `${e.idNo || demo.nationalId || ''} ${e.empNo || e.id || ''} ${e.name || demo.fullName || ''} ${demo.arabicFullName || ''} ${e.department || demo.deptTreating || ''} ${e.jobTitle || demo.positionName || ''}`.toLowerCase();

      const empDept = (e.department || demo.department || '').toLowerCase();
      const matchesDept = (dept === 'ALL' || empDept.includes(dept.toLowerCase()) || text.includes(dept.toLowerCase()));

      const empStaffGroup = (e.staffGroup || demo.staffGroup || '').toLowerCase();
      const matchesStaffGroup = (staffGroup === 'ALL' || empStaffGroup.includes(staffGroup.toLowerCase()));

      const empDeptTreating = (demo.deptTreating || e.deptTreating || '').toLowerCase();
      const matchesDeptTreating = (deptTreating === 'ALL' || empDeptTreating.includes(deptTreating.toLowerCase()));

      const computedImmunity = typeof calculateMOHImmunityStatus === 'function' ? calculateMOHImmunityStatus(e) : (e.immunityStatus || '');
      const rawImmunity = String(e.immunityStatus || '').toLowerCase();
      const rawTiter = String(e.hepbTiter || (e.labResults && e.labResults.hbsabResult) || '').toLowerCase();

      let matchesStatus = (status === 'ALL');
      if (!matchesStatus) {
        const sLower = status.toLowerCase();
        if (sLower === 'non-responder') {
          matchesStatus = computedImmunity.toLowerCase().includes('non-responder') || rawImmunity.includes('non-responder') || rawTiter.includes('non-responder') || rawTiter.includes('resistance');
        } else if (sLower === 'booster due soon') {
          matchesStatus = computedImmunity.toLowerCase().includes('booster') || rawImmunity.includes('booster');
        } else if (sLower === 'contraindicated') {
          matchesStatus = computedImmunity.toLowerCase().includes('contra') || rawImmunity.includes('contra');
        } else {
          matchesStatus = computedImmunity.toLowerCase().includes(sLower) || rawImmunity.includes(sLower);
        }
      }
      const matchesSearch = (!search || text.includes(search));

      if (!matchesDept || !matchesStaffGroup || !matchesDeptTreating || !matchesStatus || !matchesSearch) {
        return false;
      }

      if (window.activeExcelColFilters && Object.keys(window.activeExcelColFilters).length > 0) {
        const rowVals = extractRowColumnValues(e);
        for (let colKey of Object.keys(window.activeExcelColFilters)) {
          const selectedSet = window.activeExcelColFilters[colKey];
          if (!selectedSet || selectedSet.size === 0) continue;

          const rawVal = String(rowVals[colKey] || '').trim();
          if (rawVal === '') {
            if (!selectedSet.has('__BLANKS__')) return false;
          } else {
            if (!selectedSet.has(rawVal)) return false;
          }
        }
      }

      if (window.customVaricellaCategoryFilter) {
        const cat = window.customVaricellaCategoryFilter;
        const vac = e.vaccines || {};
        const lab = e.labResults || e.lab || {};
        const cpStatus = String(vac.chickenpoxStatus || vac.chickenpox || '').toLowerCase().trim();
        const cpDose1 = String(vac.chickenpoxDose1 || vac.chickenpoxDose1Date || '').toLowerCase().trim();
        const cpDose2 = String(vac.chickenpoxDose2 || vac.chickenpoxDose2Date || '').toLowerCase().trim();
        const varIgG = String(vac.varicellaIgG || lab.varicellaIgG || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '').toLowerCase().trim();

        const has2Doses = cpStatus.includes('2 dose') || cpStatus.includes('two dose') || cpStatus.includes('2 doses') || (cpDose1 && cpDose2 && cpDose2 !== 'n/a' && cpDose2 !== 'none' && cpDose2 !== 'neg');
        const isPosIgG = !has2Doses && (
          cpStatus.includes('positive igg') || cpStatus.includes('positive ig') ||
          varIgG.includes('positive') || varIgG.includes('pos') || varIgG.includes('react') || varIgG.includes('>') || varIgG.includes('miu') || varIgG.includes('titer')
        );
        const isNatImm = !has2Doses && !isPosIgG && (
          cpStatus.includes('natural') || cpStatus.includes('history') || cpStatus.includes('infec') || 
          cpStatus.includes('childhood') || cpStatus.includes('declaration') || cpStatus.includes('decleration') ||
          varIgG.includes('natural') || varIgG.includes('history') || varIgG.includes('infec')
        );

        if (cat === 'doses2' && !has2Doses) return false;
        if (cat === 'posIgG' && !isPosIgG) return false;
        if (cat === 'natImm' && !isNatImm) return false;
        if (cat === 'ongoing' && (has2Doses || isPosIgG || isNatImm)) return false;
      }

      if (window.customHBsAbCategoryFilter) {
        const cat = window.customHBsAbCategoryFilter;
        const lab = e.labResults || e.lab || {};
        const vac = e.vaccines || {};
        let rawTiter = '';
        if (lab.hbsabResult !== undefined && lab.hbsabResult !== null) rawTiter = String(lab.hbsabResult);
        else if (e.hepbTiter !== undefined && e.hepbTiter !== null) rawTiter = String(e.hepbTiter);
        rawTiter = rawTiter.toLowerCase().trim();

        const immStatus = String(e.immunityStatus || '').toLowerCase().trim();
        const isMinStaff = typeof isMinimumStaff === 'function' ? isMinimumStaff(e) : false;
        const isResist = rawTiter.includes('non-responder') || rawTiter.includes('resistance') || immStatus.includes('non-responder');
        
        const numTiterMatch = rawTiter.match(/([<>])?\s*([0-9]+(?:\.[0-9]+)?)/);
        const hasLessThan = rawTiter.includes('<');
        const hasGreaterThan = rawTiter.includes('>') || rawTiter.includes('positive') || rawTiter.includes('pos') || rawTiter.includes('immune');
        let parsedVal = numTiterMatch ? parseFloat(numTiterMatch[2]) : null;

        const isBlank = !rawTiter || rawTiter === '' || rawTiter === 'blank' || rawTiter === 'pending';
        const isLessThan10 = (parsedVal !== null && parsedVal < 10) || hasLessThan;
        const isImmune = !hasLessThan && (hasGreaterThan || (parsedVal !== null && parsedVal >= 10) || (parsedVal === null && immStatus.includes('immune') && !immStatus.includes('non-responder')));

        if (cat === 'immune') {
          if (!isImmune || isResist || isLessThan10 || isMinStaff) return false;
        } else if (cat === 'vaccinating') {
          if (!isLessThan10 || isResist) return false;
        } else if (cat === 'resistance') {
          if (!isResist) return false;
        } else if (cat === 'noNeed') {
          if (!isMinStaff || isLessThan10 || isResist) return false;
        } else if (cat === 'ongoing') {
          if (!isBlank || isImmune || isLessThan10 || isResist || isMinStaff) return false;
        }
      }

      if (window.customLabScreeningFilter) {
        const { testType, resultCategory } = window.customLabScreeningFilter;
        const lab = e.labResults || e.lab || {};
        
        let val = '';
        if (testType === 'hcv') val = String(lab.hcvResult || lab.HCV || '').toLowerCase().trim();
        else if (testType === 'hiv') val = String(lab.hivResult || lab.HIV || '').toLowerCase().trim();
        else if (testType === 'ppd') {
          const s1 = String(lab.ppdStep1Result || e.ppdStep1Result || '').toLowerCase().trim();
          const s2 = String(lab.ppdStep2Result || e.ppdStep2Result || '').toLowerCase().trim();
          const gen = String(lab.ppdResult || e.ppdResult || lab.PPD || e.PPD || '').toLowerCase().trim();
          if (s1.includes('pos') || s2.includes('pos') || gen.includes('pos') || s1.includes('react') || s2.includes('react')) val = 'positive';
          else if (s1.includes('neg') || s2.includes('neg') || gen.includes('neg') || s1.includes('non') || s2.includes('non')) val = 'negative';
          else val = '';
        }

        const isPos = val.includes('pos') || (val.includes('react') && !val.includes('non'));
        const isNeg = val.includes('neg') || val.includes('non');
        const isOngoing = !isPos && !isNeg;

        if (resultCategory === 'pos' && !isPos) return false;
        if (resultCategory === 'neg' && !isNeg) return false;
        if (resultCategory === 'ongoing' && !isOngoing) return false;
      }

      return true;
    });

    // Check for any records requiring correction and surface a clean top notice
    const malformed = rptFilteredEmployees.filter(e => e && e._normalizationError);
    let alertContainer = document.getElementById('rptMalformedRecordsAlert');
    if (malformed.length > 0) {
      if (!alertContainer) {
        alertContainer = document.createElement('div');
        alertContainer.id = 'rptMalformedRecordsAlert';
        const wrapper = document.getElementById('tableScrollWrapper');
        if (wrapper && wrapper.parentNode) {
          wrapper.parentNode.insertBefore(alertContainer, wrapper);
        }
      }
      if (alertContainer) {
        const isAr = window.i18n ? window.i18n.isRTL() : false;
        alertContainer.innerHTML = `
          <div style="background: #FFFBEB; border: 1.5px solid #FCD34D; border-radius: 8px; padding: 10px 14px; margin-bottom: 12px; color: #92400E; display: flex; align-items: center; justify-content: space-between; font-size: 0.82rem;">
            <div>
              ⚠️ <strong>${isAr ? 'تنبيه جودة البيانات' : 'Data Quality Notice'}:</strong>
              ${isAr
                ? `تم رصد (${malformed.length}) سجل(ات) تحتوي على قيم غير متوقعة أو نتائج فحوصات تحتاج تصحيحاً (مثل: ${malformed.slice(0, 3).map(m => m.empNo || m.idNo || m.name).join(', ')}). تم عرض التقرير بأمان دون توقف.`
                : `Detected (${malformed.length}) record(s) with unexpected lab formats or values requiring correction (e.g. ${malformed.slice(0, 3).map(m => m.empNo || m.idNo || m.name).join(', ')}). Report loaded safely without interruption.`}
            </div>
          </div>
        `;
      }
    } else if (alertContainer) {
      alertContainer.innerHTML = '';
    }

    rptCurrentPage = 1;
    renderReportsTableBody();
    updateReportTabStyles();
  } catch (err) {
    console.error("filterReportsTableImmediate error:", err);
  }
}

function filterReportsTable() {
  if (_filterReportsDebounceTimer) clearTimeout(_filterReportsDebounceTimer);
  _filterReportsDebounceTimer = setTimeout(() => {
    filterReportsTableImmediate();
  }, 150);
}

function filterByVaricellaCategory(categoryKey) {
  if (window.customVaricellaCategoryFilter === categoryKey) {
    window.customVaricellaCategoryFilter = null;
  } else {
    window.customVaricellaCategoryFilter = categoryKey;
  }
  filterReportsTable();

  const tableCard = document.getElementById('cardMasterReport') || document.querySelector('.reports-table-container');
  if (tableCard) {
    tableCard.scrollIntoView({ behavior: 'smooth' });
  }
}
window.filterByVaricellaCategory = filterByVaricellaCategory;

function filterByHBsAbCategory(categoryKey) {
  if (window.customHBsAbCategoryFilter === categoryKey) {
    window.customHBsAbCategoryFilter = null;
  } else {
    window.customHBsAbCategoryFilter = categoryKey;
  }
  filterReportsTable();

  const tableCard = document.getElementById('cardMasterReport') || document.querySelector('.reports-table-container');
  if (tableCard) {
    tableCard.scrollIntoView({ behavior: 'smooth' });
  }
}
window.filterByHBsAbCategory = filterByHBsAbCategory;

function filterByLabScreeningCategory(testType, resultCategory) {
  if (window.customLabScreeningFilter && window.customLabScreeningFilter.testType === testType && window.customLabScreeningFilter.resultCategory === resultCategory) {
    window.customLabScreeningFilter = null;
  } else {
    window.customLabScreeningFilter = { testType, resultCategory };
  }
  filterReportsTable();

  const tableCard = document.getElementById('cardMasterReport') || document.querySelector('.reports-table-container');
  if (tableCard) {
    tableCard.scrollIntoView({ behavior: 'smooth' });
  }
}
function getEmploymentStatusBadge(statusVal) {
  const st = String(statusVal || 'Active Staff').trim();
  const lower = st.toLowerCase();
  
  if (lower.includes('on leave') || lower.includes('إجازة')) {
    return `<span class="badge" style="background:#FEF3C7; color:#92400E; border:1px solid #FDE68A; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">🟡 ${st}</span>`;
  }
  if (lower.includes('transfer') || lower.includes('منقول')) {
    return `<span class="badge" style="background:#DBEAFE; color:#1E40AF; border:1px solid #93C5FD; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">🔵 ${st}</span>`;
  }
  if (lower.includes('resign') || lower.includes('مستقيل')) {
    return `<span class="badge" style="background:#FFEDD5; color:#C2410C; border:1px solid #FDBA74; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">🟠 ${st}</span>`;
  }
  if (lower.includes('retir') || lower.includes('متقاعد')) {
    return `<span class="badge" style="background:#F3E8FF; color:#6B21A8; border:1px solid #D8B4FE; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">🟣 ${st}</span>`;
  }
  if (lower.includes('deceas') || lower.includes('متوفى')) {
    return `<span class="badge" style="background:#1E293B; color:#FFFFFF; border:1px solid #0F172A; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">⚫ ${st}</span>`;
  }
  if (lower.includes('terminat') || lower.includes('إنهاء')) {
    return `<span class="badge" style="background:#FEE2E2; color:#991B1B; border:1px solid #FCA5A5; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">🔴 ${st}</span>`;
  }
  if (lower.includes('contract finish') || lower.includes('انتهاء عقد')) {
    return `<span class="badge" style="background:#F5F5F4; color:#57534E; border:1px solid #D6D3D1; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">🟤 ${st}</span>`;
  }
  if (lower.includes('discharg') || lower.includes('مغادر')) {
    return `<span class="badge" style="background:#F1F5F9; color:#475569; border:1px solid #CBD5E1; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">⚪ ${st}</span>`;
  }
  
  return `<span class="badge" style="background:#DCFCE7; color:#15803D; border:1px solid #86EFAC; font-weight:bold; padding:2px 8px; border-radius:12px; font-size:0.75rem;">🟢 Active Staff</span>`;
}
window.getEmploymentStatusBadge = getEmploymentStatusBadge;

function renderReportsTableBody() {
  const tbody = document.querySelector('#masterReportTable tbody');
  const topBar = document.getElementById('rptPaginationTop');
  const botBar = document.getElementById('rptPaginationBottom');
  if (!tbody) return;

  const total = rptFilteredEmployees.length;
  const isAll = (rptPageSize === 'ALL');
  const sizeNum = isAll ? total : parseInt(rptPageSize, 10);
  const maxPage = isAll ? 1 : (Math.ceil(total / sizeNum) || 1);

  if (rptCurrentPage > maxPage) rptCurrentPage = maxPage;
  if (rptCurrentPage < 1) rptCurrentPage = 1;

  const startIdx = isAll ? 0 : (rptCurrentPage - 1) * sizeNum;
  const endIdx = isAll ? total : Math.min(startIdx + sizeNum, total);
  const chunk = isAll ? rptFilteredEmployees : rptFilteredEmployees.slice(startIdx, endIdx);
  if (chunk.length > 0) {
    console.log("REPORT EMPLOYEE", chunk[0]);
  }

  tbody.innerHTML = chunk.map((e, idx) => {
    if (!e || typeof e !== 'object') return '';
    try {
    const demo = e.demographic || {};
    const lab = e.labResults || {};
    const vac = e.vaccines || {};
    const sp = e.specialVaccines || {};
    const cf = e.covidFlu || {};

    const formatDate = (val, strict = true) => (typeof standardizeDateStr === 'function' ? standardizeDateStr(val, strict) : val);

    const idNo = e.idNo || demo.nationalId || 'N/A';
    const personNo = e.empNo || demo.personNumber || e.id || 'EMP-N/A';
    const name = e.name || demo.fullName || 'Staff Member';
    const arName = demo.arabicFullName || '';
    const dob = formatDate(e.dob || demo.dob || '', false);
    const rawAgeVal = demo.age || e.age || '';
    const age = typeof formatAgeToOneDecimal === 'function' ? formatAgeToOneDecimal(rawAgeVal) : rawAgeVal;
    const gender = demo.gender || e.gender || 'N/A';
    const idType = demo.idType || e.idType || 'National ID';
    const dept = e.department || demo.deptTreating || demo.department || 'General Medical';
    const title = e.jobTitle || demo.positionName || 'Staff Member';
    const arTitle = demo.positionArabic || '';
    const assignDate = formatDate(demo.assignmentEffectiveDate || '', false);
    const group = demo.staffGroup || e.staffGroup || 'Minimum Plan';
    const treating = demo.deptTreating || e.deptTreating || '';
    const invVal = demo.invasiveProcedure || e.invasiveProcedure || (typeof isInvasiveProcedureStaff === 'function' && isInvasiveProcedureStaff(e) ? 'Yes' : 'No');
    const invBadge = (invVal === 'Yes')
      ? `<span class="role-pill role-specialist" style="background:#DC2626; color:white; padding:2px 8px; font-weight:bold; border-radius:4px;">Yes</span>`
      : `<span class="role-pill role-general" style="background:#94A3B8; color:white; padding:2px 8px; border-radius:4px;">No</span>`;

    const isFemale = (gender && gender.toString().trim().toLowerCase() === 'female');
    let preg = isFemale ? 'Not Pregnant' : 'Not Applicable';
    if (e.healthStatus && e.healthStatus.pregnancyStatus) {
      if (isFemale && (e.healthStatus.pregnancyStatus === 'Pregnant' || e.healthStatus.pregnancyStatus === 'Lactating' || e.healthStatus.pregnancyStatus === 'Not Pregnant')) {
        preg = e.healthStatus.pregnancyStatus;
      } else if (!isFemale) {
        preg = 'Not Applicable';
      }
    }
    const allergies = e.healthStatus ? e.healthStatus.allergies : 'None';
    const effectiveDateVal = demo.assignmentEffectiveDate || demo.startDate || e.startDate || '';

    const hbsab = e.hepbTiter || lab.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || '';
    const rawHbsabDate = lab.hbsabDate || (lab.HBsAb ? lab.HBsAb.date : '') || e.hbsabDate || e.hbvBoosterDate || '';
    const hbsabDate = formatDate(rawHbsabDate, true);

    const engrix1 = formatDate(lab.engrixDose1 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d1 : '') || '', true);
    const engrix2 = formatDate(lab.engrixDose2 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d2 : '') || '', true);
    const engrix3 = formatDate(lab.engrixDose3 || (vac['Hepatitis B'] ? vac['Hepatitis B'].d3 : '') || '', true);
    const engrixBooster = formatDate(lab.engrixBooster || e.hbvBoosterDate || '', true);
    const hbsag = lab.hbsagResult || (lab.HBsAg ? lab.HBsAg.result : '') || 'Negative';

    const hcv = lab.hcvResult || (lab.HCV ? lab.HCV.result : '') || 'Negative';
    const rawHcvDate = lab.hcvDate || (lab.HCV ? lab.HCV.date : '') || e.hcvDate || '';
    const hcvDate = formatDate(rawHcvDate, true);

    const hiv = lab.hivResult || (lab.HIV ? lab.HIV.result : '') || 'Negative';
    const rawHivDate = lab.hivDate || (lab.HIV ? lab.HIV.date : '') || e.hivDate || '';
    const hivDate = formatDate(rawHivDate, true);

    const ppdRes = lab.ppdStep1Result || lab.ppdResult || (lab.PPD ? lab.PPD.result : '') || 'Negative';
    const ppd1Ind = lab.ppdStep1Induration || (lab.PPD ? lab.PPD.test1 : '') || '0mm';
    const rawPpd1Date = lab.ppdStep1Date || (lab.PPD ? (lab.PPD.date1 || lab.PPD.date) : '') || e.ppdStep1Date || '';
    const ppd1Date = formatDate(rawPpd1Date, true);

    const ppd2Res = lab.ppdStep2Result || (lab.PPD ? lab.PPD.test2 : '') || 'Negative';
    const ppd2Ind = lab.ppdStep2Induration || (lab.PPD ? lab.PPD.test2 : '') || '0mm';
    const rawPpd2Date = lab.ppdStep2Date || (lab.PPD ? lab.PPD.date2 : '') || e.ppdStep2Date || '';
    const ppd2Date = formatDate(rawPpd2Date, true);

    const ipv = formatDate(vac.ipvDate || e.ipvDate || (vac.IPV ? vac.IPV.d5 || vac.IPV.d1 : '') || '', true);
    const tdap = formatDate(vac.tdapDate || e.tdapDate || (vac.Tdap ? vac.Tdap.d5 || vac.Tdap.d1 : '') || '', true);
    const mmr1 = formatDate(vac.mmrDose1 || e.mmrDose1 || (vac.MMR ? vac.MMR.d1 : '') || '', true);
    const mmr2 = formatDate(vac.mmrDose2 || e.mmrDose2 || (vac.MMR ? vac.MMR.d2 : '') || '', true);
    const chickenpox = vac.chickenpoxStatus || (vac['Varicella Zoster (Chicken pox)'] ? 'Vaccinated' : '') || '';
    const chickenpoxDose1 = formatDate(vac.chickenpoxDose1 || vac.chickenpoxDose1Date || vac.chickenpoxDateDose1 || '', true);
    const chickenpoxDose2 = formatDate(vac.chickenpoxDose2 || vac.chickenpoxDose2Date || '', true);
    const varicellaIgg = vac.varicellaIgG || lab.varicellaIgG || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '';
    const rawVarDate = vac.varicellaIgGDate || lab.varicellaIgGDate || (lab.Varicella_IgG ? lab.Varicella_IgG.date : '') || e.varicellaIgGDate || '';
    const varicellaDate = formatDate(rawVarDate, true);

    const mumpsIgg = lab.mumpsIgGTiter || (lab.Mumps_IgG ? lab.Mumps_IgG.result : '') || '';
    const mumpsDate = formatDate(lab.mumpsIgGTiterDate || (lab.Mumps_IgG ? lab.Mumps_IgG.date : '') || e.mumpsIgGTiterDate || '', true);

    const measlesIgg = lab.measlesIgGTiter || (lab.Measles_IgG ? lab.Measles_IgG.result : '') || '';
    const measlesDate = formatDate(lab.measlesIgGTiterDate || (lab.Measles_IgG ? lab.Measles_IgG.date : '') || e.measlesIgGTiterDate || '', true);

    const rubellaIgg = lab.rubellaIgGTiter || (lab.Rubella_IgG ? lab.Rubella_IgG.result : '') || '';
    const rubellaDate = formatDate(lab.rubellaIgGTiterDate || (lab.Rubella_IgG ? lab.Rubella_IgG.date : '') || e.rubellaIgGTiterDate || '', true);

    const otherLab = (lab.otherLabResult || '') + (lab.otherLabDate ? (lab.otherLabResult ? ' Date: ' : '') + formatDate(lab.otherLabDate, true) : '');

    const extraCore = vac.additionalCoreDoses && vac.additionalCoreDoses.length > 0
      ? vac.additionalCoreDoses.map(d => {
          const vals = [d.ipvDate, d.tdapDate, d.mmrDose1, d.chickenpoxStatus].filter(Boolean).map(v => formatDate(v, true)).filter(Boolean);
          return vals.length > 0 ? (d.doseLabel || 'Dose') + ': ' + vals.join(', ') : '';
        }).filter(Boolean).join('; ')
      : '';

    const meningococcal = formatDate(sp.meningococcal || '', true);
    const hepA1 = formatDate(sp.hepA1 || '', true);
    const hepA2 = formatDate(sp.hepA2 || '', true);
    const typhoid = formatDate(sp.typhoid || '', true);
    const pneumovax = formatDate(sp.pneumovax || sp.pnemovax || '', true);
    const extraSp = sp.additionalSpecialDoses && sp.additionalSpecialDoses.length > 0
      ? sp.additionalSpecialDoses.map(d => {
          if (!d.vacName && !d.date) return '';
          const fDate = formatDate(d.date, true);
          return (d.vacName || 'Vaccine') + (fDate ? ' (' + fDate + ')' : '');
        }).filter(Boolean).join('; ')
      : '';

    const canonicalRecs = typeof getCanonicalVaccineRecords === 'function' ? getCanonicalVaccineRecords(e) : [];
    const cov1Rec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'first' || r.doseType === '1st' || r.doseType === '1'));
    const cov2Rec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'second' || r.doseType === '2nd' || r.doseType === '2'));
    const cov3Rec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'third' || r.doseType === '3rd' || r.doseType === '3'));
    const covBoosterRec = canonicalRecs.find(r => r.type === 'covid' && (r.doseType === 'booster' || r.doseType === 'dose 4' || r.doseType === '4'));

    const covidD1 = cov1Rec ? formatDate(cov1Rec.date, true) : formatDate(cf.covidDose1Date || e.covidDose1Date || (vac['Covid - 19'] ? vac['Covid - 19'].d1 : ''), true);
    const covidP1 = cov1Rec ? (cov1Rec.lot || cov1Rec.mfr || '') : (cf.covidDose1Batch || e.covidDose1Batch || (vac['Covid - 19'] ? vac['Covid - 19'].p1 : ''));
    const covidD2 = cov2Rec ? formatDate(cov2Rec.date, true) : formatDate(cf.covidDose2Date || e.covidDose2Date || (vac['Covid - 19'] ? vac['Covid - 19'].d2 : ''), true);
    const covidP2 = cov2Rec ? (cov2Rec.lot || cov2Rec.mfr || '') : (cf.covidDose2Batch || e.covidDose2Batch || (vac['Covid - 19'] ? vac['Covid - 19'].p2 : ''));
    const covidD3 = cov3Rec ? formatDate(cov3Rec.date, true) : formatDate(cf.covidDose3Date || e.covidDose3Date || (vac['Covid - 19'] ? vac['Covid - 19'].d3 : ''), true);
    const covidP3 = cov3Rec ? (cov3Rec.lot || cov3Rec.mfr || '') : (cf.covidDose3Batch || e.covidDose3Batch || (vac['Covid - 19'] ? vac['Covid - 19'].p3 : ''));
    const covidD4 = covBoosterRec ? formatDate(covBoosterRec.date, true) : formatDate(cf.covidDose4Date || e.covidDose4Date || '', true);
    const covidP4 = covBoosterRec ? (covBoosterRec.lot || covBoosterRec.mfr || '') : (cf.covidDose4Batch || e.covidDose4Batch || '');
    const extraCovidFlu = cf.additionalCovidFluDoses && cf.additionalCovidFluDoses.length > 0
      ? cf.additionalCovidFluDoses.map(d => {
          if (!d.vacName && !d.date && !d.manufacturer) return '';
          const fDate = formatDate(d.date, true);
          return (d.vacName || 'Dose') + (d.manufacturer ? ' [' + d.manufacturer + ']' : '') + (fDate ? ' Date:' + fDate : '') + (d.batch ? ' Batch:' + d.batch : '');
        }).filter(Boolean).join('; ')
      : '';
    const flu2324 = formatDate(cf.flu2324 || cf.fluDate2324 || '', true);
    const flu2425 = formatDate(cf.flu2425 || cf.fluDate2425 || cf.fluDate || (vac['Flu vaccine'] ? vac['Flu vaccine'].d5 : '') || '', true);

    const startDate = formatDate(demo.startDate || e.startDate || '', false);
    const note = e.note || lab.note || '';

    const pepRecs = (e.pep && Array.isArray(e.pep.additionalPepRecords) && e.pep.additionalPepRecords.length > 0) ? e.pep.additionalPepRecords : [];
    const pepSerialNo = pepRecs.map(p => p.serialNo || p.incidentId || '').filter(Boolean).join('; ');
    const pepReportDate = pepRecs.map(p => formatDate(p.incidentDate, false)).filter(Boolean).join('; ');
    const pepProtocol = pepRecs.map(p => p.protocol || '').filter(Boolean).join('; ');
    const pepIndication = pepRecs.map(p => p.indication || '').filter(Boolean).join('; ');
    const pepDate = pepRecs.map(p => formatDate(p.date, true)).filter(Boolean).join('; ');
    const safePersonNo = String(personNo).replace(/'/g, "\\'");

    return `
      <tr>
        <td style="position: sticky; left: 0; background: white; z-index: 1; border-right: 2px solid #CBD5E1; min-width: 270px;">
          <div style="display: flex; gap: 4px; justify-content: center; flex-wrap: wrap;">
            <button class="btn btn-primary" style="padding: 3px 8px; font-size: 0.72rem; background: #2563EB; color: white; border: none; border-radius: 4px; font-weight: bold;" onclick="openQuickUpdateModal('${safePersonNo}')">⚡ Update</button>
            <button class="btn btn-outline" style="padding: 3px 6px; font-size: 0.72rem; border-color: var(--accent-teal); color: var(--accent-teal);" onclick="editEmployeeFromReportTable('${safePersonNo}')">✏️ Open Form</button>
            <button class="btn btn-outline" style="padding: 3px 6px; font-size: 0.72rem;" onclick="generateCertForEmp(${startIdx + idx})">📜 Certificate</button>
            <button class="btn btn-danger" style="padding: 3px 6px; font-size: 0.72rem; background: #EF4444; color: white; border: none; border-radius: 4px;" onclick="deleteEmployeeRecord('${safePersonNo}')">🗑️ Delete</button>
          </div>
        </td>
        <td style="position: sticky; left: 270px; background: white; font-weight: bold; z-index: 1;">${idNo}</td>
        <td style="position: sticky; left: 380px; background: white; font-weight: bold; z-index: 1; color: var(--accent-teal);">${personNo}</td>
        <td style="position: sticky; left: 480px; background: white; font-weight: bold; z-index: 1; color: var(--primary-blue); border-right: 2px solid #CBD5E1;">${name}</td>
        <td>${arName}</td>
        <td>${dob}</td>
        <td>${age}</td>
        <td>${gender}</td>
        <td>${idType}</td>
        <td>${dept}</td>
        <td>${title}</td>
        <td>${arTitle}</td>
        <td>${getEmploymentStatusBadge(e.employmentStatus || demo.employmentStatus)}</td>
        <td>${startDate}</td>
        <td>${assignDate}</td>
        <td>${group}</td>
        <td>${treating}</td>
        <td>${invBadge}</td>
        <td>${preg}</td>
        <td>${allergies}</td>
        <td><strong style="color: #166534;">${hbsab}</strong></td>
        <td>${hbsabDate}</td>
        <td>${engrix1}</td>
        <td>${engrix2}</td>
        <td>${engrix3}</td>
        <td>${engrixBooster}</td>
        <td>${hbsag}</td>
        <td>${hcv}</td>
        <td>${hcvDate}</td>
        <td>${hiv}</td>
        <td>${hivDate}</td>
        <td>${ppdRes}</td>
        <td>${ppd1Ind}</td>
        <td>${ppd1Date}</td>
        <td>${ppd2Res}</td>
        <td>${ppd2Ind}</td>
        <td>${ppd2Date}</td>
        <td>${ipv}</td>
        <td>${tdap}</td>
        <td>${mmr1}</td>
        <td>${mmr2}</td>
        <td>${chickenpox}</td>
        <td>${chickenpoxDose1}</td>
        <td>${chickenpoxDose2}</td>
        <td>${varicellaIgg}</td>
        <td>${varicellaDate}</td>
        <td>${mumpsIgg}</td>
        <td>${mumpsDate}</td>
        <td>${measlesIgg}</td>
        <td>${measlesDate}</td>
        <td>${rubellaIgg}</td>
        <td>${rubellaDate}</td>
        <td>${otherLab}</td>
        <td>${extraCore}</td>
        <td>${meningococcal}</td>
        <td>${hepA1}</td>
        <td>${hepA2}</td>
        <td>${typhoid}</td>
        <td>${pneumovax}</td>
        <td>${note}</td>
        <td>${extraSp}</td>
        <td>${covidD1}</td>
        <td>${covidP1}</td>
        <td>${covidD2}</td>
        <td>${covidP2}</td>
        <td>${covidD3}</td>
        <td>${covidP3}</td>
        <td>${extraCovidFlu}</td>
        <td>${flu2324}</td>
        <td>${flu2425}</td>
        <td>${pepSerialNo}</td>
        <td>${pepReportDate}</td>
        <td>${pepProtocol}</td>
        <td>${pepIndication}</td>
        <td>${pepDate}</td>
        <td>
          ${(() => {
            const mohStatus = typeof calculateMOHImmunityStatus === 'function' ? calculateMOHImmunityStatus(e) : (e.immunityStatus || 'Fully Immune');
            const isFull = mohStatus.startsWith('Fully');
            const isPartial = mohStatus.startsWith('Partially');
            const bg = isFull ? '#DCFCE7' : (isPartial ? '#FEF3C7' : '#E2E8F0');
            const fg = isFull ? '#15803D' : (isPartial ? '#B45309' : '#334155');
            const border = isFull ? '#86EFAC' : (isPartial ? '#FDE68A' : '#CBD5E1');
            return `<span style="background:${bg}; color:${fg}; border:1px solid ${border}; font-weight:800; border-radius:12px; padding:4px 10px; font-size:0.78rem; display:inline-block; white-space:nowrap;">${mohStatus}</span>`;
          })()}
        </td>
      </tr>
    `;
    } catch (rowErr) {
      console.error("Error rendering employee row at index " + idx, e, rowErr);
      const isArRpt = window.i18n ? window.i18n.isRTL() : false;
      const safeId = toSafeLabString(e.idNo || (e.demographic && e.demographic.nationalId) || 'N/A');
      const safeEmpNo = toSafeLabString(e.empNo || (e.demographic && e.demographic.personNumber) || e.id || 'N/A');
      const safeName = toSafeLabString(e.name || (e.demographic && e.demographic.fullName) || 'Staff Member');
      const errFieldMsg = String(rowErr.field || rowErr.message || rowErr).replace(/</g, '&lt;');
      return `
        <tr style="background: #FEF2F2; border-left: 4px solid #DC2626;">
          <td colspan="72" style="padding: 10px 14px; color: #991B1B; font-size: 0.82rem;">
            ⚠️ <strong>${isArRpt ? 'تنبيه: سجل غير صالح يحتاج تصحيحاً' : 'Warning: Staff record contains invalid data and needs review'}:</strong>
            [<strong>${safeName}</strong> | ${safeEmpNo} | ID: ${safeId}] -
            ${isArRpt ? 'الحقل / سبب التنبيه' : 'Field / Reason'}: <code>${errFieldMsg}</code>.
            <button class="btn btn-outline" style="margin-inline-start: 10px; padding: 2px 8px; font-size: 0.72rem; border-color: #DC2626; color: #DC2626; background: white;" onclick="editEmployeeFromReportTable('${safeEmpNo}')">✏️ ${isArRpt ? 'تصحيح السجل' : 'Fix Record'}</button>
          </td>
        </tr>
      `;
    }
  }).join('');

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const paginationHtml = `
    <div style="font-size: 0.85rem; color: #334155; font-weight: 600;">
      ⚡ ${isAr 
        ? `عرض ${total === 0 ? 0 : startIdx + 1} - ${endIdx} من أصل ${total} موظفاً (تحميل فوري ⚡)` 
        : `Showing ${total === 0 ? 0 : startIdx + 1} - ${endIdx} of ${total} Staff Members (Instant Load ⚡)`}
    </div>
    <div style="display: flex; gap: 8px; align-items: center;">
      <button class="btn btn-outline" style="padding: 4px 12px; font-size: 0.8rem; background: white;" ${rptCurrentPage <= 1 ? 'disabled' : ''} onclick="changeReportsPage(-1)">
        ◀️ ${isAr ? 'السابق' : 'Previous'}
      </button>
      <span style="font-size: 0.85rem; font-weight: bold; color: var(--primary-blue); padding: 0 4px;">
        ${isAr ? `صفحة ${rptCurrentPage} من ${maxPage}` : `Page ${rptCurrentPage} of ${maxPage}`}
      </span>
      <button class="btn btn-outline" style="padding: 4px 12px; font-size: 0.8rem; background: white;" ${rptCurrentPage >= maxPage ? 'disabled' : ''} onclick="changeReportsPage(1)">
        ${isAr ? 'التالي' : 'Next'} ▶️
      </button>
      <select onchange="setReportsPageSize(this.value)" style="padding: 4px 8px; font-size: 0.8rem; border-radius: 4px; border: 1px solid #CBD5E1; background: white; font-weight: 600;">
        <option value="50" ${rptPageSize == 50 ? 'selected' : ''}>50 per page</option>
        <option value="100" ${rptPageSize == 100 ? 'selected' : ''}>100 per page</option>
        <option value="200" ${rptPageSize == 200 ? 'selected' : ''}>200 per page</option>
        <option value="ALL" ${rptPageSize == 'ALL' ? 'selected' : ''}>Show All (${total})</option>
      </select>
    </div>
  `;

  if (topBar) topBar.innerHTML = paginationHtml;
  if (botBar) botBar.innerHTML = paginationHtml;

  setTimeout(() => {
    if (typeof updateTopScrollWidth === 'function') updateTopScrollWidth();
    if (typeof populateColumnFilterDropdowns === 'function') populateColumnFilterDropdowns();
  }, 100);
}

function changeReportsPage(dir) {
  rptCurrentPage += dir;
  renderReportsTableBody();
}

function setReportsPageSize(size) {
  rptPageSize = size;
  rptCurrentPage = 1;
  renderReportsTableBody();
}

async function deleteEmployeeRecord(empNoOrId, empName) {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const name = empName || empNoOrId;
  const confirmMsg = isAr 
    ? `⚠️ هل أنت متأكد من رغبتك في حذف سجل الموظف (${name})؟ يمكن للمالك المعتمد فقط استعادته لاحقاً من سلة المهملات.`
    : `⚠️ Are you sure you want to delete staff record for (${name})? Only the designated owner account can restore it from Trash.`;

  if (!confirm(confirmMsg)) return;

  try {
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.deleteEmployee === 'function') {
      await EmployeeDataService.deleteEmployee(empNoOrId);
    } else if (typeof deleteEmployeeFromMasterSheet === 'function') {
      await deleteEmployeeFromMasterSheet(empNoOrId);
    } else {
      let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
      employees = employees.filter(e => e.empNo !== empNoOrId && e.id !== empNoOrId && e.idNo !== empNoOrId && (e.demographic?.personNumber !== empNoOrId) && (e.demographic?.nationalId !== empNoOrId));
      if (typeof saveEmployeesToLocalStorage === 'function') {
        saveEmployeesToLocalStorage(employees);
      }
    }

    if (typeof showSuccessToast === 'function') {
      showSuccessToast(
        isAr ? `تم نقل سجل (${name}) إلى سلة المحذوفات بنجاح 🗑️` : `Record for (${name}) moved to Trash successfully 🗑️`,
        'Deleted / تم الحذف'
      );
    }

    const mainArea = document.getElementById('mainAppArea');
    if (typeof renderVaccinationReports === 'function' && mainArea) {
      renderVaccinationReports(mainArea);
    } else if (typeof renderStaffEntryForm === 'function' && mainArea) {
      renderStaffEntryForm(mainArea);
    }
  } catch (err) {
    console.error("Delete employee error:", err);
    alert(isAr 
      ? `❌ فشل الحذف: ${err.message}` 
      : `❌ Deletion Failed: ${err.message}`);
  }
}
window.deleteEmployeeRecord = deleteEmployeeRecord;

function exportToExcelReport() {
  try {
    if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();
    const employeesToExport = (rptFilteredEmployees && rptFilteredEmployees.length > 0)
      ? rptFilteredEmployees
      : (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (rptAllEmployeesList || []));

    if (employeesToExport.length > 0) {
      console.log("REPORT EMPLOYEE", employeesToExport[0]);
    }

    const r1 = [
      "Full Name", "National Identifier", "Person Number", "Full Name", "Arabic Full Name", "Date Of Birth", "Age", "Gender", "National Identifier Type", "Organization Name", "Position Name", "Position Arabic", "Sector", "Start Date", "Assignment Effective Date", "staff Group", "departments/units/clinics treating", "Invasive procedure ",
      "HBsAb Result ", "HBsAb Result  Date ", "Date of Engrix  first dose ", "Date of 2nd Engrix dose ", "Date of 3rd Engrix dose ", "Engrix Booster dose ", "HBsAg Result ",
      "HCV Result ", "HCV Result date ", "HIV Result ", "HIV Result date",
      "PPD 1st step result ", "PPD 1st step induration ", "PPD 1st step result date ", "PPD 2nd step result ", "PPD 2nd step induration ", "PPD 2nd step result date",
      "IPV Vaccine at Age  >18 year ", "Tdap Vaccine at age        >7 years ", "MMR Vaccine first dose at Age  >1 year ", "MMR Vaccine Second dose  at Age  >1 year ",
      "Chicken pox  infected or  Vaccinated ", "Chicken pox  vaccine dose 1", "Chicken pox   Vaccine 2nd dose", "Varicella Zoster, IgG", "Varicella Zoster, IgG date ", "Mumps IgG Titer", "Mumps IgG Titer date", "Measles IgG Titer", "Measles IgG Titer date", "Rubella IgG Titer", "Rubella IgG Titer date",
      "Allergies  (Eggs, Neomycin)", "Meningiococcal A, C", "hep A SERIES 1", "hep A SERIES2", "typhoid ", "Pnemovax ", "Note ",
      "Covid Vaccine DATE OF FIRST DOSE", "PATCH #", "Covid Vaccine DATE OF SECOUND  DOSE", "PATCH #", "Covid Vaccine DATE  OF THIRD   DOSE", "PATCH #",
      "flu vaccine 2023-2024", "flu vaccine 2024-2025", "PEP Incident Serial / Ref No.", "PEP Injury Incident Report Date", "PEP Vaccine / Medication / Protocol", "PEP Indication", "PEP Date", "Immunity Status"
    ];

    const rows = employeesToExport.map(e => {
      const vals = extractRowColumnValues(e);

      return [
        vals.fullName,
        vals.nationalId,
        vals.empNo,
        vals.fullName,
        vals.arabicFullName,
        vals.dob,
        typeof formatAgeToOneDecimal === 'function' ? formatAgeToOneDecimal(vals.age) : vals.age,
        vals.gender,
        vals.idType || "National ID",
        vals.orgName || "Augusta Victoria Hospital",
        vals.positionName,
        vals.positionArabic,
        getEmployeeSector(e),
        vals.startDate,
        vals.assignmentEffectiveDate,
        vals.staffGroup || "Extended Program",
        vals.department,
        vals.invasiveProcedure,
        vals.hbsab,
        vals.hbsabDate,
        vals.engrix1,
        vals.engrix2,
        vals.engrix3,
        vals.engrixBooster,
        vals.hbsag,
        vals.hcv,
        vals.hcvDate,
        vals.hiv,
        vals.hivDate,
        vals.ppdRes,
        vals.ppd1Ind,
        vals.ppd1Date,
        vals.ppd2Res,
        vals.ppd2Ind,
        vals.ppd2Date,
        vals.ipv,
        vals.tdap,
        vals.mmr1,
        vals.mmr2,
        vals.chickenpox,
        vals.chickenpoxDose1,
        vals.chickenpox2,
        vals.varicellaIgg,
        vals.varicellaDate,
        vals.mumpsIgg,
        vals.mumpsDate,
        vals.measlesIgg,
        vals.measlesDate,
        vals.rubellaIgg,
        vals.rubellaDate,
        vals.allergies,
        vals.meningococcal,
        vals.hepA1,
        vals.hepA2,
        vals.typhoid,
        vals.pneumovax,
        vals.note,
        vals.covidD1,
        vals.covidP1,
        vals.covidD2,
        vals.covidP2,
        vals.covidD3,
        vals.covidP3,
        vals.flu2324,
        vals.flu2425,
        vals.pepSerialNo,
        vals.pepReportDate,
        vals.pepProtocol,
        vals.pepIndication,
        vals.pepDate,
        vals.immunityStatus
      ];
    });

    let fileName = `AVH staff 2026.xlsx`;
    let sheetName = "Main Employee list ";

    if (rptActiveReportCategory === 'extended') {
      fileName = `AVH Extended Program Staff 2026.xlsx`;
      sheetName = "Extended Program Staff";
    } else if (rptActiveReportCategory === 'minimum') {
      fileName = `AVH Minimum Plan Staff 2026.xlsx`;
      sheetName = "Minimum Plan Staff";
    } else if (rptActiveReportCategory === 'basic') {
      fileName = `AVH Basic Plan Staff 2026.xlsx`;
      sheetName = "Basic Plan Staff";
    } else if (rptActiveReportCategory === 'oncology') {
      fileName = `AVH Oncology & Hemato-Oncology Staff 2026.xlsx`;
      sheetName = "Oncology & Hemato-Oncology";
    } else if (rptActiveReportCategory === 'babies') {
      fileName = `AVH Pediatric Babies Under 1Y Staff 2026.xlsx`;
      sheetName = "Babies Under 1Y Staff";
    } else if (rptActiveReportCategory === 'nocat') {
      fileName = `AVH General Units (No Special Category) Staff 2026.xlsx`;
      sheetName = "General Units Staff";
    } else if (rptActiveReportCategory === 'invasive') {
      fileName = `AVH Invasive Procedures (Apapasach) Staff 2026.xlsx`;
      sheetName = "Invasive Procedures Staff";
    } else if (rptActiveReportCategory === 'avh' || rptActiveReportCategory === 'hospital') {
      fileName = `AVH Staff 2026.xlsx`;
      sheetName = "AVH Staff";
    } else if (rptActiveReportCategory === 'gaza') {
      fileName = `AVH Gaza Project Staff 2026.xlsx`;
      sheetName = "Gaza Project Staff";
    }

    if (typeof XLSX !== 'undefined') {
      const data = [r1, ...rows];
      const ws = XLSX.utils.aoa_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
      XLSX.writeFile(wb, fileName);
    } else {
      const csvLines = [r1.map(h => `"${String(h).replace(/"/g, '""')}"`).join(",")];
      rows.forEach(r => {
        csvLines.push(r.map(cell => `"${String(cell !== null && cell !== undefined ? cell : '').replace(/"/g, '""')}"`).join(","));
      });
      const csvContent = "\uFEFF" + csvLines.join("\r\n");
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", fileName.replace('.xlsx', '.csv'));
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
  } catch (err) {
    console.error('Error exporting report:', err);
    alert('❌ Error generating Excel export. Please check console for details.');
  }
}
window.exportToExcelReport = exportToExcelReport;

function importExcelReport(event) {
  if (typeof importStaffFromExcelFile === 'function') {
    importStaffFromExcelFile(event);
  } else {
    alert('Import handler ready.');
  }
}
window.importExcelReport = importExcelReport;

function generateCertForEmp(idx) {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  if (idx >= 0 && employees[idx]) {
    activeEmpIndex = idx;
    activeEmpPersonNo = String(employees[idx].empNo || employees[idx].id || employees[idx].demographic?.personNumber || employees[idx].idNo || '');
    if (typeof window.setGlobalSelectedStaff === 'function') {
      window.setGlobalSelectedStaff(employees[idx]);
    }
  }
  switchNav('vaccination-certificate', true);
}
window.generateCertForEmp = generateCertForEmp;

function clearAllStaffRecords() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const confirmMsg = isAr 
    ? '⚠️ تحذير أمان نهائي:\n\nهل أنت متأكد تماماً من رغبتك في مسح كافة بيانات وسجلات الكوادر من قاعدة بيانات النظام؟\n\n• سيتم مسح السجلات من الذاكرة وقاعدة البيانات المحلية.\n• لن تتمكن من استرجاع البيانات إلا عبر استعادة ملف نسخة احتياطية (JSON).\n\nهل ترغب في المتابعة والتأكيد؟' 
    : '⚠️ FINAL SAFETY WARNING:\n\nAre you sure you want to completely delete ALL staff records from the system database?\n\n• Records will be cleared from memory and the local database.\n• This action cannot be reversed without restoring a backup file (JSON).\n\nDo you wish to proceed?';

  if (confirm(confirmMsg)) {
    if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.clearAllEmployees === 'function') {
      EmployeeDataService.clearAllEmployees().catch(e => console.warn(e));
    } else {
      localStorage.removeItem('avh_employees');
    }
    if (typeof AVH_MASTER_EXCEL_EMPLOYEES !== 'undefined' && Array.isArray(AVH_MASTER_EXCEL_EMPLOYEES)) {
      AVH_MASTER_EXCEL_EMPLOYEES.length = 0;
    }
    if (typeof _masterEmployeesList !== 'undefined') {
      _masterEmployeesList = [];
    }
    if (typeof invalidateEmployeesCache === 'function') invalidateEmployeesCache();

    try {
      const authHeaders = window.authManager && typeof window.authManager.getAuthHeaders === 'function'
        ? window.authManager.getAuthHeaders()
        : { 'Content-Type': 'application/json' };
      fetch('/api/employees/save', {
        method: 'POST',
        headers: authHeaders,
        body: JSON.stringify({ employees: [] })
      });
    } catch(e) {}

    alert(isAr ? '✅ تم حذف كافة السجلات والبيانات بنجاح!' : '✅ All entered staff records have been deleted!');
    const mainArea = document.getElementById('mainAppArea');
    if (typeof renderVaccinationReports === 'function' && mainArea) {
      renderVaccinationReports(mainArea);
    } else if (typeof renderStaffEntryForm === 'function' && mainArea) {
      renderStaffEntryForm(mainArea);
    }
  }
}
window.clearAllStaffRecords = clearAllStaffRecords;

function scrollTableHorizontally(amount) {
  const container = document.getElementById('tableScrollWrapper');
  if (container) {
    container.scrollBy({ left: amount, behavior: 'smooth' });
  }
}

function addNewStaffRowFromReport() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const newEmpNo = 'EMP-NEW-' + Math.floor(1000 + Math.random() * 9000);
  const newStaff = {
    id: newEmpNo,
    empNo: newEmpNo,
    idNo: '9' + Math.floor(10000000 + Math.random() * 89999999),
    name: isAr ? 'موظف جديد' : 'New Staff Member',
    department: 'General Medical',
    jobTitle: 'Healthcare Staff',
    dob: '01/01/1995',
    immunityStatus: 'Fully Immune',
    hepbTiter: '> 1000 mIU/mL',
    lastVaccineDate: new Date().toISOString().slice(0, 10),
    demographic: {
      personNumber: newEmpNo,
      nationalId: '9' + Math.floor(10000000 + Math.random() * 89999999),
      fullName: isAr ? 'موظف جديد' : 'New Staff Member',
      arabicFullName: isAr ? 'موظف جديد' : '',
      dob: '01/01/1995',
      gender: 'Male',
      department: 'General Medical',
      deptTreating: '',
      positionName: 'Healthcare Staff',
      orgName: 'Augusta Victoria Hospital',
      assignmentEffectiveDate: new Date().toISOString().slice(0, 10),
      staffGroup: 'Minimum Plan'
    },
    healthStatus: { allergies: 'None' },
    labResults: { hbsabResult: '>10 mIU/mL', hcvResult: 'Negative', hivResult: 'Negative', ppdResult: 'Negative' },
    vaccines: {},
    specialVaccines: {},
    covidFlu: {}
  };

  if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployee === 'function') {
    EmployeeDataService.saveEmployee(newStaff, 'save').catch(err => console.error("Error saving new staff row:", err));
  } else if (typeof saveEmployeesToLocalStorage === 'function') {
    let employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees().slice() : [];
    employees.unshift(newStaff);
    saveEmployeesToLocalStorage(employees);
  }

  alert(isAr 
    ? `✅ تم إضافة صف سجل موظف جديد بنجاح (${newStaff.name} - ${newEmpNo})!` 
    : `✅ Successfully added new staff record row (${newStaff.name} - ${newEmpNo})!`
  );

  const mainArea = document.getElementById('mainAppArea');
  if (typeof renderVaccinationReports === 'function' && mainArea) {
    renderVaccinationReports(mainArea);
  }
}

/* ==========================================================================
   GLOBAL SYNC ALL DATA & EXCEL / MASTER VACCINATION REPORT REFRESH ENGINE
   ========================================================================== */
function syncAllData() {
  if (typeof invalidateEmployeesCache === 'function') {
    invalidateEmployeesCache();
  }

  if (typeof getUniqueEmployees === 'function') {
    rptAllEmployeesList = getUniqueEmployees();
  } else {
    rptAllEmployeesList = JSON.parse(localStorage.getItem('avh_employees')) || [];
  }
  rptFilteredEmployees = rptAllEmployeesList.slice();

  // If Master Vaccination Report table is currently visible in DOM, refresh tbody & pagination
  const masterTable = document.getElementById('masterReportTable');
  if (masterTable && typeof renderReportsTableBody === 'function') {
    renderReportsTableBody();
  }

  // If Google Sheets Sync is connected, trigger sync for the saved record
  if (window.googleSheetsSync && window.googleSheetsSync.isConnected() && typeof currentEditingEmpNo !== 'undefined' && currentEditingEmpNo) {
    const emp = rptAllEmployeesList.find(e => e.empNo === currentEditingEmpNo || e.id === currentEditingEmpNo);
    if (emp && typeof window.googleSheetsSync.syncMasterStaffOnboarding === 'function') {
      window.googleSheetsSync.syncMasterStaffOnboarding(emp);
    }
  }
}
window.syncAllData = syncAllData;

/* ==========================================================================
   QUICK UPDATE MODAL ENGINE FOR MASTER VACCINATION REPORTS
   ========================================================================== */
function openQuickUpdateModal(empNoOrId) {
  const employees = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []);
  const emp = employees.find(e => e.empNo === empNoOrId || e.id === empNoOrId || e.idNo === empNoOrId);
  if (!emp) return;

  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const demo = emp.demographic || {};
  const lab = emp.labResults || {};
  const cf = emp.covidFlu || {};

  const formatDateForInput = (val) => {
    if (!val) return '';
    const str = String(val).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
    const parts = str.split(/[/.\-]/);
    if (parts.length === 3) {
      let [p1, p2, p3] = parts;
      if (p3.length === 4) return `${p3}-${p2.padStart(2, '0')}-${p1.padStart(2, '0')}`;
      if (p1.length === 4) return `${p1}-${p2.padStart(2, '0')}-${p3.padStart(2, '0')}`;
    }
    return str;
  };

  let modalHtml = `
    <div id="quickUpdateModalBackdrop" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.65); backdrop-filter: blur(4px); z-index: 10000; display: flex; justify-content: center; align-items: center; padding: 20px;">
      <div style="background: white; border-radius: 12px; max-width: 850px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); border: 2px solid var(--primary-blue);">
        
        <!-- MODAL HEADER -->
        <div style="position: sticky; top: 0; z-index: 100; background: linear-gradient(135deg, #113F52 0%, #1A5F7A 100%); color: white; padding: 18px 24px; border-top-left-radius: 10px; border-top-right-radius: 10px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.15);">
          <h3 style="margin: 0; font-size: 1.25rem;">✏️ ${isAr ? 'تحديث وتعديل بيانات الموظف' : 'Quick Update Staff Health Record'}</h3>
          <button type="button" onclick="closeQuickUpdateModal()" style="background: transparent; border: none; color: white; font-size: 1.5rem; cursor: pointer;">✕</button>
        </div>

        <form onsubmit="handleSaveQuickUpdateModal(event, '${emp.empNo || emp.id}')" style="padding: 24px;">
          <!-- DEMOGRAPHIC & BASIC INFO -->
          <h4 style="color: var(--primary-blue); margin-top: 0; margin-bottom: 12px; border-bottom: 2px solid #E2E8F0; padding-bottom: 6px;">
            👤 1. ${isAr ? 'البيانات الأساسية والشخصية' : 'Demographics & Position'}
          </h4>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin-bottom: 20px;">
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الاسم الكامل بالإنجليزية:' : 'Full Name (English):'}</label>
              <input type="text" id="qu_fullName" value="${emp.name || demo.fullName || ''}" required style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الاسم بالعربية:' : 'Arabic Full Name:'}</label>
              <input type="text" id="qu_arabicFullName" value="${demo.arabicFullName || ''}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; direction: rtl;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الرقم الوظيفي:' : 'Emp No:'}</label>
              <input type="text" id="qu_empNo" value="${emp.empNo || emp.id || ''}" readonly style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px; background: #F1F5F9; font-weight: bold;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'رقم الهوية:' : 'National ID:'}</label>
              <input type="text" id="qu_nationalId" value="${emp.idNo || demo.nationalId || ''}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'تاريخ الميلاد:' : 'Date Of Birth:'}</label>
              <input type="date" id="qu_dob" value="${formatDateForInput(emp.dob || demo.dob || '')}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'الجنس:' : 'Gender:'}</label>
              <select id="qu_gender" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
                <option value="Male" ${(demo.gender || emp.gender) === 'Male' ? 'selected' : ''}>Male</option>
                <option value="Female" ${(demo.gender || emp.gender) === 'Female' ? 'selected' : ''}>Female</option>
              </select>
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'القسم:' : 'Department:'}</label>
              <input type="text" id="qu_dept" value="${emp.department || demo.deptTreating || demo.department || ''}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">${isAr ? 'المسمى الوظيفي:' : 'Job Title:'}</label>
              <input type="text" id="qu_jobTitle" value="${emp.jobTitle || demo.positionName || ''}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem; color: #15803D;">🏷️ ${isAr ? 'فئة الكادر / المخطط:' : 'Staff Group / Plan:'}</label>
              <select id="qu_staffGroup" style="width: 100%; padding: 8px 10px; border: 1.5px solid #16A34A; border-radius: 4px; font-weight: bold; background: #F0FDF4; color: #15803D;">
                <option value="Extended Program" ${((emp.staffGroup || demo.staffGroup || '').toLowerCase().includes('extended')) ? 'selected' : ''}>Extended Program (البرنامج الممتد)</option>
                <option value="Basic Plan" ${((emp.staffGroup || demo.staffGroup || '').toLowerCase().includes('basic')) ? 'selected' : ''}>Basic Plan (البرنامج الأساسي)</option>
                <option value="Minimum Plan" ${((emp.staffGroup || demo.staffGroup || '').toLowerCase().includes('minimum')) ? 'selected' : ''}>Minimum Plan (البرنامج الأدنى)</option>
                <option value="Special Clinical Staff" ${((emp.staffGroup || demo.staffGroup || '').toLowerCase().includes('special')) ? 'selected' : ''}>Special Clinical Staff (كادر طبي خاص)</option>
              </select>
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem; color: #0284C7;">📌 ${isAr ? 'حالة العمل والتوظيف:' : 'Employment Status:'}</label>
              <select id="qu_employmentStatus" style="width: 100%; padding: 8px 10px; border: 1.5px solid #0284C7; border-radius: 4px; font-weight: bold; background: #F0F9FF; color: #0369A1;">
                <option value="Active Staff" ${(emp.employmentStatus === 'Active Staff' || demo.employmentStatus === 'Active Staff' || !emp.employmentStatus) ? 'selected' : ''}>🟢 Active Staff (على رأس عمله)</option>
                <option value="On Leave" ${(emp.employmentStatus === 'On Leave' || demo.employmentStatus === 'On Leave') ? 'selected' : ''}>🟡 On Leave (إجازة)</option>
                <option value="Transferred" ${(emp.employmentStatus === 'Transferred' || demo.employmentStatus === 'Transferred') ? 'selected' : ''}>🔵 Transferred (منقول)</option>
                <option value="Resigned" ${(emp.employmentStatus === 'Resigned' || demo.employmentStatus === 'Resigned') ? 'selected' : ''}>🟠 Resigned (مستقيل)</option>
                <option value="Retired" ${(emp.employmentStatus === 'Retired' || demo.employmentStatus === 'Retired') ? 'selected' : ''}>🟣 Retired (متقاعد)</option>
                <option value="Deceased" ${(emp.employmentStatus === 'Deceased' || demo.employmentStatus === 'Deceased') ? 'selected' : ''}>⚫ Deceased (متوفى)</option>
                <option value="Terminated" ${(emp.employmentStatus === 'Terminated' || demo.employmentStatus === 'Terminated') ? 'selected' : ''}>🔴 Terminated (إنهاء خدمات)</option>
                <option value="Contract Finished" ${(emp.employmentStatus === 'Contract Finished' || demo.employmentStatus === 'Contract Finished') ? 'selected' : ''}>🟤 Contract Finished (انتهاء عقد)</option>
                <option value="Discharged" ${(emp.employmentStatus === 'Discharged' || demo.employmentStatus === 'Discharged') ? 'selected' : ''}>⚪ Discharged (منتهي الخدمة)</option>
              </select>
            </div>
          </div>

          <!-- LAB RESULTS & HEPATITIS B -->
          <h4 style="color: var(--primary-blue); margin-bottom: 12px; border-bottom: 2px solid #E2E8F0; padding-bottom: 6px;">
            🔬 2. ${isAr ? 'الفحوصات المخبرية وتطعيمات التهاب الكبد B' : 'Laboratory & Hepatitis B Vaccinations'}
          </h4>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin-bottom: 20px;">
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">HBsAb Result:</label>
              <input type="text" id="qu_hbsabResult" value="${emp.hepbTiter || lab.hbsabResult || ''}" placeholder="e.g. >1000 mIU/mL" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">HBsAb Date:</label>
              <input type="date" id="qu_hbsabDate" value="${formatDateForInput(lab.hbsabDate || emp.hbsabDate || '')}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">Date of Engrix 1st Dose:</label>
              <input type="date" id="qu_engrix1" value="${formatDateForInput(lab.engrixDose1 || '')}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">Date of Engrix 2nd Dose:</label>
              <input type="date" id="qu_engrix2" value="${formatDateForInput(lab.engrixDose2 || '')}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">Date of Engrix 3rd Dose:</label>
              <input type="date" id="qu_engrix3" value="${formatDateForInput(lab.engrixDose3 || '')}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">HCV Result:</label>
              <input type="text" id="qu_hcvResult" value="${lab.hcvResult || 'Non-Reactive'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">HIV Result:</label>
              <input type="text" id="qu_hivResult" value="${lab.hivResult || 'Non-Reactive'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">PPD Step 1 Result:</label>
              <input type="text" id="qu_ppdResult" value="${lab.ppdStep1Result || '0 mm (Negative)'}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem;">Flu Vaccine Date:</label>
              <input type="date" id="qu_fluDate" value="${formatDateForInput(cf.fluDate || '')}" style="width: 100%; padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 4px;">
            </div>
            <div>
              <label style="font-weight: bold; font-size: 0.82rem; color: #0369A1;">🛡️ Immunity & Vaccination Status (حالة التطعيم والمناعة):</label>
              <select id="qu_immunityStatus" style="width: 100%; padding: 8px 10px; border: 1.5px solid #0284C7; border-radius: 4px; font-weight: bold; background: #F0F9FF; color: #0369A1;">
                <option value="Fully Vaccinated" ${emp.immunityStatus === 'Fully Vaccinated' || emp.immunityStatus === 'Fully Immune' || !emp.immunityStatus ? 'selected' : ''}>🟢 Fully Vaccinated / Fully Immune (مُلقح بالكامل)</option>
                <option value="Partially Vaccinated" ${emp.immunityStatus === 'Partially Vaccinated' ? 'selected' : ''}>🟡 Partially Vaccinated (مُلقح جزئياً)</option>
                <option value="Ongoing" ${emp.immunityStatus === 'Ongoing' || emp.immunityStatus === 'In Progress' ? 'selected' : ''}>🔵 Ongoing / In Progress (قيد التطعيم المستمر)</option>
                <option value="Not Vaccinated" ${emp.immunityStatus === 'Not Vaccinated' ? 'selected' : ''}>🔴 Not Vaccinated (غير مُلقح)</option>
                <option value="Contraindication" ${emp.immunityStatus === 'Contraindication' || emp.immunityStatus === 'Medical Exemption' ? 'selected' : ''}>⚠️ Contraindication / Medical Exemption (موانع تطبيق التطعيم)</option>
                <option value="Non-Responder" ${String(emp.immunityStatus || '').toLowerCase().includes('non-responder') || String(emp.hepbTiter || '').toLowerCase().includes('non-responder') ? 'selected' : ''}>⚠️ Non-Responder (غير مستجيب للتطعيم - HBsAb < 10 mIU/mL)</option>
              </select>
            </div>
          </div>

          <!-- FOOTER ACTIONS -->
          <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px; padding-top: 16px; border-top: 1px solid #E2E8F0;">
            <button type="button" class="btn btn-outline" onclick="closeQuickUpdateModal()" style="padding: 8px 18px;">Cancel</button>
            <button type="submit" class="btn btn-success" style="padding: 8px 22px; font-weight: bold; background: #10B981; color: white; border: none;">
              💾 ${isAr ? 'حفظ وتحديث البيانات' : 'Save & Sync Updates'}
            </button>
          </div>
        </form>
      </div>
    </div>
  `;

  let modalContainer = document.getElementById('quickUpdateModalContainer');
  if (!modalContainer) {
    modalContainer = document.createElement('div');
    modalContainer.id = 'quickUpdateModalContainer';
    document.body.appendChild(modalContainer);
  }
  modalContainer.innerHTML = modalHtml;
}
window.openQuickUpdateModal = openQuickUpdateModal;

function closeQuickUpdateModal() {
  const modalContainer = document.getElementById('quickUpdateModalContainer');
  if (modalContainer) modalContainer.innerHTML = '';
}
window.closeQuickUpdateModal = closeQuickUpdateModal;

function handleSaveQuickUpdateModal(e, empNo) {
  if (e) e.preventDefault();
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  let employees = JSON.parse(localStorage.getItem('avh_employees')) || (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : []);

  const idx = employees.findIndex(emp => emp.empNo === empNo || emp.id === empNo || emp.idNo === empNo);
  if (idx === -1) {
    alert('Employee record not found.');
    return;
  }

  const existing = employees[idx];
  const updatedName = document.getElementById('qu_fullName').value.trim() || existing.name;
  const updatedArName = document.getElementById('qu_arabicFullName').value.trim() || (existing.demographic ? existing.demographic.arabicFullName : '');
  const updatedNatId = document.getElementById('qu_nationalId').value.trim() || existing.idNo;
  const updatedDob = document.getElementById('qu_dob').value || existing.dob;
  const updatedGender = document.getElementById('qu_gender').value || (existing.demographic ? existing.demographic.gender : 'Male');
  const updatedDept = document.getElementById('qu_dept').value.trim() || existing.department;
  const updatedTitle = document.getElementById('qu_jobTitle').value.trim() || existing.jobTitle;
  const updatedStaffGroup = document.getElementById('qu_staffGroup') ? document.getElementById('qu_staffGroup').value : (existing.staffGroup || existing.demographic?.staffGroup || 'Extended Program');
  const updatedEmpStatus = document.getElementById('qu_employmentStatus') ? document.getElementById('qu_employmentStatus').value : (existing.employmentStatus || existing.demographic?.employmentStatus || 'Active Staff');
  const isNowActive = (updatedEmpStatus === 'Active Staff');

  const updatedHbsabRes = document.getElementById('qu_hbsabResult').value.trim();
  const updatedHbsabDate = document.getElementById('qu_hbsabDate').value;
  const updatedEngrix1 = document.getElementById('qu_engrix1').value;
  const updatedEngrix2 = document.getElementById('qu_engrix2').value;
  const updatedEngrix3 = document.getElementById('qu_engrix3').value;
  const updatedHcvRes = document.getElementById('qu_hcvResult').value.trim();
  const updatedHivRes = document.getElementById('qu_hivResult').value.trim();
  const updatedPpdRes = document.getElementById('qu_ppdResult').value.trim();
  const updatedFluDate = document.getElementById('qu_fluDate').value;
  const updatedImmunity = document.getElementById('qu_immunityStatus').value;

  employees[idx] = {
    ...existing,
    name: updatedName,
    idNo: updatedNatId,
    department: updatedDept,
    jobTitle: updatedTitle,
    staffGroup: updatedStaffGroup,
    employmentStatus: updatedEmpStatus,
    workStatus: updatedEmpStatus,
    isArchived: !isNowActive,
    archived: !isNowActive,
    dob: updatedDob,
    hepbTiter: updatedHbsabRes || existing.hepbTiter,
    immunityStatus: updatedImmunity,
    demographic: {
      ...(existing.demographic || {}),
      fullName: updatedName,
      arabicFullName: updatedArName,
      nationalId: updatedNatId,
      dob: updatedDob,
      gender: updatedGender,
      department: updatedDept,
      positionName: updatedTitle,
      deptTreating: updatedDept,
      staffGroup: updatedStaffGroup,
      employmentStatus: updatedEmpStatus,
      isArchived: !isNowActive,
      archived: !isNowActive
    },
    labResults: {
      ...(existing.labResults || {}),
      hbsabResult: updatedHbsabRes,
      hbsabDate: updatedHbsabDate,
      engrixDose1: updatedEngrix1,
      engrixDose2: updatedEngrix2,
      engrixDose3: updatedEngrix3,
      hcvResult: updatedHcvRes,
      hivResult: updatedHivRes,
      ppdStep1Result: updatedPpdRes
    },
    covidFlu: {
      ...(existing.covidFlu || {}),
      fluDate: updatedFluDate
    }
  };

  if (typeof EmployeeDataService !== 'undefined' && typeof EmployeeDataService.saveEmployee === 'function') {
    EmployeeDataService.saveEmployee(employees[idx], 'update').catch(err => console.error("Quick update error:", err));
  } else if (typeof saveEmployeesToLocalStorage === 'function') {
    saveEmployeesToLocalStorage(employees);
  }

  if (typeof saveEmployeeToMasterSheet === 'function') {
    saveEmployeeToMasterSheet(employees[idx]);
  }
  if (typeof currentEditingEmpNo !== 'undefined') {
    currentEditingEmpNo = empNo;
  }

  closeQuickUpdateModal();

  // Re-render reports table immediately
  if (typeof filterReportsTableImmediate === 'function') {
    filterReportsTableImmediate();
  }
  if (typeof updateReportTabStyles === 'function') {
    updateReportTabStyles();
  }
  if (typeof renderReportsTableBody === 'function') {
    renderReportsTableBody();
  }
  const mainArea = document.getElementById('mainAppArea');
  if (typeof renderVaccinationReports === 'function' && mainArea) {
    renderVaccinationReports(mainArea);
  }

  const msg = isAr 
    ? `✅ تم تحديث سجل الموظف (${updatedName}) بنجاح ومزامنة تقارير التطعيمات والإكسل!`
    : `✅ Successfully updated staff record for (${updatedName}) and synced Master Reports & Excel!`;
  alert(msg);
  if (typeof showSuccessToast === 'function') {
    showSuccessToast(msg, isAr ? 'تم التحديث بنجاح' : 'Done Successfully!');
  }
}

window.openQuickUpdateModal = openQuickUpdateModal;
window.closeQuickUpdateModal = closeQuickUpdateModal;
window.handleSaveQuickUpdateModal = handleSaveQuickUpdateModal;

/* ==========================================================================
   DUAL TOP & BOTTOM SCROLLBAR SYNCHRONIZATION ENGINE
   ========================================================================== */
function syncTopScroll(topEl) {
  const botEl = document.getElementById('tableScrollWrapper');
  if (botEl && !topEl._isSyncing) {
    botEl._isSyncing = true;
    botEl.scrollLeft = topEl.scrollLeft;
    setTimeout(() => { botEl._isSyncing = false; }, 10);
  }
}

function syncBottomScroll(botEl) {
  const topEl = document.getElementById('topScrollWrapper');
  if (topEl && !botEl._isSyncing) {
    topEl._isSyncing = true;
    topEl.scrollLeft = botEl.scrollLeft;
    setTimeout(() => { topEl._isSyncing = false; }, 10);
  }
}

function updateTopScrollWidth() {
  const table = document.getElementById('masterReportTable');
  const dummy = document.getElementById('topScrollDummy');
  if (table && dummy) {
    dummy.style.width = Math.max(table.scrollWidth, 4600) + 'px';
  }
}

window.syncTopScroll = syncTopScroll;
window.syncBottomScroll = syncBottomScroll;
window.updateTopScrollWidth = updateTopScrollWidth;

/* ==========================================================================
   UNVACCINATED & PARTIALLY VACCINATED STAFF FOLLOW-UP ACTION REPORT ENGINE
   ========================================================================== */

function getUnvaccinatedStaffList(vacFilter = 'ALL', catFilter = 'ALL') {
  const list = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
  const results = [];

  list.forEach(emp => {
    // Unconditionally exclude archived/former staff members from follow-up reports
    if (typeof isArchivedStaff === 'function' && isArchivedStaff(emp)) return;
    // Unconditionally exclude Gaza Project staff from this report
    if (typeof isGazaStaff === 'function' && isGazaStaff(emp)) return;
    if (typeof isAVHStaff === 'function' && !isAVHStaff(emp)) return;
    const deptStrCheck = String(emp.department || (emp.demographic && emp.demographic.department) || '').toLowerCase();
    if (deptStrCheck.includes('gaza')) return;

    if (catFilter === 'extended' && (!isAVHStaff(emp) || !isExtendedStaff(emp))) return;
    if (catFilter === 'minimum' && (!isAVHStaff(emp) || !isMinimumStaff(emp))) return;
    if (catFilter === 'basic' && (!isAVHStaff(emp) || !isBasicStaff(emp))) return;
    if ((catFilter === 'lab' || catFilter === 'special') && (!isAVHStaff(emp) || (!isSpecialVaccineStaff(emp) && !(typeof isSpecialVacStaffDepartment === 'function' && isSpecialVacStaffDepartment(emp.department || (emp.demographic && emp.demographic.department), emp))))) return;
    if (catFilter === 'oncology' && (!isAVHStaff(emp) || !isOncologyStaff(emp))) return;
    if (catFilter === 'babies' && (!isAVHStaff(emp) || !isBabiesPediatricStaff(emp))) return;
    if (catFilter === 'invasive' && (!isAVHStaff(emp) || !isInvasiveProcedureStaff(emp))) return;

    const mohStatus = typeof calculateMOHImmunityStatus === 'function' ? calculateMOHImmunityStatus(emp) : 'Fully Immune';

    const demo = emp.demographic || {};
    const vac = emp.vaccines || {};
    const sp = emp.specialVaccines || {};
    const lab = emp.labResults || emp.lab || {};
    const cf = emp.covidFlu || {};

    const missingVacList = [];
    const isContra = (val) => {
      const s = String(val || '').toLowerCase().trim();
      return s.includes('contra') || s.includes('exemp') || s.includes('defer');
    };

    const isSpecialStaff = (typeof isSpecialVaccineStaff === 'function' && isSpecialVaccineStaff(emp)) ||
                           (typeof isSpecialVacStaffDepartment === 'function' && isSpecialVacStaffDepartment(emp.department || demo.department, emp)) ||
                           !!(sp.typhoid || sp.meningococcal || sp.pneumovax || sp.pnemovax || sp.hepA1 || sp.hepA2 || sp.typhoidDate || sp.meningococcalDate || sp.pneumovaxDate || sp.hepADate);

    const isLabStaff = isSpecialStaff;
    const isMin = typeof isMinimumStaff === 'function' ? isMinimumStaff(emp) : false;
    const isExt = typeof isExtendedStaff === 'function' ? isExtendedStaff(emp) : false;
    const isBasic = typeof isBasicStaff === 'function' ? isBasicStaff(emp) : false;

    const hasTdap = !!(vac.tdapDate || (vac.Tdap && (vac.Tdap.d5 || vac.Tdap.d1)));
    const isMMRImmune = typeof isMMRProtected === 'function' ? isMMRProtected(emp) : !!(vac.mmrDose1 || (vac.MMR && vac.MMR.d1));
    const cpStatus = String(vac.chickenpoxStatus || vac.chickenpox || '').toLowerCase();
    const varIgG = String(vac.varicellaIgG || lab.varicellaIgG || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '').toLowerCase();
    const isVaricellaImmune = !!(vac.chickenpoxDose2 || vac.chickenpoxDose1 || cpStatus.includes('vaccin') || cpStatus.includes('immune') || cpStatus.includes('natural') || cpStatus.includes('pos') || varIgG.includes('pos') || varIgG.includes('immune') || varIgG.includes('natural'));
    const hasPolio = !!(vac.ipvDate || (vac.IPV && (vac.IPV.d5 || vac.IPV.d1)));

    // Hepatitis B MOH Logic: HBsAb result > 10 = Fully Immune (no need for HBV Series, Anti-HBc, HBsAg). Non-responder = No missing HBV items.
    const rawHbsab = String(emp.hepbTiter || lab.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || '').toLowerCase().trim();
    const immStatus = String(emp.immunityStatus || '').toLowerCase().trim();

    const isNonResponder = rawHbsab.includes('non-responder') || rawHbsab.includes('non responder') || 
                           rawHbsab.includes('resistance') || rawHbsab.includes('nonresponder') ||
                           immStatus.includes('non-responder') || immStatus.includes('resistance');

    const numMatch = rawHbsab.match(/([<>])?\s*([0-9]+(?:\.[0-9]+)?)/);
    const hasLessThan = rawHbsab.includes('<');
    const hasGreaterThan = rawHbsab.includes('>') || rawHbsab.includes('positive') || rawHbsab.includes('pos') || rawHbsab.includes('immune') || rawHbsab.includes('react');
    let parsedVal = numMatch ? parseFloat(numMatch[2]) : null;

    const isImmuneGreater10 = !hasLessThan && (hasGreaterThan || (parsedVal !== null && parsedVal >= 10) || (parsedVal === null && immStatus.includes('immune') && !immStatus.includes('non-responder')));

    const hasHBVVac = !!(lab.engrixDose3 || lab.engrixDose2 || lab.engrixDose1 || (vac['Hepatitis B'] && vac['Hepatitis B'].d1));
    const hasAntiHBs = isImmuneGreater10 || isNonResponder || !!(rawHbsab && !rawHbsab.includes('blank') && !rawHbsab.includes('pending') && rawHbsab !== '0');
    const hasAntiHBc = isImmuneGreater10 || isNonResponder || !!(lab.antiHbcResult || lab.antiHBc);
    const hasHBsAg = isImmuneGreater10 || isNonResponder || !!(lab.hbsagResult || lab.HBsAg);
    const noNeedHBV = isImmuneGreater10 || isNonResponder;

    const isHbsabInProgress = !isNonResponder && !isImmuneGreater10 && ((parsedVal !== null && parsedVal < 10) || hasLessThan || rawHbsab.includes('<') || (!isMin && (hasHBVVac || rawHbsab.includes('in progress') || rawHbsab.includes('progress'))));
    if (isHbsabInProgress) {
      missingVacList.push({ name: 'anti-HBs <10 mIU/mL (Vaccination in progress)', category: 'HbsabInProgress' });
    }

    const rawHcv = String(lab.hcvResult || lab.HCV || '').toLowerCase();
    const hasAntiHCV = !!(rawHcv && !rawHcv.includes('blank') && !rawHcv.includes('pending'));
    const rawPpd = String(lab.ppdStep1Result || lab.ppdResult || lab.PPD || '').toLowerCase();
    const hasPPD = !!(rawPpd && !rawPpd.includes('blank') && !rawPpd.includes('pending'));
    const hasFlu = !!(cf.flu2425 || cf.flu2324 || cf.fluDate || (vac['Flu vaccine'] && vac['Flu vaccine'].d5));
    const hasTyphoid = !!(sp.typhoid || sp.typhoidDate);
    const hasMeningo = !!(sp.meningococcal || sp.meningococcalDate);
    const hasPneumo = !!(sp.pneumovax || sp.pnemovax || sp.pneumovaxDate);
    const hasHepA1 = !!(sp.hepA1 || sp.hepADate);
    const hasHepA2 = !!(sp.hepA2);

    if (!hasTdap && !isContra(vac.tdapDate || (vac.Tdap && (vac.Tdap.d5 || vac.Tdap.d1)))) missingVacList.push({ name: 'Tdap Vaccine', category: 'Core' });
    if (!isMMRImmune && !isContra(vac.mmrDose1 || (vac.MMR && vac.MMR.d1))) missingVacList.push({ name: 'MMR Vaccine', category: 'Core' });
    if (!isVaricellaImmune && !isContra(vac.chickenpoxStatus || vac.chickenpoxDose2 || lab.varicellaIgG)) missingVacList.push({ name: 'Chickenpox / Varicella', category: 'Core' });
    if (!hasFlu && !isContra(cf.flu2425 || cf.fluDate)) missingVacList.push({ name: 'Seasonal Flu Vaccine', category: 'Flu' });

    if (isLabStaff || isExt || isBasic) {
      if (!hasPolio && !isContra(vac.ipvDate || (vac.IPV && (vac.IPV.d5 || vac.IPV.d1)))) missingVacList.push({ name: 'Polio Vaccine (IPV)', category: 'Core' });
      if (!noNeedHBV && !hasHBVVac && !isContra(vac['Hepatitis B'] && vac['Hepatitis B'].d1)) missingVacList.push({ name: 'Hepatitis B Series', category: 'HepB' });
      if (!hasPPD && !isContra(lab.ppdStep1Result || lab.ppdResult)) missingVacList.push({ name: 'PPD Tuberculin Test', category: 'Core' });
    }

    if (isLabStaff || isExt) {
      if (!noNeedHBV && !hasAntiHBs && !isContra(rawHbsab)) missingVacList.push({ name: 'Anti-HBs Titer', category: 'HepB' });
      if (!hasAntiHCV && !isContra(rawHcv)) missingVacList.push({ name: 'Anti-HCV Screening', category: 'HepB' });
      if (!noNeedHBV && !hasAntiHBc && !isContra(lab.antiHbcResult)) missingVacList.push({ name: 'Anti-HBc Screening', category: 'HepB' });
      if (!noNeedHBV && !hasHBsAg && !isContra(lab.hbsagResult)) missingVacList.push({ name: 'HBsAg Screening', category: 'HepB' });
    }

    if (isSpecialStaff || isLabStaff || catFilter === 'special' || catFilter === 'lab') {
      if (!hasTyphoid && !isContra(sp.typhoid)) missingVacList.push({ name: 'Typhoid Vaccine', category: 'Special' });
      if (!hasMeningo && !isContra(sp.meningococcal)) missingVacList.push({ name: 'Meningococcal Vaccine', category: 'Special' });
      if (!hasPneumo && !isContra(sp.pneumovax || sp.pnemovax)) missingVacList.push({ name: 'Pneumovax 23', category: 'Special' });
      if (!hasHepA1 && !isContra(sp.hepA1)) missingVacList.push({ name: 'Hepatitis A (Series 1)', category: 'Special' });
      if (!hasHepA2 && !isContra(sp.hepA2)) missingVacList.push({ name: 'Hepatitis A (Series 2)', category: 'Special' });
    }

    let filteredMissing = missingVacList;
    if (vacFilter === 'CORE') filteredMissing = missingVacList.filter(m => m.category === 'Core');
    if (vacFilter === 'SPECIAL') filteredMissing = missingVacList.filter(m => m.category === 'Special');
    if (vacFilter === 'HEPB') filteredMissing = missingVacList.filter(m => m.category === 'HepB');
    if (vacFilter === 'HBSAB_IN_PROGRESS') filteredMissing = missingVacList.filter(m => m.category === 'HbsabInProgress');
    if (vacFilter === 'FLU') filteredMissing = missingVacList.filter(m => m.category === 'Flu');

    if (filteredMissing.length > 0) {
      results.push({
        emp: emp,
        missing: filteredMissing,
        totalMissingCount: filteredMissing.length,
        mohStatus: mohStatus
      });
    }
  });

  return results;
}
window.getUnvaccinatedStaffList = getUnvaccinatedStaffList;

function openUnvaccinatedFollowupReport(vacFilter = 'ALL', catFilter = 'ALL') {
  if (vacFilter === 'HEPB') vacFilter = 'HBSAB_IN_PROGRESS';
  window._currentUnvacModalVacFilter = vacFilter;
  window._currentUnvacModalCatFilter = catFilter;

  const isAr = window.i18n ? window.i18n.isRTL() : false;

  // Pre-calculate counts for each vaccine filter option (excluding Gaza)
  const allList = getUnvaccinatedStaffList('ALL', catFilter);
  const coreList = getUnvaccinatedStaffList('CORE', catFilter);
  const hbsinprogList = getUnvaccinatedStaffList('HBSAB_IN_PROGRESS', catFilter);
  const fluList = getUnvaccinatedStaffList('FLU', catFilter);
  const specialList = getUnvaccinatedStaffList('SPECIAL', catFilter);

  const countAll = allList.length;
  const countCore = coreList.length;
  const countHbsInProg = hbsinprogList.length;
  const countFlu = fluList.length;
  const countSpecial = specialList.length;

  let list = allList;
  if (vacFilter === 'CORE') list = coreList;
  else if (vacFilter === 'HBSAB_IN_PROGRESS' || vacFilter === 'HEPB') list = hbsinprogList;
  else if (vacFilter === 'FLU') list = fluList;
  else if (vacFilter === 'SPECIAL') list = specialList;

  const modalHtml = `
    <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.75); z-index: 99999; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px); padding: 20px;">
      <div style="background: white; border-radius: 12px; max-width: 1150px; width: 100%; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35); border: 1px solid #CBD5E1; overflow: hidden;">
        
        <!-- MODAL HEADER -->
        <div style="background: linear-gradient(135deg, #1E293B 0%, #0F172A 100%); color: white; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #EF4444;">
          <div>
            <div style="font-weight: 800; font-size: 1.15rem; display: flex; align-items: center; gap: 8px;">
              <span>📋 ${isAr ? `تقرير متابعة الكوادر المفتقدة للتطعيمات والتحاليل (${list.length} موظف)` : `Unvaccinated & Partially Vaccinated Follow-Up Action Report (${list.length} Staff)`}</span>
            </div>
            <div style="font-size: 0.8rem; color: #94A3B8; margin-top: 2px;">
              ${isAr ? 'تقرير الفحص والمتابعة التفصيلي للكوادر ذات التطعيمات والتحاليل المعلقة (مستثنى منها مشروع غزة).' : 'Detailed follow-up action report for staff members requiring pending vaccine doses, titers, or screening tests (Excluding Gaza Project).'}
            </div>
          </div>
          <button type="button" onclick="closeUnvaccinatedFollowupReport()" style="background: rgba(255,255,255,0.1); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-size: 1.1rem; font-weight: bold; display: flex; align-items: center; justify-content: center;">✕</button>
        </div>

        <!-- VACCINE FILTER & EXPORT ACTION BAR -->
        <div style="padding: 14px 24px; background: #F8FAFC; border-bottom: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
            <span style="font-size: 0.8rem; font-weight: 800; color: #475569; text-transform: uppercase;">💉 ${isAr ? 'نوع التطعيم:' : 'Vaccine Type:'}</span>
            <button type="button" class="btn" style="padding: 5px 12px; font-size: 0.8rem; font-weight: bold; border-radius: 6px; cursor: pointer; background: ${vacFilter === 'ALL' ? '#DC2626' : 'white'}; color: ${vacFilter === 'ALL' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openUnvaccinatedFollowupReport('ALL', '${catFilter}')">
              🎯 ${isAr ? `جميع التطعيمات المطلوبة (${countAll})` : `All Missing Doses (${countAll})`}
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-size: 0.8rem; font-weight: bold; border-radius: 6px; cursor: pointer; background: ${vacFilter === 'CORE' ? '#2563EB' : 'white'}; color: ${vacFilter === 'CORE' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openUnvaccinatedFollowupReport('CORE', '${catFilter}')">
              💉 ${isAr ? `التطعيمات الأساسية (${countCore})` : `Core Doses (${countCore})`}
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-size: 0.8rem; font-weight: bold; border-radius: 6px; cursor: pointer; background: ${(vacFilter === 'HBSAB_IN_PROGRESS' || vacFilter === 'HEPB') ? '#D97706' : 'white'}; color: ${(vacFilter === 'HBSAB_IN_PROGRESS' || vacFilter === 'HEPB') ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openUnvaccinatedFollowupReport('HBSAB_IN_PROGRESS', '${catFilter}')">
              🩸 ${isAr ? `الكبد ب - قيد برنامج التطعيم (${countHbsInProg})` : `anti-HBs: Vaccination in progress (${countHbsInProg})`}
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-size: 0.8rem; font-weight: bold; border-radius: 6px; cursor: pointer; background: ${vacFilter === 'FLU' ? '#7C3AED' : 'white'}; color: ${vacFilter === 'FLU' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openUnvaccinatedFollowupReport('FLU', '${catFilter}')">
              🦠 ${isAr ? `الأنفلونزا الموسمية (${countFlu})` : `Seasonal Flu (${countFlu})`}
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-size: 0.8rem; font-weight: bold; border-radius: 6px; cursor: pointer; background: ${vacFilter === 'SPECIAL' ? '#047857' : 'white'}; color: ${vacFilter === 'SPECIAL' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openUnvaccinatedFollowupReport('SPECIAL', '${catFilter}')">
              🛡️ ${isAr ? `التطعيمات الخاصة (${countSpecial})` : `Special Vaccines (${countSpecial})`}
            </button>
          </div>

          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button type="button" class="btn btn-outline" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: white; color: #1E293B; border: 1px solid #CBD5E1; border-radius: 6px; cursor: pointer;" onclick="printUnvaccinatedFollowupReport()">
              🖨️ ${isAr ? 'طباعة التقرير' : 'Print Report'}
            </button>
            <button type="button" class="btn btn-success" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: #10B981; color: white; border: none; border-radius: 6px; cursor: pointer;" onclick="exportUnvaccinatedFollowupExcel('${vacFilter}', '${catFilter}')">
              📥 ${isAr ? 'تصدير القائمة للإكسل' : 'Export Follow-Up Report (.xlsx)'}
            </button>
          </div>
        </div>

        <!-- MODAL TABLE BODY -->
        <div style="flex: 1; overflow-y: auto; padding: 20px;">
          ${list.length === 0 ? `
            <div style="text-align: center; padding: 40px; color: #059669; font-weight: bold; font-size: 1.1rem; background: #F0FDF4; border-radius: 8px; border: 1px solid #A7F3D0;">
              🎉 ${isAr ? 'ممتاز! جميع الكوادر ملقحون ومكتملو التطعيمات 100%' : 'Awesome! 100% of staff members are fully compliant!'}
            </div>
          ` : `
            <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt;">
              <thead>
                <tr style="background: #F1F5F9; color: #1E293B; text-align: left;">
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: center;">#</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'الرقم الوظيفي / الهوية' : 'Emp No / ID'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'اسم الموظف' : 'Staff Name'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'القسم / الوحدة' : 'Department / Treating Unit'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'فئة الكادر' : 'Staff Group'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'حالة المناعة الرسمية (MOH)' : 'Immunity Status'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? `الجرعات المطلوبة المفقودة (${list.length} كوادر)` : `Required Missing Doses/Tests (${list.length} Staff)`}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: center;">${isAr ? 'الإجراء المباشر' : 'Follow-up Actions'}</th>
                </tr>
              </thead>
              <tbody>
                ${list.map((item, idx) => {
                  const emp = item.emp;
                  const demo = emp.demographic || {};
                  const empNo = emp.empNo || emp.id || demo.personNumber || 'N/A';
                  const natId = emp.idNo || demo.nationalId || '';
                  const nameStr = emp.name || demo.fullName || demo.arabicFullName || 'Staff Member';
                  const deptStr = emp.department || demo.deptTreating || demo.department || 'General Medical';
                  const groupStr = emp.staffGroup || demo.staffGroup || 'Minimum Plan';

                  let statusStr = item.mohStatus || 'Pending';
                  if (item.missing && item.missing.some(m => m.category === 'Special')) {
                    statusStr = 'Special Vaccines Pending';
                  }
                  const isPartial = statusStr.startsWith('Partially') || statusStr.includes('Pending');
                  const bg = isPartial ? '#FEF3C7' : '#E2E8F0';
                  const fg = isPartial ? '#B45309' : '#334155';
                  const border = isPartial ? '#FDE68A' : '#CBD5E1';

                  return `
                    <tr style="background: ${idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC'};">
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold; color: #64748B;">${idx + 1}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #0284C7;">
                        <div>${empNo}</div>
                        <div style="font-size: 0.75rem; color: #64748B;">ID: ${natId}</div>
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold;">
                        <div style="color: #1E293B;">${nameStr}</div>
                        ${demo.arabicFullName ? `<div style="font-size: 0.78rem; color: #475569;">${demo.arabicFullName}</div>` : ''}
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.85rem;">${deptStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.82rem; font-weight: bold; color: #166534;">${groupStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0;">
                        <span style="background:${bg}; color:${fg}; border:1px solid ${border}; font-weight:800; border-radius:12px; padding:3px 8px; font-size:0.75rem; display:inline-block;">
                          ${statusStr}
                        </span>
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0;">
                        <div style="font-size: 0.73rem; font-weight: 800; color: #DC2626; margin-bottom: 4px;">
                          ⚠️ ${item.missing.length} ${isAr ? 'تطعيمات/تحاليل معلقة' : 'Missing Doses/Tests'}:
                        </div>
                        <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                          ${item.missing.map(m => `
                            <span class="badge" style="background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; font-size: 0.75rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">
                              ⚠️ ${m.name}
                            </span>
                          `).join('')}
                        </div>
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center;">
                        <div style="display: flex; gap: 4px; justify-content: center;">
                          <button type="button" class="btn btn-primary" style="padding: 4px 8px; font-size: 0.75rem; background: #0284C7; border: none; color: white; border-radius: 4px; font-weight: bold;" onclick="openQuickUpdateModal('${empNo}'); closeUnvaccinatedFollowupReport();">
                            ⚡ ${isAr ? 'تحديث سريع' : 'Quick Update'}
                          </button>
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.75rem; border: 1px solid #64748B; color: #334155; border-radius: 4px; font-weight: bold;" onclick="editEmployeeFromReportTable('${empNo}'); closeUnvaccinatedFollowupReport();">
                            📝 ${isAr ? 'النموذج' : 'Open Form'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          `}
        </div>

        <!-- MODAL FOOTER -->
        <div style="padding: 14px 24px; background: #F1F5F9; border-top: 1px solid #CBD5E1; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-size: 0.82rem; font-weight: bold; color: #475569;">
            ${isAr ? `إجمالي الكوادر المستهدفة للمتابعة: ${list.length} موظف (مستثنى منهم مشروع غزة)` : `Total Staff Requiring Follow-Up Action: ${list.length} Staff Members (Excluding Gaza Project)`}
          </div>
          <button type="button" class="btn btn-outline" style="padding: 6px 18px; font-weight: bold;" onclick="closeUnvaccinatedFollowupReport()">Close Report</button>
        </div>

      </div>
    </div>
  `;

  let modalContainer = document.getElementById('unvaccinatedFollowupModalContainer');
  if (!modalContainer) {
    modalContainer = document.createElement('div');
    modalContainer.id = 'unvaccinatedFollowupModalContainer';
    document.body.appendChild(modalContainer);
  }
  modalContainer.innerHTML = modalHtml;
}
window.openUnvaccinatedFollowupReport = openUnvaccinatedFollowupReport;

function getContraindicatedStaffList() {
  const list = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const results = [];

  list.forEach(emp => {
    if (typeof isArchivedStaff === 'function' && isArchivedStaff(emp)) return;
    const vac = emp.vaccines || {};
    const sp = emp.specialVaccines || {};
    const lab = emp.labResults || emp.lab || {};

    const contraVacs = [];

    const checkContra = (val, name) => {
      const str = String(val || '').toLowerCase().trim();
      if (str.includes('contra') || str.includes('exemp') || str.includes('defer')) {
        contraVacs.push(name);
      }
    };

    checkContra(vac.ipvDate || vac.IPV?.d1, 'IPV Vaccine (>18Y)');
    checkContra(vac.tdapDate || vac.Tdap?.d1, 'Tdap Vaccine (>7Y)');
    checkContra(vac.mmrDose1 || vac.MMR?.d1, 'MMR 1st Dose (>1Y)');
    checkContra(vac.mmrDose2 || vac.MMR?.d2, 'MMR 2nd Dose (>1Y)');
    checkContra(vac.chickenpoxStatus || vac.chickenpoxDose2 || lab.varicellaIgG, 'Chickenpox / Varicella');
    checkContra(sp.meningococcal, 'Meningococcal A, C');
    checkContra(sp.hepA1, 'Hep A Series 1');
    checkContra(sp.hepA2, 'Hep A Series 2');
    checkContra(sp.typhoid, 'Typhoid Vaccine');
    checkContra(sp.pneumovax || sp.pnemovax, 'Pneumovax 23');

    if (contraVacs.length > 0) {
      results.push({ emp, contraVacs });
    }
  });

  return results;
}
window.getContraindicatedStaffList = getContraindicatedStaffList;

function openContraindicationsReport() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const list = getContraindicatedStaffList();

  const modalHtml = `
    <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.75); z-index: 99999; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px); padding: 20px;">
      <div style="background: white; border-radius: 12px; max-width: 1000px; width: 100%; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35); border: 1px solid #FCD34D; overflow: hidden;">
        
        <!-- MODAL HEADER -->
        <div style="background: linear-gradient(135deg, #78350F 0%, #451A03 100%); color: white; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #F59E0B;">
          <div>
            <div style="font-weight: 800; font-size: 1.15rem; display: flex; align-items: center; gap: 8px;">
              <span>📋 ${isAr ? 'تقرير موانع التطعيم الطبية الموثقة' : 'Documented Medical Contraindications Report'}</span>
            </div>
            <div style="font-size: 0.8rem; color: #FDE68A; margin-top: 2px;">
              ${isAr ? 'قائمة الكوادر الطبية ذات الموانع الصحية الموثقة لحمايتهم وإعفائهم الرسمية' : 'Official list of staff members with documented medical contraindications and exemptions.'}
            </div>
          </div>
          <button type="button" onclick="closeContraindicationsReport()" style="background: rgba(255,255,255,0.15); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-size: 1.1rem; font-weight: bold; display: flex; align-items: center; justify-content: center;">✕</button>
        </div>

        <!-- SEARCH & EXPORT BAR -->
        <div style="padding: 14px 24px; background: #FFFBEB; border-bottom: 1px solid #FDE68A; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-weight: bold; color: #92400E; font-size: 0.9rem;">
            ⚠️ ${list.length} ${isAr ? 'موظفين لديهم موانع طبية موثقة' : 'Staff Members with Documented Contraindications'}
          </div>
          <div style="display: flex; gap: 8px;">
            <button type="button" class="btn btn-outline" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: white; color: #78350F; border: 1px solid #FDE68A; border-radius: 6px; cursor: pointer;" onclick="printContraindicationsReport()">
              🖨️ ${isAr ? 'طباعة التقرير' : 'Print Report'}
            </button>
            <button type="button" class="btn btn-warning" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: #D97706; color: white; border: none; border-radius: 6px; cursor: pointer;" onclick="exportContraindicationsExcel()">
              📥 ${isAr ? 'تصدير التقرير للإكسل' : 'Export Report (.xlsx)'}
            </button>
          </div>
        </div>

        <!-- MODAL TABLE BODY -->
        <div style="padding: 20px 24px; overflow-y: auto; flex: 1;">
          ${list.length === 0 ? `
            <div style="padding: 40px; text-align: center; color: #059669; font-weight: bold; font-size: 1.1rem;">
              ✅ ${isAr ? 'لا يوجد أي موظف لديه موانع تطعيم حالياً' : 'No staff members have documented medical contraindications.'}
            </div>
          ` : `
            <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt;">
              <thead>
                <tr style="background: #FEF3C7; color: #78350F;">
                  <th style="padding: 10px; border: 1px solid #FDE68A; text-align: center; width: 40px;">#</th>
                  <th style="padding: 10px; border: 1px solid #FDE68A; text-align: left;">Emp No</th>
                  <th style="padding: 10px; border: 1px solid #FDE68A; text-align: left;">Staff Full Name</th>
                  <th style="padding: 10px; border: 1px solid #FDE68A; text-align: left;">National ID</th>
                  <th style="padding: 10px; border: 1px solid #FDE68A; text-align: left;">Department</th>
                  <th style="padding: 10px; border: 1px solid #FDE68A; text-align: left;">Contraindicated Vaccines</th>
                  <th style="padding: 10px; border: 1px solid #FDE68A; text-align: center; width: 120px;">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${list.map((item, index) => {
                  const emp = item.emp;
                  const demo = emp.demographic || {};
                  const empNo = emp.empNo || emp.id || 'N/A';
                  const nameStr = emp.name || demo.fullName || demo.arabicFullName || 'N/A';
                  const idStr = emp.idNo || demo.nationalId || 'N/A';
                  const deptStr = emp.department || demo.deptTreating || demo.department || 'N/A';

                  return `
                    <tr style="background: ${index % 2 === 0 ? '#FFFFFF' : '#FFFDF5'};">
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${index + 1}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #1E293B;">${empNo}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #78350F;">${nameStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.85rem;">${idStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.85rem;">${deptStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0;">
                        <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                          ${item.contraVacs.map(v => `
                            <span class="badge" style="background: #FEF3C7; color: #92400E; border: 1px solid #FDE68A; font-size: 0.75rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">
                              ⚠️ ${v}
                            </span>
                          `).join('')}
                        </div>
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center;">
                        <button type="button" class="btn btn-warning" style="padding: 4px 10px; font-size: 0.75rem; background: #D97706; border: none; color: white; border-radius: 4px; font-weight: bold; cursor: pointer;" onclick="openQuickUpdateModal('${empNo}'); closeContraindicationsReport();">
                          ⚡ ${isAr ? 'تعديل' : 'Edit'}
                        </button>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          `}
        </div>

        <!-- MODAL FOOTER -->
        <div style="padding: 14px 24px; background: #FFFBEB; border-top: 1px solid #FDE68A; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-size: 0.82rem; font-weight: bold; color: #92400E;">
            ${isAr ? `إجمالي الحالات الموثقة للموانع: ${list.length} موظف` : `Total Staff Members with Medical Contraindications: ${list.length}`}
          </div>
          <button type="button" class="btn btn-outline" style="padding: 6px 18px; font-weight: bold; border-color: #D97706; color: #92400E;" onclick="closeContraindicationsReport()">Close Report</button>
        </div>

      </div>
    </div>
  `;

  let modalContainer = document.getElementById('contraindicationsReportModalContainer');
  if (!modalContainer) {
    modalContainer = document.createElement('div');
    modalContainer.id = 'contraindicationsReportModalContainer';
    document.body.appendChild(modalContainer);
  }
  modalContainer.innerHTML = modalHtml;
}
window.openContraindicationsReport = openContraindicationsReport;

function closeContraindicationsReport() {
  const modalContainer = document.getElementById('contraindicationsReportModalContainer');
  if (modalContainer) modalContainer.innerHTML = '';
}
window.closeContraindicationsReport = closeContraindicationsReport;

function exportContraindicationsExcel() {
  const list = getContraindicatedStaffList();
  if (list.length === 0) {
    alert("No contraindication data to export.");
    return;
  }

  const exportData = list.map((item, index) => ({
    "Seq #": index + 1,
    "Employee No": item.emp.empNo || item.emp.id || '',
    "Full Name": item.emp.name || item.emp.demographic?.fullName || '',
    "National ID": item.emp.idNo || item.emp.demographic?.nationalId || '',
    "Department": item.emp.department || item.emp.demographic?.deptTreating || '',
    "Contraindicated Vaccines": item.contraVacs.join(', ')
  }));

  if (typeof XLSX !== 'undefined') {
    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Contraindications");
    XLSX.writeFile(wb, `AVH_Staff_Medical_Contraindications_${new Date().toISOString().slice(0,10)}.xlsx`);
  } else {
    alert("SheetJS library loaded required.");
  }
}
window.exportContraindicationsExcel = exportContraindicationsExcel;

function getRefusedStaffList() {
  const list = typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : [];
  const results = [];

  list.forEach(emp => {
    if (typeof isArchivedStaff === 'function' && isArchivedStaff(emp)) return;
    const vac = emp.vaccines || {};
    const sp = emp.specialVaccines || {};
    const lab = emp.labResults || emp.lab || {};

    const refusedVacs = [];

    const checkRefused = (val, name) => {
      const str = String(val || '').toLowerCase().trim();
      if (str.includes('refus')) {
        refusedVacs.push(name);
      }
    };

    checkRefused(vac.ipvDate || vac.IPV?.d1, 'IPV Vaccine (>18Y)');
    checkRefused(vac.tdapDate || vac.Tdap?.d1, 'Tdap Vaccine (>7Y)');
    checkRefused(vac.mmrDose1 || vac.MMR?.d1, 'MMR 1st Dose (>1Y)');
    checkRefused(vac.mmrDose2 || vac.MMR?.d2, 'MMR 2nd Dose (>1Y)');
    checkRefused(vac.chickenpoxStatus || vac.chickenpoxDose2 || lab.varicellaIgG, 'Chickenpox / Varicella');
    checkRefused(sp.meningococcal, 'Meningococcal A, C');
    checkRefused(sp.hepA1, 'Hep A Series 1');
    checkRefused(sp.hepA2, 'Hep A Series 2');
    checkRefused(sp.typhoid, 'Typhoid Vaccine');
    checkRefused(sp.pneumovax || sp.pnemovax, 'Pneumovax 23');

    if (refusedVacs.length > 0) {
      results.push({ emp, refusedVacs });
    }
  });

  return results;
}
window.getRefusedStaffList = getRefusedStaffList;

function openRefusalsReport() {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const list = getRefusedStaffList();

  const modalHtml = `
    <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.75); z-index: 99999; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px); padding: 20px;">
      <div style="background: white; border-radius: 12px; max-width: 1000px; width: 100%; max-height: 90vh; display: flex; flex-direction: column; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35); border: 1px solid #CBD5E1; overflow: hidden;">
        
        <!-- MODAL HEADER -->
        <div style="background: linear-gradient(135deg, #334155 0%, #1E293B 100%); color: white; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #64748B;">
          <div>
            <div style="font-weight: 800; font-size: 1.15rem; display: flex; align-items: center; gap: 8px;">
              <span>📋 ${isAr ? 'تقرير الرفض الموثق للتطعيمات' : 'Documented Vaccination Refusals Report'}</span>
            </div>
            <div style="font-size: 0.8rem; color: #94A3B8; margin-top: 2px;">
              ${isAr ? 'قائمة الكوادر الطبية الموثق رفضهم الرسمي للتطعيمات لأغراض الفحص والتوثيق' : 'Official list of staff members with documented vaccination refusals.'}
            </div>
          </div>
          <button type="button" onclick="closeRefusalsReport()" style="background: rgba(255,255,255,0.15); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-size: 1.1rem; font-weight: bold; display: flex; align-items: center; justify-content: center;">✕</button>
        </div>

        <!-- SEARCH & EXPORT BAR -->
        <div style="padding: 14px 24px; background: #F8FAFC; border-bottom: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-weight: bold; color: #475569; font-size: 0.9rem;">
            🚫 ${list.length} ${isAr ? 'موظفين لديهم رفض موثق للتطعيمات' : 'Staff Members with Documented Refusals'}
          </div>
          <div style="display: flex; gap: 8px;">
            <button type="button" class="btn btn-outline" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: white; color: #1E293B; border: 1px solid #CBD5E1; border-radius: 6px; cursor: pointer;" onclick="printRefusalsReport()">
              🖨️ ${isAr ? 'طباعة التقرير' : 'Print Report'}
            </button>
            <button type="button" class="btn btn-secondary" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: #475569; color: white; border: none; border-radius: 6px; cursor: pointer;" onclick="exportRefusalsExcel()">
              📥 ${isAr ? 'تصدير التقرير للإكسل' : 'Export Report (.xlsx)'}
            </button>
          </div>
        </div>

        <!-- MODAL TABLE BODY -->
        <div style="padding: 20px 24px; overflow-y: auto; flex: 1;">
          ${list.length === 0 ? `
            <div style="padding: 40px; text-align: center; color: #059669; font-weight: bold; font-size: 1.1rem;">
              ✅ ${isAr ? 'لا يوجد أي موظف لديه رفض موثق للتطعيمات حالياً' : 'No staff members have documented vaccination refusals.'}
            </div>
          ` : `
            <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt;">
              <thead>
                <tr style="background: #F1F5F9; color: #334155;">
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: center; width: 40px;">#</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: left;">Emp No</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: left;">Staff Full Name</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: left;">National ID</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: left;">Department</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: left;">Refused Vaccines</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: center; width: 120px;">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${list.map((item, index) => {
                  const emp = item.emp;
                  const demo = emp.demographic || {};
                  const empNo = emp.empNo || emp.id || 'N/A';
                  const nameStr = emp.name || demo.fullName || demo.arabicFullName || 'N/A';
                  const idStr = emp.idNo || demo.nationalId || 'N/A';
                  const deptStr = emp.department || demo.deptTreating || demo.department || 'N/A';

                  return `
                    <tr style="background: ${index % 2 === 0 ? '#FFFFFF' : '#F8FAFC'};">
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold;">${index + 1}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #1E293B;">${empNo}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #334155;">${nameStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.85rem;">${idStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.85rem;">${deptStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0;">
                        <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                          ${item.refusedVacs.map(v => `
                            <span class="badge" style="background: #F1F5F9; color: #475569; border: 1px solid #CBD5E1; font-size: 0.75rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">
                              🚫 ${v}
                            </span>
                          `).join('')}
                        </div>
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center;">
                        <button type="button" class="btn btn-secondary" style="padding: 4px 10px; font-size: 0.75rem; background: #475569; border: none; color: white; border-radius: 4px; font-weight: bold; cursor: pointer;" onclick="openQuickUpdateModal('${empNo}'); closeRefusalsReport();">
                          ⚡ ${isAr ? 'تعديل' : 'Edit'}
                        </button>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          `}
        </div>

        <!-- MODAL FOOTER -->
        <div style="padding: 14px 24px; background: #F8FAFC; border-top: 1px solid #CBD5E1; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-size: 0.82rem; font-weight: bold; color: #475569;">
            ${isAr ? `إجمالي حالات الرفض الموثقة: ${list.length} موظف` : `Total Staff Members with Documented Refusals: ${list.length}`}
          </div>
          <button type="button" class="btn btn-outline" style="padding: 6px 18px; font-weight: bold; border-color: #64748B; color: #334155;" onclick="closeRefusalsReport()">Close Report</button>
        </div>

      </div>
    </div>
  `;

  let modalContainer = document.getElementById('refusalsReportModalContainer');
  if (!modalContainer) {
    modalContainer = document.createElement('div');
    modalContainer.id = 'refusalsReportModalContainer';
    document.body.appendChild(modalContainer);
  }
  modalContainer.innerHTML = modalHtml;
}
window.openRefusalsReport = openRefusalsReport;

function closeRefusalsReport() {
  const modalContainer = document.getElementById('refusalsReportModalContainer');
  if (modalContainer) modalContainer.innerHTML = '';
}
window.closeRefusalsReport = closeRefusalsReport;

function exportRefusalsExcel() {
  const list = getRefusedStaffList();
  if (list.length === 0) {
    alert("No refusal data to export.");
    return;
  }

  const exportData = list.map((item, index) => ({
    "Seq #": index + 1,
    "Employee No": item.emp.empNo || item.emp.id || '',
    "Full Name": item.emp.name || item.emp.demographic?.fullName || '',
    "National ID": item.emp.idNo || item.emp.demographic?.nationalId || '',
    "Department": item.emp.department || item.emp.demographic?.deptTreating || '',
    "Refused Vaccines": item.refusedVacs.join(', ')
  }));

  if (typeof XLSX !== 'undefined') {
    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Refusals");
    XLSX.writeFile(wb, `AVH_Staff_Vaccination_Refusals_${new Date().toISOString().slice(0,10)}.xlsx`);
  } else {
    alert("SheetJS library loaded required.");
  }
}
window.exportRefusalsExcel = exportRefusalsExcel;

function closeUnvaccinatedFollowupReport() {
  const container = document.getElementById('unvaccinatedFollowupModalContainer');
  if (container) container.innerHTML = '';
}
window.closeUnvaccinatedFollowupReport = closeUnvaccinatedFollowupReport;

function exportUnvaccinatedFollowupExcel(vacFilter = 'ALL', catFilter = 'ALL') {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const list = getUnvaccinatedStaffList(vacFilter, catFilter);

  if (list.length === 0) {
    alert(isAr ? '⚠️ لا توجد كوادر مفقودة التطعيمات في هذه الفئة لتصديرها.' : '⚠️ No unvaccinated staff in this category to export.');
    return;
  }

  const rows = list.map((item, idx) => {
    const emp = item.emp;
    const demo = emp.demographic || {};
    return [
      idx + 1,
      emp.empNo || emp.id || demo.personNumber || '',
      emp.idNo || demo.nationalId || '',
      emp.name || demo.fullName || '',
      demo.arabicFullName || '',
      emp.department || demo.deptTreating || '',
      emp.jobTitle || demo.positionName || '',
      getEmployeeSector(emp),
      emp.staffGroup || demo.staffGroup || '',
      item.mohStatus || 'Pending',
      item.missing.map(m => m.name).join(' | '),
      item.totalMissingCount
    ];
  });

  const headers = [
    '#', 'Emp No', 'National ID', 'Staff Full Name (EN)', 'Staff Full Name (AR)', 'Department', 'Position', 'Sector', 'Staff Group', 'Official Immunity Status (MOH)', 'Required Missing Vaccine(s) & Doses', 'Total Missing Count'
  ];

  const fileName = `AVH_Incomplete_Immunity_FollowUp_${catFilter.toUpperCase()}_${vacFilter}_2026.xlsx`;

  if (typeof XLSX !== 'undefined') {
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Incomplete Immunity Follow-Up");
    XLSX.writeFile(wb, fileName);
  } else {
    const csvLines = [headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(",")];
    rows.forEach(r => {
      csvLines.push(r.map(cell => `"${String(cell !== null && cell !== undefined ? cell : '').replace(/"/g, '""')}"`).join(","));
    });
    const csvContent = "\uFEFF" + csvLines.join("\r\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", fileName.replace('.xlsx', '.csv'));
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}
window.exportUnvaccinatedFollowupExcel = exportUnvaccinatedFollowupExcel;

/* ==========================================================================
   STATUTORY MOH IMMUNITY & CATEGORY BREAKDOWN REPORT ENGINE
   ========================================================================== */

function getEmpMissingMOHRequirements(emp) {
  if (!emp) return [];

  const demo = emp.demographic || {};
  const vac = emp.vaccines || {};
  const lab = emp.labResults || emp.lab || {};
  const sp = emp.specialVaccines || {};
  const cf = emp.covidFlu || {};

  const hasTdap = !!(vac.tdapDate || (vac.Tdap && (vac.Tdap.d5 || vac.Tdap.d1)));
  const isMMRImmune = typeof isMMRProtected === 'function' ? isMMRProtected(emp) : !!(vac.mmrDose1 || (vac.MMR && vac.MMR.d1));
  const cpStatus = String(vac.chickenpoxStatus || vac.chickenpox || '').toLowerCase();
  const varIgG = String(vac.varicellaIgG || lab.varicellaIgG || (lab.Varicella_IgG ? lab.Varicella_IgG.result : '') || '').toLowerCase();
  const isVaricellaImmune = !!(vac.chickenpoxDose2 || vac.chickenpoxDose1 || cpStatus.includes('vaccin') || cpStatus.includes('immune') || cpStatus.includes('natural') || cpStatus.includes('pos') || varIgG.includes('pos') || varIgG.includes('immune') || varIgG.includes('natural'));
  const hasPolio = !!(vac.ipvDate || (vac.IPV && (vac.IPV.d5 || vac.IPV.d1)));
  
  // Hepatitis B MOH Logic: HBsAb result > 10 = Fully Immune (no need for HBV Series, Anti-HBc, HBsAg). Non-responder = No missing HBV items.
  const rawHbsab = String(emp.hepbTiter || lab.hbsabResult || (lab.HBsAb ? lab.HBsAb.result : '') || '').toLowerCase().trim();
  const immStatus = String(emp.immunityStatus || '').toLowerCase().trim();

  const isNonResponder = rawHbsab.includes('non-responder') || rawHbsab.includes('non responder') || 
                         rawHbsab.includes('resistance') || rawHbsab.includes('nonresponder') ||
                         immStatus.includes('non-responder') || immStatus.includes('resistance');

  const numMatch = rawHbsab.match(/([<>])?\s*([0-9]+(?:\.[0-9]+)?)/);
  const hasLessThan = rawHbsab.includes('<');
  const hasGreaterThan = rawHbsab.includes('>') || rawHbsab.includes('positive') || rawHbsab.includes('pos') || rawHbsab.includes('immune') || rawHbsab.includes('react');
  let parsedVal = numMatch ? parseFloat(numMatch[2]) : null;

  const isImmuneGreater10 = !hasLessThan && (hasGreaterThan || (parsedVal !== null && parsedVal >= 10) || (parsedVal === null && immStatus.includes('immune') && !immStatus.includes('non-responder')));

  const hasHBVVac = !!(lab.engrixDose3 || lab.engrixDose2 || lab.engrixDose1 || (vac['Hepatitis B'] && vac['Hepatitis B'].d1));
  const hasAntiHBs = isImmuneGreater10 || isNonResponder;
  const hasAntiHBc = isImmuneGreater10 || isNonResponder || !!(lab.antiHbcResult || lab.antiHBc);
  const hasHBsAg = isImmuneGreater10 || isNonResponder || !!(lab.hbsagResult || lab.HBsAg);
  const noNeedHBV = isImmuneGreater10 || isNonResponder;

  const rawHcv = String(lab.hcvResult || lab.HCV || '').toLowerCase();
  const hasAntiHCV = !!(rawHcv && !rawHcv.includes('blank') && !rawHcv.includes('pending'));
  const rawPpd = String(lab.ppdStep1Result || lab.ppdResult || lab.PPD || '').toLowerCase();
  const hasPPD = !!(rawPpd && !rawPpd.includes('blank') && !rawPpd.includes('pending'));
  const hasFlu = !!(cf.flu2425 || cf.flu2324 || cf.fluDate || (vac['Flu vaccine'] && vac['Flu vaccine'].d5));
  const hasTyphoid = !!(sp.typhoid || sp.typhoidDate);
  const hasMeningo = !!(sp.meningococcal || sp.meningococcalDate);
  const hasPneumo = !!(sp.pneumovax || sp.pnemovax || sp.pneumovaxDate);
  const hasHepA = !!(sp.hepA2 || sp.hepA1 || sp.hepADate);

  const isLabStaff = typeof isSpecialVaccineStaff === 'function' ? isSpecialVaccineStaff(emp) : false;

  const isMin = typeof isMinimumStaff === 'function' ? isMinimumStaff(emp) : false;
  const isExt = typeof isExtendedStaff === 'function' ? isExtendedStaff(emp) : false;
  const isBasic = typeof isBasicStaff === 'function' ? isBasicStaff(emp) : false;

  let missing = [];

  if (isLabStaff) {
    if (!hasTdap) missing.push('Tdap Vaccine');
    if (!isMMRImmune) missing.push('MMR Vaccine');
    if (!isVaricellaImmune) missing.push('Chickenpox');
    if (!hasPolio) missing.push('Polio Vaccine');
    if (!noNeedHBV && !hasHBVVac) missing.push('HBV Series');
    if (!noNeedHBV && !hasAntiHBs) missing.push('Anti-HBs Titer');
    if (!hasAntiHCV) missing.push('Anti-HCV Screening');
    if (!noNeedHBV && !hasAntiHBc) missing.push('Anti-HBc Screening');
    if (!noNeedHBV && !hasHBsAg) missing.push('HBsAg Screening');
    if (!hasPPD) missing.push('PPD Test');
    if (!hasTyphoid) missing.push('Typhoid Vaccine');
    if (!hasMeningo) missing.push('Meningococcal');
    if (!hasPneumo) missing.push('Pneumovax 23');
    if (!hasHepA) missing.push('Hep A (2 Doses)');
  } else if (isExt) {
    if (!hasTdap) missing.push('Tdap Vaccine');
    if (!isMMRImmune) missing.push('MMR Vaccine');
    if (!isVaricellaImmune) missing.push('Chickenpox');
    if (!hasPolio) missing.push('Polio Vaccine');
    if (!noNeedHBV && !hasHBVVac) missing.push('HBV Series');
    if (!noNeedHBV && !hasAntiHBs) missing.push('Anti-HBs Titer');
    if (!hasPPD) missing.push('PPD Test');
  } else if (isBasic) {
    if (!hasTdap) missing.push('Tdap Vaccine');
    if (!isMMRImmune) missing.push('MMR Vaccine');
    if (!isVaricellaImmune) missing.push('Chickenpox');
    if (!hasPolio) missing.push('Polio Vaccine');
    if (!noNeedHBV && !hasHBVVac) missing.push('HBV Series');
    if (!noNeedHBV && !hasAntiHBs) missing.push('Anti-HBs Titer');
    if (!hasPPD) missing.push('PPD Test');
  } else {
    if (!hasTdap) missing.push('Tdap Vaccine');
    if (!isMMRImmune) missing.push('MMR Vaccine');
    if (!isVaricellaImmune) missing.push('Chickenpox');
  }

  return missing;
}
window.getEmpMissingMOHRequirements = getEmpMissingMOHRequirements;

function getMOHImmunityBreakdownList(statusFilter = 'ALL', catFilter = 'ALL') {
  const list = (typeof getUniqueEmployees === 'function' ? getUniqueEmployees() : (JSON.parse(localStorage.getItem('avh_employees')) || []));
  const results = [];

  list.forEach(emp => {
    // Unconditionally exclude archived/non-active staff members from MOH Statutory Immunity Report
    if (typeof isArchivedStaff === 'function' && isArchivedStaff(emp)) return;
    // Unconditionally exclude Gaza Project staff from MOH Statutory Immunity Report
    if (typeof isGazaStaff === 'function' && isGazaStaff(emp)) return;
    if (typeof isAVHStaff === 'function' && !isAVHStaff(emp)) return;
    const deptStrCheck = String(emp.department || (emp.demographic && emp.demographic.department) || '').toLowerCase();
    if (deptStrCheck.includes('gaza')) return;

    if (catFilter === 'extended' && !isExtendedStaff(emp)) return;
    if (catFilter === 'minimum' && !isMinimumStaff(emp)) return;
    if (catFilter === 'basic' && !isBasicStaff(emp)) return;
    if ((catFilter === 'lab' || catFilter === 'special') && !isSpecialVaccineStaff(emp)) return;
    if (catFilter === 'oncology' && !isOncologyStaff(emp)) return;
    if (catFilter === 'babies' && !isBabiesPediatricStaff(emp)) return;
    if (catFilter === 'invasive' && !isInvasiveProcedureStaff(emp)) return;

    const mohStatus = typeof calculateMOHImmunityStatus === 'function' ? calculateMOHImmunityStatus(emp) : 'Fully Immune';

    if (statusFilter === 'FULL' && !mohStatus.startsWith('Fully')) return;
    if (statusFilter === 'PARTIAL' && !mohStatus.startsWith('Partially')) return;
    if (statusFilter === 'PENDING' && !mohStatus.startsWith('Pending')) return;

    const missingItems = getEmpMissingMOHRequirements(emp);

    results.push({
      emp: emp,
      mohStatus: mohStatus,
      missingItems: missingItems
    });
  });

  return results;
}
window.getMOHImmunityBreakdownList = getMOHImmunityBreakdownList;

function openMOHImmunityBreakdownReport(statusFilter = 'ALL', catFilter = 'ALL') {
  window._currentMOHModalStatus = statusFilter;
  window._currentMOHModalCategory = catFilter;
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const list = getMOHImmunityBreakdownList(statusFilter, catFilter);

  const fullList = getMOHImmunityBreakdownList('ALL', catFilter);
  const fullyImmuneCount = fullList.filter(i => i.mohStatus.startsWith('Fully')).length;
  const partiallyCount = fullList.filter(i => i.mohStatus.startsWith('Partially')).length;
  const pendingCount = fullList.filter(i => i.mohStatus.startsWith('Pending')).length;
  const totalCount = fullList.length || 1;

  const fullPct = Math.round((fullyImmuneCount / totalCount) * 100);
  const partialPct = Math.round((partiallyCount / totalCount) * 100);
  const pendingPct = Math.round((pendingCount / totalCount) * 100);

  const catCounts = {
    ALL: getMOHImmunityBreakdownList(statusFilter, 'ALL').length,
    extended: getMOHImmunityBreakdownList(statusFilter, 'extended').length,
    minimum: getMOHImmunityBreakdownList(statusFilter, 'minimum').length,
    basic: getMOHImmunityBreakdownList(statusFilter, 'basic').length,
    special: getMOHImmunityBreakdownList(statusFilter, 'special').length,
    lab: getMOHImmunityBreakdownList(statusFilter, 'lab').length,
    oncology: getMOHImmunityBreakdownList(statusFilter, 'oncology').length,
    babies: getMOHImmunityBreakdownList(statusFilter, 'babies').length,
    invasive: getMOHImmunityBreakdownList(statusFilter, 'invasive').length
  };

  const modalHtml = `
    <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15, 23, 42, 0.75); z-index: 99999; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px); padding: 20px;">
      <div style="background: white; border-radius: 12px; max-width: 1200px; width: 100%; max-height: 92vh; display: flex; flex-direction: column; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35); border: 1px solid #0F766E; overflow: hidden;">
        
        <!-- MODAL HEADER -->
        <div style="background: linear-gradient(135deg, #0F766E 0%, #115E59 100%); color: white; padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #0D9488;">
          <div>
            <div style="font-weight: 800; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
              <span>🛡️ ${isAr ? 'تقرير مناعة الكوادر حسب التصنيف والتغطية الرسمية (MOH)' : 'MOH Statutory Immunity & Category Breakdown Report'}</span>
            </div>
            <div style="font-size: 0.82rem; color: #CCFBF1; margin-top: 2px;">
              ${isAr ? 'تقرير شامل مقسم حسب حالة المناعة وفئات الكادر وفقاً لمعايير وزارة الصحة (مستثنى منها مشروع غزة).' : 'Comprehensive statutory compliance report grouped by Immunity Status and Staff Categories (Excluding Gaza Project).'}
            </div>
          </div>
          <button type="button" onclick="closeMOHImmunityBreakdownReport()" style="background: rgba(255,255,255,0.15); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-size: 1.1rem; font-weight: bold; display: flex; align-items: center; justify-content: center;">✕</button>
        </div>

        <!-- KPI STATS CARDS BAR -->
        <div style="padding: 14px 24px; background: #F0FDF4; border-bottom: 1px solid #A7F3D0; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px;">
          <div style="background: white; border-radius: 8px; border: 1px solid #10B981; padding: 10px 14px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.03);">
            <div style="font-size: 0.76rem; font-weight: 800; color: #15803D; text-transform: uppercase;">🟢 Fully Immune</div>
            <div style="font-size: 1.35rem; font-weight: 900; color: #166534; margin-top: 2px;">${fullyImmuneCount} <span style="font-size: 0.85rem; font-weight: 700; color: #15803D;">(${fullPct}%)</span></div>
          </div>
          <div style="background: white; border-radius: 8px; border: 1px solid #F59E0B; padding: 10px 14px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.03);">
            <div style="font-size: 0.76rem; font-weight: 800; color: #B45309; text-transform: uppercase;">🟡 Partially Compliant (Flu, etc.)</div>
            <div style="font-size: 1.35rem; font-weight: 900; color: #92400E; margin-top: 2px;">${partiallyCount} <span style="font-size: 0.85rem; font-weight: 700; color: #B45309;">(${partialPct}%)</span></div>
          </div>
          <div style="background: white; border-radius: 8px; border: 1px solid #64748B; padding: 10px 14px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.03);">
            <div style="font-size: 0.76rem; font-weight: 800; color: #475569; text-transform: uppercase;">⚪ Pending Required Doses/Tests</div>
            <div style="font-size: 1.35rem; font-weight: 900; color: #334155; margin-top: 2px;">${pendingCount} <span style="font-size: 0.85rem; font-weight: 700; color: #475569;">(${pendingPct}%)</span></div>
          </div>
        </div>

        <!-- CATEGORY & STATUS FILTER TABS -->
        <div style="padding: 14px 24px; background: #F8FAFC; border-bottom: 1px solid #E2E8F0; display: flex; flex-direction: column; gap: 10px;">
          
          <!-- CATEGORY FILTERS -->
          <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
            <span style="font-size: 0.8rem; font-weight: 800; color: #475569; text-transform: uppercase;">📌 ${isAr ? 'فئة الكادر:' : 'Staff Category:'}</span>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'ALL' ? '#0F766E' : 'white'}; color: ${catFilter === 'ALL' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'ALL')">
              🌐 All Categories (${catCounts.ALL})
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'extended' ? '#0F766E' : 'white'}; color: ${catFilter === 'extended' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'extended')">
              🌟 Extended (${catCounts.extended})
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'minimum' ? '#B45309' : 'white'}; color: ${catFilter === 'minimum' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'minimum')">
              📋 Minimum (${catCounts.minimum})
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'basic' ? '#1D4ED8' : 'white'}; color: ${catFilter === 'basic' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'basic')">
              📄 Basic (${catCounts.basic})
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'special' ? '#047857' : 'white'}; color: ${catFilter === 'special' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'special')">
              🛡️ Special Staff (${catCounts.special})
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'lab' ? '#047857' : 'white'}; color: ${catFilter === 'lab' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'lab')">
              🔬 Lab Techs (${catCounts.lab})
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'oncology' ? '#6D28D9' : 'white'}; color: ${catFilter === 'oncology' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'oncology')">
              🎗️ Oncology (${catCounts.oncology})
            </button>
            <button type="button" class="btn" style="padding: 5px 12px; font-weight: bold; font-size: 0.8rem; border-radius: 6px; cursor: pointer; background: ${catFilter === 'babies' ? '#4338CA' : 'white'}; color: ${catFilter === 'babies' ? 'white' : '#1E293B'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('${statusFilter}', 'babies')">
              👶 Babies (<1Y) (${catCounts.babies})
            </button>
          </div>

          <!-- STATUS FILTERS & EXPORT BUTTON -->
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; border-top: 1px dashed #CBD5E1; padding-top: 8px;">
            <div style="display: flex; gap: 6px; flex-wrap: wrap; align-items: center;">
              <span style="font-size: 0.8rem; font-weight: 800; color: #475569; text-transform: uppercase;">🛡️ ${isAr ? 'حالة المناعة:' : 'Immunity Status:'}</span>
              <button type="button" class="btn" style="padding: 4px 10px; font-size: 0.78rem; font-weight: bold; border-radius: 4px; cursor: pointer; background: ${statusFilter === 'ALL' ? '#0F172A' : 'white'}; color: ${statusFilter === 'ALL' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('ALL', '${catFilter}')">
                All Statuses (${fullList.length})
              </button>
              <button type="button" class="btn" style="padding: 4px 10px; font-size: 0.78rem; font-weight: bold; border-radius: 4px; cursor: pointer; background: ${statusFilter === 'FULL' ? '#166534' : 'white'}; color: ${statusFilter === 'FULL' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('FULL', '${catFilter}')">
                🟢 Fully Immune (${fullyImmuneCount})
              </button>
              <button type="button" class="btn" style="padding: 4px 10px; font-size: 0.78rem; font-weight: bold; border-radius: 4px; cursor: pointer; background: ${statusFilter === 'PARTIAL' ? '#D97706' : 'white'}; color: ${statusFilter === 'PARTIAL' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('PARTIAL', '${catFilter}')">
                🟡 Partially Compliant (${partiallyCount})
              </button>
              <button type="button" class="btn" style="padding: 4px 10px; font-size: 0.78rem; font-weight: bold; border-radius: 4px; cursor: pointer; background: ${statusFilter === 'PENDING' ? '#475569' : 'white'}; color: ${statusFilter === 'PENDING' ? 'white' : '#334155'}; border: 1px solid #CBD5E1;" onclick="openMOHImmunityBreakdownReport('PENDING', '${catFilter}')">
                ⚪ Pending (${pendingCount})
              </button>
            </div>

            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
              <button type="button" class="btn btn-outline" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: white; color: #1E293B; border: 1px solid #CBD5E1; border-radius: 6px; cursor: pointer;" onclick="printMOHImmunityReport()">
                🖨️ ${isAr ? 'طباعة التقرير' : 'Print Report'}
              </button>
              <button type="button" class="btn btn-success" style="padding: 6px 16px; font-weight: bold; font-size: 0.82rem; background: #10B981; color: white; border: none; border-radius: 6px; cursor: pointer;" onclick="exportMOHImmunityBreakdownExcel('${statusFilter}', '${catFilter}')">
                📥 ${isAr ? 'تصدير تقرير المناعة للإكسل' : 'Export Immunity Breakdown (.xlsx)'}
              </button>
            </div>
          </div>

        </div>

        <!-- MODAL TABLE BODY -->
        <div style="flex: 1; overflow-y: auto; padding: 20px;">
          ${list.length === 0 ? `
            <div style="text-align: center; padding: 40px; color: #475569; font-weight: bold; font-size: 1.05rem; background: #F8FAFC; border-radius: 8px; border: 1px solid #CBD5E1;">
              ℹ️ ${isAr ? 'لا توجد كوادر تطابق الفلاتر المحددة حالياً' : 'No staff members match the selected status and category filters.'}
            </div>
          ` : `
            <table class="clinical-table" style="width: 100%; border-collapse: collapse; font-size: 9pt;">
              <thead>
                <tr style="background: #F1F5F9; color: #1E293B; text-align: left;">
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: center;">#</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'الرقم الوظيفي / الهوية' : 'Emp No / ID'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'اسم الموظف' : 'Staff Name'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'القسم / الوحدة' : 'Department / Treating Unit'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'فئة الكادر (MOH Plan)' : 'MOH Category / Plan'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'حالة المناعة الرسمية' : 'MOH Immunity Status'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1;">${isAr ? 'الفحوصات/التطعيمات المتبقية' : 'Pending Requirements'}</th>
                  <th style="padding: 10px; border: 1px solid #CBD5E1; text-align: center;">${isAr ? 'الإجراء المباشر' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody>
                ${list.map((item, idx) => {
                  const emp = item.emp;
                  const demo = emp.demographic || {};
                  const empNo = emp.empNo || emp.id || demo.personNumber || 'N/A';
                  const natId = emp.idNo || demo.nationalId || '';
                  const nameStr = emp.name || demo.fullName || demo.arabicFullName || 'Staff Member';
                  const deptStr = emp.department || demo.deptTreating || demo.department || 'General Medical';
                  const groupStr = emp.staffGroup || demo.staffGroup || 'Minimum Plan';

                  const statusStr = item.mohStatus || 'Pending';
                  const isFull = statusStr.startsWith('Fully');
                  const isPartial = statusStr.startsWith('Partially');
                  const bg = isFull ? '#DCFCE7' : (isPartial ? '#FEF3C7' : '#E2E8F0');
                  const fg = isFull ? '#15803D' : (isPartial ? '#B45309' : '#334155');
                  const border = isFull ? '#86EFAC' : (isPartial ? '#FDE68A' : '#CBD5E1');

                  return `
                    <tr style="background: ${idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC'};">
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center; font-weight: bold; color: #64748B;">${idx + 1}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold; color: #0284C7;">
                        <div>${empNo}</div>
                        <div style="font-size: 0.75rem; color: #64748B;">ID: ${natId}</div>
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-weight: bold;">
                        <div style="color: #1E293B;">${nameStr}</div>
                        ${demo.arabicFullName ? `<div style="font-size: 0.78rem; color: #475569;">${demo.arabicFullName}</div>` : ''}
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.85rem;">${deptStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; font-size: 0.82rem; font-weight: bold; color: #166534;">${groupStr}</td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0;">
                        <span style="background:${bg}; color:${fg}; border:1px solid ${border}; font-weight:800; border-radius:12px; padding:3px 10px; font-size:0.78rem; display:inline-block;">
                          ${statusStr}
                        </span>
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0;">
                        ${item.missingItems.length === 0 ? `
                          <span style="color: #166534; font-weight: bold; font-size: 0.8rem;">✅ All Requirements Complete</span>
                        ` : `
                          <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                            ${item.missingItems.map(m => `
                              <span class="badge" style="background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; font-size: 0.74rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">
                                ⚠️ ${m}
                              </span>
                            `).join('')}
                          </div>
                        `}
                      </td>
                      <td style="padding: 8px; border: 1px solid #E2E8F0; text-align: center;">
                        <div style="display: flex; gap: 4px; justify-content: center;">
                          <button type="button" class="btn btn-primary" style="padding: 4px 8px; font-size: 0.75rem; background: #0284C7; border: none; color: white; border-radius: 4px; font-weight: bold;" onclick="openQuickUpdateModal('${empNo}'); closeMOHImmunityBreakdownReport();">
                            ⚡ ${isAr ? 'تحديث سريع' : 'Quick Update'}
                          </button>
                          <button type="button" class="btn btn-outline" style="padding: 4px 8px; font-size: 0.75rem; border: 1px solid #64748B; color: #334155; border-radius: 4px; font-weight: bold;" onclick="editEmployeeFromReportTable('${empNo}'); closeMOHImmunityBreakdownReport();">
                            📝 ${isAr ? 'النموذج' : 'Open Form'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          `}
        </div>

        <!-- MODAL FOOTER -->
        <div style="padding: 14px 24px; background: #F1F5F9; border-top: 1px solid #CBD5E1; display: flex; justify-content: space-between; align-items: center;">
          <div style="font-size: 0.82rem; font-weight: bold; color: #475569;">
            ${isAr ? `إجمالي الكوادر المستعرضة: ${list.length} موظف` : `Total Staff Displayed in Breakdown: ${list.length} Staff Members`}
          </div>
          <button type="button" class="btn btn-outline" style="padding: 6px 18px; font-weight: bold;" onclick="closeMOHImmunityBreakdownReport()">Close Report</button>
        </div>

      </div>
    </div>
  `;

  let modalContainer = document.getElementById('mohImmunityBreakdownModalContainer');
  if (!modalContainer) {
    modalContainer = document.createElement('div');
    modalContainer.id = 'mohImmunityBreakdownModalContainer';
    document.body.appendChild(modalContainer);
  }
  modalContainer.innerHTML = modalHtml;
}
window.openMOHImmunityBreakdownReport = openMOHImmunityBreakdownReport;

function closeMOHImmunityBreakdownReport() {
  const container = document.getElementById('mohImmunityBreakdownModalContainer');
  if (container) container.innerHTML = '';
}
window.closeMOHImmunityBreakdownReport = closeMOHImmunityBreakdownReport;

function exportMOHImmunityBreakdownExcel(statusFilter = 'ALL', catFilter = 'ALL') {
  const isAr = window.i18n ? window.i18n.isRTL() : false;
  const list = getMOHImmunityBreakdownList(statusFilter, catFilter);

  if (list.length === 0) {
    alert(isAr ? '⚠️ لا توجد بيانات في الفلاتر المحددة لتصديرها.' : '⚠️ No staff data matching selected filters to export.');
    return;
  }

  const rows = list.map((item, idx) => {
    const emp = item.emp;
    const demo = emp.demographic || {};
    return [
      idx + 1,
      emp.empNo || emp.id || demo.personNumber || '',
      emp.idNo || demo.nationalId || '',
      emp.name || demo.fullName || '',
      demo.arabicFullName || '',
      emp.department || demo.deptTreating || '',
      emp.jobTitle || demo.positionName || '',
      getEmployeeSector(emp),
      emp.staffGroup || demo.staffGroup || '',
      item.mohStatus || 'Pending',
      item.missingItems.length > 0 ? item.missingItems.join(' | ') : 'Complete (Fully Immune)',
      item.missingItems.length
    ];
  });

  const headers = [
    '#', 'Emp No', 'National ID', 'Staff Full Name (EN)', 'Staff Full Name (AR)', 'Department', 'Position', 'Sector', 'Staff Group (MOH Plan)', 'MOH Immunity Status', 'Pending Requirements', 'Missing Count'
  ];

  const fileName = `AVH_MOH_Immunity_Breakdown_${catFilter.toUpperCase()}_${statusFilter}_2026.xlsx`;

  if (typeof XLSX !== 'undefined') {
    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "MOH Immunity Breakdown");
    XLSX.writeFile(wb, fileName);
  } else {
    const csvLines = [headers.map(h => `"${String(h).replace(/"/g, '""')}"`).join(",")];
    rows.forEach(r => {
      csvLines.push(r.map(cell => `"${String(cell !== null && cell !== undefined ? cell : '').replace(/"/g, '""')}"`).join(","));
    });
    const csvContent = "\uFEFF" + csvLines.join("\r\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", fileName.replace('.xlsx', '.csv'));
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}
window.exportMOHImmunityBreakdownExcel = exportMOHImmunityBreakdownExcel;

if (typeof window !== 'undefined') {
  const refreshReportsOnUpdate = function() {
    if (typeof invalidateEmployeesCache === 'function') {
      invalidateEmployeesCache(false);
    }
    if (typeof getUniqueEmployees === 'function') {
      rptAllEmployeesList = getUniqueEmployees();
      window.rptAllEmployeesList = rptAllEmployeesList;
    }
    const isReportsActive = (typeof activeNavTab !== 'undefined' && (activeNavTab === 'vaccination-reports' || activeNavTab === 'reports')) ||
      (document.getElementById('masterReportTable') !== null);
    const mainArea = document.getElementById('mainAppArea');

    if (isReportsActive && mainArea && typeof renderVaccinationReports === 'function') {
      renderVaccinationReports(mainArea);
    } else {
      if (typeof filterReportsTable === 'function') {
        filterReportsTable();
      }
      if (typeof renderReportsTableBody === 'function') {
        renderReportsTableBody();
      }
    }
  };
  window.refreshReportsOnUpdate = refreshReportsOnUpdate;
  window.addEventListener('avh_data_updated', refreshReportsOnUpdate);
  window.addEventListener('staffDataUpdated', refreshReportsOnUpdate);
}

function printUnvaccinatedFollowupReport() {
  const container = document.getElementById('unvaccinatedFollowupModalContainer') || document.getElementById('mainAppArea');
  if (window.AVHPrintController) {
    window.AVHPrintController.printContainer(container, { mode: 'landscape', printClass: 'printing-unvac-report' });
  } else {
    window.print();
  }
}
window.printUnvaccinatedFollowupReport = printUnvaccinatedFollowupReport;

function printContraindicationsReport() {
  const container = document.getElementById('contraindicationsReportModalContainer') || document.getElementById('mainAppArea');
  if (window.AVHPrintController) {
    window.AVHPrintController.printContainer(container, { mode: 'landscape', printClass: 'printing-contra-report' });
  } else {
    window.print();
  }
}
window.printContraindicationsReport = printContraindicationsReport;

function printRefusalsReport() {
  const container = document.getElementById('refusalsReportModalContainer') || document.getElementById('mainAppArea');
  if (window.AVHPrintController) {
    window.AVHPrintController.printContainer(container, { mode: 'landscape', printClass: 'printing-refusals-report' });
  } else {
    window.print();
  }
}
window.printRefusalsReport = printRefusalsReport;

function printMOHImmunityReport() {
  const container = document.getElementById('mohImmunityBreakdownModalContainer') || document.getElementById('mainAppArea');
  if (window.AVHPrintController) {
    window.AVHPrintController.printContainer(container, { mode: 'landscape', printClass: 'printing-moh-report' });
  } else {
    window.print();
  }
}
window.printMOHImmunityReport = printMOHImmunityReport;
