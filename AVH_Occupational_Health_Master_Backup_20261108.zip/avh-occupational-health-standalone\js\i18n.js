/* ==========================================================================
   AUGUSTA VICTORIA HOSPITAL - INTERNATIONALIZATION (i18n) MANAGER
   Bilingual Support: English (en) & Arabic (ar)
   ========================================================================== */

(function() {
  const translations = {
    en: {
      // General Hospital Branding
      hospital_name: "Augusta Victoria Hospital",
      hospital_name_ar: "مستشفى الأوغستا فكتوريا (المُطلع)",
      unit_name: "STAFF OCCUPATIONAL HEALTH & VACCINATION SYSTEM",
      lwf_accreditation: "The Lutheran World Federation | ISO 9001:2015 Certified System",
      years_service: "75 Years of Healthcare Service",

      // Authentication & Roles
      login_title: "LOGIN",
      username: "UserName",
      password: "Password",
      forgot_password: "Forgot Password",
      quick_demo_login: "Quick Demo Login:",
      login_btn: "LogIn",
      logout_btn: "Log Out",
      role_admin: "Admin",
      role_specialist: "Specialist",
      role_employee: "Staff",
      role_auditor: "Auditor",
      login_error_empty: "Please enter username and password",
      login_error_invalid: "Invalid credentials",

      // Top Bar & Navigation Tabs
      portal_title: "STAFF OCCUPATIONAL HEALTH & VACCINATION",
      menu_toggle: "Menu",
      
      // 4 Main Portal Categories
      cat_occupational_health: "Staff Occupational Health & Vaccination",
      cat_ipc: "Infection Prevention & Control (IPC)",
      cat_ams: "Antimicrobial Stewardship (AMS)",
      cat_system_management: "System Management & Authorization Control",

      tab_portal_home: "Portal Main Home Screen",
      tab_staff_entry: "Staff Registration & Centralized Entry Portal",
      tab_dashboard: "Statistical & Reporting Dashboard",
      tab_vaccination_forms: "Staff Vaccination & Test History Forms",
      tab_injury_report: "Injury Incident Report (SQE 02.01)",
      tab_vaccination_certificate: "Official Vaccination & Immunity Certificate",
      tab_vaccination_reports: "Master Vaccination Reports & Excel Sync",
      tab_system_management: "System Management & Authorization Control",
      sub_sys_users: "1. User Authorizations & Roles Matrix",
      sub_sys_dropdowns: "2. Master Dropdown Lists Management Authority",
      sub_sys_database: "3. Central Database, Trash & Audit Trail",

      // IPC & AMS Sub-Tabs
      tab_ipc_isolation: "1. Isolation Status Follow-Up",
      tab_ipc_hai_followup: "2. Healthcare-Associated Infection (HAI) Follow-Up Form",
      tab_ipc_outbreak: "3. Outbreak Investigations",
      tab_ipc_moh_notification: "4. MOH Communicable Disease Notification Form",
      sub_ipc_cre: "4.1 CRE Report",
      sub_ipc_cd: "4.2 Communicable Disease Report",
      tab_ipc_surveillance: "5. IPC Surveillance",
      tab_ipc_qip: "6. Quality Improvement Plan (QIP)",
      tab_ipc_training: "7. IPC Training & Staff Education",
      tab_ipc_audit: "8. Environmental Hygiene & Audit Checklists",
      sub_ipc_audit_clinical: "8.1 Clinical Departments",
      sub_ipc_audit_public: "8.2 Public Services Dept (Maintenance, Kitchen, Housekeeping)",
      sub_ipc_audit_morgue: "8.3 Morgue",
      sub_ipc_audit_hotels: "8.4 Patient Hotels & Accommodations",
      tab_ipc_hospital_forms: "9. Hospital IPC Forms",
      tab_ipc_strategy_risk: "10. Strategy & Risk Management",
      tab_ipc_tor: "11. Unit Terms of Reference (TOR)",

      // Category 3: AMS Sub-Groups
      tab_ams_program: "1. AMS Program",
      tab_ams_surveillance: "2. AMS Surveillance",
      tab_ams_prescribing: "2.1 Antibiotic Prescribing & Consumption",
      tab_ams_interventions: "2.2 Stewardship Interventions & Authorizations",
      sub_ams_prescribing: "2.1 Antibiotic Prescribing & Consumption",
      sub_ams_interventions: "2.2 Stewardship Interventions & Authorizations",
      tab_ams_antibiogram: "3. Antibiogram & Resistance Patterns",

      // Sub-Tabs for Vaccination Forms
      sub_exemption: "1. Form HR-02 Medical Fee Exemption Form",
      sub_checklist: "2. Pre-Vaccination Check List (SQE 02.01)",
      sub_history: "3. Vaccination & Test History Form (SQE 02.01)",
      sub_old_vac: "4. Old Vaccination Declaration Form (SQE 02.01)",
      sub_chickenpox: "5. Declaration About Chickenpox (SQE 02.01)",
      sub_covid_flu: "6. Annual Flu & COVID-19 Tracking Record",
      sub_special: "7. Special & High-Risk Occupational Vaccinations Form",
      sub_pep: "8. Post-Exposure Prophylaxis (PEP) & Sharps Injury Record",
      sub_refusal: "9. Seasonal Influenza & Other Vaccine Refusal Forms",
      sub_infection_control: "10. Infection Control (IPC & AMS) Approval Card 🖨️",

      // Common Form Actions & Buttons
      save_btn: "Save Form",
      print_btn: "Print Official Form (1 Page)",
      export_excel_btn: "Export to Excel",
      search_placeholder: "Search employee by name, ID, or department...",
      select_employee: "Select Employee",
      department: "Department",
      job_title: "Job Title",
      employee_id: "Employee ID",
      employee_name: "Employee Name",
      date: "Date",
      status: "Status",
      actions: "Actions",

      // Dashboard KPI & Analytics
      kpi_compliance: "Overall Staff Immunization Compliance",
      kpi_monitored: "Healthcare Workers Monitored",
      kpi_exposures: "Active Body Fluid Exposures",
      kpi_highrisk: "High-Risk Dept Immunity (Oncology/ICU)",
      chart_dept_title: "Departmental Immunization Rates",
      chart_incident_title: "Monthly Body Fluid Incident Trends",
      hepb_breakdown: "Hepatitis B Titer Immunity Breakdown",
      high_responders: "High Responders (>10 mIU/mL)",
      low_titer: "Low Titer (Booster Scheduled)",
      non_responders: "Non-Responders (Under Protocol)",

      // Staff Entry Portal Keys
      portal_header_title: "Staff Registration & Centralized Entry Portal",
      portal_header_sub: "Introduce new staff members, search records, update clinical data, and auto-sync to Google Sheets backup.",
      btn_introduce_new: "➕ Introduce New Staff Member",
      search_title: "🔍 Search Staff Record by Employee ID, National Identifier, Person Number, or Name:",
      search_placeholder_full: "Type ID, Person Number, or Name (e.g., 902148591, EMP-2041, Yousef Khoury)...",
      sec1_title: "👤 Section 1: Employee Demographic Information",
      sec2_title: "🩺 Section 2: Employee Health Status & Pre-Vaccination Check List",
      sec3_title: "🧪 Section 3: Laboratory Test Results (HBsAb, HCV, HIV, PPD, MMR Titers, Varicella)",
      sec4_title: "💉 Section 4: Employee Vaccination (Given Inside Hospital or Historical Outside)",
      sec5_title: "🛡️ Section 5: Special Vaccination for Special Employee Categories",
      sec6_title: "🦠 Section 6: Covid-19 & Influenza Seasonal Vaccination",
      sec7_title: "⚠️ Section 7: Post Exposure Prophylaxis (PEP) & Incident Follow-Up",
      btn_save_sync: "💾 Save / Update Staff Entry & Sync to Google Sheets",
      btn_reset_form: "🧹 Reset Form",
      btn_edit_staff: "✏️ Edit Current Staff Record",
      btn_print_staff: "🖨️ Print Unified 7-Section Staff Record",
      editing_mode: "✏️ Editing Existing Staff Record:",
      new_mode: "➕ Creating New Staff Entry",

      // Language Toggle Button Label
      lang_btn_text: "العربية 🌐"
    },

    ar: {
      // General Hospital Branding
      hospital_name: "مستشفى الأوغستا فكتوريا (المُطلع)",
      hospital_name_ar: "مستشفى الأوغستا فكتوريا (المُطلع)",
      unit_name: "نظام صحة العاملين والتطعيمات المهنية",
      lwf_accreditation: "الاتحاد اللوثري العالمي | نظام معتمد حسب مواصفة ISO 9001:2015",
      years_service: "75 عاماً من الخدمة الطبية والإنسانية",

      // Authentication & Roles
      login_title: "تسجيل الدخول",
      username: "اسم المستخدم",
      password: "كلمة المرور",
      forgot_password: "نسيت كلمة المرور",
      quick_demo_login: "تسجيل دخول سريع للتجربة:",
      login_btn: "دخول",
      logout_btn: "خروج",
      role_admin: "مدير النظام",
      role_specialist: "أخصائي صحة مهنية",
      role_employee: "موظف",
      role_auditor: "مدقق حسابات",
      login_error_empty: "يرجى إدخال اسم المستخدم وكلمة المرور",
      login_error_invalid: "بيانات الدخول غير صحيحة",

      // Top Bar & Navigation Tabs
      portal_title: "برنامج صحة العاملين والتطعيمات المهنية",
      menu_toggle: "القائمة",

      // 4 Main Portal Categories
      cat_occupational_health: "صحة العاملين والتطعيمات",
      cat_ipc: "الوقاية من العدوى ومكافحتها (IPC)",
      cat_ams: "الإشراف على استخدام مضادات الميكروبات (AMS)",
      cat_system_management: "إدارة النظام والتحكم بالتراخيص",

      tab_portal_home: "الصفحة الرئيسية / البوابة المركزية",
      tab_staff_entry: "بوابة تسجيل الكوادر المركزية وإدخال البيانات",
      tab_dashboard: "لوحة الإحصائيات والتقارير",
      tab_vaccination_forms: "نماذج التطعيمات والسجلات الطبية",
      tab_injury_report: "تقرير إصابات وحوادث العمل (SQE 02.01)",
      tab_vaccination_certificate: "شهادة التطعيم والمناعة الرسمية",
      tab_vaccination_reports: "تقارير التطعيمات الشاملة والتصدير",
      tab_system_management: "إدارة النظام وصلاحيات المستخدمين",
      sub_sys_users: "1. ترخيص وصلاحيات الكوادر والمستخدمين",
      sub_sys_dropdowns: "2. سلطة إدارة القوائم المنسدلة",
      sub_sys_database: "3. قاعدة البيانات المركزية وسلة المهملات وسجل التدقيق",

      // IPC & AMS Sub-Tabs
      tab_ipc_isolation: "1. متابعة حالات العزل الطبي (Isolation Status)",
      tab_ipc_hai_followup: "2. نموذج متابعة عدوى المستشفيات (HAI Follow-Up Form)",
      tab_ipc_outbreak: "3. تحقيقات وتقصي الأوبئة (Outbreak Investigations)",
      tab_ipc_moh_notification: "4. نموذج إبلاغ وزارة الصحة للأمراض السارية (MOH Notification)",
      sub_ipc_cre: "4.1 تقرير ترصد بكتيريا CRE Report",
      sub_ipc_cd: "4.2 تقرير الأمراض السارية Communicable Disease Report",
      tab_ipc_surveillance: "5. ترصد مكافحة العدوى (IPC Surveillance)",
      tab_ipc_qip: "6. خطة تحسين الجودة (Quality Improvement Plan)",
      tab_ipc_training: "7. تدريب وتثقيف الكوادر (IPC Training)",
      tab_ipc_audit: "8. قوائم تدقيق النظافة البيئية والسلامة (Environmental Hygiene Audits)",
      sub_ipc_audit_clinical: "8.1 الأقسام الطبية والسريرية (Clinical Departments)",
      sub_ipc_audit_public: "8.2 قسم الخدمات العامة (الصيانة، المطبخ، التدبير المنزلي)",
      sub_ipc_audit_morgue: "8.3 ثلاجة الموتى (Morgue)",
      sub_ipc_audit_hotels: "8.4 سكن وفنادق المرضى (Patient Hotels)",
      tab_ipc_hospital_forms: "9. نماذج مكافحة العدوى بالمستشفى (Hospital Forms)",
      tab_ipc_strategy_risk: "10. الاستراتيجية وإدارة المخاطر (Strategy & Risk Management)",
      tab_ipc_tor: "11. الشروط المرجعية للوحدة (Unit Terms of Reference - TOR)",

      // Category 3: AMS Sub-Groups
      tab_ams_program: "1. برنامج الإشراف على المضادات الحيوية (AMS Program)",
      tab_ams_surveillance: "2. ترصد ورصد المضادات الحيوية (AMS Surveillance)",
      tab_ams_prescribing: "2.1 وصف واستهلاك المضادات الحيوية (Prescribing & Consumption)",
      tab_ams_interventions: "2.2 التدخلات والتراخيص الطبية (Stewardship Interventions)",
      sub_ams_prescribing: "2.1 وصف واستهلاك المضادات الحيوية (Prescribing & Consumption)",
      sub_ams_interventions: "2.2 التدخلات والتراخيص الطبية (Stewardship Interventions)",
      tab_ams_antibiogram: "3. خريطة الحساسية الجرثومية (Antibiogram & Resistance Patterns)",

      // Sub-Tabs for Vaccination Forms
      sub_exemption: "1. نموذج إعفاء من رسوم الفحوصات الطبية",
      sub_checklist: "2. قائمة التقييم قبل التطعيم (Check List)",
      sub_history: "3. سجل التطعيمات والفحوصات الطبية",
      sub_old_vac: "4. سجل التطعيمات السابقة",
      sub_chickenpox: "5. إقرار الإصابة بجدري الماء (Chickenpox)",
      sub_covid_flu: "6. تطعيم كوفيد-19 والانفلونزا الموسمية",
      sub_special: "7. التطعيمات الخاصة والإضافية",
      sub_pep: "8. العلاج الوقائي بعد التعرض (PEP)",
      sub_refusal: "9. إقرار رفض تلقي التطعيمات",
      sub_infection_control: "10. اعتماد وتأكيد قسم مكافحة العدوى 🖨️",

      // Common Form Actions & Buttons
      save_btn: "حفظ النموذج",
      print_btn: "طباعة النموذج الرسمي (صفحة واحدة)",
      export_excel_btn: "تصدير إلى إكسل",
      search_placeholder: "ابحث عن موظف بالاسم، الرقم الوظيفي، أو القسم...",
      select_employee: "اختر الموظف",
      department: "القسم",
      job_title: "المسمى الوظيفي",
      employee_id: "الرقم الوظيفي",
      employee_name: "اسم الموظف",
      date: "التاريخ",
      status: "الحالة",
      actions: "الإجراءات",

      // Dashboard KPI & Analytics
      kpi_compliance: "نسبة التغطية الشاملة للتطعيمات",
      kpi_monitored: "عدد الكوادر الطبية والموظفين",
      kpi_exposures: "حالات التعرض لوخز الإبر والسوائل النشطة",
      kpi_highrisk: "مناعة الأقسام عالية الخطورة (الأورام/العناية)",
      chart_dept_title: "نسب التطعيم حسب الأقسام الطبية",
      chart_incident_title: "مخطط حوادث التعرض للسوائل حسب الشهر",
      hepb_breakdown: "تحليل مستوى مناعة التهاب الكبد ب (Hepatitis B Titer)",
      high_responders: "مناعة عالية عيار ممتازة (>10 mIU/mL)",
      low_titer: "عيار منخفض (جدولة جرعة منشطة)",
      non_responders: "غير مستجيب (تحت البروتوكول الطبي)",

      // Staff Entry Portal Keys
      portal_header_title: "بوابة توظيف وإدخال بيانات الكوادر الطبية",
      portal_header_sub: "إدخال بيانات الموظفين الجدد، البحث في السجلات، تحديث البيانات الطبية، والتزامن التلقائي مع جوجل شيت.",
      btn_introduce_new: "➕ إضافة موظف جديد",
      search_title: "🔍 البحث في سجلات الموظفين بواسطة رقم الهوية، الرقم الوظيفي، أو الاسم:",
      search_placeholder_full: "أدخل رقم الهوية، الرقم الوظيفي، أو اسم الموظف...",
      sec1_title: "👤 القسم 1: البيانات الشخصية والوظيفية للموظف",
      sec2_title: "🩺 القسم 2: الحالة الصحية للموظف وقائمة التقييم قبل التطعيم",
      sec3_title: "🧪 القسم 3: نتائج الفحوصات المخبرية (HBsAb, HCV, HIV, PPD, عيارات MMR, Varicella)",
      sec4_title: "💉 القسم 4: تطعيمات الموظف (داخل المستشفى أو السابقة خارجها)",
      sec5_title: "🛡️ القسم 5: التطعيمات الخاصة للفئات والأقسام الخاصة",
      sec6_title: "🦠 القسم 6: تطعيم الانفلونزا الموسمية وكوفيد-19",
      sec7_title: "⚠️ القسم 7: العلاج الوقائي ومتابعة حوادث التعرض (PEP)",
      btn_save_sync: "💾 حفظ / تحديث بيانات الموظف والتزامن مع جوجل شيت",
      btn_reset_form: "🧹 تفريغ النموذج",
      btn_edit_staff: "✏️ تعديل سجل الموظف الحالي",
      btn_print_staff: "🖨️ طباعة السجل الطبي الموحد للموظف",
      editing_mode: "✏️ جاري تعديل سجل الموظف الحالي:",
      new_mode: "➕ إنشاء سجل موظف جديد",

      // Language Toggle Button Label
      lang_btn_text: "English 🌐"
    }
  };

  let currentLang = localStorage.getItem('avh_lang') || 'en';

  window.i18n = {
    getLang: function() {
      return currentLang;
    },
    isRTL: function() {
      return currentLang === 'ar';
    },
    t: function(key) {
      if (translations[currentLang] && translations[currentLang][key]) {
        return translations[currentLang][key];
      }
      if (translations['en'] && translations['en'][key]) {
        return translations['en'][key];
      }
      return key;
    },
    setLanguage: function(lang) {
      if (lang !== 'en' && lang !== 'ar') return;
      currentLang = lang;
      localStorage.setItem('avh_lang', lang);
      document.documentElement.setAttribute('lang', lang);
      document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
      
      // Re-initialize application UI
      if (typeof initApp === 'function') {
        initApp();
      }
    },
    toggleLanguage: function() {
      const nextLang = currentLang === 'en' ? 'ar' : 'en';
      this.setLanguage(nextLang);
    }
  };

  // Initialize document direction immediately on script load
  document.documentElement.setAttribute('lang', currentLang);
  document.documentElement.setAttribute('dir', currentLang === 'ar' ? 'rtl' : 'ltr');
})();
